// Copyright 2012 Google Inc. All rights reserved.
(function(w, g) {
    w[g] = w[g] || {};
    w[g].e = function(s) {
        return eval(s);
    };
})(window, 'google_tag_manager');
(function() {

    var data = {
        "resource": {
            "version": "296",

            "macros": [{
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "info.targetType"
            }, {
                "function": "__e"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "source"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "environment"
            }, {
                "function": "__u",
                "vtp_component": "HOST",
                "vtp_enableMultiQueryKeys": false,
                "vtp_enableIgnoreEmptyQueryParam": false
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "info.action"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "data.current.hostname"
            }, {
                "function": "__u",
                "vtp_component": "PATH",
                "vtp_enableMultiQueryKeys": false,
                "vtp_enableIgnoreEmptyQueryParam": false
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "info.pageType"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "contentGroup"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "info.data.userid"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "info.data.userid"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "userid"
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){var a;", ["escape", ["macro", 10], 8, 16], "?a=", ["escape", ["macro", 10], 8, 16], ":", ["escape", ["macro", 11], 8, 16], "?a=", ["escape", ["macro", 11], 8, 16], ":", ["escape", ["macro", 12], 8, 16], "\u0026\u0026(a=", ["escape", ["macro", 12], 8, 16], ");if(a)return a=a.toString(),a=sha256(a)})();"]
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "data.first.href"
            }, {
                "function": "__u",
                "vtp_component": "URL",
                "vtp_enableMultiQueryKeys": false,
                "vtp_enableIgnoreEmptyQueryParam": false
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "data.first.search.is_seller"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "data.first.search.gclid"
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){return function(b,a){var c=b.split(\"?\");if(2\u003C=c.length){b=encodeURIComponent(a)+\"\\x3d\";a=c[1].split(\/[\u0026;]\/g);for(var d=a.length;0\u003Cd--;)-1!==a[d].lastIndexOf(b,0)\u0026\u0026a.splice(d,1);b=c[0]+\"?\"+a.join(\"\\x26\")}return b}})();"]
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "data.first.search.dclid"
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){var a=", ["escape", ["macro", 14], 8, 16], "||", ["escape", ["macro", 15], 8, 16], ";\"true\"==", ["escape", ["macro", 16], 8, 16], "\u0026\u0026", ["escape", ["macro", 17], 8, 16], "\u0026\u0026(a=", ["escape", ["macro", 18], 8, 16], "(a,\"gclid\"));\"true\"==", ["escape", ["macro", 16], 8, 16], "\u0026\u0026", ["escape", ["macro", 19], 8, 16], "\u0026\u0026(a=", ["escape", ["macro", 18], 8, 16], "(a,\"dclid\"));return a})();"]
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){var e=[\"email\",\"loginKey\"],a=", ["escape", ["macro", 20], 8, 16], ";-1!==a.indexOf(\"undefined\")\u0026\u0026(a=a.replace(\"undefined\",\"\"));var b=document.createElement(\"a\");b.href=a;if(b.search){a=b.search.replace(\"?\",\"\\x26\");var c;for(c=0;c\u003Ce.length;c++){var d=e[c];d=new RegExp(\"\\x26\"+d+\"\\x3d[^\\x26]*(\\x26|$)\",\"gi\");a=a.replace(d,\"\\x26\")}\"\\x26\"===a[0]?a=a.slice(1):\"\";b.search=a}return b.href})();"]
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "data.current.pathname"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "data.current.href"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "data.current.origin"
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){var a=", ["escape", ["macro", 23], 8, 16], ",b=", ["escape", ["macro", 24], 8, 16], "+", ["escape", ["macro", 22], 8, 16], ";return a=a.split(b)[1]||\"\"})();"]
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){var a=", ["escape", ["macro", 22], 8, 16], "||", ["escape", ["macro", 7], 8, 16], ";a+=", ["escape", ["macro", 25], 8, 16], ";\"true\"==", ["escape", ["macro", 16], 8, 16], "\u0026\u0026", ["escape", ["macro", 17], 8, 16], "\u0026\u0026(a=", ["escape", ["macro", 18], 8, 16], "(a,\"gclid\"));\"true\"==", ["escape", ["macro", 16], 8, 16], "\u0026\u0026", ["escape", ["macro", 19], 8, 16], "\u0026\u0026(a=", ["escape", ["macro", 18], 8, 16], "(a,\"dclid\"));return a})();"]
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){var c=[\"email\",\"loginKey\"],a=", ["escape", ["macro", 26], 8, 16], ";if(a){-1!==a.indexOf(\"undefined\")\u0026\u0026(a=a.replace(\"undefined\",\"\"));a=a.replace(\"?\",\"\\x26\");var b;for(b=0;b\u003Cc.length;b++){var d=c[b];d=new RegExp(\"\\x26\"+d+\"\\x3d[^\\x26]*(\\x26|$)\",\"gi\");a=a.replace(d,\"\\x26\")}\"\\x26\"===a[0]?a=a.slice(1):\"\";a=a.replace(\"\\x26\",\"?\")}return c=a})();"]
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "userGroup"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "data.first.search.gbraid"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "data.first.search.wbraid"
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){if(", ["escape", ["macro", 17], 8, 16], ")return ", ["escape", ["macro", 17], 8, 16], ";if(", ["escape", ["macro", 19], 8, 16], ")return ", ["escape", ["macro", 19], 8, 16], ";if(", ["escape", ["macro", 29], 8, 16], ")return ", ["escape", ["macro", 29], 8, 16], ";if(", ["escape", ["macro", 30], 8, 16], ")return ", ["escape", ["macro", 30], 8, 16], "})();"]
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){if(", ["escape", ["macro", 17], 8, 16], ")return\"gclid\";if(", ["escape", ["macro", 19], 8, 16], ")return\"dclid\";if(", ["escape", ["macro", 29], 8, 16], ")return\"gbraid\";if(", ["escape", ["macro", 30], 8, 16], ")return\"wbraid\"})();"]
            }, {
                "function": "__remm",
                "vtp_setDefaultValue": false,
                "vtp_input": ["macro", 4],
                "vtp_fullMatch": false,
                "vtp_replaceAfterMatch": false,
                "vtp_ignoreCase": true,
                "vtp_map": ["list", ["map", "key", "shopee.co.id", "value", "UA-61904553-8"],
                    ["map", "key", "shopee.sg", "value", "UA-61921742-7"],
                    ["map", "key", "shopee.com.my", "value", "UA-61915055-6"],
                    ["map", "key", "shopee.tw", "value", "UA-61915057-6"],
                    ["map", "key", "shopee.co.th", "value", "UA-61914165-6"],
                    ["map", "key", "shopee.vn", "value", "UA-61914164-6"],
                    ["map", "key", "shopee.ph", "value", "UA-61918643-6"],
                    ["map", "key", "shopee.com.br", "value", "UA-149843394-1"],
                    ["map", "key", "shopee.com.mx", "value", "UA-188791374-1"],
                    ["map", "key", "shopee.com.co", "value", "UA-197472871-1"],
                    ["map", "key", "shopee.cl", "value", "UA-197488217-1"],
                    ["map", "key", "shopee.pl", "value", "UA-205013480-1"],
                    ["map", "key", "shopee.es", "value", "UA-207271611-1"],
                    ["map", "key", "shopee.fr", "value", "UA-207288375-1"],
                    ["map", "key", "shopee.in", "value", "UA-207303638-1"]
                ]
            }, {
                "function": "__gas",
                "vtp_useDebugVersion": false,
                "vtp_useHashAutoLink": false,
                "vtp_contentGroup": ["list", ["map", "index", "1", "group", ["macro", 8]],
                    ["map", "index", "2", "group", ["macro", 9]]
                ],
                "vtp_decorateFormsAutoLink": false,
                "vtp_cookieDomain": "auto",
                "vtp_doubleClick": true,
                "vtp_setTrackerName": true,
                "vtp_fieldsToSet": ["list", ["map", "fieldName", "allowLinker", "value", "true"],
                    ["map", "fieldName", "useAmpClientId", "value", "true"],
                    ["map", "fieldName", "userId", "value", ["macro", 13]],
                    ["map", "fieldName", "location", "value", ["macro", 21]],
                    ["map", "fieldName", "page", "value", ["macro", 27]]
                ],
                "vtp_trackerName": "",
                "vtp_enableLinkId": true,
                "vtp_dimension": ["list", ["map", "index", "3", "dimension", ["macro", 13]],
                    ["map", "index", "2", "dimension", ["macro", 28]],
                    ["map", "index", "4", "dimension", ["macro", 31]],
                    ["map", "index", "6", "dimension", ["macro", 32]]
                ],
                "vtp_enableEcommerce": false,
                "vtp_trackingId": ["macro", 33],
                "vtp_enableRecaptchaOption": false,
                "vtp_enableUaRlsa": false,
                "vtp_enableUseInternalVersion": false,
                "vtp_enableGA4Schema": false
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": true,
                "vtp_defaultValue": "false",
                "vtp_name": "info.initial"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "country"
            }, {
                "function": "__remm",
                "vtp_setDefaultValue": false,
                "vtp_input": ["macro", 4],
                "vtp_fullMatch": false,
                "vtp_replaceAfterMatch": false,
                "vtp_ignoreCase": true,
                "vtp_map": ["list", ["map", "key", "shopee.tw", "value", "34651"],
                    ["map", "key", "shopee.vn", "value", "34657"],
                    ["map", "key", "shopee.co.id", "value", "34652"],
                    ["map", "key", "shopee.com.my", "value", "32773"],
                    ["map", "key", "shopee.ph", "value", "34655"],
                    ["map", "key", "shopee.co.th", "value", "34654"],
                    ["map", "key", "shopee.sg", "value", "32772"]
                ]
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": true,
                "vtp_defaultValue": "",
                "vtp_name": "info.impressions.0.targetData.accountInfo.email"
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){return 767\u003E=window.innerWidth?\"m\":980\u003C=window.innerWidth?\"d\":\"t\"})();"]
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "info.impressions.0.targetData.cart.items"
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){var a=", ["escape", ["macro", 40], 8, 16], "||[],c=[],b;for(b in a)c.push({id:a[b].itemid,price:parseFloat(a[b].price)\/1E5,quantity:a[b].quantity});return c})();"]
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "info.impressions"
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){var a=[];a=", ["escape", ["macro", 42], 8, 16], "||[];return a=a.map(function(a){return a.targetData.item.itemid})})();"]
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "info.impressions.0.targetData.item.itemid"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "info.data.response.checkoutid"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "info.data.orders"
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){for(var b=", ["escape", ["macro", 46], 8, 16], ",d=[],a=0;a\u003Cb.length;a++)for(var c=0;c\u003Cb[a].items.length;c++)d.push({id:\"\"+b[a].items[c].itemid,item_price:b[a].items[c].price\/1E5,quantity:b[a].items[c].quantity});return d})();"]
            }, {
                "function": "__remm",
                "vtp_setDefaultValue": false,
                "vtp_input": ["macro", 4],
                "vtp_fullMatch": false,
                "vtp_replaceAfterMatch": false,
                "vtp_ignoreCase": true,
                "vtp_map": ["list", ["map", "key", "shopee.sg", "value", "SGD"],
                    ["map", "key", "shopee.com.my", "value", "MYR"],
                    ["map", "key", "shopee.co.th", "value", "THB"],
                    ["map", "key", "shopee.tw", "value", "TWD"],
                    ["map", "key", "shopee.co.id", "value", "IDR"],
                    ["map", "key", "shopee.vn", "value", "VND"],
                    ["map", "key", "shopee.ph", "value", "PHP"],
                    ["map", "key", "shopee.com.br", "value", "BRL"],
                    ["map", "key", "shopee.com.mx", "value", "MXN"],
                    ["map", "key", "shopee.com.co", "value", "COP"],
                    ["map", "key", "shopee.cl", "value", "CLP"],
                    ["map", "key", "shopee.pl", "value", "PLN"],
                    ["map", "key", "shopee.es", "value", "EUR"],
                    ["map", "key", "shopee.fr", "value", "EUR"],
                    ["map", "key", "shopee.in", "value", "INR"]
                ]
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "info.data.name"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "info.data.itemId"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "info.data.price"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "info.data.quantity"
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){var a=", ["escape", ["macro", 51], 8, 16], "*", ["escape", ["macro", 52], 8, 16], "\/1E5;return a})();"]
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "info.data.catId"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "info.data.modelId"
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){var a={ecommerce:{currencyCode:\"", ["escape", ["macro", 48], 7], "\",add:{products:[{name:\"", ["escape", ["macro", 49], 7], "\",id:\"", ["escape", ["macro", 50], 7], "\",price:\"", ["escape", ["macro", 53], 7], "\",category:\"", ["escape", ["macro", 54], 7], "\",variant:\"", ["escape", ["macro", 55], 7], "\",quantity:", ["escape", ["macro", 52], 8, 16], "}]}}};return a})();"]
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "info.operation"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "info.data.register_channel"
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){for(var b=", ["escape", ["macro", 46], 8, 16], ",c=0,a=0;a\u003Cb.length;a++)c+=b[a].total_without_shipping;return c\/1E5})();"]
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){for(var a=", ["escape", ["macro", 46], 8, 16], ",d=0,e=[],b=0;b\u003Ca.length;b++){for(var c=0;c\u003Ca[b].items.length;c++)try{var f=void 0===a[b].items[c].categories?\"\":a[b].items[c].categories[0].catids.join(\".\");e.push({id:a[b].items[c].itemid,price:a[b].items[c].price\/1E5,name:a[b].items[c].name,quantity:a[b].items[c].quantity,category:f})}catch(g){console.warn(g)}d+=a[b].shipping_fee}a={ecommerce:{purchase:{actionField:{id:\"", ["escape", ["macro", 45], 7], "\",revenue:\"", ["escape", ["macro", 59], 7], "\",shipping:d\/1E5},products:e}}};\nstr=JSON.stringify(a);return a})();"]
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "info.data.response.orderids"
            }, {
                "function": "__j",
                "vtp_name": "document.title"
            }, {
                "function": "__k",
                "vtp_decodeCookie": true,
                "vtp_name": "_med"
            }, {
                "function": "__gas",
                "vtp_useDebugVersion": false,
                "vtp_useHashAutoLink": false,
                "vtp_contentGroup": ["list", ["map", "index", "1", "group", ["macro", 8]]],
                "vtp_decorateFormsAutoLink": false,
                "vtp_cookieDomain": "auto",
                "vtp_useEcommerceDataLayer": true,
                "vtp_doubleClick": true,
                "vtp_setTrackerName": false,
                "vtp_fieldsToSet": ["list", ["map", "fieldName", "allowLinker", "value", "true"],
                    ["map", "fieldName", "useAmpClientId", "value", "true"],
                    ["map", "fieldName", "userId", "value", ["macro", 13]],
                    ["map", "fieldName", "location", "value", ["macro", 21]],
                    ["map", "fieldName", "page", "value", ["macro", 27]]
                ],
                "vtp_enableLinkId": true,
                "vtp_dimension": ["list", ["map", "index", "1", "dimension", ["macro", 12]],
                    ["map", "index", "3", "dimension", ["macro", 13]],
                    ["map", "index", "2", "dimension", ["macro", 28]],
                    ["map", "index", "4", "dimension", ["macro", 31]],
                    ["map", "index", "6", "dimension", ["macro", 32]]
                ],
                "vtp_enableEcommerce": true,
                "vtp_trackingId": "UA-125099498-1",
                "vtp_enableRecaptchaOption": false,
                "vtp_enableUaRlsa": false,
                "vtp_enableUseInternalVersion": false,
                "vtp_ecommerceIsEnabled": true,
                "vtp_enableGA4Schema": false
            }, {
                "function": "__remm",
                "vtp_setDefaultValue": false,
                "vtp_input": ["macro", 4],
                "vtp_fullMatch": false,
                "vtp_replaceAfterMatch": false,
                "vtp_ignoreCase": true,
                "vtp_map": ["list", ["map", "key", "shopee.co.id", "value", "UA-61904553-8"],
                    ["map", "key", "shopee.sg", "value", "UA-61921742-7"],
                    ["map", "key", "shopee.com.my", "value", "UA-61915055-6"],
                    ["map", "key", "shopee.tw", "value", "UA-61915057-6"],
                    ["map", "key", "shopee.co.th", "value", "UA-61914165-6"],
                    ["map", "key", "shopee.vn", "value", "UA-61914164-6"],
                    ["map", "key", "shopee.ph", "value", "UA-61918643-6"],
                    ["map", "key", "shopee.com.co", "value", "UA-197472871-1"],
                    ["map", "key", "shopee.com.br", "value", "UA-149843394-1"],
                    ["map", "key", "shopee.com.mx", "value", "UA-188791374-1"],
                    ["map", "key", "shopee.com", "value", "UA-132684032-1"],
                    ["map", "key", "shopee.cl", "value", "UA-197488217-1"],
                    ["map", "key", "shopee.pl", "value", "UA-205013480-1"],
                    ["map", "key", "shopee.es", "value", "UA-207271611-1"],
                    ["map", "key", "shopee.fr", "value", "UA-207288375-1"],
                    ["map", "key", "shopee.in", "value", "UA-207303638-1"]
                ]
            }, {
                "function": "__gas",
                "vtp_cookieDomain": "auto",
                "vtp_doubleClick": true,
                "vtp_setTrackerName": true,
                "vtp_useDebugVersion": false,
                "vtp_fieldsToSet": ["list", ["map", "fieldName", "allowLinker", "value", "true"],
                    ["map", "fieldName", "useAmpClientId", "value", "true"],
                    ["map", "fieldName", "userId", "value", ["macro", 13]],
                    ["map", "fieldName", "location", "value", ["macro", 21]],
                    ["map", "fieldName", "page", "value", ["macro", 27]]
                ],
                "vtp_trackerName": "",
                "vtp_useHashAutoLink": false,
                "vtp_decorateFormsAutoLink": false,
                "vtp_enableLinkId": true,
                "vtp_dimension": ["list", ["map", "index", "3", "dimension", ["macro", 13]],
                    ["map", "index", "2", "dimension", ["macro", 28]],
                    ["map", "index", "4", "dimension", ["macro", 31]],
                    ["map", "index", "6", "dimension", ["macro", 32]]
                ],
                "vtp_enableEcommerce": false,
                "vtp_trackingId": ["macro", 65],
                "vtp_enableRecaptchaOption": false,
                "vtp_enableUaRlsa": false,
                "vtp_enableUseInternalVersion": false,
                "vtp_enableGA4Schema": false
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "info.data.name"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "info.data.itemid"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "info.data.price"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "info.data.quantity"
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){var a=", ["escape", ["macro", 69], 8, 16], "*", ["escape", ["macro", 70], 8, 16], "\/1E5;return a})();"]
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "info.data.catid_be"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "info.data.modelId"
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){var a={ecommerce:{remove:{products:[{name:\"", ["escape", ["macro", 67], 7], "\",id:\"", ["escape", ["macro", 68], 7], "\",price:", ["escape", ["macro", 71], 8, 16], ",category:\"", ["escape", ["macro", 72], 7], "\",variant:\"", ["escape", ["macro", 73], 7], "\",quantity:", ["escape", ["macro", 70], 8, 16], "}]}}};return a})();"]
            }, {
                "function": "__v",
                "vtp_name": "gtm.historyChangeSource",
                "vtp_dataLayerVersion": 1
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "info.data.type"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "info.data.login_option"
            }, {
                "function": "__remm",
                "vtp_setDefaultValue": false,
                "vtp_input": ["macro", 4],
                "vtp_fullMatch": false,
                "vtp_replaceAfterMatch": false,
                "vtp_ignoreCase": true,
                "vtp_map": ["list", ["map", "key", "shopee.co.id", "value", "UA-61904553-9"],
                    ["map", "key", "shopee.sg", "value", "UA-61921742-12"],
                    ["map", "key", "shopee.com.my", "value", "UA-61915055-10"],
                    ["map", "key", "shopee.tw", "value", "UA-61915057-10"],
                    ["map", "key", "shopee.co.th", "value", "UA-61914165-10"],
                    ["map", "key", "(giaitri|nhasach).shopee.vn", "value", "UA-61914164-10"],
                    ["map", "key", "shopee.ph", "value", "UA-61918643-10"]
                ]
            }, {
                "function": "__gas",
                "vtp_cookieDomain": "auto",
                "vtp_doubleClick": true,
                "vtp_setTrackerName": true,
                "vtp_useDebugVersion": false,
                "vtp_fieldsToSet": ["list", ["map", "fieldName", "allowLinker", "value", "true"],
                    ["map", "fieldName", "useAmpClientId", "value", "true"],
                    ["map", "fieldName", "userId", "value", ["macro", 13]],
                    ["map", "fieldName", "location", "value", ["macro", 21]],
                    ["map", "fieldName", "page", "value", ["macro", 27]]
                ],
                "vtp_trackerName": "",
                "vtp_useHashAutoLink": false,
                "vtp_decorateFormsAutoLink": false,
                "vtp_enableLinkId": true,
                "vtp_dimension": ["list", ["map", "index", "3", "dimension", ["macro", 13]],
                    ["map", "index", "2", "dimension", ["macro", 28]],
                    ["map", "index", "4", "dimension", ["macro", 31]],
                    ["map", "index", "6", "dimension", ["macro", 32]]
                ],
                "vtp_enableEcommerce": false,
                "vtp_trackingId": ["macro", 78],
                "vtp_enableRecaptchaOption": false,
                "vtp_enableUaRlsa": false,
                "vtp_enableUseInternalVersion": false,
                "vtp_enableGA4Schema": false
            }, {
                "function": "__r"
            }, {
                "function": "__u",
                "vtp_enableMultiQueryKeys": false,
                "vtp_enableIgnoreEmptyQueryParam": false
            }, {
                "function": "__u",
                "vtp_component": "QUERY",
                "vtp_queryKey": "keyword",
                "vtp_enableMultiQueryKeys": false,
                "vtp_enableIgnoreEmptyQueryParam": false
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){var a=", ["escape", ["macro", 42], 8, 16], ";return a.map(function(a){return a.targetData.item.itemid})})();"]
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){var e=[\"email\",\"loginKey\"],a=location.pathname+location.search,b=document.createElement(\"a\"),d;b.href=a;if(b.search){a=\"\\x26\"+b.search.replace(\"?\",\"\")+\"\\x26\";for(d=0;d\u003Ce.length;d++){var c=e[d];c=a.indexOf(\"\\x26\"+c+\"\\x3d\");if(-1\u003Cc){var f=a.indexOf(\"\\x26\",c+1);a=a.slice(0,c)+a.slice(f,a.length)}}b.search=a.slice(1,a.length-1)}return b.href.replace(location.origin,\"\")})();"]
            }, {
                "function": "__e"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "ecommerce.purchase.actionField.id"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "ecommerce.purchase.actionField.id"
            }, {
                "function": "__remm",
                "vtp_setDefaultValue": false,
                "vtp_input": ["macro", 4],
                "vtp_fullMatch": false,
                "vtp_replaceAfterMatch": false,
                "vtp_ignoreCase": true,
                "vtp_map": ["list", ["map", "key", "shopee.co.id", "value", "UA-61904553-14"],
                    ["map", "key", "shopee.sg", "value", "UA-61921742-14"],
                    ["map", "key", "shopee.com.my", "value", "UA-61915055-12"],
                    ["map", "key", "shopee.tw", "value", "UA-61915057-13"],
                    ["map", "key", "shopee.co.th", "value", "UA-61914165-12"],
                    ["map", "key", "shopee.vn", "value", "UA-61914164-12"],
                    ["map", "key", "shopee.ph", "value", "UA-61918643-12"],
                    ["map", "key", "shopee.com.br", "value", "UA-149843394-3"],
                    ["map", "key", "shopee.cn", "value", "UA-132390336-4"]
                ]
            }, {
                "function": "__gas",
                "vtp_cookieDomain": "auto",
                "vtp_doubleClick": true,
                "vtp_setTrackerName": true,
                "vtp_useDebugVersion": false,
                "vtp_fieldsToSet": ["list", ["map", "fieldName", "allowLinker", "value", "true"],
                    ["map", "fieldName", "userId", "value", ["macro", 13]],
                    ["map", "fieldName", "location", "value", ["macro", 21]],
                    ["map", "fieldName", "page", "value", ["macro", 27]]
                ],
                "vtp_trackerName": "",
                "vtp_useHashAutoLink": false,
                "vtp_decorateFormsAutoLink": false,
                "vtp_enableLinkId": true,
                "vtp_dimension": ["list", ["map", "index", "3", "dimension", ["macro", 13]],
                    ["map", "index", "4", "dimension", ["macro", 31]],
                    ["map", "index", "6", "dimension", ["macro", 32]]
                ],
                "vtp_enableEcommerce": false,
                "vtp_trackingId": ["macro", 88],
                "vtp_enableRecaptchaOption": false,
                "vtp_enableUaRlsa": false,
                "vtp_enableUseInternalVersion": false,
                "vtp_enableGA4Schema": false
            }, {
                "function": "__v",
                "vtp_name": "gtm.elementClasses",
                "vtp_dataLayerVersion": 1
            }, {
                "function": "__aev",
                "vtp_varType": "TEXT"
            }, {
                "function": "__remm",
                "vtp_setDefaultValue": false,
                "vtp_input": ["macro", 4],
                "vtp_fullMatch": false,
                "vtp_replaceAfterMatch": false,
                "vtp_ignoreCase": true,
                "vtp_map": ["list", ["map", "key", "shopee.co.id", "value", "G-SW6D8G0HXK"],
                    ["map", "key", "shopee.sg", "value", "G-4572B3WZ33"],
                    ["map", "key", "shopee.com.my", "value", "G-H06K3499BD"],
                    ["map", "key", "shopee.tw", "value", "G-RPSBE3TQZZ"],
                    ["map", "key", "shopee.co.th", "value", "G-L4QXS6R7YG"],
                    ["map", "key", "shopee.vn", "value", "G-M32T05RVZT"],
                    ["map", "key", "shopee.ph", "value", "G-CB0044GVTM"],
                    ["map", "key", "shopee.com.br", "value", "G-0GS478VKB8"],
                    ["map", "key", "shopee.com.mx", "value", "G-FYC06KL06Z"],
                    ["map", "key", "shopee.com.co", "value", ""],
                    ["map", "key", "shopee.cl", "value", ""],
                    ["map", "key", "shopee.pl", "value", ""],
                    ["map", "key", "shopee.es", "value", ""],
                    ["map", "key", "shopee.fr", "value", ""],
                    ["map", "key", "shopee.in", "value", ""]
                ]
            }, {
                "function": "__remm",
                "vtp_setDefaultValue": false,
                "vtp_input": ["macro", 15],
                "vtp_fullMatch": false,
                "vtp_replaceAfterMatch": false,
                "vtp_ignoreCase": true,
                "vtp_map": ["list", ["map", "key", "https:\/\/seller.shopee.co.id\/edu\/", "value", "UA-61904553-16"],
                    ["map", "key", "https:\/\/seller.shopee.sg\/edu\/", "value", "UA-61921742-15"],
                    ["map", "key", "https:\/\/seller.shopee.com.my\/edu\/", "value", "UA-61915055-13"],
                    ["map", "key", "https:\/\/seller.shopee.tw\/edu\/", "value", "UA-61915057-14"],
                    ["map", "key", "https:\/\/seller.shopee.co.th\/edu\/", "value", "UA-61914165-13"],
                    ["map", "key", "https:\/\/banhang.shopee.vn\/edu\/", "value", "UA-61914164-13"],
                    ["map", "key", "https:\/\/seller.shopee.ph\/edu\/", "value", "UA-61918643-13"],
                    ["map", "key", "https:\/\/seller.shopee.com.br\/edu\/", "value", "UA-149843394-4"],
                    ["map", "key", "https:\/\/seller.shopee.com.mx\/edu\/", "value", "UA-188791374-3"],
                    ["map", "key", "https:\/\/seller.shopee.pl\/edu\/", "value", "UA-205013480-3"]
                ]
            }, {
                "function": "__gas",
                "vtp_cookieDomain": "auto",
                "vtp_doubleClick": true,
                "vtp_setTrackerName": true,
                "vtp_useDebugVersion": false,
                "vtp_fieldsToSet": ["list", ["map", "fieldName", "allowLinker", "value", "true"],
                    ["map", "fieldName", "userId", "value", ["macro", 13]],
                    ["map", "fieldName", "location", "value", ["macro", 21]],
                    ["map", "fieldName", "page", "value", ["macro", 27]]
                ],
                "vtp_trackerName": "",
                "vtp_useHashAutoLink": false,
                "vtp_decorateFormsAutoLink": false,
                "vtp_enableLinkId": true,
                "vtp_dimension": ["list", ["map", "index", "3", "dimension", ["macro", 13]],
                    ["map", "index", "4", "dimension", ["macro", 31]],
                    ["map", "index", "6", "dimension", ["macro", 32]]
                ],
                "vtp_enableEcommerce": false,
                "vtp_trackingId": ["macro", 93],
                "vtp_enableRecaptchaOption": false,
                "vtp_enableUaRlsa": false,
                "vtp_enableUseInternalVersion": false,
                "vtp_enableGA4Schema": false
            }, {
                "function": "__v",
                "vtp_name": "gtm.elementUrl",
                "vtp_dataLayerVersion": 1
            }, {
                "function": "__v",
                "vtp_name": "gtm.triggers",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": true,
                "vtp_defaultValue": ""
            }, {
                "function": "__t"
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){if(\"pc\"===", ["escape", ["macro", 2], 8, 16], ")return\"pc\";if(\"rweb\"===", ["escape", ["macro", 2], 8, 16], "||\"rweb_android\"===", ["escape", ["macro", 2], 8, 16], "||\"mweb\"===", ["escape", ["macro", 2], 8, 16], ")return\"mobile\"})();"]
            }, {
                "function": "__cid"
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){return google_tag_manager[", ["escape", ["macro", 99], 8, 16], "].dataLayer})();"]
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "info.impressions.0.targetData.item.catid"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "info.pageParams.subcategory"
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){return void 0===", ["escape", ["macro", 102], 8, 16], "?\"cat1\":\"cat2\"})();"]
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "info.pageParams.categoryId"
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){var a=", ["escape", ["macro", 51], 8, 16], "\/1E5;return a})();"]
            }, {
                "function": "__remm",
                "vtp_setDefaultValue": false,
                "vtp_input": ["macro", 4],
                "vtp_fullMatch": false,
                "vtp_replaceAfterMatch": false,
                "vtp_ignoreCase": true,
                "vtp_map": ["list", ["map", "key", "shopee.sg", "value", "139835196351422"],
                    ["map", "key", "shopee.com.my", "value", "757894527666013"],
                    ["map", "key", "shopee.co.th", "value", "905703166183408"],
                    ["map", "key", "shopee.tw", "value", "503280033161781"],
                    ["map", "key", "shopee.co.id", "value", "466924370133774"],
                    ["map", "key", "shopee.vn", "value", "1457130904612161"],
                    ["map", "key", "shopee.ph", "value", "1478059392491608"],
                    ["map", "key", "shopee.com.br", "value", "703307166810792"],
                    ["map", "key", "shopee.com.mx", "value", "850328915514180"],
                    ["map", "key", "shopee.com.co", "value", "248175970416870"],
                    ["map", "key", "shopee.cl", "value", "471906773873929"],
                    ["map", "key", "shopee.pl", "value", "1001237330729003"],
                    ["map", "key", "shopee.es", "value", "1227997144360328"],
                    ["map", "key", "shopee.fr", "value", "617624929239053"],
                    ["map", "key", "shopee.in", "value", "425973298946645"]
                ]
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "info.impressions.0.targetData.item.price"
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){var a=", ["escape", ["macro", 107], 8, 16], "\/1E5;return a})();"]
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){for(var b=", ["escape", ["macro", 46], 8, 16], ",d=[],a=0;a\u003Cb.length;a++)for(var c=0;c\u003Cb[a].items.length;c++)d.push(b[a].items[c].itemid);return d.join(\",\")})();"]
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){for(var b=", ["escape", ["macro", 46], 8, 16], ",d=[],a=0;a\u003Cb.length;a++)for(var c=0;c\u003Cb[a].items.length;c++)d.push({id:\"\"+b[a].items[c].itemid,item_price:b[a].items[c].price\/1E5,quantity:b[a].items[c].quantity,category:b[a].items[c].categories[0].catids.join(\"\\x3e\")});return d})();"]
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "info.pageParams.categoryName"
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){var a={cookieName:\"_med\",cookieTime:30,keyToGet:\"utm_medium\",keyToSearch:{gclid:\"cpc\"},shopee_refer:\"^((http(s?):\/\/)(([a-z0-9_]+.)?)(shopee.(sg|com.my|co.th|tw|co.id|vn|ph|com.br|com.mx|com.co|cl)\/))\",path:\"\/\",domain:\".\"+location.hostname.replace(\/^www\\.\/i,\"\")};return a})();"]
            }, {
                "function": "__f",
                "vtp_component": "URL"
            }, {
                "function": "__remm",
                "vtp_setDefaultValue": false,
                "vtp_input": ["macro", 4],
                "vtp_fullMatch": false,
                "vtp_replaceAfterMatch": false,
                "vtp_ignoreCase": true,
                "vtp_map": ["list", ["map", "key", "shopee.vn", "value", "ICay2JfBmbeRc1R5Enp1"],
                    ["map", "key", "shopee.co.id", "value", "IfdkwXB0UU0fVf5tq0DM"],
                    ["map", "key", "shopee.com.my", "value", "zlDYA9jJjHq1nyHyCLaU"],
                    ["map", "key", "shopee.ph", "value", "l7fVkOg4vYLmM3fayfyy"],
                    ["map", "key", "shopee.co.th", "value", "zXiY0VQ8H0VLkoIzoC80"],
                    ["map", "key", "shopee.sg", "value", "bQSfrGqH6d5VMoTaldIA"]
                ]
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){var a=", ["escape", ["macro", 40], 8, 16], "||[],b=[],c;for(c in a)b.push(a[c].itemid);return b.join(\",\")})();"]
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){for(var b=", ["escape", ["macro", 46], 8, 16], ",c,a=0;a\u003Cb.length;a++)c=b[a].shop.shopid;return c})();"]
            }, {
                "function": "__remm",
                "vtp_setDefaultValue": false,
                "vtp_input": ["macro", 116],
                "vtp_fullMatch": true,
                "vtp_replaceAfterMatch": true,
                "vtp_ignoreCase": true,
                "vtp_map": ["list", ["map", "key", "58418206|16621457", "value", "AW-692053728"],
                    ["map", "key", "40867978", "value", "AW-608738266"],
                    ["map", "key", "119485441", "value", "AW-611398152"],
                    ["map", "key", "75422406", "value", "AW-573532228"],
                    ["map", "key", "53892420", "value", "AW-671893767"],
                    ["map", "key", "37251933", "value", "AW-627492082"],
                    ["map", "key", "29668384", "value", "AW-620288715"],
                    ["map", "key", "29667634", "value", "AW-603702153"],
                    ["map", "key", "29668843", "value", "AW-408024625"],
                    ["map", "key", "91799978", "value", "AW-443061445"],
                    ["map", "key", "39401693", "value", "AW-389061488"],
                    ["map", "key", "55027948", "value", "AW-388991082"],
                    ["map", "key", "51678844", "value", "AW-389059076"],
                    ["map", "key", "59860978", "value", "AW-618568444"],
                    ["map", "key", "83276818", "value", "AW-415164151"],
                    ["map", "key", "43416591", "value", "AW-388561066"],
                    ["map", "key", "26947756|111138057", "value", "AW-679064000"],
                    ["map", "key", "269296276", "value", "AW-611139237"],
                    ["map", "key", "40492624", "value", "AW-608737966"],
                    ["map", "key", "45237836", "value", "AW-561149564"],
                    ["map", "key", "29990515", "value", "AW-585668020"],
                    ["map", "key", "241142788", "value", "AW-393240317"],
                    ["map", "key", "76176908", "value", "AW-602187227"],
                    ["map", "key", "327041081", "value", "AW-368278428"],
                    ["map", "key", "254644909", "value", "AW-674528537"],
                    ["map", "key", "272467617", "value", "AW-440337508"],
                    ["map", "key", "176534566", "value", "AW-610652310"],
                    ["map", "key", "98316282", "value", "AW-626542429"],
                    ["map", "key", "55788683", "value", "AW-643752044"],
                    ["map", "key", "62579622", "value", "AW-610719491"],
                    ["map", "key", "109598751", "value", "AW-623301224"],
                    ["map", "key", "35357809", "value", "AW-376335887"],
                    ["map", "key", "277411443", "value", "AW-407528078"],
                    ["map", "key", "32467552", "value", "AW-599274589"],
                    ["map", "key", "57205325", "value", "AW-644348490"],
                    ["map", "key", "164729718|164729277|28265861", "value", "AW-561158251"],
                    ["map", "key", "56542501|121205602|56540396", "value", "AW-635093888"]
                ]
            }, {
                "function": "__remm",
                "vtp_setDefaultValue": false,
                "vtp_input": ["macro", 116],
                "vtp_fullMatch": true,
                "vtp_replaceAfterMatch": true,
                "vtp_ignoreCase": true,
                "vtp_map": ["list", ["map", "key", "58418206|16621457", "value", "XI9KCPjfkPkBEODN_8kC"],
                    ["map", "key", "40867978", "value", "BwtQCLqckfkBENq3oqIC"],
                    ["map", "key", "119485441", "value", "m4CJCMqGtPkBEIjkxKMC"],
                    ["map", "key", "75422406", "value", "0bLqCO30pvkBEMTQvZEC"],
                    ["map", "key", "53892420", "value", "In_dCJy6kfkBEIeSscAC"],
                    ["map", "key", "37251933", "value", "Gx6hCOKHp_kBEPKJm6sC"],
                    ["map", "key", "29668384", "value", "TIaVCPektPkBEMu146cC"],
                    ["map", "key", "29667634", "value", "nJPNCPqqtPkBEImH758C"],
                    ["map", "key", "29668843", "value", "16QSCNPh3PoBELHsx8IB"],
                    ["map", "key", "91799978", "value", "mgeuCN-2kfEBEMWpotMB"],
                    ["map", "key", "39401693", "value", "u7dMCOOO-P8BEPC2wrkB"],
                    ["map", "key", "55027948", "value", "_tejCJGN4f8BEOqQvrkB"],
                    ["map", "key", "51678844", "value", "txW6COeO__8BEISkwrkB"],
                    ["map", "key", "59860978", "value", "_xy2CPWd-P8BEPy1-qYC"],
                    ["map", "key", "83276818", "value", "LTjOCJ6j-P8BEPfN-8UB"],
                    ["map", "key", "43416591", "value", "OxrmCIHx8v8BEKrxo7kB"],
                    ["map", "key", "26947756|111138057", "value", "FCQxCLSVj90CEMDj5sMC"],
                    ["map", "key", "269296276", "value", "YwAgCL2mkd0CEKX9tKMC"],
                    ["map", "key", "40492624", "value", "cSrkCKvEkd0CEK61oqIC"],
                    ["map", "key", "45237836", "value", "Yms8CO_-6NwCEPzsyYsC"],
                    ["map", "key", "29990515", "value", "nbs3CPO-6dwCELSropcC"],
                    ["map", "key", "241142788", "value", "silSCNLH6dwCEP29wbsB"],
                    ["map", "key", "76176908", "value", "C3xXCNDPkt0CENvLkp8C"],
                    ["map", "key", "327041081", "value", "_WL1CKnFjN0CEJz3za8B"],
                    ["map", "key", "254644909", "value", "VUuQCOz86dwCEJn60cEC"],
                    ["map", "key", "272467617", "value", "wBPTCIuT6twCEOSI_NEB"],
                    ["map", "key", "176534566", "value", "2tXYCIGZk90CEJahl6MC"],
                    ["map", "key", "98316282", "value", "wZloCM6g9N4CEN2O4aoC"],
                    ["map", "key", "55788683", "value", "lURpCPWOjd0CEOzA-7IC"],
                    ["map", "key", "62579622", "value", "QAw7CPfwh90CEIOum6MC"],
                    ["map", "key", "109598751", "value", "Pa3OCPeVnd0CEOikm6kC"],
                    ["map", "key", "35357809", "value", "-lLoCMDl9dwCEI_cubMB"],
                    ["map", "key", "277411443", "value", "RWI_CJDgnt0CEI7FqcIB"],
                    ["map", "key", "32467552", "value", "qxCICNaW9twCEN3o4J0C"],
                    ["map", "key", "57205325", "value", "WYK4CPPvmd0CEMr0n7MC"],
                    ["map", "key", "164729718|164729277|28265861", "value", "MvFHCO-48d0CEOuwyosC"],
                    ["map", "key", "56542501|121205602|56540396", "value", "xdotCJ6q99wCEICH664C"]
                ]
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "info.pageParams.shopId"
            }, {
                "function": "__remm",
                "vtp_setDefaultValue": false,
                "vtp_input": ["macro", 119],
                "vtp_fullMatch": true,
                "vtp_replaceAfterMatch": true,
                "vtp_ignoreCase": true,
                "vtp_map": ["list", ["map", "key", "58418206|16621457", "value", "AW-692053728"],
                    ["map", "key", "40867978", "value", "AW-608738266"],
                    ["map", "key", "119485441", "value", "AW-611398152"],
                    ["map", "key", "75422406", "value", "AW-573532228"],
                    ["map", "key", "53892420", "value", "AW-671893767"],
                    ["map", "key", "37251933", "value", "AW-627492082"],
                    ["map", "key", "29668384", "value", "AW-620288715"],
                    ["map", "key", "29667634", "value", "AW-603702153"],
                    ["map", "key", "29668843", "value", "AW-408024625"],
                    ["map", "key", "91799978", "value", "AW-443061445"],
                    ["map", "key", "39401693", "value", "AW-389061488"],
                    ["map", "key", "55027948", "value", "AW-388991082"],
                    ["map", "key", "51678844", "value", "AW-389059076"],
                    ["map", "key", "59860978", "value", "AW-618568444"],
                    ["map", "key", "83276818", "value", "AW-415164151"],
                    ["map", "key", "43416591", "value", "AW-388561066"],
                    ["map", "key", "26947756|111138057", "value", "AW-679064000"],
                    ["map", "key", "269296276", "value", "AW-611139237"],
                    ["map", "key", "40492624", "value", "AW-608737966"],
                    ["map", "key", "45237836", "value", "AW-561149564"],
                    ["map", "key", "29990515", "value", "AW-585668020"],
                    ["map", "key", "241142788", "value", "AW-393240317"],
                    ["map", "key", "76176908", "value", "AW-602187227"],
                    ["map", "key", "327041081", "value", "AW-368278428"],
                    ["map", "key", "254644909", "value", "AW-674528537"],
                    ["map", "key", "272467617", "value", "AW-440337508"],
                    ["map", "key", "176534566", "value", "AW-610652310"],
                    ["map", "key", "98316282", "value", "AW-626542429"],
                    ["map", "key", "55788683", "value", "AW-643752044"],
                    ["map", "key", "62579622", "value", "AW-610719491"],
                    ["map", "key", "109598751", "value", "AW-623301224"],
                    ["map", "key", "35357809", "value", "AW-376335887"],
                    ["map", "key", "277411443", "value", "AW-407528078"],
                    ["map", "key", "32467552", "value", "AW-599274589"],
                    ["map", "key", "57205325", "value", "AW-644348490"],
                    ["map", "key", "164729718|164729277|28265861", "value", "AW-561158251"],
                    ["map", "key", "56542501|121205602|56540396", "value", "AW-635093888"]
                ]
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "info.data.shopId"
            }, {
                "function": "__remm",
                "vtp_setDefaultValue": false,
                "vtp_input": ["macro", 119],
                "vtp_fullMatch": true,
                "vtp_replaceAfterMatch": true,
                "vtp_ignoreCase": true,
                "vtp_map": ["list", ["map", "key", "58418206|16621457", "value", "Bua5CJ-spvkBEODN_8kC"],
                    ["map", "key", "40867978", "value", "_qDFCLyhkfkBENq3oqIC"],
                    ["map", "key", "119485441", "value", "bTY-CNrtpvkBEIjkxKMC"],
                    ["map", "key", "75422406", "value", "9LuNCPmukfkBEMTQvZEC"],
                    ["map", "key", "53892420", "value", "s6R2CPCgtPkBEIeSscAC"],
                    ["map", "key", "37251933", "value", "e_jFCJyjtPkBEPKJm6sC"],
                    ["map", "key", "29668384", "value", "Smq9COWqtPkBEMu146cC"],
                    ["map", "key", "29667634", "value", "Fdt5CNvSkfkBEImH758C"],
                    ["map", "key", "29668843", "value", "4-T1COzz8voBELHsx8IB"],
                    ["map", "key", "91799978", "value", "2LF0CJjX8fABEMWpotMB"],
                    ["map", "key", "39401693", "value", "xRfRCMuI-P8BEPC2wrkB"],
                    ["map", "key", "55027948", "value", "i_bpCIKN4f8BEOqQvrkB"],
                    ["map", "key", "51678844", "value", "Q0iTCMKH__8BEISkwrkB"],
                    ["map", "key", "59860978", "value", "kmcsCNKb-P8BEPy1-qYC"],
                    ["map", "key", "83276818", "value", "ytDmCI6f-P8BEPfN-8UB"],
                    ["map", "key", "43416591", "value", "NUqBCOzt8v8BEKrxo7kB"],
                    ["map", "key", "26947756|111138057", "value", "iDYcCOmZid0CEMDj5sMC"],
                    ["map", "key", "269296276", "value", "U7nsCNuskd0CEKX9tKMC"],
                    ["map", "key", "40492624", "value", "OOS3CM3Ikd0CEK61oqIC"],
                    ["map", "key", "45237836", "value", "Is0ZCMrskd0CEPzsyYsC"],
                    ["map", "key", "29990515", "value", "b6gxCPjD6dwCELSropcC"],
                    ["map", "key", "241142788", "value", "_MaFCLSpjN0CEP29wbsB"],
                    ["map", "key", "76176908", "value", "TX0uCK3n6dwCENvLkp8C"],
                    ["map", "key", "327041081", "value", "tPaQCL_t6dwCEJz3za8B"],
                    ["map", "key", "254644909", "value", "-3cICJL3kt0CEJn60cEC"],
                    ["map", "key", "272467617", "value", "J_A3CPKDk90CEOSI_NEB"],
                    ["map", "key", "176534566", "value", "iRDZCPqdk90CEJahl6MC"],
                    ["map", "key", "98316282", "value", "7S9QCPel9N4CEN2O4aoC"],
                    ["map", "key", "55788683", "value", "PqpFCKSnk90CEOzA-7IC"],
                    ["map", "key", "62579622", "value", "4-ZHCOucj90CEIOum6MC"],
                    ["map", "key", "109598751", "value", "3ETICLeJnt0CEOikm6kC"],
                    ["map", "key", "35357809", "value", "LKZcCNPOmN0CEI_cubMB"],
                    ["map", "key", "277411443", "value", "LbfvCI_cnt0CEI7FqcIB"],
                    ["map", "key", "32467552", "value", "IMKCCPSQ9twCEN3o4J0C"],
                    ["map", "key", "57205325", "value", "P2n8CJ3w9twCEMr0n7MC"],
                    ["map", "key", "164729718|164729277|28265861", "value", "2LowCJa28d0CEOuwyosC"],
                    ["map", "key", "56542501|121205602|56540396", "value", "xOo0CM2MoN0CEICH664C"]
                ]
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "info.impressions.0.targetData.item.name"
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){return ", ["escape", ["macro", 36], 8, 16], "})();"]
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "info.pageParams.category"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "info.pageParams.isOfficialShopTheme"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "info.pageParams.keyword"
            }, {
                "function": "__remm",
                "vtp_setDefaultValue": false,
                "vtp_input": ["macro", 4],
                "vtp_fullMatch": false,
                "vtp_replaceAfterMatch": false,
                "vtp_ignoreCase": true,
                "vtp_map": ["list", ["map", "key", "shopee.sg", "value", "11"],
                    ["map", "key", "shopee.com.my", "value", "8"],
                    ["map", "key", "shopee.co.id", "value", "14"],
                    ["map", "key", "shopee.vn", "value", "9"],
                    ["map", "key", "shopee.ph", "value", "15"],
                    ["map", "key", "shopee.tw", "value", "13"]
                ]
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "info.data.price"
            }, {
                "function": "__remm",
                "vtp_setDefaultValue": false,
                "vtp_input": ["macro", 4],
                "vtp_fullMatch": false,
                "vtp_replaceAfterMatch": false,
                "vtp_ignoreCase": true,
                "vtp_map": ["list", ["map", "key", "shopee.co.id", "value", "100188"],
                    ["map", "key", "shopee.com.my", "value", "100126"],
                    ["map", "key", "shopee.co.th", "value", "100245"],
                    ["map", "key", "shopee.sg", "value", "100376"]
                ]
            }, {
                "function": "__remm",
                "vtp_setDefaultValue": false,
                "vtp_input": ["macro", 4],
                "vtp_fullMatch": false,
                "vtp_replaceAfterMatch": false,
                "vtp_ignoreCase": true,
                "vtp_map": ["list", ["map", "key", "shopee.co.id", "value", "ICM-39-1334"],
                    ["map", "key", "shopee.com.my", "value", "ICM-11-1270"],
                    ["map", "key", "shopee.co.th", "value", "ICM-49-1393"]
                ]
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": true,
                "vtp_defaultValue": "",
                "vtp_name": "crto.products"
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){for(var b=", ["escape", ["macro", 132], 8, 16], ",c=[],a=0;a\u003Cb.length\u0026\u00263\u003Ea;a++)\"object\"==typeof b[a]?b[a].hasOwnProperty(\"id\")\u0026\u0026c.push(b[a].id):(\"number\"==typeof b[a]||\"number\"==typeof b[a])\u0026\u0026c.push(b[a]);return c})();"]
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){return\/iPad\/.test(navigator.userAgent)?\"t\":\/Mobile|iP(hone|od)|Android|BlackBerry|IEMobile|Silk\/.test(navigator.userAgent)?\"m\":\"d\"})();"]
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "info.impressions.0.targetData.item.itemid"
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){var a=", ["escape", ["macro", 40], 8, 16], "||[],c=[],b;for(b in a)c.push({id:a[b].itemid,price:parseFloat(a[b].price)\/1E5,quantity:a[b].quantity});return c})();"]
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "info.impressions.0.targetData.cart.totalPrice"
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){var a=", ["escape", ["macro", 137], 8, 16], "\/1E5;return a})();"]
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){var a=", ["escape", ["macro", 46], 8, 16], ",d=[];a=a.filter(function(a){return a.hasOwnProperty(\"items\")});for(var b=0;b\u003Ca.length;b++)for(var c=0;c\u003Ca[b].items.length;c++)d.push(a[b].items[c].itemid);return d.join(\"|\")})();"]
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){for(var c=", ["escape", ["macro", 46], 8, 16], ",d=[],e=c.filter(function(a){return a.hasOwnProperty(\"items\")}),a=0;a\u003Ce.length;a++)for(var b=0;b\u003Ce[a].items.length;b++)d.push(c[a].items[b].price\/1E5*c[a].items[b].quantity);return d.join(\"|\")})();"]
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){for(var b=[{items:{0:{itemid:15014125,status:1,quantity:2,none_shippable_full_reason:null,price:3E7,donot_add_quantity:!1,shopid:3905134,currency:\"TWD\",item_discount:0,is_flash_sale:!1,mtime:1528495159,free_return_days:null,condition:1,shippable:!0,name:\"\\u9810\\u8cfc iPhoneX \\u5b9a\\u5236 \\u65e5\\u97d3\\u6587\\u85dd\\u6e05\\u65b0\\u5c0f\\u788e\\u82b1 \\u786c\\u6bbc\\u534a\\u5305\/\\u8edf\\u6bbc\\u5168\\u5305 \\u860b\\u679c i8X i7 i6 Plus i5se \\u624b\\u6a5f\\u6bbc\",stock:6,image:\"620beb14b85b2d9a069b10cdd41575be\",\nnone_shippable_reason:null,source:\"null\",modelid:6993834,checkout:!0,model_name:\"i6\/6s \\u8edf\\u6bbc\",addin_time:1529553717,service_by_shopee_flag:0},1:{itemid:15014125,status:1,quantity:5,none_shippable_full_reason:null,price:3E7,donot_add_quantity:!1,shopid:3905134,currency:\"TWD\",item_discount:0,is_flash_sale:!1,mtime:1528495159,free_return_days:null,condition:1,shippable:!0,name:\"\\u9810\\u8cfc iPhoneX \\u5b9a\\u5236 \\u65e5\\u97d3\\u6587\\u85dd\\u6e05\\u65b0\\u5c0f\\u788e\\u82b1 \\u786c\\u6bbc\\u534a\\u5305\/\\u8edf\\u6bbc\\u5168\\u5305 \\u860b\\u679c i8X i7 i6 Plus i5se \\u624b\\u6a5f\\u6bbc\",\nstock:8,image:\"620beb14b85b2d9a069b10cdd41575be\",none_shippable_reason:null,source:\"null\",modelid:6993832,checkout:!0,model_name:\"i8\/i7Plus \\u8edf\\u6bbc\",addin_time:1529553755,service_by_shopee_flag:0}},shop:{is_official_shop:!1,shopid:3905134,shop_name:\"\\u5b8c\\u7f8e\\u5c0f\\u59d0\\u624b\\u6a5f\\u6bbc\\u5c08\\u8ce3\",support_ereceipt:!1,images:\"\",cb_option:!1},shipping_fee:3E6,total_without_shipping:21E7}],d=[],a=0;a\u003Cb.length;a++)for(var c=0;c\u003Cb[a].items.length;c++)d.push(b[a].items[c].itemid);return d})();"]
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){var a=[{items:{0:{itemid:15014125,status:1,quantity:2,none_shippable_full_reason:null,price:3E7,donot_add_quantity:!1,shopid:3905134,currency:\"TWD\",item_discount:0,is_flash_sale:!1,mtime:1528495159,free_return_days:null,condition:1,shippable:!0,name:\"\\u9810\\u8cfc iPhoneX \\u5b9a\\u5236 \\u65e5\\u97d3\\u6587\\u85dd\\u6e05\\u65b0\\u5c0f\\u788e\\u82b1 \\u786c\\u6bbc\\u534a\\u5305\/\\u8edf\\u6bbc\\u5168\\u5305 \\u860b\\u679c i8X i7 i6 Plus i5se \\u624b\\u6a5f\\u6bbc\",stock:6,image:\"620beb14b85b2d9a069b10cdd41575be\",\nnone_shippable_reason:null,source:\"null\",modelid:6993834,checkout:!0,model_name:\"i6\/6s \\u8edf\\u6bbc\",addin_time:1529553717,service_by_shopee_flag:0},1:{itemid:15014125,status:1,quantity:5,none_shippable_full_reason:null,price:3E7,donot_add_quantity:!1,shopid:3905134,currency:\"TWD\",item_discount:0,is_flash_sale:!1,mtime:1528495159,free_return_days:null,condition:1,shippable:!0,name:\"\\u9810\\u8cfc iPhoneX \\u5b9a\\u5236 \\u65e5\\u97d3\\u6587\\u85dd\\u6e05\\u65b0\\u5c0f\\u788e\\u82b1 \\u786c\\u6bbc\\u534a\\u5305\/\\u8edf\\u6bbc\\u5168\\u5305 \\u860b\\u679c i8X i7 i6 Plus i5se \\u624b\\u6a5f\\u6bbc\",\nstock:8,image:\"620beb14b85b2d9a069b10cdd41575be\",none_shippable_reason:null,source:\"null\",modelid:6993832,checkout:!0,model_name:\"i8\/i7Plus \\u8edf\\u6bbc\",addin_time:1529553755,service_by_shopee_flag:0}},shop:{is_official_shop:!1,shopid:3905134,shop_name:\"\\u5b8c\\u7f8e\\u5c0f\\u59d0\\u624b\\u6a5f\\u6bbc\\u5c08\\u8ce3\",support_ereceipt:!1,images:\"\",cb_option:!1},shipping_fee:3E6,total_without_shipping:21E7}];return a.map(function(a){return a.items.map(function(a){return a.itemid}).join(\"|\")}).join(\"|\")})();"]
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){for(var b=[{items:{0:{itemid:15014125,status:1,quantity:2,none_shippable_full_reason:null,price:3E7,donot_add_quantity:!1,shopid:3905134,currency:\"TWD\",item_discount:0,is_flash_sale:!1,mtime:1528495159,free_return_days:null,condition:1,shippable:!0,name:\"\\u9810\\u8cfc iPhoneX \\u5b9a\\u5236 \\u65e5\\u97d3\\u6587\\u85dd\\u6e05\\u65b0\\u5c0f\\u788e\\u82b1 \\u786c\\u6bbc\\u534a\\u5305\/\\u8edf\\u6bbc\\u5168\\u5305 \\u860b\\u679c i8X i7 i6 Plus i5se \\u624b\\u6a5f\\u6bbc\",stock:6,image:\"620beb14b85b2d9a069b10cdd41575be\",\nnone_shippable_reason:null,source:\"null\",modelid:6993834,checkout:!0,model_name:\"i6\/6s \\u8edf\\u6bbc\",addin_time:1529553717,service_by_shopee_flag:0},1:{itemid:15014125,status:1,quantity:5,none_shippable_full_reason:null,price:3E7,donot_add_quantity:!1,shopid:3905134,currency:\"TWD\",item_discount:0,is_flash_sale:!1,mtime:1528495159,free_return_days:null,condition:1,shippable:!0,name:\"\\u9810\\u8cfc iPhoneX \\u5b9a\\u5236 \\u65e5\\u97d3\\u6587\\u85dd\\u6e05\\u65b0\\u5c0f\\u788e\\u82b1 \\u786c\\u6bbc\\u534a\\u5305\/\\u8edf\\u6bbc\\u5168\\u5305 \\u860b\\u679c i8X i7 i6 Plus i5se \\u624b\\u6a5f\\u6bbc\",\nstock:8,image:\"620beb14b85b2d9a069b10cdd41575be\",none_shippable_reason:null,source:\"null\",modelid:6993832,checkout:!0,model_name:\"i8\/i7Plus \\u8edf\\u6bbc\",addin_time:1529553755,service_by_shopee_flag:0}},shop:{is_official_shop:!1,shopid:3905134,shop_name:\"\\u5b8c\\u7f8e\\u5c0f\\u59d0\\u624b\\u6a5f\\u6bbc\\u5c08\\u8ce3\",support_ereceipt:!1,images:\"\",cb_option:!1},shipping_fee:3E6,total_without_shipping:21E7}],d=[],a=0;a\u003Cb.length;a++)for(var c=0;c\u003Cb[a].items.length;c++)d.push({id:\"\"+b[a].items[c].itemid,item_price:b[a].items[c].price\/\n1E5,quantity:b[a].items[c].quantity,category:b[a].items[c].categories[0].catids.join(\"\\x3e\")});return d})();"]
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "info.data.price"
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){var a=", ["escape", ["macro", 129], 8, 16], ",b=a.shipping_subtotal\/1E5,c=a.tax_payable\/1E5;return a=a.total_payable\/1E5-b-c})();"]
            }, {
                "function": "__remm",
                "vtp_setDefaultValue": false,
                "vtp_input": ["macro", 15],
                "vtp_fullMatch": true,
                "vtp_replaceAfterMatch": true,
                "vtp_ignoreCase": true,
                "vtp_map": ["list", ["map", "key", "https:\/\/shopee.vn\/m\/99", "value", "1005975"],
                    ["map", "key", "https:\/\/shopee.co.id\/m\/super-shopping-day-129", "value", "1005969"],
                    ["map", "key", "https:\/\/shopee.co.th\/m\/99", "value", "1005972"],
                    ["map", "key", "https:\/\/shopee.com.my\/m\/99", "value", "1005973"],
                    ["map", "key", "https:\/\/shopee.ph\/m\/99", "value", "953969"],
                    ["map", "key", "https:\/\/shopee.sg\/m\/99", "value", "1005974"],
                    ["map", "key", "https:\/\/shopee.tw\/m\/99", "value", "1005971"]
                ]
            }, {
                "function": "__remm",
                "vtp_setDefaultValue": false,
                "vtp_input": ["macro", 4],
                "vtp_fullMatch": false,
                "vtp_replaceAfterMatch": false,
                "vtp_ignoreCase": true,
                "vtp_map": ["list", ["map", "key", "shopee.sg", "value", "1011l628"],
                    ["map", "key", "shopee.co.th", "value", "1100l551"],
                    ["map", "key", "shopee.vn", "value", "1100l682"],
                    ["map", "key", "shopee.ph", "value", "1100l720"],
                    ["map", "key", "shopee.com.my", "value", "1100l721"],
                    ["map", "key", "shopee.tw", "value", "1011l795"],
                    ["map", "key", "shopee.co.id", "value", "1101l712"],
                    ["map", "key", "shopee.com.br", "value", "1011l971"]
                ]
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){var b=", ["escape", ["macro", 147], 8, 16], ",n=", ["escape", ["macro", 45], 8, 16], ",p=", ["escape", ["macro", 61], 8, 16], ",c=", ["escape", ["macro", 46], 8, 16], ";b=\"https:\/\/prf.hn\/conversion\/campaign:\"+b+\"\/conversionref:\"+n+\"\/country:\"+", ["escape", ["macro", 36], 8, 16], "+\"\/currency:\"+", ["escape", ["macro", 48], 8, 16], "+\"\/\";var f=[];(c||[]).forEach(function(a){(Object.values(a.items)||[]).forEach(function(a){var b=a.itemid,c=a.price\/1E5,d=a.quantity,e=a.shopid;a=a.categories[0].catids[0];f.push({itemId:b,itemPrice:c,quantity:d,shopId:e,categoryL1:a})})});var d,e,g,h,k,l=[];\n(Object.values(f)||[]).forEach(function(a){d=a.itemId;e=a.itemPrice;g=a.quantity;h=a.categoryL1;k=a.shopId;l.push(\"[category:\"+h+\"\/sku:\"+d+\"\/value:\"+e+\"\/quantity:\"+g+\"\/shop_id:\"+k+\"\/order_id:\"+p+\"\/]\")});var m=\"\";(Object.values(l)||[]).forEach(function(a){m+=a});return c=b+m})();"]
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){var a=document.location.pathname.split(\"\/\");return a[1].toLowerCase()})();"]
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "info.data"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "info.data"
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){return window.location.pathname+window.location.search+window.location.hash})();"]
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "info.data.shopid"
            }, {
                "function": "__remm",
                "vtp_setDefaultValue": false,
                "vtp_input": ["macro", 4],
                "vtp_fullMatch": false,
                "vtp_replaceAfterMatch": false,
                "vtp_ignoreCase": true,
                "vtp_map": ["list", ["map", "key", "shopee.co.id", "value", "2599"]]
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){var g=", ["escape", ["macro", 154], 8, 16], ",h=", ["escape", ["macro", 45], 8, 16], ",a=", ["escape", ["macro", 46], 8, 16], ",k=", ["escape", ["macro", 59], 8, 16], ",l=", ["escape", ["macro", 61], 8, 16], ",d=[],e=[],f=[];(a||[]).forEach(function(a){(Object.values(a.items)||[]).forEach(function(a){})});for(var b=0;b\u003Ca.length;b++)for(var c=0;c\u003Ca[b].items.length;c++)d.push(a[b].items[c].shopid),e.push(a[b].items[c].itemid),f.push(a[b].items[c].categories[0].catids[0]);d=d.join(\"|\");e=e.join(\"|\");f=f.join(\"|\");a=[];a=l.join(\"|\");return g=\"https:\/\/shopback.go2cloud.org\/aff_l?offer_id\\x3d\"+\ng+\"\\x26adv_sub\\x3d\"+h+\"\\x26adv_sub2\\x3d\"+d+\"\\x26adv_sub3\\x3d\"+e+\"\\x26adv_sub4\\x3d\"+a+\"\\x26adv_sub5\\x3d\"+f+\"\\x26amount\\x3d\"+k})();"]
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "info.data.response"
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){var b=", ["escape", ["macro", 147], 8, 16], ",e=", ["escape", ["macro", 45], 8, 16], ",f=", ["escape", ["macro", 61], 8, 16], ",g=", ["escape", ["macro", 46], 8, 16], ",c=\"https:\/\/prf.hn\/conversion\/campaign:\"+b+\"\/conversionref:\"+e+\"\/country:\"+", ["escape", ["macro", 36], 8, 16], "+\"\/currency:\"+", ["escape", ["macro", 48], 8, 16], "+\"\/\";b=g.filter(function(d){return d.hasOwnProperty(\"items\")});console.log(\"check \"+b);b.forEach(function(d,h){d.items.forEach(function(a){var k=a.itemid,l=a.price\/1E5,m=a.quantity,n=a.shopid;a=a.categories[0].catids[0];c+=\"[category:\"+a+\"\/sku:\"+k+\"\/value:\"+l+\n\"\/quantity:\"+m+\"\/shop_id:\"+n+\"\/order_id:\"+f[h]+\"\/]\"})});console.log(\"::: \"+c);return c})();"]
            }, {
                "function": "__u",
                "vtp_component": "QUERY",
                "vtp_queryKey": "gclid",
                "vtp_enableMultiQueryKeys": false,
                "vtp_enableIgnoreEmptyQueryParam": false
            }, {
                "function": "__remm",
                "vtp_setDefaultValue": false,
                "vtp_input": ["macro", 4],
                "vtp_fullMatch": false,
                "vtp_replaceAfterMatch": false,
                "vtp_ignoreCase": true,
                "vtp_map": ["list", ["map", "key", "shopee.co.id", "value", "G-SW6D8G0HXK"],
                    ["map", "key", "shopee.sg", "value", ""],
                    ["map", "key", "shopee.com.my", "value", ""],
                    ["map", "key", "shopee.tw", "value", ""],
                    ["map", "key", "shopee.co.th", "value", ""],
                    ["map", "key", "shopee.vn", "value", ""],
                    ["map", "key", "shopee.ph", "value", ""],
                    ["map", "key", "shopee.com.br", "value", ""],
                    ["map", "key", "shopee.com.mx", "value", ""],
                    ["map", "key", "shopee.com.co", "value", ""],
                    ["map", "key", "shopee.cl", "value", ""],
                    ["map", "key", "shopee.pl", "value", ""],
                    ["map", "key", "shopee.es", "value", ""],
                    ["map", "key", "shopee.fr", "value", ""]
                ]
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "data.current.hash"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "data.current.host"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "data.current.protocol"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "data.current.search.utm_campaign"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "data.current.search.utm_content"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "data.current.search.utm_medium"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "data.current.search.utm_source"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "data.current.title"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "data.first.hash"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "data.first.host"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "data.first.hostname"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "data.first.origin"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "data.first.pathname"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "data.first.protocol"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "data.first.title"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "data.first.search.utm_source"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "data.first.search.utm_campaign"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "data.first.search.utm_content"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "data.first.search.utm_medium"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "data.prev.hash"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "data.first.search.gclsrc"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "data.first.search.utm_term"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "data.prev.href"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "data.prev.host"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "data.prev.hostname"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "data.prev.origin"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "data.prev.pathname"
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "data.prev.title"
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){var a=", ["escape", ["macro", 160], 8, 16], ";if(0\u003Ca.length)return a})();"]
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){var a=", ["escape", ["macro", 179], 8, 16], ";if(0\u003Ca.length)return a})();"]
            }, {
                "function": "__jsm",
                "vtp_javascript": ["template", "(function(){for(var b=", ["escape", ["macro", 46], 8, 16], ",d=[],a=0;a\u003Cb.length;a++)for(var c=0;c\u003Cb[a].items.length;c++)try{\"undefined\"===typeof d[b[a].items[c].shopid]?d[b[a].items[c].shopid]={shopId:b[a].items[c].shopid,conversionId:\"", ["escape", ["macro", 120], 7], "\",conversionLabel:\"", ["escape", ["macro", 118], 7], "\",quantity:b[a].items[c].quantity,totalValue:b[a].items[c].price\/1E5*b[a].items[c].quantity}:(d[b[a].items[c].shopid].quantity+=b[a].items[c].quantity,d[b[a].items[c].shopid].totalValue+=b[a].items[c].price\/1E5*b[a].items[c].quantity)}catch(e){console.warn(e)}console.log(\"*****\"+\nObject.values(d));return Object.values(d)})();"]
            }, {
                "function": "__v",
                "vtp_dataLayerVersion": 2,
                "vtp_setDefaultValue": false,
                "vtp_name": "session_id"
            }, {
                "function": "__remm",
                "vtp_setDefaultValue": false,
                "vtp_input": ["macro", 22],
                "vtp_fullMatch": true,
                "vtp_replaceAfterMatch": true,
                "vtp_ignoreCase": true,
                "vtp_map": ["list", ["map", "key", "(\/unilever_householdcare)|(\/unilever_beautyhotpro)", "value", "AW-692053728"],
                    ["map", "key", "\/unilever_personalcare", "value", "AW-608738266"],
                    ["map", "key", "\/realmeofficialstore", "value", "AW-611398152"],
                    ["map", "key", "\/nutrilonofficialstore", "value", "AW-573532228"],
                    ["map", "key", "\/oppo_official_store", "value", "AW-671893767"],
                    ["map", "key", "\/lorealparis_officialstore", "value", "AW-627492082"],
                    ["map", "key", "\/garnier_thailand", "value", "AW-620288715"],
                    ["map", "key", "\/lorealparis", "value", "AW-603702153"],
                    ["map", "key", "\/maybelline_thailand", "value", "AW-408024625"],
                    ["map", "key", "\/smartsg", "value", "AW-443061445"],
                    ["map", "key", "\/mobilehubsg", "value", "AW-389061488"],
                    ["map", "key", "\/absolutepiano", "value", "AW-388991082"],
                    ["map", "key", "\/atrixofficial", "value", "AW-389059076"],
                    ["map", "key", "\/foremost_official_shop", "value", "AW-618568444"],
                    ["map", "key", "\/samsung_thailand", "value", "AW-415164151"],
                    ["map", "key", "\/movingpeach.sg", "value", "AW-388561066"]
                ]
            }, {
                "function": "__v",
                "vtp_name": "gtm.element",
                "vtp_dataLayerVersion": 1
            }, {
                "function": "__v",
                "vtp_name": "gtm.elementId",
                "vtp_dataLayerVersion": 1
            }, {
                "function": "__v",
                "vtp_name": "gtm.elementTarget",
                "vtp_dataLayerVersion": 1
            }, {
                "function": "__v",
                "vtp_name": "gtm.newUrlFragment",
                "vtp_dataLayerVersion": 1
            }, {
                "function": "__v",
                "vtp_name": "gtm.oldUrlFragment",
                "vtp_dataLayerVersion": 1
            }, {
                "function": "__v",
                "vtp_name": "gtm.newHistoryState",
                "vtp_dataLayerVersion": 1
            }, {
                "function": "__v",
                "vtp_name": "gtm.oldHistoryState",
                "vtp_dataLayerVersion": 1
            }, {
                "function": "__v",
                "vtp_name": "gtm.videoUrl",
                "vtp_dataLayerVersion": 1
            }, {
                "function": "__v",
                "vtp_name": "gtm.videoTitle",
                "vtp_dataLayerVersion": 1
            }, {
                "function": "__v",
                "vtp_name": "gtm.videoPercent",
                "vtp_dataLayerVersion": 1
            }, {
                "function": "__v",
                "vtp_name": "gtm.videoStatus",
                "vtp_dataLayerVersion": 1
            }, {
                "function": "__v",
                "vtp_name": "gtm.scrollThreshold",
                "vtp_dataLayerVersion": 1
            }],
            "tags": [{
                "function": "__ua",
                "priority": 50,
                "once_per_event": true,
                "vtp_nonInteraction": false,
                "vtp_overrideGaSettings": true,
                "vtp_useEcommerceDataLayer": false,
                "vtp_ecommerceMacroData": ["macro", 60],
                "vtp_eventCategory": "tracking",
                "vtp_trackType": "TRACK_EVENT",
                "vtp_gaSettings": ["macro", 34],
                "vtp_eventAction": "purchase",
                "vtp_eventLabel": ["macro", 61],
                "vtp_enableEcommerce": true,
                "vtp_enableRecaptchaOption": false,
                "vtp_enableUaRlsa": false,
                "vtp_enableUseInternalVersion": false,
                "vtp_enableFirebaseCampaignData": true,
                "vtp_ecommerceIsEnabled": true,
                "vtp_trackTypeIsEvent": true,
                "vtp_enableGA4Schema": false,
                "tag_id": 68
            }, {
                "function": "__html",
                "priority": 2,
                "once_per_event": true,
                "vtp_html": ["template", "\u003Cscript type=\"text\/gtmscript\"\u003Evar p=", ["escape", ["macro", 112], 8, 16], ";document.cookie=p.cookieName+\"\\x3d; expires\\x3dThu, 01 Jan 1970 00:00:01 GMT; path\\x3d\"+p.path+\";domain\\x3d\"+p.domain;\u003C\/script\u003E\n"],
                "vtp_supportDocumentWrite": false,
                "vtp_enableIframeMode": false,
                "vtp_enableEditJsMacroBehavior": false,
                "tag_id": 79
            }, {
                "function": "__paused",
                "vtp_originalTagType": "html",
                "tag_id": 2
            }, {
                "function": "__paused",
                "vtp_originalTagType": "html",
                "tag_id": 3
            }, {
                "function": "__paused",
                "vtp_originalTagType": "html",
                "tag_id": 4
            }, {
                "function": "__paused",
                "vtp_originalTagType": "html",
                "tag_id": 5
            }, {
                "function": "__paused",
                "vtp_originalTagType": "html",
                "tag_id": 6
            }, {
                "function": "__paused",
                "vtp_originalTagType": "html",
                "tag_id": 8
            }, {
                "function": "__ua",
                "metadata": ["map"],
                "once_per_load": true,
                "vtp_overrideGaSettings": false,
                "vtp_trackType": "TRACK_PAGEVIEW",
                "vtp_gaSettings": ["macro", 34],
                "vtp_enableRecaptchaOption": false,
                "vtp_enableUaRlsa": false,
                "vtp_enableUseInternalVersion": false,
                "vtp_enableFirebaseCampaignData": true,
                "vtp_enableGA4Schema": false,
                "tag_id": 15
            }, {
                "function": "__paused",
                "vtp_originalTagType": "html",
                "tag_id": 21
            }, {
                "function": "__paused",
                "vtp_originalTagType": "html",
                "tag_id": 28
            }, {
                "function": "__paused",
                "vtp_originalTagType": "html",
                "tag_id": 29
            }, {
                "function": "__paused",
                "vtp_originalTagType": "html",
                "tag_id": 30
            }, {
                "function": "__hjtc",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_hotjar_site_id": "868286",
                "tag_id": 32
            }, {
                "function": "__paused",
                "vtp_originalTagType": "html",
                "tag_id": 33
            }, {
                "function": "__paused",
                "vtp_originalTagType": "html",
                "tag_id": 34
            }, {
                "function": "__paused",
                "vtp_originalTagType": "html",
                "tag_id": 35
            }, {
                "function": "__paused",
                "vtp_originalTagType": "html",
                "tag_id": 36
            }, {
                "function": "__paused",
                "vtp_originalTagType": "html",
                "tag_id": 37
            }, {
                "function": "__paused",
                "vtp_originalTagType": "html",
                "tag_id": 38
            }, {
                "function": "__crto",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_accountId": ["macro", 37],
                "vtp_hashedEmail": ["macro", 38],
                "vtp_tagType": "BASKET_TAG",
                "vtp_siteType": ["macro", 39],
                "vtp_basketArray": ["macro", 41],
                "tag_id": 50
            }, {
                "function": "__crto",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_accountId": ["macro", 37],
                "vtp_hashedEmail": ["macro", 38],
                "vtp_tagType": "HOME_TAG",
                "vtp_siteType": ["macro", 39],
                "tag_id": 51
            }, {
                "function": "__crto",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_accountId": ["macro", 37],
                "vtp_hashedEmail": ["macro", 38],
                "vtp_tagType": "LISTING_TAG",
                "vtp_listingID": ["macro", 43],
                "vtp_siteType": ["macro", 39],
                "tag_id": 52
            }, {
                "function": "__crto",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_accountId": ["macro", 37],
                "vtp_hashedEmail": ["macro", 38],
                "vtp_productID": ["macro", 44],
                "vtp_tagType": "PRODUCT_TAG",
                "vtp_siteType": ["macro", 39],
                "tag_id": 53
            }, {
                "function": "__crto",
                "metadata": ["map"],
                "once_per_load": true,
                "vtp_accountId": ["macro", 37],
                "vtp_hashedEmail": ["macro", 38],
                "vtp_tagType": "TRANSACTION_TAG",
                "vtp_siteType": ["macro", 39],
                "vtp_TransactionID": ["macro", 45],
                "vtp_TransactionArray": ["macro", 47],
                "tag_id": 54
            }, {
                "function": "__gclidw",
                "once_per_event": true,
                "vtp_enableCookieOverrides": false,
                "vtp_enableCrossDomainFeature": true,
                "vtp_enableCookieFlagsFeature": true,
                "tag_id": 57
            }, {
                "function": "__hjtc",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_hotjar_site_id": "955851",
                "tag_id": 63
            }, {
                "function": "__paused",
                "vtp_originalTagType": "html",
                "tag_id": 64
            }, {
                "function": "__paused",
                "vtp_originalTagType": "ua",
                "tag_id": 65
            }, {
                "function": "__ua",
                "once_per_event": true,
                "vtp_nonInteraction": false,
                "vtp_overrideGaSettings": true,
                "vtp_useEcommerceDataLayer": false,
                "vtp_ecommerceMacroData": ["macro", 56],
                "vtp_eventCategory": "tracking",
                "vtp_trackType": "TRACK_EVENT",
                "vtp_gaSettings": ["macro", 34],
                "vtp_eventAction": "add_to_cart",
                "vtp_enableEcommerce": true,
                "vtp_enableRecaptchaOption": false,
                "vtp_enableUaRlsa": false,
                "vtp_enableUseInternalVersion": false,
                "vtp_enableFirebaseCampaignData": true,
                "vtp_ecommerceIsEnabled": true,
                "vtp_trackTypeIsEvent": true,
                "vtp_enableGA4Schema": false,
                "tag_id": 66
            }, {
                "function": "__ua",
                "once_per_event": true,
                "vtp_nonInteraction": false,
                "vtp_overrideGaSettings": true,
                "vtp_eventCategory": "register",
                "vtp_trackType": "TRACK_EVENT",
                "vtp_gaSettings": ["macro", 34],
                "vtp_eventAction": ["macro", 58],
                "vtp_eventLabel": ["macro", 13],
                "vtp_dimension": ["list", ["map", "index", "1", "dimension", ["macro", 13]]],
                "vtp_enableRecaptchaOption": false,
                "vtp_enableUaRlsa": false,
                "vtp_enableUseInternalVersion": false,
                "vtp_enableFirebaseCampaignData": true,
                "vtp_trackTypeIsEvent": true,
                "vtp_enableGA4Schema": false,
                "tag_id": 67
            }, {
                "function": "__paused",
                "vtp_originalTagType": "ua",
                "tag_id": 69
            }, {
                "function": "__paused",
                "vtp_originalTagType": "html",
                "tag_id": 71
            }, {
                "function": "__ua",
                "metadata": ["map"],
                "unlimited": true,
                "vtp_overrideGaSettings": true,
                "vtp_fieldsToSet": ["list", ["map", "fieldName", "title", "value", ["macro", 62]]],
                "vtp_trackType": "TRACK_PAGEVIEW",
                "vtp_gaSettings": ["macro", 34],
                "vtp_enableRecaptchaOption": false,
                "vtp_enableUaRlsa": false,
                "vtp_enableUseInternalVersion": false,
                "vtp_enableFirebaseCampaignData": true,
                "vtp_enableGA4Schema": false,
                "tag_id": 72
            }, {
                "function": "__paused",
                "vtp_originalTagType": "html",
                "tag_id": 73
            }, {
                "function": "__paused",
                "vtp_originalTagType": "html",
                "tag_id": 74
            }, {
                "function": "__paused",
                "vtp_originalTagType": "hjtc",
                "tag_id": 75
            }, {
                "function": "__paused",
                "vtp_originalTagType": "html",
                "tag_id": 76
            }, {
                "function": "__paused",
                "vtp_originalTagType": "img",
                "tag_id": 77
            }, {
                "function": "__ua",
                "once_per_event": true,
                "vtp_nonInteraction": false,
                "vtp_overrideGaSettings": true,
                "vtp_useEcommerceDataLayer": false,
                "vtp_ecommerceMacroData": ["macro", 56],
                "vtp_eventCategory": "tracking",
                "vtp_trackType": "TRACK_EVENT",
                "vtp_gaSettings": ["macro", 64],
                "vtp_eventAction": "add_to_cart",
                "vtp_enableEcommerce": true,
                "vtp_enableRecaptchaOption": false,
                "vtp_enableUaRlsa": false,
                "vtp_enableUseInternalVersion": false,
                "vtp_enableFirebaseCampaignData": true,
                "vtp_ecommerceIsEnabled": true,
                "vtp_trackTypeIsEvent": true,
                "vtp_enableGA4Schema": false,
                "tag_id": 81
            }, {
                "function": "__paused",
                "vtp_originalTagType": "ua",
                "tag_id": 82
            }, {
                "function": "__ua",
                "metadata": ["map"],
                "unlimited": true,
                "vtp_overrideGaSettings": true,
                "vtp_fieldsToSet": ["list", ["map", "fieldName", "title", "value", ["macro", 62]]],
                "vtp_trackType": "TRACK_PAGEVIEW",
                "vtp_gaSettings": ["macro", 64],
                "vtp_enableRecaptchaOption": false,
                "vtp_enableUaRlsa": false,
                "vtp_enableUseInternalVersion": false,
                "vtp_enableFirebaseCampaignData": true,
                "vtp_enableGA4Schema": false,
                "tag_id": 83
            }, {
                "function": "__ua",
                "metadata": ["map"],
                "once_per_load": true,
                "vtp_overrideGaSettings": false,
                "vtp_trackType": "TRACK_PAGEVIEW",
                "vtp_gaSettings": ["macro", 64],
                "vtp_enableRecaptchaOption": false,
                "vtp_enableUaRlsa": false,
                "vtp_enableUseInternalVersion": false,
                "vtp_enableFirebaseCampaignData": true,
                "vtp_enableGA4Schema": false,
                "tag_id": 84
            }, {
                "function": "__ua",
                "once_per_event": true,
                "vtp_nonInteraction": false,
                "vtp_overrideGaSettings": true,
                "vtp_useEcommerceDataLayer": false,
                "vtp_ecommerceMacroData": ["macro", 60],
                "vtp_eventCategory": "tracking",
                "vtp_trackType": "TRACK_EVENT",
                "vtp_gaSettings": ["macro", 64],
                "vtp_eventAction": "purchase",
                "vtp_eventLabel": ["macro", 61],
                "vtp_enableEcommerce": true,
                "vtp_enableRecaptchaOption": false,
                "vtp_enableUaRlsa": false,
                "vtp_enableUseInternalVersion": false,
                "vtp_enableFirebaseCampaignData": true,
                "vtp_ecommerceIsEnabled": true,
                "vtp_trackTypeIsEvent": true,
                "vtp_enableGA4Schema": false,
                "tag_id": 85
            }, {
                "function": "__paused",
                "vtp_originalTagType": "ua",
                "tag_id": 86
            }, {
                "function": "__ua",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_nonInteraction": false,
                "vtp_overrideGaSettings": true,
                "vtp_eventCategory": "register",
                "vtp_trackType": "TRACK_EVENT",
                "vtp_gaSettings": ["macro", 64],
                "vtp_eventAction": ["macro", 58],
                "vtp_eventLabel": ["macro", 13],
                "vtp_dimension": ["list", ["map", "index", "1", "dimension", ["macro", 13]]],
                "vtp_enableRecaptchaOption": false,
                "vtp_enableUaRlsa": false,
                "vtp_enableUseInternalVersion": false,
                "vtp_enableFirebaseCampaignData": true,
                "vtp_trackTypeIsEvent": true,
                "vtp_enableGA4Schema": false,
                "tag_id": 87
            }, {
                "function": "__paused",
                "vtp_originalTagType": "html",
                "tag_id": 88
            }, {
                "function": "__paused",
                "vtp_originalTagType": "html",
                "tag_id": 89
            }, {
                "function": "__paused",
                "vtp_originalTagType": "html",
                "tag_id": 90
            }, {
                "function": "__paused",
                "vtp_originalTagType": "html",
                "tag_id": 91
            }, {
                "function": "__paused",
                "vtp_originalTagType": "html",
                "tag_id": 92
            }, {
                "function": "__ua",
                "metadata": ["map"],
                "once_per_load": true,
                "vtp_overrideGaSettings": false,
                "vtp_trackType": "TRACK_PAGEVIEW",
                "vtp_gaSettings": ["macro", 66],
                "vtp_enableRecaptchaOption": false,
                "vtp_enableUaRlsa": false,
                "vtp_enableUseInternalVersion": false,
                "vtp_enableFirebaseCampaignData": true,
                "vtp_enableGA4Schema": false,
                "tag_id": 96
            }, {
                "function": "__paused",
                "vtp_originalTagType": "html",
                "tag_id": 97
            }, {
                "function": "__paused",
                "vtp_originalTagType": "html",
                "tag_id": 98
            }, {
                "function": "__ua",
                "once_per_event": true,
                "vtp_nonInteraction": false,
                "vtp_overrideGaSettings": true,
                "vtp_useEcommerceDataLayer": false,
                "vtp_ecommerceMacroData": ["macro", 74],
                "vtp_eventCategory": "tracking",
                "vtp_trackType": "TRACK_EVENT",
                "vtp_gaSettings": ["macro", 34],
                "vtp_eventAction": "remove_from_cart",
                "vtp_enableEcommerce": true,
                "vtp_enableRecaptchaOption": false,
                "vtp_enableUaRlsa": false,
                "vtp_enableUseInternalVersion": false,
                "vtp_enableFirebaseCampaignData": true,
                "vtp_ecommerceIsEnabled": true,
                "vtp_trackTypeIsEvent": true,
                "vtp_enableGA4Schema": false,
                "tag_id": 100
            }, {
                "function": "__paused",
                "vtp_originalTagType": "html",
                "tag_id": 101
            }, {
                "function": "__paused",
                "vtp_originalTagType": "html",
                "tag_id": 102
            }, {
                "function": "__paused",
                "vtp_originalTagType": "ua",
                "tag_id": 103
            }, {
                "function": "__paused",
                "vtp_originalTagType": "html",
                "tag_id": 104
            }, {
                "function": "__ua",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_overrideGaSettings": true,
                "vtp_trackType": "TRACK_PAGEVIEW",
                "vtp_gaSettings": ["macro", 66],
                "vtp_enableRecaptchaOption": false,
                "vtp_enableUaRlsa": false,
                "vtp_enableUseInternalVersion": false,
                "vtp_enableFirebaseCampaignData": true,
                "vtp_enableGA4Schema": false,
                "tag_id": 106
            }, {
                "function": "__ua",
                "once_per_event": true,
                "vtp_nonInteraction": false,
                "vtp_overrideGaSettings": true,
                "vtp_eventCategory": "login",
                "vtp_trackType": "TRACK_EVENT",
                "vtp_gaSettings": ["macro", 34],
                "vtp_eventAction": ["macro", 76],
                "vtp_eventLabel": ["macro", 13],
                "vtp_dimension": ["list", ["map", "index", "1", "dimension", ["macro", 13]]],
                "vtp_enableRecaptchaOption": false,
                "vtp_enableUaRlsa": false,
                "vtp_enableUseInternalVersion": false,
                "vtp_enableFirebaseCampaignData": true,
                "vtp_trackTypeIsEvent": true,
                "vtp_enableGA4Schema": false,
                "tag_id": 107
            }, {
                "function": "__ua",
                "once_per_event": true,
                "vtp_nonInteraction": false,
                "vtp_overrideGaSettings": true,
                "vtp_eventCategory": "login",
                "vtp_trackType": "TRACK_EVENT",
                "vtp_gaSettings": ["macro", 34],
                "vtp_eventAction": ["macro", 77],
                "vtp_eventLabel": ["macro", 13],
                "vtp_dimension": ["list", ["map", "index", "1", "dimension", ["macro", 13]]],
                "vtp_enableRecaptchaOption": false,
                "vtp_enableUaRlsa": false,
                "vtp_enableUseInternalVersion": false,
                "vtp_enableFirebaseCampaignData": true,
                "vtp_trackTypeIsEvent": true,
                "vtp_enableGA4Schema": false,
                "tag_id": 108
            }, {
                "function": "__paused",
                "vtp_originalTagType": "html",
                "tag_id": 109
            }, {
                "function": "__paused",
                "vtp_originalTagType": "html",
                "tag_id": 110
            }, {
                "function": "__paused",
                "vtp_originalTagType": "img",
                "tag_id": 118
            }, {
                "function": "__ua",
                "metadata": ["map"],
                "once_per_load": true,
                "vtp_overrideGaSettings": false,
                "vtp_trackType": "TRACK_PAGEVIEW",
                "vtp_gaSettings": ["macro", 79],
                "vtp_enableRecaptchaOption": false,
                "vtp_enableUaRlsa": false,
                "vtp_enableUseInternalVersion": false,
                "vtp_enableFirebaseCampaignData": true,
                "vtp_enableGA4Schema": false,
                "tag_id": 120
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u31", "value", ["macro", 13]],
                    ["map", "key", "u33", "value", ["macro", 76]]
                ],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "id-w-lm",
                "vtp_ordinalType": "STANDARD",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9469210",
                "vtp_ordinalStandard": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 121
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u30", "value", ["macro", 58]],
                    ["map", "key", "u31", "value", ["macro", 13]]
                ],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "id-w-ss",
                "vtp_ordinalType": "UNIQUE",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9469210",
                "vtp_ordinalUnique": "1",
                "vtp_number": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 123
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u31", "value", ["macro", 13]],
                    ["map", "key", "u32", "value", ["macro", 77]]
                ],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "id-w-ld",
                "vtp_ordinalType": "STANDARD",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9469210",
                "vtp_ordinalStandard": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 124
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u49", "value", ["macro", 82]],
                    ["map", "key", "u50", "value", ["macro", 83]]
                ],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "id-w-sit",
                "vtp_ordinalType": "STANDARD",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9469210",
                "vtp_ordinalStandard": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 125
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u28", "value", ["macro", 84]],
                    ["map", "key", "u29", "value", ["macro", 62]]
                ],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "id-w-pg",
                "vtp_ordinalType": "STANDARD",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9469210",
                "vtp_ordinalStandard": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 126
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "id-w-pv",
                "vtp_ordinalType": "STANDARD",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9469210",
                "vtp_ordinalStandard": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 127
            }, {
                "function": "__fls",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u40", "value", ["macro", 67]],
                    ["map", "key", "u41", "value", ["macro", 68]],
                    ["map", "key", "u42", "value", ["macro", 71]],
                    ["map", "key", "u43", "value", ["macro", 72]],
                    ["map", "key", "u44", "value", ["macro", 73]],
                    ["map", "key", "u45", "value", ["macro", 70]]
                ],
                "vtp_revenue": ["macro", 71],
                "vtp_enableConversionLinker": true,
                "vtp_countingMethod": "TRANSACTIONS",
                "vtp_orderId": ["macro", 68],
                "vtp_enableProductReporting": false,
                "vtp_groupTag": "sconv",
                "vtp_useImageTag": false,
                "vtp_activityTag": "id-w-rc",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9469210",
                "vtp_countingMethodIsTransactions": true,
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 128
            }, {
                "function": "__fls",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u34", "value", ["macro", 49]],
                    ["map", "key", "u35", "value", ["macro", 50]],
                    ["map", "key", "u36", "value", ["macro", 53]],
                    ["map", "key", "u37", "value", ["macro", 54]],
                    ["map", "key", "u38", "value", ["macro", 55]],
                    ["map", "key", "u39", "value", ["macro", 52]]
                ],
                "vtp_revenue": ["macro", 53],
                "vtp_enableConversionLinker": true,
                "vtp_countingMethod": "TRANSACTIONS",
                "vtp_orderId": ["macro", 50],
                "vtp_enableProductReporting": false,
                "vtp_groupTag": "sconv",
                "vtp_useImageTag": false,
                "vtp_activityTag": "id-w-ac",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9469210",
                "vtp_countingMethodIsTransactions": true,
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 129
            }, {
                "function": "__fls",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u46", "value", ["macro", 61]],
                    ["map", "key", "u47", "value", ["macro", 45]],
                    ["map", "key", "u48", "value", ["macro", 59]]
                ],
                "vtp_revenue": ["macro", 59],
                "vtp_enableConversionLinker": true,
                "vtp_countingMethod": "TRANSACTIONS",
                "vtp_orderId": ["macro", 61],
                "vtp_enableProductReporting": false,
                "vtp_groupTag": "fconv",
                "vtp_useImageTag": false,
                "vtp_activityTag": "id-w-po",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9469210",
                "vtp_countingMethodIsTransactions": true,
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 130
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "my-w-pv",
                "vtp_ordinalType": "STANDARD",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9526848",
                "vtp_ordinalStandard": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 131
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_customVariable": ["list", ["map", "key", "u31", "value", ["macro", 13]],
                    ["map", "key", "u32", "value", ["macro", 77]]
                ],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "my-w-ld",
                "vtp_ordinalType": "STANDARD",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9526848",
                "vtp_ordinalStandard": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 134
            }, {
                "function": "__fls",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_customVariable": ["list", ["map", "key", "u34", "value", ["macro", 49]],
                    ["map", "key", "u35", "value", ["macro", 50]],
                    ["map", "key", "u36", "value", ["macro", 53]],
                    ["map", "key", "u37", "value", ["macro", 54]],
                    ["map", "key", "u38", "value", ["macro", 55]],
                    ["map", "key", "u39", "value", ["macro", 52]]
                ],
                "vtp_revenue": ["macro", 53],
                "vtp_enableConversionLinker": true,
                "vtp_countingMethod": "TRANSACTIONS",
                "vtp_orderId": ["macro", 50],
                "vtp_enableProductReporting": false,
                "vtp_groupTag": "sconv",
                "vtp_useImageTag": false,
                "vtp_activityTag": "my-w-ac",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9526848",
                "vtp_countingMethodIsTransactions": true,
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 135
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_customVariable": ["list", ["map", "key", "u31", "value", ["macro", 13]],
                    ["map", "key", "u33", "value", ["macro", 76]]
                ],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "my-w-lm",
                "vtp_ordinalType": "STANDARD",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9526848",
                "vtp_ordinalStandard": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 136
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u49", "value", ["macro", 82]],
                    ["map", "key", "u50", "value", ["macro", 83]]
                ],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "my-w-sit",
                "vtp_ordinalType": "STANDARD",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9526848",
                "vtp_ordinalStandard": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 137
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u30", "value", ["macro", 58]],
                    ["map", "key", "u31", "value", ["macro", 13]]
                ],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "my-w-ss",
                "vtp_ordinalType": "UNIQUE",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9526848",
                "vtp_ordinalUnique": "1",
                "vtp_number": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 138
            }, {
                "function": "__fls",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u46", "value", ["macro", 61]],
                    ["map", "key", "u47", "value", ["macro", 45]],
                    ["map", "key", "u48", "value", ["macro", 59]]
                ],
                "vtp_revenue": ["macro", 59],
                "vtp_enableConversionLinker": true,
                "vtp_countingMethod": "TRANSACTIONS",
                "vtp_orderId": ["macro", 61],
                "vtp_enableProductReporting": false,
                "vtp_groupTag": "fconv",
                "vtp_useImageTag": false,
                "vtp_activityTag": "my-w-po",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9526848",
                "vtp_countingMethodIsTransactions": true,
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 139
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_customVariable": ["list", ["map", "key", "u28", "value", ["macro", 84]],
                    ["map", "key", "u29", "value", ["macro", 62]]
                ],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "my-w-pg",
                "vtp_ordinalType": "STANDARD",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9526848",
                "vtp_ordinalStandard": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 140
            }, {
                "function": "__fls",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u40", "value", ["macro", 67]],
                    ["map", "key", "u41", "value", ["macro", 68]],
                    ["map", "key", "u42", "value", ["macro", 71]],
                    ["map", "key", "u43", "value", ["macro", 72]],
                    ["map", "key", "u44", "value", ["macro", 73]],
                    ["map", "key", "u45", "value", ["macro", 70]]
                ],
                "vtp_revenue": ["macro", 71],
                "vtp_enableConversionLinker": true,
                "vtp_countingMethod": "TRANSACTIONS",
                "vtp_orderId": ["macro", 68],
                "vtp_enableProductReporting": false,
                "vtp_groupTag": "sconv",
                "vtp_useImageTag": false,
                "vtp_activityTag": "my-w-rc",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9526848",
                "vtp_countingMethodIsTransactions": true,
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 141
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_customVariable": ["list", ["map", "key", "u28", "value", ["macro", 84]],
                    ["map", "key", "u29", "value", ["macro", 62]]
                ],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "ph-w-pg",
                "vtp_ordinalType": "STANDARD",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9554009",
                "vtp_ordinalStandard": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 142
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u30", "value", ["macro", 58]],
                    ["map", "key", "u31", "value", ["macro", 13]]
                ],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "ph-w-ss",
                "vtp_ordinalType": "UNIQUE",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9554009",
                "vtp_ordinalUnique": "1",
                "vtp_number": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 143
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_customVariable": ["list", ["map", "key", "u31", "value", ["macro", 13]],
                    ["map", "key", "u32", "value", ["macro", 77]]
                ],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "ph-w-ld",
                "vtp_ordinalType": "STANDARD",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9554009",
                "vtp_ordinalStandard": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 144
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_customVariable": ["list", ["map", "key", "u31", "value", ["macro", 13]],
                    ["map", "key", "u33", "value", ["macro", 76]]
                ],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "ph-w-lm",
                "vtp_ordinalType": "STANDARD",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9554009",
                "vtp_ordinalStandard": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 145
            }, {
                "function": "__fls",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u46", "value", ["macro", 61]],
                    ["map", "key", "u47", "value", ["macro", 45]],
                    ["map", "key", "u48", "value", ["macro", 59]]
                ],
                "vtp_revenue": ["macro", 59],
                "vtp_enableConversionLinker": true,
                "vtp_countingMethod": "TRANSACTIONS",
                "vtp_orderId": ["macro", 61],
                "vtp_enableProductReporting": false,
                "vtp_groupTag": "fconv",
                "vtp_useImageTag": false,
                "vtp_activityTag": "ph-w-po",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9554009",
                "vtp_countingMethodIsTransactions": true,
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 146
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u49", "value", ["macro", 82]],
                    ["map", "key", "u50", "value", ["macro", 83]]
                ],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "sg-w-sit",
                "vtp_ordinalType": "STANDARD",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9554009",
                "vtp_ordinalStandard": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 147
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "ph-w-pv",
                "vtp_ordinalType": "STANDARD",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9554009",
                "vtp_ordinalStandard": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 148
            }, {
                "function": "__fls",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_customVariable": ["list", ["map", "key", "u34", "value", ["macro", 49]],
                    ["map", "key", "u35", "value", ["macro", 50]],
                    ["map", "key", "u36", "value", ["macro", 53]],
                    ["map", "key", "u37", "value", ["macro", 54]],
                    ["map", "key", "u38", "value", ["macro", 55]],
                    ["map", "key", "u39", "value", ["macro", 52]]
                ],
                "vtp_revenue": ["macro", 53],
                "vtp_enableConversionLinker": true,
                "vtp_countingMethod": "TRANSACTIONS",
                "vtp_orderId": ["macro", 50],
                "vtp_enableProductReporting": false,
                "vtp_groupTag": "sconv",
                "vtp_useImageTag": false,
                "vtp_activityTag": "ph-w-ac",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9554009",
                "vtp_countingMethodIsTransactions": true,
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 149
            }, {
                "function": "__fls",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u40", "value", ["macro", 67]],
                    ["map", "key", "u41", "value", ["macro", 68]],
                    ["map", "key", "u42", "value", ["macro", 71]],
                    ["map", "key", "u43", "value", ["macro", 72]],
                    ["map", "key", "u44", "value", ["macro", 73]],
                    ["map", "key", "u45", "value", ["macro", 70]]
                ],
                "vtp_revenue": ["macro", 71],
                "vtp_enableConversionLinker": true,
                "vtp_countingMethod": "TRANSACTIONS",
                "vtp_orderId": ["macro", 68],
                "vtp_enableProductReporting": false,
                "vtp_groupTag": "sconv",
                "vtp_useImageTag": false,
                "vtp_activityTag": "ph-w-rc",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9554009",
                "vtp_countingMethodIsTransactions": true,
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 150
            }, {
                "function": "__fls",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_customVariable": ["list", ["map", "key", "u34", "value", ["macro", 49]],
                    ["map", "key", "u35", "value", ["macro", 50]],
                    ["map", "key", "u36", "value", ["macro", 53]],
                    ["map", "key", "u37", "value", ["macro", 54]],
                    ["map", "key", "u38", "value", ["macro", 55]],
                    ["map", "key", "u39", "value", ["macro", 52]]
                ],
                "vtp_revenue": ["macro", 53],
                "vtp_enableConversionLinker": true,
                "vtp_countingMethod": "TRANSACTIONS",
                "vtp_orderId": ["macro", 50],
                "vtp_enableProductReporting": false,
                "vtp_groupTag": "sconv",
                "vtp_useImageTag": false,
                "vtp_activityTag": "sg-w-ac",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9555544",
                "vtp_countingMethodIsTransactions": true,
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 151
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u49", "value", ["macro", 82]],
                    ["map", "key", "u50", "value", ["macro", 83]]
                ],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "sg-w-sit",
                "vtp_ordinalType": "STANDARD",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9555544",
                "vtp_ordinalStandard": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 152
            }, {
                "function": "__fls",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u40", "value", ["macro", 67]],
                    ["map", "key", "u41", "value", ["macro", 68]],
                    ["map", "key", "u42", "value", ["macro", 71]],
                    ["map", "key", "u43", "value", ["macro", 72]],
                    ["map", "key", "u44", "value", ["macro", 73]],
                    ["map", "key", "u45", "value", ["macro", 70]]
                ],
                "vtp_revenue": ["macro", 71],
                "vtp_enableConversionLinker": true,
                "vtp_countingMethod": "TRANSACTIONS",
                "vtp_orderId": ["macro", 68],
                "vtp_enableProductReporting": false,
                "vtp_groupTag": "sconv",
                "vtp_useImageTag": false,
                "vtp_activityTag": "sg-w-rc",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9555544",
                "vtp_countingMethodIsTransactions": true,
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 153
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "sg-w-pv",
                "vtp_ordinalType": "STANDARD",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9555544",
                "vtp_ordinalStandard": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 154
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u30", "value", ["macro", 58]],
                    ["map", "key", "u31", "value", ["macro", 13]]
                ],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "sg-w-ss",
                "vtp_ordinalType": "UNIQUE",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9555544",
                "vtp_ordinalUnique": "1",
                "vtp_number": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 155
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_customVariable": ["list", ["map", "key", "u31", "value", ["macro", 13]],
                    ["map", "key", "u32", "value", ["macro", 77]]
                ],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "sg-w-ld",
                "vtp_ordinalType": "STANDARD",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9555544",
                "vtp_ordinalStandard": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 156
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u31", "value", ["macro", 13]],
                    ["map", "key", "u33", "value", ["macro", 76]]
                ],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "sg-w-lm",
                "vtp_ordinalType": "STANDARD",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9555544",
                "vtp_ordinalStandard": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 157
            }, {
                "function": "__fls",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u46", "value", ["macro", 61]],
                    ["map", "key", "u47", "value", ["macro", 45]],
                    ["map", "key", "u48", "value", ["macro", 59]]
                ],
                "vtp_revenue": ["macro", 59],
                "vtp_enableConversionLinker": true,
                "vtp_countingMethod": "TRANSACTIONS",
                "vtp_orderId": ["macro", 61],
                "vtp_enableProductReporting": false,
                "vtp_groupTag": "fconv",
                "vtp_useImageTag": false,
                "vtp_activityTag": "sg-w-po",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9555544",
                "vtp_countingMethodIsTransactions": true,
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 158
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_customVariable": ["list", ["map", "key", "u28", "value", ["macro", 84]],
                    ["map", "key", "u29", "value", ["macro", 62]]
                ],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "sg-w-pg",
                "vtp_ordinalType": "STANDARD",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9555544",
                "vtp_ordinalStandard": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 159
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u31", "value", ["macro", 13]],
                    ["map", "key", "u33", "value", ["macro", 76]]
                ],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "th-w-lm",
                "vtp_ordinalType": "STANDARD",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9527148",
                "vtp_ordinalStandard": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 160
            }, {
                "function": "__fls",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u46", "value", ["macro", 61]],
                    ["map", "key", "u47", "value", ["macro", 45]],
                    ["map", "key", "u48", "value", ["macro", 59]]
                ],
                "vtp_revenue": ["macro", 59],
                "vtp_enableConversionLinker": true,
                "vtp_countingMethod": "TRANSACTIONS",
                "vtp_orderId": ["macro", 61],
                "vtp_enableProductReporting": false,
                "vtp_groupTag": "fconv",
                "vtp_useImageTag": false,
                "vtp_activityTag": "th-w-po",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9527148",
                "vtp_countingMethodIsTransactions": true,
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 161
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u30", "value", ["macro", 58]],
                    ["map", "key", "u31", "value", ["macro", 13]]
                ],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "th-w-ss",
                "vtp_ordinalType": "UNIQUE",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9527148",
                "vtp_ordinalUnique": "1",
                "vtp_number": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 163
            }, {
                "function": "__fls",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u40", "value", ["macro", 67]],
                    ["map", "key", "u41", "value", ["macro", 68]],
                    ["map", "key", "u42", "value", ["macro", 71]],
                    ["map", "key", "u43", "value", ["macro", 72]],
                    ["map", "key", "u44", "value", ["macro", 73]],
                    ["map", "key", "u45", "value", ["macro", 70]]
                ],
                "vtp_revenue": ["macro", 71],
                "vtp_enableConversionLinker": true,
                "vtp_countingMethod": "TRANSACTIONS",
                "vtp_orderId": ["macro", 68],
                "vtp_enableProductReporting": false,
                "vtp_groupTag": "sconv",
                "vtp_useImageTag": false,
                "vtp_activityTag": "th-w-rc",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9527148",
                "vtp_countingMethodIsTransactions": true,
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 164
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u49", "value", ["macro", 82]],
                    ["map", "key", "u50", "value", ["macro", 83]]
                ],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "th-w-sit",
                "vtp_ordinalType": "STANDARD",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9527148",
                "vtp_ordinalStandard": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 165
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "th-w-pv",
                "vtp_ordinalType": "STANDARD",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9527148",
                "vtp_ordinalStandard": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 166
            }, {
                "function": "__fls",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_customVariable": ["list", ["map", "key", "u34", "value", ["macro", 49]],
                    ["map", "key", "u35", "value", ["macro", 50]],
                    ["map", "key", "u36", "value", ["macro", 53]],
                    ["map", "key", "u37", "value", ["macro", 54]],
                    ["map", "key", "u38", "value", ["macro", 55]],
                    ["map", "key", "u39", "value", ["macro", 52]]
                ],
                "vtp_revenue": ["macro", 53],
                "vtp_enableConversionLinker": true,
                "vtp_countingMethod": "TRANSACTIONS",
                "vtp_orderId": ["macro", 50],
                "vtp_enableProductReporting": false,
                "vtp_groupTag": "sconv",
                "vtp_useImageTag": false,
                "vtp_activityTag": "th-w-ac",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9527148",
                "vtp_countingMethodIsTransactions": true,
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 167
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u28", "value", ["macro", 84]],
                    ["map", "key", "u29", "value", ["macro", 62]]
                ],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "th-w-pg",
                "vtp_ordinalType": "STANDARD",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9527148",
                "vtp_ordinalStandard": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 168
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_customVariable": ["list", ["map", "key", "u31", "value", ["macro", 13]],
                    ["map", "key", "u32", "value", ["macro", 77]]
                ],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "th-w-ld",
                "vtp_ordinalType": "STANDARD",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9527148",
                "vtp_ordinalStandard": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 169
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u31", "value", ["macro", 13]],
                    ["map", "key", "u33", "value", ["macro", 76]]
                ],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "vn-w-lm",
                "vtp_ordinalType": "STANDARD",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9526557",
                "vtp_ordinalStandard": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 170
            }, {
                "function": "__fls",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u46", "value", ["macro", 61]],
                    ["map", "key", "u47", "value", ["macro", 45]],
                    ["map", "key", "u48", "value", ["macro", 59]]
                ],
                "vtp_revenue": ["macro", 59],
                "vtp_enableConversionLinker": true,
                "vtp_countingMethod": "TRANSACTIONS",
                "vtp_orderId": ["macro", 61],
                "vtp_enableProductReporting": false,
                "vtp_groupTag": "fconv",
                "vtp_useImageTag": false,
                "vtp_activityTag": "vn-w-po",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9526557",
                "vtp_countingMethodIsTransactions": true,
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 171
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u49", "value", ["macro", 82]],
                    ["map", "key", "u50", "value", ["macro", 83]]
                ],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "vn-w-sit",
                "vtp_ordinalType": "STANDARD",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9526557",
                "vtp_ordinalStandard": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 172
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u30", "value", ["macro", 58]],
                    ["map", "key", "u31", "value", ["macro", 13]]
                ],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "vn-w-ss",
                "vtp_ordinalType": "UNIQUE",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9526557",
                "vtp_ordinalUnique": "1",
                "vtp_number": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 173
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u28", "value", ["macro", 84]],
                    ["map", "key", "u29", "value", ["macro", 62]]
                ],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "vn-w-pg",
                "vtp_ordinalType": "STANDARD",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9526557",
                "vtp_ordinalStandard": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 174
            }, {
                "function": "__fls",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_customVariable": ["list", ["map", "key", "u34", "value", ["macro", 49]],
                    ["map", "key", "u35", "value", ["macro", 50]],
                    ["map", "key", "u36", "value", ["macro", 53]],
                    ["map", "key", "u37", "value", ["macro", 54]],
                    ["map", "key", "u38", "value", ["macro", 55]],
                    ["map", "key", "u39", "value", ["macro", 52]]
                ],
                "vtp_revenue": ["macro", 53],
                "vtp_enableConversionLinker": true,
                "vtp_countingMethod": "TRANSACTIONS",
                "vtp_orderId": ["macro", 50],
                "vtp_enableProductReporting": false,
                "vtp_groupTag": "sconv",
                "vtp_useImageTag": false,
                "vtp_activityTag": "vn-w-ac",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9526557",
                "vtp_countingMethodIsTransactions": true,
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 175
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "vn-w-pv",
                "vtp_ordinalType": "STANDARD",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9526557",
                "vtp_ordinalStandard": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 176
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_customVariable": ["list", ["map", "key", "u31", "value", ["macro", 13]],
                    ["map", "key", "u32", "value", ["macro", 77]]
                ],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "vn-w-ld",
                "vtp_ordinalType": "STANDARD",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9526557",
                "vtp_ordinalStandard": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 177
            }, {
                "function": "__fls",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u40", "value", ["macro", 67]],
                    ["map", "key", "u41", "value", ["macro", 68]],
                    ["map", "key", "u42", "value", ["macro", 71]],
                    ["map", "key", "u43", "value", ["macro", 72]],
                    ["map", "key", "u44", "value", ["macro", 73]],
                    ["map", "key", "u45", "value", ["macro", 70]]
                ],
                "vtp_revenue": ["macro", 71],
                "vtp_enableConversionLinker": true,
                "vtp_countingMethod": "TRANSACTIONS",
                "vtp_orderId": ["macro", 68],
                "vtp_enableProductReporting": false,
                "vtp_groupTag": "sconv",
                "vtp_useImageTag": false,
                "vtp_activityTag": "vn-w-rc",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9526557",
                "vtp_countingMethodIsTransactions": true,
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 178
            }, {
                "function": "__gaawc",
                "metadata": ["map"],
                "once_per_load": true,
                "vtp_fieldsToSet": ["list", ["map", "name", "allowLinker", "value", "true"],
                    ["map", "name", "useAmpClientId", "value", "true"],
                    ["map", "name", "userId", "value", ["macro", 13]],
                    ["map", "name", "location", "value", ["macro", 21]]
                ],
                "vtp_sendPageView": true,
                "vtp_measurementId": "G-KK6LLGGZNQ",
                "vtp_enableUserProperties": true,
                "vtp_enableMoreSettings": true,
                "vtp_enableEuid": false,
                "tag_id": 179
            }, {
                "function": "__gaawc",
                "metadata": ["map"],
                "unlimited": true,
                "vtp_fieldsToSet": ["list", ["map", "name", "allowLinker", "value", "true"],
                    ["map", "name", "useAmpClientId", "value", "true"],
                    ["map", "name", "userId", "value", ["macro", 13]],
                    ["map", "name", "location", "value", ["macro", 21]],
                    ["map", "name", "page", "value", ["macro", 27]]
                ],
                "vtp_sendPageView": true,
                "vtp_measurementId": "G-KK6LLGGZNQ",
                "vtp_enableUserProperties": true,
                "vtp_enableMoreSettings": true,
                "vtp_enableEuid": false,
                "tag_id": 180
            }, {
                "function": "__paused",
                "vtp_originalTagType": "html",
                "tag_id": 181
            }, {
                "function": "__paused",
                "vtp_originalTagType": "html",
                "tag_id": 182
            }, {
                "function": "__paused",
                "vtp_originalTagType": "html",
                "tag_id": 183
            }, {
                "function": "__ua",
                "metadata": ["map"],
                "unlimited": true,
                "vtp_overrideGaSettings": true,
                "vtp_fieldsToSet": ["list", ["map", "fieldName", "title", "value", ["macro", 62]]],
                "vtp_trackType": "TRACK_PAGEVIEW",
                "vtp_gaSettings": ["macro", 79],
                "vtp_enableRecaptchaOption": false,
                "vtp_enableUaRlsa": false,
                "vtp_enableUseInternalVersion": false,
                "vtp_enableFirebaseCampaignData": true,
                "vtp_enableGA4Schema": false,
                "tag_id": 184
            }, {
                "function": "__ua",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_nonInteraction": false,
                "vtp_overrideGaSettings": true,
                "vtp_useEcommerceDataLayer": true,
                "vtp_eventCategory": "tracking",
                "vtp_trackType": "TRACK_EVENT",
                "vtp_gaSettings": ["macro", 64],
                "vtp_eventAction": "purchase",
                "vtp_eventLabel": ["macro", 87],
                "vtp_enableEcommerce": true,
                "vtp_enableRecaptchaOption": false,
                "vtp_enableUaRlsa": false,
                "vtp_enableUseInternalVersion": false,
                "vtp_enableFirebaseCampaignData": true,
                "vtp_ecommerceIsEnabled": true,
                "vtp_trackTypeIsEvent": true,
                "vtp_enableGA4Schema": false,
                "tag_id": 185
            }, {
                "function": "__paused",
                "vtp_originalTagType": "cvt_7691473_357",
                "tag_id": 186
            }, {
                "function": "__paused",
                "vtp_originalTagType": "cvt_7691473_357",
                "tag_id": 187
            }, {
                "function": "__paused",
                "vtp_originalTagType": "cvt_7691473_357",
                "tag_id": 188
            }, {
                "function": "__paused",
                "vtp_originalTagType": "cvt_7691473_357",
                "tag_id": 189
            }, {
                "function": "__paused",
                "vtp_originalTagType": "cvt_7691473_357",
                "tag_id": 190
            }, {
                "function": "__paused",
                "vtp_originalTagType": "cvt_7691473_357",
                "tag_id": 191
            }, {
                "function": "__paused",
                "vtp_originalTagType": "cvt_7691473_357",
                "tag_id": 192
            }, {
                "function": "__paused",
                "vtp_originalTagType": "cvt_7691473_357",
                "tag_id": 193
            }, {
                "function": "__ua",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_nonInteraction": false,
                "vtp_overrideGaSettings": true,
                "vtp_useEcommerceDataLayer": true,
                "vtp_eventCategory": "tracking",
                "vtp_trackType": "TRACK_EVENT",
                "vtp_gaSettings": ["macro", 34],
                "vtp_eventAction": "purchase",
                "vtp_eventLabel": ["macro", 87],
                "vtp_enableEcommerce": true,
                "vtp_enableRecaptchaOption": false,
                "vtp_enableUaRlsa": false,
                "vtp_enableUseInternalVersion": false,
                "vtp_enableFirebaseCampaignData": true,
                "vtp_ecommerceIsEnabled": true,
                "vtp_trackTypeIsEvent": true,
                "vtp_enableGA4Schema": false,
                "tag_id": 194
            }, {
                "function": "__ua",
                "metadata": ["map"],
                "unlimited": true,
                "vtp_overrideGaSettings": true,
                "vtp_fieldsToSet": ["list", ["map", "fieldName", "title", "value", ["macro", 62]]],
                "vtp_trackType": "TRACK_PAGEVIEW",
                "vtp_gaSettings": ["macro", 89],
                "vtp_enableRecaptchaOption": false,
                "vtp_enableUaRlsa": false,
                "vtp_enableUseInternalVersion": false,
                "vtp_enableFirebaseCampaignData": true,
                "vtp_enableGA4Schema": false,
                "tag_id": 195
            }, {
                "function": "__ua",
                "metadata": ["map"],
                "once_per_load": true,
                "vtp_overrideGaSettings": false,
                "vtp_trackType": "TRACK_PAGEVIEW",
                "vtp_gaSettings": ["macro", 89],
                "vtp_enableRecaptchaOption": false,
                "vtp_enableUaRlsa": false,
                "vtp_enableUseInternalVersion": false,
                "vtp_enableFirebaseCampaignData": true,
                "vtp_enableGA4Schema": false,
                "tag_id": 196
            }, {
                "function": "__ua",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_nonInteraction": false,
                "vtp_overrideGaSettings": false,
                "vtp_eventCategory": "myads-link-clicked",
                "vtp_trackType": "TRACK_EVENT",
                "vtp_gaSettings": ["macro", 89],
                "vtp_eventAction": ["macro", 15],
                "vtp_eventLabel": ["macro", 91],
                "vtp_enableRecaptchaOption": false,
                "vtp_enableUaRlsa": false,
                "vtp_enableUseInternalVersion": false,
                "vtp_enableFirebaseCampaignData": true,
                "vtp_trackTypeIsEvent": true,
                "vtp_enableGA4Schema": false,
                "tag_id": 197
            }, {
                "function": "__gaawc",
                "metadata": ["map"],
                "unlimited": true,
                "vtp_fieldsToSet": ["list", ["map", "name", "allowLinker", "value", "true"],
                    ["map", "name", "useAmpClientId", "value", "true"],
                    ["map", "name", "userId", "value", ["macro", 13]],
                    ["map", "name", "location", "value", ["macro", 21]],
                    ["map", "name", "page", "value", ["macro", 27]]
                ],
                "vtp_sendPageView": true,
                "vtp_measurementId": ["macro", 92],
                "vtp_enableUserProperties": true,
                "vtp_enableMoreSettings": true,
                "vtp_enableEuid": false,
                "tag_id": 392
            }, {
                "function": "__gaawc",
                "metadata": ["map"],
                "once_per_load": true,
                "vtp_fieldsToSet": ["list", ["map", "name", "allowLinker", "value", "true"],
                    ["map", "name", "useAmpClientId", "value", "true"],
                    ["map", "name", "userId", "value", ["macro", 13]],
                    ["map", "name", "location", "value", ["macro", 21]]
                ],
                "vtp_sendPageView": true,
                "vtp_measurementId": ["macro", 92],
                "vtp_enableUserProperties": true,
                "vtp_enableMoreSettings": true,
                "vtp_enableEuid": false,
                "tag_id": 393
            }, {
                "function": "__paused",
                "vtp_originalTagType": "html",
                "tag_id": 480
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u28", "value", ["macro", 84]],
                    ["map", "key", "u29", "value", ["macro", 62]]
                ],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "br-w-pg",
                "vtp_ordinalType": "STANDARD",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9895457",
                "vtp_ordinalStandard": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 510
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u30", "value", ["macro", 58]],
                    ["map", "key", "u31", "value", ["macro", 13]]
                ],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "br-w-ss",
                "vtp_ordinalType": "UNIQUE",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9895457",
                "vtp_ordinalUnique": "1",
                "vtp_number": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 511
            }, {
                "function": "__fls",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u40", "value", ["macro", 67]],
                    ["map", "key", "u41", "value", ["macro", 68]],
                    ["map", "key", "u42", "value", ["macro", 71]],
                    ["map", "key", "u43", "value", ["macro", 72]],
                    ["map", "key", "u44", "value", ["macro", 73]],
                    ["map", "key", "u45", "value", ["macro", 70]]
                ],
                "vtp_revenue": ["macro", 71],
                "vtp_enableConversionLinker": true,
                "vtp_countingMethod": "TRANSACTIONS",
                "vtp_orderId": ["macro", 68],
                "vtp_enableProductReporting": false,
                "vtp_groupTag": "s-conv",
                "vtp_useImageTag": false,
                "vtp_activityTag": "br-w-rc",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9895457",
                "vtp_countingMethodIsTransactions": true,
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 512
            }, {
                "function": "__fls",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u46", "value", ["macro", 61]],
                    ["map", "key", "u47", "value", ["macro", 45]],
                    ["map", "key", "u48", "value", ["macro", 59]]
                ],
                "vtp_revenue": ["macro", 59],
                "vtp_enableConversionLinker": true,
                "vtp_countingMethod": "TRANSACTIONS",
                "vtp_orderId": ["macro", 61],
                "vtp_enableProductReporting": false,
                "vtp_groupTag": "fconv",
                "vtp_useImageTag": false,
                "vtp_activityTag": "br-w-po",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9895457",
                "vtp_countingMethodIsTransactions": true,
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 513
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u31", "value", ["macro", 13]],
                    ["map", "key", "u32", "value", ["macro", 77]]
                ],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "br-w-ld",
                "vtp_ordinalType": "STANDARD",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9895457",
                "vtp_ordinalStandard": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 514
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "br-w-pv",
                "vtp_ordinalType": "STANDARD",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9895457",
                "vtp_ordinalStandard": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 515
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u31", "value", ["macro", 13]],
                    ["map", "key", "u33", "value", ["macro", 76]]
                ],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "br-w-lm",
                "vtp_ordinalType": "STANDARD",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9895457",
                "vtp_ordinalStandard": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 516
            }, {
                "function": "__fls",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u34", "value", ["macro", 49]],
                    ["map", "key", "u35", "value", ["macro", 50]],
                    ["map", "key", "u36", "value", ["macro", 53]],
                    ["map", "key", "u37", "value", ["macro", 54]],
                    ["map", "key", "u38", "value", ["macro", 55]],
                    ["map", "key", "u39", "value", ["macro", 52]]
                ],
                "vtp_revenue": ["macro", 53],
                "vtp_enableConversionLinker": true,
                "vtp_countingMethod": "TRANSACTIONS",
                "vtp_orderId": ["macro", 50],
                "vtp_enableProductReporting": false,
                "vtp_groupTag": "s-conv",
                "vtp_useImageTag": false,
                "vtp_activityTag": "br-w-ac",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9895457",
                "vtp_countingMethodIsTransactions": true,
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 517
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u49", "value", ["macro", 82]],
                    ["map", "key", "u50", "value", ["macro", 83]]
                ],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "br-w-sit",
                "vtp_ordinalType": "STANDARD",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "9895457",
                "vtp_ordinalStandard": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 518
            }, {
                "function": "__ua",
                "metadata": ["map"],
                "once_per_load": true,
                "vtp_overrideGaSettings": false,
                "vtp_trackType": "TRACK_PAGEVIEW",
                "vtp_gaSettings": ["macro", 94],
                "vtp_enableRecaptchaOption": false,
                "vtp_enableUaRlsa": false,
                "vtp_enableUseInternalVersion": false,
                "vtp_enableFirebaseCampaignData": true,
                "vtp_enableGA4Schema": false,
                "tag_id": 522
            }, {
                "function": "__ua",
                "metadata": ["map"],
                "unlimited": true,
                "vtp_overrideGaSettings": true,
                "vtp_fieldsToSet": ["list", ["map", "fieldName", "title", "value", ["macro", 62]]],
                "vtp_trackType": "TRACK_PAGEVIEW",
                "vtp_gaSettings": ["macro", 94],
                "vtp_enableRecaptchaOption": false,
                "vtp_enableUaRlsa": false,
                "vtp_enableUseInternalVersion": false,
                "vtp_enableFirebaseCampaignData": true,
                "vtp_enableGA4Schema": false,
                "tag_id": 525
            }, {
                "function": "__paused",
                "vtp_originalTagType": "html",
                "tag_id": 534
            }, {
                "function": "__fls",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u34", "value", ["macro", 49]],
                    ["map", "key", "u35", "value", ["macro", 50]],
                    ["map", "key", "u36", "value", ["macro", 53]],
                    ["map", "key", "u37", "value", ["macro", 54]],
                    ["map", "key", "u38", "value", ["macro", 55]],
                    ["map", "key", "u39", "value", ["macro", 52]]
                ],
                "vtp_revenue": ["macro", 53],
                "vtp_enableConversionLinker": true,
                "vtp_countingMethod": "TRANSACTIONS",
                "vtp_orderId": ["macro", 50],
                "vtp_enableProductReporting": false,
                "vtp_groupTag": "sconv",
                "vtp_useImageTag": false,
                "vtp_activityTag": "mx-w-ac",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "11057481",
                "vtp_countingMethodIsTransactions": true,
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 559
            }, {
                "function": "__fls",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u40", "value", ["macro", 67]],
                    ["map", "key", "u41", "value", ["macro", 68]],
                    ["map", "key", "u42", "value", ["macro", 71]],
                    ["map", "key", "u43", "value", ["macro", 72]],
                    ["map", "key", "u44", "value", ["macro", 73]],
                    ["map", "key", "u45", "value", ["macro", 70]]
                ],
                "vtp_revenue": ["macro", 71],
                "vtp_enableConversionLinker": true,
                "vtp_countingMethod": "TRANSACTIONS",
                "vtp_orderId": ["macro", 68],
                "vtp_enableProductReporting": false,
                "vtp_groupTag": "sconv",
                "vtp_useImageTag": false,
                "vtp_activityTag": "mx-w-rc",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "11057481",
                "vtp_countingMethodIsTransactions": true,
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 560
            }, {
                "function": "__fls",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u46", "value", ["macro", 61]],
                    ["map", "key", "u47", "value", ["macro", 45]],
                    ["map", "key", "u48", "value", ["macro", 59]]
                ],
                "vtp_revenue": ["macro", 59],
                "vtp_enableConversionLinker": true,
                "vtp_countingMethod": "TRANSACTIONS",
                "vtp_orderId": ["macro", 61],
                "vtp_enableProductReporting": false,
                "vtp_groupTag": "fconv",
                "vtp_useImageTag": false,
                "vtp_activityTag": "mx-w-po",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "11057481",
                "vtp_countingMethodIsTransactions": true,
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 561
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u49", "value", ["macro", 82]],
                    ["map", "key", "u50", "value", ["macro", 83]]
                ],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "mx-w-sit",
                "vtp_ordinalType": "STANDARD",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "11057481",
                "vtp_ordinalStandard": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 562
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u28", "value", ["macro", 84]],
                    ["map", "key", "u29", "value", ["macro", 62]]
                ],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "mx-w-pg",
                "vtp_ordinalType": "STANDARD",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "11057481",
                "vtp_ordinalStandard": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 563
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "mx-w-pv",
                "vtp_ordinalType": "STANDARD",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "11057481",
                "vtp_ordinalStandard": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 564
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u30", "value", ["macro", 58]],
                    ["map", "key", "u31", "value", ["macro", 13]]
                ],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "mx-w-ss",
                "vtp_ordinalType": "UNIQUE",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "11057481",
                "vtp_ordinalUnique": "1",
                "vtp_number": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 565
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u31", "value", ["macro", 13]],
                    ["map", "key", "u32", "value", ["macro", 77]]
                ],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "mx-w-ld",
                "vtp_ordinalType": "STANDARD",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "11057481",
                "vtp_ordinalStandard": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 566
            }, {
                "function": "__flc",
                "metadata": ["map"],
                "vtp_customVariable": ["list", ["map", "key", "u31", "value", ["macro", 13]],
                    ["map", "key", "u33", "value", ["macro", 76]]
                ],
                "vtp_enableConversionLinker": true,
                "vtp_groupTag": "eng",
                "vtp_useImageTag": false,
                "vtp_activityTag": "mx-w-lm",
                "vtp_ordinalType": "STANDARD",
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_advertiserId": "11057481",
                "vtp_ordinalStandard": ["macro", 80],
                "vtp_url": ["macro", 81],
                "vtp_enableGoogleAttributionOptions": false,
                "vtp_showConversionLinkingControls": true,
                "vtp_enableEnhancedConversions": false,
                "tag_id": 567
            }, {
                "function": "__awct",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_enableNewCustomerReporting": false,
                "vtp_enableConversionLinker": true,
                "vtp_enableProductReporting": false,
                "vtp_conversionCookiePrefix": "_gcl",
                "vtp_enableShippingData": false,
                "vtp_conversionId": "469734325",
                "vtp_conversionLabel": "zfC_CMDTvv0CELWn_t8B",
                "vtp_rdp": false,
                "vtp_url": ["macro", 81],
                "vtp_enableProductReportingCheckbox": true,
                "vtp_enableNewCustomerReportingCheckbox": true,
                "vtp_enableEnhancedConversionsCheckbox": false,
                "vtp_enableEnhancedConversionVariable": false,
                "vtp_enableRdpCheckbox": true,
                "vtp_enableTransportUrl": false,
                "vtp_enableShoppingQualitySettings": true,
                "tag_id": 589
            }, {
                "function": "__hl",
                "tag_id": 594
            }, {
                "function": "__tl",
                "vtp_eventName": "pageState",
                "vtp_interval": "3000",
                "vtp_uniqueTriggerId": "7691473_172",
                "tag_id": 595
            }, {
                "function": "__hl",
                "tag_id": 596
            }, {
                "function": "__hl",
                "tag_id": 597
            }, {
                "function": "__tl",
                "vtp_eventName": "gtm.timer",
                "vtp_interval": "5000",
                "vtp_uniqueTriggerId": "7691473_360",
                "tag_id": 598
            }, {
                "function": "__hl",
                "tag_id": 599
            }, {
                "function": "__hl",
                "tag_id": 600
            }, {
                "function": "__hl",
                "tag_id": 601
            }, {
                "function": "__cl",
                "tag_id": 602
            }, {
                "function": "__hl",
                "tag_id": 603
            }, {
                "function": "__hl",
                "tag_id": 604
            }, {
                "function": "__hl",
                "tag_id": 605
            }, {
                "function": "__hl",
                "tag_id": 606
            }, {
                "function": "__lcl",
                "vtp_waitForTags": false,
                "vtp_checkValidation": false,
                "vtp_waitForTagsTimeout": "2000",
                "vtp_uniqueTriggerId": "7691473_588",
                "tag_id": 607
            }, {
                "function": "__html",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_html": ["template", "\u003Cscript type=\"text\/gtmscript\"\u003Evar pid=\"mobile\"===", ["escape", ["macro", 98], 8, 16], "?\"item_m\":\"item\",data=", ["escape", ["macro", 100], 8, 16], ";(window._bwtm=window._bwtm||[]).push({ch:", ["escape", ["macro", 101], 8, 16], ",iid:", ["escape", ["macro", 44], 8, 16], ",uid:", ["escape", ["macro", 12], 8, 16], ",pid:pid,mid:422});\u003C\/script\u003E"],
                "vtp_supportDocumentWrite": false,
                "vtp_enableIframeMode": false,
                "vtp_enableEditJsMacroBehavior": false,
                "tag_id": 1
            }, {
                "function": "__html",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_html": "\u003Cscript async data-gtmsrc=\"\/\/rec.scupio.com\/recweb\/js\/rec.js\" type=\"text\/gtmscript\"\u003E\u003C\/script\u003E",
                "vtp_supportDocumentWrite": false,
                "vtp_enableIframeMode": false,
                "vtp_enableEditJsMacroBehavior": false,
                "tag_id": 7
            }, {
                "function": "__html",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_html": ["template", "\u003Cscript type=\"text\/gtmscript\"\u003Evar pid=\"mobile\"===", ["escape", ["macro", 98], 8, 16], "?\"home_m\":\"home\";(window._bwtm=window._bwtm||[]).push({mid:422,pid:pid,uid:", ["escape", ["macro", 12], 8, 16], "});\u003C\/script\u003E"],
                "vtp_supportDocumentWrite": false,
                "vtp_enableIframeMode": false,
                "vtp_enableEditJsMacroBehavior": false,
                "tag_id": 9
            }, {
                "function": "__html",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_html": ["template", "\u003Cscript type=\"text\/gtmscript\"\u003E\"cat2\"===", ["escape", ["macro", 103], 8, 16], "?(pid=\"mobile\"===", ["escape", ["macro", 98], 8, 16], "?\"cat2_m\":\"cat2\",ch=", ["escape", ["macro", 102], 8, 16], "):(pid=\"mobile\"===", ["escape", ["macro", 98], 8, 16], "?\"cat1_m\":\"cat1\",ch=", ["escape", ["macro", 104], 8, 16], ");(window._bwtm=window._bwtm||[]).push({mid:422,pid:pid,ch:ch,uid:", ["escape", ["macro", 12], 8, 16], "});\u003C\/script\u003E"],
                "vtp_supportDocumentWrite": false,
                "vtp_enableIframeMode": false,
                "vtp_enableEditJsMacroBehavior": false,
                "tag_id": 10
            }, {
                "function": "__html",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_html": ["template", "\u003Cscript type=\"text\/gtmscript\"\u003Evar pid=\"mobile\"===", ["escape", ["macro", 98], 8, 16], "?\"cart_m\":\"cart\";(window._bwtm=window._bwtm||[]).push({mid:422,pid:pid,carts:[{itemid:", ["escape", ["macro", 50], 8, 16], ",price:", ["escape", ["macro", 105], 8, 16], ",count:", ["escape", ["macro", 52], 8, 16], "}],uid:", ["escape", ["macro", 12], 8, 16], "});\u003C\/script\u003E\n\u003Cscript async data-gtmsrc=\"\/\/rec.scupio.com\/recweb\/js\/rec.js\" type=\"text\/gtmscript\"\u003E\u003C\/script\u003E"],
                "vtp_supportDocumentWrite": false,
                "vtp_enableIframeMode": false,
                "vtp_enableEditJsMacroBehavior": false,
                "tag_id": 11
            }, {
                "function": "__html",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_html": ["template", "\u003Cscript type=\"text\/gtmscript\"\u003Efor(var pid=\"mobile\"===", ["escape", ["macro", 98], 8, 16], "?\"buy_m\":\"buy\",orders=", ["escape", ["macro", 46], 8, 16], ",orderItems=[],i=0;i\u003Corders.length;i++)for(var j=0;j\u003Corders[i].items.length;j++)orderItems.push({itemid:orders[i].items[j].itemid,price:orders[i].items[j].price\/1E5,count:orders[i].items[j].quantity});(window._bwtm=window._bwtm||[]).push({mid:422,pid:pid,bitem:orderItems,uid:", ["escape", ["macro", 12], 8, 16], ",order:", ["escape", ["macro", 45], 8, 16], "});\u003C\/script\u003E\n\u003Cscript async data-gtmsrc=\"\/\/rec.scupio.com\/recweb\/js\/rec.js\" type=\"text\/gtmscript\"\u003E\u003C\/script\u003E"],
                "vtp_supportDocumentWrite": false,
                "vtp_enableIframeMode": false,
                "vtp_enableEditJsMacroBehavior": false,
                "tag_id": 12
            }, {
                "function": "__html",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_html": ["template", "\u003Cscript type=\"text\/gtmscript\"\u003Efor(var orderItems=", ["escape", ["macro", 46], 8, 16], ",totalPrice=0,i=0;i\u003CorderItems.length;i++)ga(\"gtm.ec:addProduct\",{id:orderItems[i].itemid,quantity:orderItems[i].quantity}),totalPrice+=orderItems[i].price\/1E5;ga(\"gtm.ec:setAction\",\"purchase\",{id:", ["escape", ["macro", 45], 8, 16], "+\"\",revenue:totalPrice});ga(\"gtm.send\",\"event\",\"tracking\",\"purchase\");\u003C\/script\u003E"],
                "vtp_supportDocumentWrite": false,
                "vtp_enableIframeMode": false,
                "vtp_enableEditJsMacroBehavior": false,
                "tag_id": 13
            }, {
                "function": "__html",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_html": ["template", "\u003Cscript type=\"text\/gtmscript\"\u003Evar pid=\"ios\"===", ["escape", ["macro", 98], 8, 16], "||\"android\"===", ["escape", ["macro", 98], 8, 16], "?\"search_m\":\"search\";(window._bwtm=window._bwtm||[]).push({mid:422,pid:pid,kw:", ["escape", ["macro", 82], 8, 16], ",uid:", ["escape", ["macro", 12], 8, 16], "});\u003C\/script\u003E\n"],
                "vtp_supportDocumentWrite": false,
                "vtp_enableIframeMode": false,
                "vtp_enableEditJsMacroBehavior": false,
                "tag_id": 14
            }, {
                "function": "__html",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_html": ["template", "\n\u003Cscript type=\"text\/gtmscript\"\u003E!function(b,e,f,g,a,c,d){b.fbq||(a=b.fbq=function(){a.callMethod?a.callMethod.apply(a,arguments):a.queue.push(arguments)},b._fbq||(b._fbq=a),a.push=a,a.loaded=!0,a.version=\"2.0\",a.queue=[],c=e.createElement(f),c.async=!0,c.src=g,d=e.getElementsByTagName(f)[0],d.parentNode.insertBefore(c,d))}(window,document,\"script\",\"\/\/connect.facebook.net\/en_US\/fbevents.js\");fbq(\"init\",", ["escape", ["macro", 106], 8, 16], ");fbq(\"track\",\"PageView\");\u003C\/script\u003E\n\u003Cnoscript\u003E\u003Cimg height=\"1\" width=\"1\" style=\"display:none\" src=\"https:\/\/www.facebook.com\/tr?id=", ["escape", ["macro", 106], 12], "\u0026amp;ev=PageView\u0026amp;noscript=1\"\u003E\u003C\/noscript\u003E\n"],
                "vtp_supportDocumentWrite": false,
                "vtp_enableIframeMode": false,
                "vtp_enableEditJsMacroBehavior": false,
                "tag_id": 39
            }, {
                "function": "__html",
                "setup_tags": ["list", ["tag", 186, 1]],
                "once_per_event": true,
                "vtp_html": ["template", "\u003Cscript type=\"text\/gtmscript\"\u003Efbq(\"track\",\"Search\",{search_string:\"", ["escape", ["macro", 82], 7], "\",content_ids:\"", ["escape", ["macro", 83], 7], "\",content_type:\"product\",content_category:\"Internal Site Search\"});\u003C\/script\u003E"],
                "vtp_supportDocumentWrite": false,
                "vtp_enableIframeMode": false,
                "vtp_enableEditJsMacroBehavior": false,
                "tag_id": 40
            }, {
                "function": "__html",
                "setup_tags": ["list", ["tag", 186, 1]],
                "once_per_event": true,
                "vtp_html": ["template", "\u003Cscript type=\"text\/gtmscript\"\u003Efbq(\"track\",\"ViewContent\",{value:", ["escape", ["macro", 108], 8, 16], ",currency:\"", ["escape", ["macro", 48], 7], "\",content_ids:\"", ["escape", ["macro", 44], 7], "\",content_type:\"product\"});\u003C\/script\u003E"],
                "vtp_supportDocumentWrite": false,
                "vtp_enableIframeMode": false,
                "vtp_enableEditJsMacroBehavior": false,
                "tag_id": 41
            }, {
                "function": "__html",
                "setup_tags": ["list", ["tag", 186, 1]],
                "once_per_event": true,
                "vtp_html": ["template", "\u003Cscript type=\"text\/gtmscript\"\u003Efbq(\"track\",\"AddToCart\",{value:", ["escape", ["macro", 53], 8, 16], ",currency:\"", ["escape", ["macro", 48], 7], "\",content_ids:\"", ["escape", ["macro", 50], 7], "\",content_type:\"product\",contents:[{id:\"", ["escape", ["macro", 50], 7], "\",quantity:", ["escape", ["macro", 52], 8, 16], ",item_price:", ["escape", ["macro", 105], 8, 16], "}]});\u003C\/script\u003E\n"],
                "vtp_supportDocumentWrite": false,
                "vtp_enableIframeMode": false,
                "vtp_enableEditJsMacroBehavior": false,
                "tag_id": 42
            }, {
                "function": "__html",
                "metadata": ["map"],
                "setup_tags": ["list", ["tag", 186, 1]],
                "once_per_event": true,
                "vtp_html": ["template", "\u003Cscript type=\"text\/gtmscript\"\u003Efbq(\"track\",\"Purchase\",{value:1*", ["escape", ["macro", 59], 8, 16], ",currency:\"", ["escape", ["macro", 48], 7], "\",content_ids:\"", ["escape", ["macro", 109], 7], "\",content_type:\"product\",contents:", ["escape", ["macro", 110], 8, 16], "});\u003C\/script\u003E"],
                "vtp_supportDocumentWrite": false,
                "vtp_enableIframeMode": false,
                "vtp_enableEditJsMacroBehavior": false,
                "tag_id": 43
            }, {
                "function": "__html",
                "setup_tags": ["list", ["tag", 186, 1]],
                "once_per_event": true,
                "vtp_html": ["template", "\u003Cscript type=\"text\/gtmscript\"\u003Efbq(\"trackCustom\",\"ViewCategory\",{content_name:\"", ["escape", ["macro", 111], 7], "\",content_category:\"", ["escape", ["macro", 104], 7], "\",content_ids:\"", ["escape", ["macro", 43], 7], "\",content_type:\"product\"});\u003C\/script\u003E"],
                "vtp_supportDocumentWrite": false,
                "vtp_enableIframeMode": false,
                "vtp_enableEditJsMacroBehavior": false,
                "tag_id": 44
            }, {
                "function": "__html",
                "setup_tags": ["list", ["tag", 186, 1]],
                "once_per_event": true,
                "vtp_html": "\u003Cscript type=\"text\/gtmscript\"\u003Efbq(\"track\",\"CompleteRegistration\");\u003C\/script\u003E\n",
                "vtp_supportDocumentWrite": false,
                "vtp_enableIframeMode": false,
                "vtp_enableEditJsMacroBehavior": false,
                "tag_id": 58
            }, {
                "function": "__html",
                "setup_tags": ["list", ["tag", 186, 1]],
                "once_per_event": true,
                "vtp_html": "\u003Cscript type=\"text\/gtmscript\"\u003Efbq(\"track\",\"AddPaymentInfo\");\u003C\/script\u003E\n",
                "vtp_supportDocumentWrite": false,
                "vtp_enableIframeMode": false,
                "vtp_enableEditJsMacroBehavior": false,
                "tag_id": 59
            }, {
                "function": "__html",
                "setup_tags": ["list", ["tag", 186, 1]],
                "once_per_event": true,
                "vtp_html": "\u003Cscript type=\"text\/gtmscript\"\u003Efbq(\"track\",\"InitiateCheckout\");\u003C\/script\u003E\n",
                "vtp_supportDocumentWrite": false,
                "vtp_enableIframeMode": false,
                "vtp_enableEditJsMacroBehavior": false,
                "tag_id": 60
            }, {
                "function": "__html",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_html": ["template", "\u003Cscript type=\"text\/gtmscript\"\u003E(window._bwtm=window._bwtm||[]).push({mid:422,uid:", ["escape", ["macro", 12], 8, 16], "});\u003C\/script\u003E\n"],
                "vtp_supportDocumentWrite": false,
                "vtp_enableIframeMode": false,
                "vtp_enableEditJsMacroBehavior": false,
                "tag_id": 70
            }, {
                "function": "__html",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_html": ["template", "\u003Cscript type=\"text\/gtmscript\"\u003Efunction track_keyToGet(){try{var a=get_key(p.keyToGet);null!==a?setCookie(p.cookieName,a):track_keyToSearch()}catch(b){console.warn(\"[medium_cookie_create][track_keyToGet]\",b)}}function track_keyToSearch(){try{var a=Object.entries(p.keyToSearch),b=!0;for(i=0;i\u003Ca.length;i++){var c=a[i],d=get_key(c[0]);if(null!==d){setCookie(p.cookieName,c[1]);b=!1;break}}b\u0026\u0026get_refer()}catch(e){console.warn(\"[medium_cookie_create][track_keyToSearch]\",e)}}\nfunction get_refer(){try{refer\u0026\u0026!shopee_refer_check.test(refer)\u0026\u0026setCookie(p.cookieName,\"refer\")}catch(a){console.warn(\"[medium_cookie_create][get_refer]\",a)}}function get_key(a){try{var b=window.location.href;a=\"[\\\\?\\x26]\"+a+\"\\x3d([^\\x26#]*)\";a=new RegExp(a);a=a.exec(b);return null==a?null:a[1]}catch(c){return console.warn(\"[medium_cookie_create][get_key]\",c),null}}\nfunction setCookie(a,b){try{var c=new Date;c.setTime(c.getTime()+864E5*p.cookieTime);var d=\";expires\\x3d\"+c.toUTCString();document.cookie=a+\"\\x3d\"+b+d+\";path\\x3d\"+p.path+\";domain\\x3d\"+p.domain}catch(e){return console.warn(\"[medium_cookie_create][setCookie]\",e),null}}try{var p=", ["escape", ["macro", 112], 8, 16], ",refer=", ["escape", ["macro", 113], 8, 16], ",shopee_refer_check=new RegExp(p.shopee_refer,\"i\");track_keyToGet()}catch(a){console.warn(\"[medium_cookie_create]\",a)};\u003C\/script\u003E\n"],
                "vtp_supportDocumentWrite": false,
                "vtp_enableIframeMode": false,
                "vtp_enableEditJsMacroBehavior": false,
                "tag_id": 78
            }, {
                "function": "__html",
                "once_per_event": true,
                "vtp_html": "\u003Cscript type=\"text\/gtmscript\"\u003E!function(){function k(a,b){b?(l[0]=l[16]=l[1]=l[2]=l[3]=l[4]=l[5]=l[6]=l[7]=l[8]=l[9]=l[10]=l[11]=l[12]=l[13]=l[14]=l[15]=0,this.blocks=l):this.blocks=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];a?(this.h0=3238371032,this.h1=914150663,this.h2=812702999,this.h3=4144912697,this.h4=4290775857,this.h5=1750603025,this.h6=1694076839,this.h7=3204075428):(this.h0=1779033703,this.h1=3144134277,this.h2=1013904242,this.h3=2773480762,this.h4=1359893119,this.h5=2600822924,this.h6=528734635,this.h7=1541459225);this.block=\nthis.start=this.bytes=this.hBytes=0;this.finalized=this.hashed=!1;this.first=!0;this.is224=a}function x(a,b,c){var f=typeof a;if(\"string\"===f){var e,m=[],d=a.length,g=0;for(f=0;f\u003Cd;++f)128\u003E(e=a.charCodeAt(f))?m[g++]=e:2048\u003Ee?(m[g++]=192|e\u003E\u003E6,m[g++]=128|63\u0026e):55296\u003Ee||57344\u003C=e?(m[g++]=224|e\u003E\u003E12,m[g++]=128|e\u003E\u003E6\u002663,m[g++]=128|63\u0026e):(e=65536+((1023\u0026e)\u003C\u003C10|1023\u0026a.charCodeAt(++f)),m[g++]=240|e\u003E\u003E18,m[g++]=128|e\u003E\u003E12\u002663,m[g++]=128|e\u003E\u003E6\u002663,m[g++]=128|63\u0026e);a=m}else{if(\"object\"!==f)throw Error(u);if(null===\na)throw Error(u);if(w\u0026\u0026a.constructor===ArrayBuffer)a=new Uint8Array(a);else if(!(Array.isArray(a)||w\u0026\u0026ArrayBuffer.isView(a)))throw Error(u);}64\u003Ca.length\u0026\u0026(a=(new k(b,!0)).update(a).array());e=[];m=[];for(f=0;64\u003Ef;++f)d=a[f]||0,e[f]=92^d,m[f]=54^d;k.call(this,b,c);this.update(m);this.oKeyPad=e;this.inner=!0;this.sharedMemory=c}var u=\"input is invalid type\",v=\"object\"==typeof window,p=v?window:{};p.JS_SHA256_NO_WINDOW\u0026\u0026(v=!1);v=!v\u0026\u0026\"object\"==typeof self;var A=!p.JS_SHA256_NO_NODE_JS\u0026\u0026\"object\"==typeof process\u0026\u0026\nprocess.versions\u0026\u0026process.versions.node;A?p=global:v\u0026\u0026(p=self);v=!p.JS_SHA256_NO_COMMON_JS\u0026\u0026\"object\"==typeof module\u0026\u0026module.exports;var F=\"function\"==typeof define\u0026\u0026define.amd,w=!p.JS_SHA256_NO_ARRAY_BUFFER\u0026\u0026\"undefined\"!=typeof ArrayBuffer,c=\"0123456789abcdef\".split(\"\"),G=[-2147483648,8388608,32768,128],n=[24,16,8,0],y=[1116352408,1899447441,3049323471,3921009573,961987163,1508970993,2453635748,2870763221,3624381080,310598401,607225278,1426881987,1925078388,2162078206,2614888103,3248222580,3835390401,\n4022224774,264347078,604807628,770255983,1249150122,1555081692,1996064986,2554220882,2821834349,2952996808,3210313671,3336571891,3584528711,113926993,338241895,666307205,773529912,1294757372,1396182291,1695183700,1986661051,2177026350,2456956037,2730485921,2820302411,3259730800,3345764771,3516065817,3600352804,4094571909,275423344,430227734,506948616,659060556,883997877,958139571,1322822218,1537002063,1747873779,1955562222,2024104815,2227730452,2361852424,2428436474,2756734187,3204031479,3329325298],\nz=[\"hex\",\"array\",\"digest\",\"arrayBuffer\"],l=[];!p.JS_SHA256_NO_NODE_JS\u0026\u0026Array.isArray||(Array.isArray=function(a){return\"[object Array]\"===Object.prototype.toString.call(a)});!w||!p.JS_SHA256_NO_ARRAY_BUFFER_IS_VIEW\u0026\u0026ArrayBuffer.isView||(ArrayBuffer.isView=function(a){return\"object\"==typeof a\u0026\u0026a.buffer\u0026\u0026a.buffer.constructor===ArrayBuffer});var B=function(a,b){return function(m){return(new k(b,!0)).update(m)[a]()}},C=function(a){var b=B(\"hex\",a);A\u0026\u0026(b=H(b,a));b.create=function(){return new k(a)};b.update=\nfunction(a){return b.create().update(a)};for(var m=0;m\u003Cz.length;++m){var c=z[m];b[c]=B(c,a)}return b},H=function(a,b){var c=eval(\"require('crypto')\"),f=eval(\"require('buffer').Buffer\"),e=b?\"sha224\":\"sha256\",h=function(b){if(\"string\"==typeof b)return c.createHash(e).update(b,\"utf8\").digest(\"hex\");if(null===b||void 0===b)throw Error(u);return b.constructor===ArrayBuffer\u0026\u0026(b=new Uint8Array(b)),Array.isArray(b)||ArrayBuffer.isView(b)||b.constructor===f?c.createHash(e).update(new f(b)).digest(\"hex\"):a(b)};\nreturn h},D=function(a,b){return function(c,f){return(new x(c,b,!0)).update(f)[a]()}},E=function(a){var b=D(\"hex\",a);b.create=function(b){return new x(b,a)};b.update=function(a,c){return b.create(a).update(c)};for(var c=0;c\u003Cz.length;++c){var f=z[c];b[f]=D(f,a)}return b};k.prototype.update=function(a){if(!this.finalized){var b=typeof a;if(\"string\"!==b){if(\"object\"!==b)throw Error(u);if(null===a)throw Error(u);if(w\u0026\u0026a.constructor===ArrayBuffer)a=new Uint8Array(a);else if(!(Array.isArray(a)||w\u0026\u0026ArrayBuffer.isView(a)))throw Error(u);\nvar c=!0}for(var f,e=0,h=a.length,d=this.blocks;e\u003Ch;){if(this.hashed\u0026\u0026(this.hashed=!1,d[0]=this.block,d[16]=d[1]=d[2]=d[3]=d[4]=d[5]=d[6]=d[7]=d[8]=d[9]=d[10]=d[11]=d[12]=d[13]=d[14]=d[15]=0),c)for(b=this.start;e\u003Ch\u0026\u002664\u003Eb;++e)d[b\u003E\u003E2]|=a[e]\u003C\u003Cn[3\u0026b++];else for(b=this.start;e\u003Ch\u0026\u002664\u003Eb;++e)128\u003E(f=a.charCodeAt(e))?d[b\u003E\u003E2]|=f\u003C\u003Cn[3\u0026b++]:2048\u003Ef?(d[b\u003E\u003E2]|=(192|f\u003E\u003E6)\u003C\u003Cn[3\u0026b++],d[b\u003E\u003E2]|=(128|63\u0026f)\u003C\u003Cn[3\u0026b++]):55296\u003Ef||57344\u003C=f?(d[b\u003E\u003E2]|=(224|f\u003E\u003E12)\u003C\u003Cn[3\u0026b++],d[b\u003E\u003E2]|=(128|f\u003E\u003E6\u002663)\u003C\u003Cn[3\u0026b++],d[b\u003E\u003E2]|=(128|63\u0026f)\u003C\u003C\nn[3\u0026b++]):(f=65536+((1023\u0026f)\u003C\u003C10|1023\u0026a.charCodeAt(++e)),d[b\u003E\u003E2]|=(240|f\u003E\u003E18)\u003C\u003Cn[3\u0026b++],d[b\u003E\u003E2]|=(128|f\u003E\u003E12\u002663)\u003C\u003Cn[3\u0026b++],d[b\u003E\u003E2]|=(128|f\u003E\u003E6\u002663)\u003C\u003Cn[3\u0026b++],d[b\u003E\u003E2]|=(128|63\u0026f)\u003C\u003Cn[3\u0026b++]);this.lastByteIndex=b;this.bytes+=b-this.start;64\u003C=b?(this.block=d[16],this.start=b-64,this.hash(),this.hashed=!0):this.start=b}return 4294967295\u003Cthis.bytes\u0026\u0026(this.hBytes+=this.bytes\/4294967296\u003C\u003C0,this.bytes%=4294967296),this}};k.prototype.finalize=function(){if(!this.finalized){this.finalized=!0;var a=this.blocks,\nb=this.lastByteIndex;a[16]=this.block;a[b\u003E\u003E2]|=G[3\u0026b];this.block=a[16];56\u003C=b\u0026\u0026(this.hashed||this.hash(),a[0]=this.block,a[16]=a[1]=a[2]=a[3]=a[4]=a[5]=a[6]=a[7]=a[8]=a[9]=a[10]=a[11]=a[12]=a[13]=a[14]=a[15]=0);a[14]=this.hBytes\u003C\u003C3|this.bytes\u003E\u003E\u003E29;a[15]=this.bytes\u003C\u003C3;this.hash()}};k.prototype.hash=function(){var a,b,c,f,e=this.h0,h=this.h1,d=this.h2,g=this.h3,k=this.h4,l=this.h5,r=this.h6,q=this.h7,n=this.blocks;for(a=16;64\u003Ea;++a){var p=((c=n[a-15])\u003E\u003E\u003E7|c\u003C\u003C25)^(c\u003E\u003E\u003E18|c\u003C\u003C14)^c\u003E\u003E\u003E3;var t=((c=n[a-2])\u003E\u003E\u003E\n17|c\u003C\u003C15)^(c\u003E\u003E\u003E19|c\u003C\u003C13)^c\u003E\u003E\u003E10;n[a]=n[a-16]+p+n[a-7]+t\u003C\u003C0}var u=h\u0026d;for(a=0;64\u003Ea;a+=4)this.first?(this.is224?(f=300032,q=(c=n[0]-1413257819)-150054599\u003C\u003C0,g=c+24177077\u003C\u003C0):(f=704751109,q=(c=n[0]-210244248)-1521486534\u003C\u003C0,g=c+143694565\u003C\u003C0),this.first=!1):(p=(e\u003E\u003E\u003E2|e\u003C\u003C30)^(e\u003E\u003E\u003E13|e\u003C\u003C19)^(e\u003E\u003E\u003E22|e\u003C\u003C10),b=(f=e\u0026h)^e\u0026d^u,q=g+(c=q+((k\u003E\u003E\u003E6|k\u003C\u003C26)^(k\u003E\u003E\u003E11|k\u003C\u003C21)^(k\u003E\u003E\u003E25|k\u003C\u003C7))+(k\u0026l^~k\u0026r)+y[a]+n[a])\u003C\u003C0,g=c+(p+b)\u003C\u003C0),p=(g\u003E\u003E\u003E2|g\u003C\u003C30)^(g\u003E\u003E\u003E13|g\u003C\u003C19)^(g\u003E\u003E\u003E22|g\u003C\u003C10),b=(u=g\u0026e)^g\u0026h^f,r=d+(c=r+((q\u003E\u003E\u003E6|q\u003C\u003C26)^(q\u003E\u003E\u003E11|\nq\u003C\u003C21)^(q\u003E\u003E\u003E25|q\u003C\u003C7))+(q\u0026k^~q\u0026l)+y[a+1]+n[a+1])\u003C\u003C0,p=((d=c+(p+b)\u003C\u003C0)\u003E\u003E\u003E2|d\u003C\u003C30)^(d\u003E\u003E\u003E13|d\u003C\u003C19)^(d\u003E\u003E\u003E22|d\u003C\u003C10),b=(t=d\u0026g)^d\u0026e^u,l=h+(c=l+((r\u003E\u003E\u003E6|r\u003C\u003C26)^(r\u003E\u003E\u003E11|r\u003C\u003C21)^(r\u003E\u003E\u003E25|r\u003C\u003C7))+(r\u0026q^~r\u0026k)+y[a+2]+n[a+2])\u003C\u003C0,p=((h=c+(p+b)\u003C\u003C0)\u003E\u003E\u003E2|h\u003C\u003C30)^(h\u003E\u003E\u003E13|h\u003C\u003C19)^(h\u003E\u003E\u003E22|h\u003C\u003C10),b=(u=h\u0026d)^h\u0026g^t,k=e+(c=k+((l\u003E\u003E\u003E6|l\u003C\u003C26)^(l\u003E\u003E\u003E11|l\u003C\u003C21)^(l\u003E\u003E\u003E25|l\u003C\u003C7))+(l\u0026r^~l\u0026q)+y[a+3]+n[a+3])\u003C\u003C0,e=c+(p+b)\u003C\u003C0;this.h0=this.h0+e\u003C\u003C0;this.h1=this.h1+h\u003C\u003C0;this.h2=this.h2+d\u003C\u003C0;this.h3=this.h3+g\u003C\u003C0;this.h4=this.h4+k\u003C\u003C0;this.h5=this.h5+\nl\u003C\u003C0;this.h6=this.h6+r\u003C\u003C0;this.h7=this.h7+q\u003C\u003C0};k.prototype.hex=function(){this.finalize();var a=this.h0,b=this.h1,m=this.h2,f=this.h3,e=this.h4,h=this.h5,d=this.h6,g=this.h7;a=c[a\u003E\u003E28\u002615]+c[a\u003E\u003E24\u002615]+c[a\u003E\u003E20\u002615]+c[a\u003E\u003E16\u002615]+c[a\u003E\u003E12\u002615]+c[a\u003E\u003E8\u002615]+c[a\u003E\u003E4\u002615]+c[15\u0026a]+c[b\u003E\u003E28\u002615]+c[b\u003E\u003E24\u002615]+c[b\u003E\u003E20\u002615]+c[b\u003E\u003E16\u002615]+c[b\u003E\u003E12\u002615]+c[b\u003E\u003E8\u002615]+c[b\u003E\u003E4\u002615]+c[15\u0026b]+c[m\u003E\u003E28\u002615]+c[m\u003E\u003E24\u002615]+c[m\u003E\u003E20\u002615]+c[m\u003E\u003E16\u002615]+c[m\u003E\u003E12\u002615]+c[m\u003E\u003E8\u002615]+c[m\u003E\u003E4\u002615]+c[15\u0026m]+c[f\u003E\u003E28\u002615]+c[f\u003E\u003E24\u002615]+c[f\u003E\u003E20\u002615]+c[f\u003E\u003E16\u002615]+c[f\u003E\u003E12\u0026\n15]+c[f\u003E\u003E8\u002615]+c[f\u003E\u003E4\u002615]+c[15\u0026f]+c[e\u003E\u003E28\u002615]+c[e\u003E\u003E24\u002615]+c[e\u003E\u003E20\u002615]+c[e\u003E\u003E16\u002615]+c[e\u003E\u003E12\u002615]+c[e\u003E\u003E8\u002615]+c[e\u003E\u003E4\u002615]+c[15\u0026e]+c[h\u003E\u003E28\u002615]+c[h\u003E\u003E24\u002615]+c[h\u003E\u003E20\u002615]+c[h\u003E\u003E16\u002615]+c[h\u003E\u003E12\u002615]+c[h\u003E\u003E8\u002615]+c[h\u003E\u003E4\u002615]+c[15\u0026h]+c[d\u003E\u003E28\u002615]+c[d\u003E\u003E24\u002615]+c[d\u003E\u003E20\u002615]+c[d\u003E\u003E16\u002615]+c[d\u003E\u003E12\u002615]+c[d\u003E\u003E8\u002615]+c[d\u003E\u003E4\u002615]+c[15\u0026d];return this.is224||(a+=c[g\u003E\u003E28\u002615]+c[g\u003E\u003E24\u002615]+c[g\u003E\u003E20\u002615]+c[g\u003E\u003E16\u002615]+c[g\u003E\u003E12\u002615]+c[g\u003E\u003E8\u002615]+c[g\u003E\u003E4\u002615]+c[15\u0026g]),a};k.prototype.toString=k.prototype.hex;k.prototype.digest=function(){this.finalize();\nvar a=this.h0,b=this.h1,c=this.h2,f=this.h3,e=this.h4,h=this.h5,d=this.h6,g=this.h7;a=[a\u003E\u003E24\u0026255,a\u003E\u003E16\u0026255,a\u003E\u003E8\u0026255,255\u0026a,b\u003E\u003E24\u0026255,b\u003E\u003E16\u0026255,b\u003E\u003E8\u0026255,255\u0026b,c\u003E\u003E24\u0026255,c\u003E\u003E16\u0026255,c\u003E\u003E8\u0026255,255\u0026c,f\u003E\u003E24\u0026255,f\u003E\u003E16\u0026255,f\u003E\u003E8\u0026255,255\u0026f,e\u003E\u003E24\u0026255,e\u003E\u003E16\u0026255,e\u003E\u003E8\u0026255,255\u0026e,h\u003E\u003E24\u0026255,h\u003E\u003E16\u0026255,h\u003E\u003E8\u0026255,255\u0026h,d\u003E\u003E24\u0026255,d\u003E\u003E16\u0026255,d\u003E\u003E8\u0026255,255\u0026d];return this.is224||a.push(g\u003E\u003E24\u0026255,g\u003E\u003E16\u0026255,g\u003E\u003E8\u0026255,255\u0026g),a};k.prototype.array=k.prototype.digest;k.prototype.arrayBuffer=function(){this.finalize();var a=new ArrayBuffer(this.is224?\n28:32),b=new DataView(a);return b.setUint32(0,this.h0),b.setUint32(4,this.h1),b.setUint32(8,this.h2),b.setUint32(12,this.h3),b.setUint32(16,this.h4),b.setUint32(20,this.h5),b.setUint32(24,this.h6),this.is224||b.setUint32(28,this.h7),a};x.prototype=new k;x.prototype.finalize=function(){if(k.prototype.finalize.call(this),this.inner){this.inner=!1;var a=this.array();k.call(this,this.is224,this.sharedMemory);this.update(this.oKeyPad);this.update(a);k.prototype.finalize.call(this)}};var t=C();t.sha256=\nt;t.sha224=C(!0);t.sha256.hmac=E();t.sha224.hmac=E(!0);v?module.exports=t:(p.sha256=t.sha256,p.sha224=t.sha224,F\u0026\u0026define(function(){return t}))}();\u003C\/script\u003E",
                "vtp_supportDocumentWrite": false,
                "vtp_enableIframeMode": false,
                "vtp_enableEditJsMacroBehavior": false,
                "tag_id": 105
            }, {
                "function": "__html",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_html": ["template", "\u003Ciframe src=\"https:\/\/asia.creativecdn.com\/tags?id=pr_", ["escape", ["macro", 114], 12], "_home\u0026amp;id=pr_", ["escape", ["macro", 114], 12], "_uid_", ["escape", ["macro", 13], 12], "\" width=\"1\" height=\"1\" scrolling=\"no\" frameborder=\"0\" style=\"display: none;\"\u003E\u003C\/iframe\u003E\n"],
                "vtp_supportDocumentWrite": false,
                "vtp_enableIframeMode": false,
                "vtp_enableEditJsMacroBehavior": false,
                "tag_id": 381
            }, {
                "function": "__html",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_html": ["template", "\u003Ciframe src=\"https:\/\/asia.creativecdn.com\/tags?id=pr_", ["escape", ["macro", 114], 12], "_category2_", ["escape", ["macro", 104], 12], "\u0026amp;id=pr_", ["escape", ["macro", 114], 12], "_uid_", ["escape", ["macro", 13], 12], "\" width=\"1\" height=\"1\" scrolling=\"no\" frameborder=\"0\" style=\"display: none;\"\u003E\u003C\/iframe\u003E"],
                "vtp_supportDocumentWrite": false,
                "vtp_enableIframeMode": false,
                "vtp_enableEditJsMacroBehavior": false,
                "tag_id": 382
            }, {
                "function": "__html",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_html": ["template", "\u003Ciframe src=\"https:\/\/asia.creativecdn.com\/tags?id=pr_", ["escape", ["macro", 114], 12], "_offer_", ["escape", ["macro", 44], 12], "\u0026amp;id=pr_", ["escape", ["macro", 114], 12], "_uid_", ["escape", ["macro", 13], 12], "\" width=\"1\" height=\"1\" scrolling=\"no\" frameborder=\"0\" style=\"display: none;\"\u003E\u003C\/iframe\u003E"],
                "vtp_supportDocumentWrite": false,
                "vtp_enableIframeMode": false,
                "vtp_enableEditJsMacroBehavior": false,
                "tag_id": 383
            }, {
                "function": "__html",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_html": ["template", "\u003Ciframe src=\"https:\/\/asia.creativecdn.com\/tags?id=pr_", ["escape", ["macro", 114], 12], "_listing_", ["escape", ["macro", 83], 12], "\u0026amp;id=pr_", ["escape", ["macro", 114], 12], "_uid_", ["escape", ["macro", 13], 12], "\" width=\"1\" height=\"1\" scrolling=\"no\" frameborder=\"0\" style=\"display: none;\"\u003E\u003C\/iframe\u003E"],
                "vtp_supportDocumentWrite": false,
                "vtp_enableIframeMode": false,
                "vtp_enableEditJsMacroBehavior": false,
                "tag_id": 384
            }, {
                "function": "__html",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_html": ["template", "\u003Ciframe src=\"https:\/\/asia.creativecdn.com\/tags?id=pr_", ["escape", ["macro", 114], 12], "_basketstatus_", ["escape", ["macro", 115], 12], "\u0026amp;id=pr_", ["escape", ["macro", 114], 12], "_uid_", ["escape", ["macro", 13], 12], "\" width=\"1\" height=\"1\" scrolling=\"no\" frameborder=\"0\" style=\"display: none;\"\u003E\u003C\/iframe\u003E"],
                "vtp_supportDocumentWrite": false,
                "vtp_enableIframeMode": false,
                "vtp_enableEditJsMacroBehavior": false,
                "tag_id": 385
            }, {
                "function": "__html",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_html": ["template", "\u003Ciframe src=\"https:\/\/asia.creativecdn.com\/tags?id=pr_", ["escape", ["macro", 114], 12], "_startorder\u0026amp;id=pr_", ["escape", ["macro", 114], 12], "_uid_", ["escape", ["macro", 13], 12], "\" width=\"1\" height=\"1\" scrolling=\"no\" frameborder=\"0\" style=\"display: none;\"\u003E\u003C\/iframe\u003E"],
                "vtp_supportDocumentWrite": false,
                "vtp_enableIframeMode": false,
                "vtp_enableEditJsMacroBehavior": false,
                "tag_id": 386
            }, {
                "function": "__html",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_html": ["template", "\u003Ciframe src=\"https:\/\/asia.creativecdn.com\/tags?id=pr_", ["escape", ["macro", 114], 12], "\u0026amp;ncm=1\u0026amp;id=pr_", ["escape", ["macro", 114], 12], "_uid_", ["escape", ["macro", 13], 12], "\" width=\"1\" height=\"1\" scrolling=\"no\" frameborder=\"0\" style=\"display: none;\"\u003E\u003C\/iframe\u003E"],
                "vtp_supportDocumentWrite": false,
                "vtp_enableIframeMode": false,
                "vtp_enableEditJsMacroBehavior": false,
                "tag_id": 387
            }, {
                "function": "__html",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_html": ["template", "\u003Ciframe src=\"https:\/\/asia.creativecdn.com\/tags?id=pr_", ["escape", ["macro", 114], 12], "_orderstatus2_", ["escape", ["macro", 59], 12], "_", ["escape", ["macro", 45], 12], "_", ["escape", ["macro", 109], 12], "\u0026amp;cd=default\u0026amp;id=pr_", ["escape", ["macro", 114], 12], "_uid_", ["escape", ["macro", 13], 12], "\" width=\"1\" height=\"1\" scrolling=\"no\" frameborder=\"0\" style=\"display: none;\"\u003E\u003C\/iframe\u003E"],
                "vtp_supportDocumentWrite": false,
                "vtp_enableIframeMode": false,
                "vtp_enableEditJsMacroBehavior": false,
                "tag_id": 388
            }, {
                "function": "__html",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_html": ["template", "\u003Cscript async data-gtmsrc=\"https:\/\/www.googletagmanager.com\/gtag\/js?id=", ["escape", ["macro", 117], 12], "\" type=\"text\/gtmscript\"\u003E\u003C\/script\u003E\n\n\u003Cscript type=\"text\/gtmscript\"\u003Ewindow.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments)}gtag(\"js\",new Date);\nfor(var transactionId=", ["escape", ["macro", 45], 8, 16], ",transactionCurrency=\"", ["escape", ["macro", 48], 7], "\",orders=", ["escape", ["macro", 46], 8, 16], ",purchaseInfo=[],i=0;i\u003Corders.length;i++)for(var j=0;j\u003Corders[i].items.length;j++)try{\"undefined\"===typeof purchaseInfo[orders[i].items[j].shopid]?purchaseInfo[orders[i].items[j].shopid]={shopId:orders[i].items[j].shopid,conversionId:\"", ["escape", ["macro", 117], 7], "\",conversionLabel:\"", ["escape", ["macro", 118], 7], "\",quantity:orders[i].items[j].quantity,totalValue:orders[i].items[j].price\/1E5*orders[i].items[j].quantity}:\n(purchaseInfo[orders[i].items[j].shopid].quantity+=orders[i].items[j].quantity,purchaseInfo[orders[i].items[j].shopid].totalValue+=orders[i].items[j].price\/1E5*orders[i].items[j].quantity)}catch(a){console.warn(a)}var shopPurchases=Object.values(purchaseInfo);\nfor(i=0;i\u003CshopPurchases.length;i++){var shopPurchase=shopPurchases[i],shopId=shopPurchase.shopId,conversionId=shopPurchase.conversionId,conversionLabel=shopPurchase.conversionLabel,conversionValue=shopPurchase.totalValue;gtag(\"config\",conversionId,{allow_ad_personalization_signals:!1});gtag(\"event\",\"conversion\",{send_to:conversionId+\"\/\"+conversionLabel,value:conversionValue,currency:transactionCurrency,transaction_id:transactionId+\"_\"+shopId})};\u003C\/script\u003E"],
                "vtp_supportDocumentWrite": false,
                "vtp_enableIframeMode": false,
                "vtp_enableEditJsMacroBehavior": false,
                "tag_id": 479
            }, {
                "function": "__html",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_html": ["template", "\u003Cscript async data-gtmsrc=\"https:\/\/www.googletagmanager.com\/gtag\/js?id=", ["escape", ["macro", 120], 12], "\" type=\"text\/gtmscript\"\u003E\u003C\/script\u003E\n\n\u003Cscript type=\"text\/gtmscript\"\u003Ewindow.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments)}gtag(\"js\",new Date);gtag(\"config\",", ["escape", ["macro", 120], 8, 16], ",{allow_ad_personalization_signals:!1});\u003C\/script\u003E  \n"],
                "vtp_supportDocumentWrite": false,
                "vtp_enableIframeMode": false,
                "vtp_enableEditJsMacroBehavior": false,
                "tag_id": 485
            }, {
                "function": "__html",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_html": ["template", "\u003Cscript async data-gtmsrc=\"https:\/\/www.googletagmanager.com\/gtag\/js?id=", ["escape", ["macro", 120], 12], "\" type=\"text\/gtmscript\"\u003E\u003C\/script\u003E\n\n\u003Cscript type=\"text\/gtmscript\"\u003Ewindow.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments)}gtag(\"js\",new Date);gtag(\"config\",", ["escape", ["macro", 120], 8, 16], ",{allow_ad_personalization_signals:!1});var conversionId=\"", ["escape", ["macro", 120], 7], "\",conversionLabel=\"", ["escape", ["macro", 122], 7], "\",addToCartCurrency=\"", ["escape", ["macro", 48], 7], "\";gtag(\"event\",\"conversion\",{send_to:conversionId+\"\/\"+conversionLabel,value:.0555*", ["escape", ["macro", 53], 8, 16], ",currency:addToCartCurrency});\u003C\/script\u003E"],
                "vtp_supportDocumentWrite": false,
                "vtp_enableIframeMode": false,
                "vtp_enableEditJsMacroBehavior": false,
                "tag_id": 492
            }, {
                "function": "__html",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_html": "\u003Cscript type=\"text\/gtmscript\"\u003Evar href=location.href,path=location.pathname,contentGroup=\"\";\ncontentGroup=path.match(\"^\/universal-link\/|^\/bridge_cmd\")||href.match(\"\/download(\\\\?|\/\\\\?pid)\")?\"Redirect\":path.match(\"(^\/user\/|^\/docs\/|^\/buyer\/|^\/communityRules\/|^\/legaldoc\/|^\/tips\/|\/func\/app_select|\/seller\/|\/shopping_cart\/|\/payment\/)\")||href.match(\"(\/cart($|\/)|\/me($|\/))|^((\/checkout\/)|(\/checkout\\\\?))|\/(addresses)|(edit_addresses)\")?\"User features\":path.match(\"^\/daily_discover|^\/from_same_shop\/|^\/similar_products\/|^\/you_may_also_like|^\/mall\/just-for-you|^\/double_eleven_big_sale\/\")||href.match(\"(^\/top\\\\_products$)|(^\/top\\\\_products\\\\?)\")?\n\"Recommendation\":path.match(\"^\/\\\\?|^\/$\")?\"Homepage\":path.match(\"\\\\-i\\\\.[0-9][0-9][0-9].*\/similar|\\\\-i\\\\.[0-9][0-9][0-9].*\/promotion\")?\"Similar Product\":path.match(\"\\\\-i\\\\.[0-9][0-9][0-9]|\/product\/|^\/item\/\")?\"Product\":\"Shop \\x26 MISC (v2019.04)\";dataLayer.push({event:\"cusevent\",contentGroup:contentGroup});\u003C\/script\u003E  ",
                "vtp_supportDocumentWrite": false,
                "vtp_enableIframeMode": false,
                "vtp_enableEditJsMacroBehavior": false,
                "tag_id": 593
            }],
            "predicates": [{
                "function": "_eq",
                "arg0": ["macro", 0],
                "arg1": "ProductPage.Self"
            }, {
                "function": "_eq",
                "arg0": ["macro", 1],
                "arg1": "impression"
            }, {
                "function": "_eq",
                "arg0": ["macro", 2],
                "arg1": "pc"
            }, {
                "function": "_re",
                "arg0": ["macro", 1],
                "arg1": ".*"
            }, {
                "function": "_eq",
                "arg0": ["macro", 3],
                "arg1": "test"
            }, {
                "function": "_re",
                "arg0": ["macro", 4],
                "arg1": "test.shopee.(sg|com.my|co.th|tw|co.id|vn|ph|com.br|com.mx|com.co|cl|pl|es|fr|in)",
                "ignore_case": true
            }, {
                "function": "_eq",
                "arg0": ["macro", 3],
                "arg1": "uat"
            }, {
                "function": "_re",
                "arg0": ["macro", 4],
                "arg1": "uat.shopee.(sg|com.my|co.th|tw|co.id|vn|ph|com.br|com.mx|com.co|cl|pl|es|fr|in)",
                "ignore_case": true
            }, {
                "function": "_re",
                "arg0": ["macro", 4],
                "arg1": "(uat|test|live-test|staging).shopee.(sg|com.my|co.th|tw|co.id|vn|ph|com.br|com.mx|com.co|cl|pl|es|fr|in)",
                "ignore_case": true
            }, {
                "function": "_eq",
                "arg0": ["macro", 1],
                "arg1": "gtm.js"
            }, {
                "function": "_re",
                "arg0": ["macro", 4],
                "arg1": "(uat|test).shopee.(sg|com.my|co.th|tw|co.id|vn|ph|com.br|com.mx|com.co|cl|pl|es|fr|in)",
                "ignore_case": true
            }, {
                "function": "_re",
                "arg0": ["macro", 4],
                "arg1": "(uat|test).shopee.(sg|com.my|co.th|tw|co.id|vn|ph|com.br|com.mx|com.co|cl)",
                "ignore_case": true
            }, {
                "function": "_eq",
                "arg0": ["macro", 1],
                "arg1": "gtm.historyChange"
            }, {
                "function": "_re",
                "arg0": ["macro", 4],
                "arg1": "(uat|test).shopee.(sg|com.my|co.th|tw|co.id|vn|ph)",
                "ignore_case": true
            }, {
                "function": "_eq",
                "arg0": ["macro", 1],
                "arg1": "gtm.load"
            }, {
                "function": "_re",
                "arg0": ["macro", 0],
                "arg1": "ItemCard",
                "ignore_case": true
            }, {
                "function": "_cn",
                "arg0": ["macro", 0],
                "arg1": "ItemCard"
            }, {
                "function": "_eq",
                "arg0": ["macro", 1],
                "arg1": "click"
            }, {
                "function": "_cn",
                "arg0": ["macro", 5],
                "arg1": "addToCart"
            }, {
                "function": "_eq",
                "arg0": ["macro", 1],
                "arg1": "action"
            }, {
                "function": "_cn",
                "arg0": ["macro", 2],
                "arg1": "mweb"
            }, {
                "function": "_re",
                "arg0": ["macro", 6],
                "arg1": "(uat|test|live-test|staging).shopee.(sg|com.my|co.th|tw|co.id|vn|ph|com.br|com.mx|com.co|cl|pl|es|fr|in)",
                "ignore_case": true
            }, {
                "function": "_cn",
                "arg0": ["macro", 7],
                "arg1": "\/produk-digital\/"
            }, {
                "function": "_re",
                "arg0": ["macro", 4],
                "arg1": "lite.shopee.(sg|com.my|co.th|tw|co.id|vn|ph|com.br|com.mx|com.co|cl|pl|es|fr|in)",
                "ignore_case": true
            }, {
                "function": "_cn",
                "arg0": ["macro", 7],
                "arg1": "\/scp\/"
            }, {
                "function": "_eq",
                "arg0": ["macro", 8],
                "arg1": "HomePage"
            }, {
                "function": "_eq",
                "arg0": ["macro", 35],
                "arg1": "true"
            }, {
                "function": "_eq",
                "arg0": ["macro", 1],
                "arg1": "pageState"
            }, {
                "function": "_cn",
                "arg0": ["macro", 8],
                "arg1": "CategoryPage"
            }, {
                "function": "_eq",
                "arg0": ["macro", 5],
                "arg1": "buyNow"
            }, {
                "function": "_eq",
                "arg0": ["macro", 0],
                "arg1": "ShopPage.Self"
            }, {
                "function": "_cn",
                "arg0": ["macro", 8],
                "arg1": "OfficialShopLandingPage"
            }, {
                "function": "_eq",
                "arg0": ["macro", 8],
                "arg1": "CollectionPage"
            }, {
                "function": "_cn",
                "arg0": ["macro", 8],
                "arg1": "FlashSale"
            }, {
                "function": "_eq",
                "arg0": ["macro", 8],
                "arg1": "PageMicroSite"
            }, {
                "function": "_cn",
                "arg0": ["macro", 0],
                "arg1": "MallPage.Self"
            }, {
                "function": "_re",
                "arg0": ["macro", 22],
                "arg1": "\/search",
                "ignore_case": true
            }, {
                "function": "_re",
                "arg0": ["macro", 1],
                "arg1": "gtm.historyChange"
            }, {
                "function": "_eq",
                "arg0": ["macro", 36],
                "arg1": "tw"
            }, {
                "function": "_eq",
                "arg0": ["macro", 36],
                "arg1": "sg"
            }, {
                "function": "_eq",
                "arg0": ["macro", 36],
                "arg1": "ph"
            }, {
                "function": "_eq",
                "arg0": ["macro", 36],
                "arg1": "vn"
            }, {
                "function": "_eq",
                "arg0": ["macro", 1],
                "arg1": "gtm.dom"
            }, {
                "function": "_eq",
                "arg0": ["macro", 36],
                "arg1": "co"
            }, {
                "function": "_eq",
                "arg0": ["macro", 36],
                "arg1": "cl"
            }, {
                "function": "_eq",
                "arg0": ["macro", 5],
                "arg1": "placeOrder"
            }, {
                "function": "_eq",
                "arg0": ["macro", 36],
                "arg1": "my"
            }, {
                "function": "_eq",
                "arg0": ["macro", 36],
                "arg1": "id"
            }, {
                "function": "_eq",
                "arg0": ["macro", 36],
                "arg1": "th"
            }, {
                "function": "_eq",
                "arg0": ["macro", 36],
                "arg1": "br"
            }, {
                "function": "_eq",
                "arg0": ["macro", 36],
                "arg1": "mx"
            }, {
                "function": "_re",
                "arg0": ["macro", 8],
                "arg1": "Search(Result|)Page"
            }, {
                "function": "_eq",
                "arg0": ["macro", 8],
                "arg1": "CartPage"
            }, {
                "function": "_eq",
                "arg0": ["macro", 8],
                "arg1": "CheckoutPage"
            }, {
                "function": "_eq",
                "arg0": ["macro", 57],
                "arg1": "action_sign_up_success"
            }, {
                "function": "_eq",
                "arg0": ["macro", 1],
                "arg1": "v3"
            }, {
                "function": "_re",
                "arg0": ["macro", 6],
                "arg1": "shopee.(sg|com.my|co.th|tw|co.id|vn|ph|com.br|com.mx|com.co|cl|pl|es|fr|in)",
                "ignore_case": true
            }, {
                "function": "_re",
                "arg0": ["macro", 6],
                "arg1": "(uat|test|live-test|staging|lite).shopee.(sg|com.my|co.th|tw|co.id|vn|ph|com.br|com.mx|com.co|cl|pl|es|fr|in)",
                "ignore_case": true
            }, {
                "function": "_cn",
                "arg0": ["macro", 7],
                "arg1": "produk-digital"
            }, {
                "function": "_re",
                "arg0": ["macro", 4],
                "arg1": "lite.(uat|test|live-test|staging).shopee.(sg|com.my|co.th|tw|co.id|vn|ph|com.br|com.mx|com.co|cl|pl|es|fr|in)",
                "ignore_case": true
            }, {
                "function": "_re",
                "arg0": ["macro", 23],
                "arg1": "(http|https):\/\/shopee.(vn|co.th|com.my|ph|sg|tw)\/m\/99",
                "ignore_case": true
            }, {
                "function": "_re",
                "arg0": ["macro", 23],
                "arg1": "(http|https):\/\/shopee.co.id\/m\/super-shopping-day-129",
                "ignore_case": true
            }, {
                "function": "_re",
                "arg0": ["macro", 63],
                "arg1": "(affiliate|affiliates)",
                "ignore_case": true
            }, {
                "function": "_eq",
                "arg0": ["macro", 3],
                "arg1": "live"
            }, {
                "function": "_re",
                "arg0": ["macro", 4],
                "arg1": "^shopee.(sg|com.my|co.th|tw|co.id|vn|ph|com.br|com.mx|com.co|cl|pl|es|fr|in)",
                "ignore_case": true
            }, {
                "function": "_re",
                "arg0": ["macro", 4],
                "arg1": "(test|uat|live-test|staging).shopee.(sg|com.my|co.th|tw|co.id|vn|ph|com.br|com.mx|com.co|cl|pl|es|fr|in)",
                "ignore_case": true
            }, {
                "function": "_re",
                "arg0": ["macro", 4],
                "arg1": "(uat|test|live-test|staging).shopee.(sg|com.my|co.th|tw|co.id|vn|ph|com.br|com.mx|com.co|cl|pl|com.ar|es|fr|in)",
                "ignore_case": true
            }, {
                "function": "_cn",
                "arg0": ["macro", 22],
                "arg1": "produk-digital"
            }, {
                "function": "_re",
                "arg0": ["macro", 4],
                "arg1": "(uat|test|live-test|staging).shopee.(sg|com.my|co.th|tw|co.id|vn|ph|com.br|com.mx|com.co|cl)",
                "ignore_case": true
            }, {
                "function": "_re",
                "arg0": ["macro", 4],
                "arg1": "lite.(uat|test|live-test|staging).shopee.(sg|com.my|co.th|tw|co.id|vn|ph|com.br|com.mx|com.co|cl)",
                "ignore_case": true
            }, {
                "function": "_re",
                "arg0": ["macro", 7],
                "arg1": "\/web$",
                "ignore_case": true
            }, {
                "function": "_eq",
                "arg0": ["macro", 4],
                "arg1": "shopee.com"
            }, {
                "function": "_cn",
                "arg0": ["macro", 5],
                "arg1": "action_delete_shopping_cart_item"
            }, {
                "function": "_eq",
                "arg0": ["macro", 75],
                "arg1": "popstate"
            }, {
                "function": "_re",
                "arg0": ["macro", 6],
                "arg1": "(event|doitac).shopee.*",
                "ignore_case": true
            }, {
                "function": "_eq",
                "arg0": ["macro", 5],
                "arg1": "login_success"
            }, {
                "function": "_eq",
                "arg0": ["macro", 57],
                "arg1": "action_login_success"
            }, {
                "function": "_eq",
                "arg0": ["macro", 4],
                "arg1": "localhost"
            }, {
                "function": "_re",
                "arg0": ["macro", 4],
                "arg1": "(giaitri|nhasach).shopee.vn",
                "ignore_case": true
            }, {
                "function": "_eq",
                "arg0": ["macro", 36],
                "arg1": "es"
            }, {
                "function": "_eq",
                "arg0": ["macro", 36],
                "arg1": "pl"
            }, {
                "function": "_eq",
                "arg0": ["macro", 36],
                "arg1": "fr"
            }, {
                "function": "_eq",
                "arg0": ["macro", 36],
                "arg1": "xx"
            }, {
                "function": "_eq",
                "arg0": ["macro", 36],
                "arg1": "in"
            }, {
                "function": "_eq",
                "arg0": ["macro", 5],
                "arg1": "registration"
            }, {
                "function": "_re",
                "arg0": ["macro", 4],
                "arg1": "nhasach.shopee.vn",
                "ignore_case": true
            }, {
                "function": "_eq",
                "arg0": ["macro", 85],
                "arg1": "purchase"
            }, {
                "function": "_re",
                "arg0": ["macro", 86],
                "arg1": "^(undefined|null|NaN|0|false)?$",
                "ignore_case": true
            }, {
                "function": "_eq",
                "arg0": ["macro", 1],
                "arg1": "purchase"
            }, {
                "function": "_re",
                "arg0": ["macro", 4],
                "arg1": "(myads|iklanku|muatukhoa|ads).shopee.(sg|com.my|co.th|tw|co.id|vn|ph|com.br|com.mx|com.co|cl|cn|pl|es|fr|in)",
                "ignore_case": true
            }, {
                "function": "_eq",
                "arg0": ["macro", 90],
                "arg1": "btn"
            }, {
                "function": "_eq",
                "arg0": ["macro", 1],
                "arg1": "gtm.click"
            }, {
                "function": "_re",
                "arg0": ["macro", 15],
                "arg1": "(seller|banhang).shopee.(sg|com.my|co.th|tw|co.id|vn|ph|com.br|com.mx|com.co|cl|pl)\\\/edu\\\/",
                "ignore_case": true
            }, {
                "function": "_re",
                "arg0": ["macro", 15],
                "arg1": "(seller|banhang).shopee.(sg|com.my|co.th|tw|co.id|vn|ph|com.br|com.mx|com.co|cl|pl|es|fr|in)\\\/edu\\\/",
                "ignore_case": true
            }, {
                "function": "_re",
                "arg0": ["macro", 23],
                "arg1": "\\\/(smartsg|unilever_householdcare|unilever_beautyhotpro|unilever_personalcare|realmeofficialstore|nutrilonofficialstore|oppo_official_store|lorealparis_officialstore|garnier_thailand|lorealparis|maybelline_thailand)",
                "ignore_case": true
            }, {
                "function": "_re",
                "arg0": ["macro", 23],
                "arg1": "\\\/(mobilehubsg|absolutepiano|atrixofficial|samsung_thailand|movingpeach.sg|foremost_official_shop)",
                "ignore_case": true
            }, {
                "function": "_cn",
                "arg0": ["macro", 95],
                "arg1": "forms.gle\/Gh3FgypEVEHJUYYY7"
            }, {
                "function": "_cn",
                "arg0": ["macro", 15],
                "arg1": "\/m\/shop-moi-len-san"
            }, {
                "function": "_cn",
                "arg0": ["macro", 4],
                "arg1": "shopee.vn"
            }, {
                "function": "_eq",
                "arg0": ["macro", 1],
                "arg1": "gtm.linkClick"
            }, {
                "function": "_re",
                "arg0": ["macro", 96],
                "arg1": "(^$|((^|,)7691473_588($|,)))"
            }, {
                "function": "_eq",
                "arg0": ["macro", 85],
                "arg1": "pageState"
            }, {
                "function": "_eq",
                "arg0": ["macro", 85],
                "arg1": "impressions"
            }, {
                "function": "_re",
                "arg0": ["macro", 119],
                "arg1": "91799978|58418206|16621457|40867978|119485441|75422406|53892420|37251933|29668384|29667634|29668843",
                "ignore_case": true
            }, {
                "function": "_re",
                "arg0": ["macro", 119],
                "arg1": "39401693|55027948|51678844|59860978|83276818|43416591",
                "ignore_case": true
            }, {
                "function": "_re",
                "arg0": ["macro", 119],
                "arg1": "26947756|111138057|269296276|40492624|45237836|29990515|241142788|76176908|327041081|254644909|272467617|176534566|98316282|55788683|62579622|109598751|35357809|277411443|32467552|57205325|164729718|164729277|28265861|56542501|121205602|56540396",
                "ignore_case": true
            }, {
                "function": "_re",
                "arg0": ["macro", 121],
                "arg1": "91799978|58418206|16621457|40867978|119485441|75422406|53892420|37251933|29668384|29667634|29668843",
                "ignore_case": true
            }, {
                "function": "_re",
                "arg0": ["macro", 121],
                "arg1": "39401693|55027948|51678844|59860978|83276818|43416591",
                "ignore_case": true
            }, {
                "function": "_re",
                "arg0": ["macro", 121],
                "arg1": "26947756|111138057|269296276|40492624|45237836|29990515|241142788|76176908|327041081|254644909|272467617|176534566|98316282|55788683|62579622|109598751|35357809|277411443|32467552|57205325|164729718|164729277|28265861|56542501|121205602|56540396",
                "ignore_case": true
            }],
            "rules": [
                [
                    ["if", 0, 1],
                    ["add", 2, 9, 11, 13, 14, 23, 26, 32, 34, 55, 62, 129, 178, 188, 200]
                ],
                [
                    ["if", 9],
                    ["unless", 10],
                    ["add", 3, 179],
                    ["block", 9]
                ],
                [
                    ["if", 12],
                    ["unless", 11],
                    ["add", 4, 209]
                ],
                [
                    ["if", 14],
                    ["unless", 13],
                    ["add", 4]
                ],
                [
                    ["if", 1, 15],
                    ["add", 5, 31, 40]
                ],
                [
                    ["if", 16, 17],
                    ["add", 6, 28, 44]
                ],
                [
                    ["if", 18, 19],
                    ["add", 7, 9, 11, 14, 29, 32, 34, 39, 55, 62, 73, 77, 91, 93, 108, 116, 149, 154, 182, 189]
                ],
                [
                    ["if", 3, 20],
                    ["unless", 21],
                    ["add", 8, 71, 75, 90, 96, 107, 117, 140, 147, 159]
                ],
                [
                    ["if", 9, 22],
                    ["add", 8, 42, 140]
                ],
                [
                    ["if", 9, 23],
                    ["add", 8, 42, 140]
                ],
                [
                    ["if", 9, 24],
                    ["add", 8]
                ],
                [
                    ["if", 25, 26, 27],
                    ["add", 9, 11, 13, 14, 21, 26, 32, 34, 55, 62, 127, 180, 198]
                ],
                [
                    ["if", 26, 27, 28],
                    ["add", 9, 11, 13, 14, 22, 26, 32, 34, 55, 62, 128, 181, 191, 199]
                ],
                [
                    ["if", 19, 29],
                    ["add", 9, 11, 32, 34, 55, 62, 182]
                ],
                [
                    ["if", 1, 30],
                    ["add", 9, 11, 13, 14, 26, 32, 34, 55, 62, 134, 204]
                ],
                [
                    ["if", 27, 31],
                    ["add", 9, 11, 13, 14, 26, 32, 34, 55, 62]
                ],
                [
                    ["if", 27, 32],
                    ["add", 9, 11, 13, 14, 22, 26, 32, 34, 55, 62, 134, 204]
                ],
                [
                    ["if", 27, 33],
                    ["add", 9, 11, 13, 14, 26, 32, 34, 55, 62, 134, 204]
                ],
                [
                    ["if", 27, 34],
                    ["add", 9, 11, 13, 14, 26, 32, 34, 55, 62, 134, 195, 204]
                ],
                [
                    ["if", 1, 35],
                    ["add", 9, 11, 13, 14, 26, 32, 34, 55, 62]
                ],
                [
                    ["if", 26, 36, 37],
                    ["add", 9, 11, 13, 22, 26, 32, 34, 55, 62, 69, 79, 89, 94, 106, 113, 130, 150, 157, 185, 187, 201]
                ],
                [
                    ["if", 19, 45],
                    ["add", 10, 12, 15, 16, 17, 18, 19, 24, 27, 0, 35, 37, 43, 46, 47, 48, 49, 50, 56, 63, 74, 81, 88, 100, 103, 112, 133, 141, 145, 156, 183, 184, 190, 1, 205, 206],
                    ["block", 147, 159]
                ],
                [
                    ["if", 26, 27, 51],
                    ["add", 14]
                ],
                [
                    ["if", 27, 52],
                    ["add", 20, 131, 194, 202]
                ],
                [
                    ["if", 9],
                    ["add", 25, 124, 186, 196, 197, 209, 164, 166, 167, 169, 170, 171, 172, 173, 174, 175, 176, 177]
                ],
                [
                    ["if", 27, 53],
                    ["add", 26, 132, 193, 203]
                ],
                [
                    ["if", 54, 55],
                    ["add", 30, 45, 67, 80, 85, 97, 104, 114, 143, 160, 192]
                ],
                [
                    ["if", 27, 56],
                    ["unless", 57],
                    ["add", 33, 70, 82, 84, 101, 109, 115, 139, 142, 158, 186]
                ],
                [
                    ["if", 12, 58],
                    ["unless", 8],
                    ["add", 33, 139]
                ],
                [
                    ["if", 12, 23],
                    ["unless", 59],
                    ["add", 33, 139]
                ],
                [
                    ["if", 9, 60],
                    ["add", 36]
                ],
                [
                    ["if", 9, 61],
                    ["add", 36]
                ],
                [
                    ["if", 19, 45, 62],
                    ["add", 38, 53, 58, 64, 122]
                ],
                [
                    ["if", 27, 66],
                    ["add", 41, 121]
                ],
                [
                    ["if", 12, 67, 68],
                    ["add", 41, 121]
                ],
                [
                    ["if", 8, 12],
                    ["add", 41, 121]
                ],
                [
                    ["if", 12, 69],
                    ["add", 41, 121]
                ],
                [
                    ["if", 3, 20, 65],
                    ["add", 42, 120]
                ],
                [
                    ["if", 9, 70],
                    ["add", 42, 51, 120]
                ],
                [
                    ["if", 8, 9],
                    ["add", 42, 120],
                    ["block", 2, 3, 4, 5, 6, 7, 8, 10, 11, 13, 15, 17, 18, 20, 21, 22, 23, 24, 26, 27, 28, 29, 30, 0, 31, 32, 33, 34, 35, 36, 38, 46, 47, 48, 51, 53, 54, 55, 56, 58, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 122, 123, 124, 125, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 154, 155, 156, 157, 158, 159, 160, 161, 162, 178, 179, 180, 181, 182, 183, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 198, 199, 200, 201, 202, 203, 204, 205, 209]
                ],
                [
                    ["if", 9, 71],
                    ["add", 51]
                ],
                [
                    ["if", 3, 4, 5],
                    ["add", 52],
                    ["block", 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 18, 19, 20, 21, 22, 23, 24, 26, 27, 28, 29, 30, 0, 31, 32, 33, 34, 35, 36, 38, 46, 47, 48, 51, 53, 54, 55, 56, 58, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 122, 123, 124, 125, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 154, 155, 156, 157, 158, 159, 160, 161, 162, 186, 187, 188, 189, 190, 191, 192, 193, 194, 198, 199, 200, 201, 202, 203, 204, 205, 209]
                ],
                [
                    ["if", 3, 6, 7],
                    ["add", 52],
                    ["block", 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 18, 19, 20, 21, 22, 23, 24, 27, 28, 29, 30, 0, 31, 32, 33, 34, 35, 38, 46, 47, 48, 51, 53, 54, 55, 56, 58, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 122, 123, 124, 125, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 154, 155, 156, 157, 158, 159, 160, 161, 162, 186, 187, 188, 189, 190, 191, 192, 193, 194, 198, 199, 200, 201, 202, 203, 204, 205, 209]
                ],
                [
                    ["if", 19, 72],
                    ["add", 54, 57, 72, 83, 92, 95, 105, 119, 144, 155]
                ],
                [
                    ["if", 12, 73, 74],
                    ["add", 59]
                ],
                [
                    ["if", 9, 74],
                    ["add", 59]
                ],
                [
                    ["if", 19, 75],
                    ["add", 60, 66, 78, 87, 99, 102, 111, 148, 162]
                ],
                [
                    ["if", 55, 76],
                    ["add", 61, 68, 76, 86, 98, 110, 118, 146, 161]
                ],
                [
                    ["if", 9, 78],
                    ["add", 65],
                    ["block", 124, 179]
                ],
                [
                    ["if", 19, 62, 84],
                    ["add", 123]
                ],
                [
                    ["if", 12, 85],
                    ["unless", 68],
                    ["add", 125, 186, 209]
                ],
                [
                    ["if", 86, 88],
                    ["unless", 87],
                    ["add", 126, 135]
                ],
                [
                    ["if", 12, 89],
                    ["add", 136]
                ],
                [
                    ["if", 9, 89],
                    ["add", 137]
                ],
                [
                    ["if", 90, 91],
                    ["add", 138]
                ],
                [
                    ["if", 9, 92],
                    ["add", 151]
                ],
                [
                    ["if", 12, 93],
                    ["add", 152]
                ],
                [
                    ["if", 27, 94],
                    ["add", 153]
                ],
                [
                    ["if", 27, 95],
                    ["add", 153]
                ],
                [
                    ["if", 96, 97, 98, 99, 100],
                    ["add", 163]
                ],
                [
                    ["if", 9, 101],
                    ["add", 165]
                ],
                [
                    ["if", 9, 102],
                    ["add", 168]
                ],
                [
                    ["if", 27, 103],
                    ["add", 207]
                ],
                [
                    ["if", 27, 104],
                    ["add", 207]
                ],
                [
                    ["if", 27, 105],
                    ["add", 207]
                ],
                [
                    ["if", 18, 19, 106],
                    ["add", 208]
                ],
                [
                    ["if", 18, 19, 107],
                    ["add", 208]
                ],
                [
                    ["if", 18, 19, 108],
                    ["add", 208]
                ],
                [
                    ["if", 2, 3],
                    ["block", 2, 3, 4, 5, 6, 7, 18, 184]
                ],
                [
                    ["if", 3, 38],
                    ["block", 9, 10, 11, 13, 14, 15, 16, 17, 19, 26, 27, 32, 34, 35, 53, 55, 56, 58, 62, 63, 64, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 122, 123, 124, 127, 128, 129, 130, 131, 132, 133, 134, 142, 143, 144, 145, 146, 147, 148, 149, 150, 154, 155, 156, 157, 158, 159, 160, 161, 162, 184, 198, 199, 200, 201, 202, 203, 204, 205]
                ],
                [
                    ["if", 3, 39],
                    ["block", 9, 10, 11, 12, 13, 14, 16, 17, 26, 27, 32, 34, 35, 53, 55, 56, 58, 62, 63, 64, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 122, 123, 124, 142, 143, 144, 145, 146, 147, 148, 149, 150, 154, 155, 156, 157, 158, 159, 160, 161, 162, 178, 179, 180, 181, 182, 183, 184, 185, 195]
                ],
                [
                    ["if", 3, 40],
                    ["block", 9, 10, 11, 12, 13, 14, 15, 16, 17, 26, 27, 32, 34, 35, 53, 55, 56, 58, 62, 63, 64, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 122, 123, 124, 142, 143, 144, 145, 146, 147, 148, 149, 150, 154, 155, 156, 157, 158, 159, 160, 161, 162, 178, 179, 180, 181, 182, 183, 184, 185, 195]
                ],
                [
                    ["if", 3, 41],
                    ["block", 9, 14, 15, 26, 27, 32, 55, 56, 62, 63, 64, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 122, 123, 124, 142, 143, 144, 145, 146, 147, 148, 149, 150, 154, 155, 156, 157, 158, 159, 160, 161, 162, 178, 179, 180, 181, 182, 183, 184, 185, 195]
                ],
                [
                    ["if", 42],
                    ["block", 9]
                ],
                [
                    ["if", 3, 43],
                    ["block", 9, 10, 11, 12, 13, 14, 15, 16, 17, 19, 20, 21, 22, 23, 24, 26, 27, 32, 34, 35, 38, 53, 55, 56, 58, 62, 63, 64, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 122, 123, 124, 127, 128, 129, 130, 131, 132, 133, 134, 142, 143, 144, 145, 146, 147, 148, 149, 150, 154, 155, 156, 157, 158, 159, 160, 161, 162, 178, 179, 180, 181, 182, 183, 184, 185, 195, 198, 199, 200, 201, 202, 203, 204, 205]
                ],
                [
                    ["if", 3, 44],
                    ["block", 9, 10, 11, 12, 13, 14, 15, 16, 17, 19, 20, 21, 22, 23, 24, 26, 27, 32, 34, 35, 38, 53, 55, 56, 58, 62, 63, 64, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 122, 123, 124, 127, 128, 129, 130, 131, 132, 133, 134, 142, 143, 144, 145, 146, 147, 148, 149, 150, 154, 155, 156, 157, 158, 159, 160, 161, 162, 178, 179, 180, 181, 182, 183, 184, 185, 195, 198, 199, 200, 201, 202, 203, 204, 205]
                ],
                [
                    ["if", 3, 46],
                    ["block", 10, 11, 13, 14, 16, 17, 19, 26, 27, 32, 34, 35, 53, 58, 62, 63, 64, 66, 67, 68, 69, 70, 71, 72, 73, 74, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 122, 123, 124, 142, 143, 144, 145, 146, 147, 148, 149, 150, 154, 155, 156, 157, 158, 159, 160, 161, 162, 178, 179, 180, 181, 182, 183, 184, 185, 195]
                ],
                [
                    ["if", 3, 47],
                    ["block", 10, 11, 13, 16, 17, 19, 27, 32, 34, 35, 53, 55, 56, 58, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 122, 123, 124, 142, 143, 144, 145, 146, 147, 148, 149, 150, 154, 155, 156, 157, 158, 159, 160, 161, 162, 178, 179, 180, 181, 182, 183, 184, 185, 195]
                ],
                [
                    ["if", 3, 48],
                    ["block", 10, 11, 13, 14, 16, 17, 19, 26, 34, 35, 53, 55, 56, 58, 62, 63, 64, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 111, 112, 113, 114, 115, 116, 117, 118, 119, 142, 143, 144, 145, 146, 147, 148, 149, 150, 154, 155, 156, 157, 158, 159, 160, 161, 162, 178, 179, 180, 181, 182, 183, 184, 185, 195]
                ],
                [
                    ["if", 3, 49],
                    ["block", 10, 11, 13, 15, 17, 20, 21, 22, 23, 24, 26, 27, 32, 34, 35, 53, 55, 56, 58, 62, 63, 64, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 122, 123, 124, 127, 128, 129, 130, 131, 132, 133, 134, 154, 155, 156, 157, 158, 159, 160, 161, 162, 178, 179, 180, 181, 182, 183, 185, 195, 198, 199, 200, 201, 202, 203, 204, 205]
                ],
                [
                    ["if", 3, 50],
                    ["block", 13, 15, 17, 20, 21, 22, 23, 24, 26, 34, 35, 38, 53, 55, 56, 58, 62, 63, 64, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 122, 123, 124, 142, 143, 144, 145, 146, 147, 148, 149, 150, 178, 179, 180, 181, 182, 183, 185, 195, 198, 199, 200, 201, 202, 203, 204, 205]
                ],
                [
                    ["if", 3, 63, 64],
                    ["block", 39, 40, 41, 42, 43, 44, 45, 49, 50, 57, 92, 120, 121, 126]
                ],
                [
                    ["if", 9],
                    ["unless", 65],
                    ["block", 39, 40, 41, 42, 43, 44, 45, 49, 50, 57, 120, 121, 126]
                ],
                [
                    ["if", 3, 77],
                    ["block", 62]
                ],
                [
                    ["if", 3, 79],
                    ["block", 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 142, 143, 144, 145, 146, 147, 148, 149, 150, 154, 155, 156, 157, 158, 159, 160, 161, 162]
                ],
                [
                    ["if", 3, 80],
                    ["block", 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 142, 143, 144, 145, 146, 147, 148, 149, 150, 154, 155, 156, 157, 158, 159, 160, 161, 162]
                ],
                [
                    ["if", 3, 81],
                    ["block", 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 142, 143, 144, 145, 146, 147, 148, 149, 150, 154, 155, 156, 157, 158, 159, 160, 161, 162]
                ],
                [
                    ["if", 3, 82],
                    ["block", 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 142, 143, 144, 145, 146, 147, 148, 149, 150, 154, 155, 156, 157, 158, 159, 160, 161, 162]
                ],
                [
                    ["if", 3, 83],
                    ["block", 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 142, 143, 144, 145, 146, 147, 148, 149, 150, 154, 155, 156, 157, 158, 159, 160, 161, 162]
                ]
            ]
        },
        "runtime": [
            [50, "__crto", [46, "a"],
                [52, "b", ["require", "createQueue"]],
                [52, "c", ["require", "injectScript"]],
                [52, "d", "https://static.criteo.net/js/ld/ld.js"],
                [52, "e", ["b", "criteo_q"]],
                [41, "f"],
                [3, "f", [8, "event", "viewHome"]],
                [38, [17, [15, "a"], "tagType"],
                    [46, "LISTING_TAG", "PRODUCT_TAG", "BASKET_TAG", "TRANSACTION_TAG"],
                    [46, [5, [46, [3, "f", [8, "event", "viewList", "item", [17, [15, "a"], "listingID"]]],
                            [4]
                        ]],
                        [5, [46, [3, "f", [8, "event", "viewItem", "item", [17, [15, "a"], "productID"]]],
                            [4]
                        ]],
                        [5, [46, [3, "f", [8, "event", "viewBasket", "item", [17, [15, "a"], "basketArray"]]],
                            [4]
                        ]],
                        [5, [46, [3, "f", [8, "event", "trackTransaction", "id", [30, [17, [15, "a"], "TransactionID"], ""], "item", [17, [15, "a"], "TransactionArray"]]],
                            [4]
                        ]]
                    ]
                ],
                ["e", [8, "event", "setAccount", "account", [17, [15, "a"], "accountId"]],
                    [8, "event", "setHashedEmail", "email", [30, [17, [15, "a"], "hashedEmail"], ""]],
                    [8, "event", "setSiteType", "type", [30, [17, [15, "a"], "siteType"], "d"]],
                    [15, "f"]
                ],
                ["c", [15, "d"],
                    [17, [15, "a"], "gtmOnSuccess"],
                    [17, [15, "a"], "gtmOnFailure"], "criteoStatic"
                ]
            ],
            [50, "__hjtc", [46, "a"],
                [52, "b", ["require", "createArgumentsQueue"]],
                [52, "c", ["require", "encodeUriComponent"]],
                [52, "d", ["require", "injectScript"]],
                [52, "e", ["require", "makeString"]],
                [52, "f", ["require", "setInWindow"]],
                ["b", "hj", "hj.q"],
                [52, "g", [17, [15, "a"], "hotjar_site_id"]],
                ["f", "_hjSettings", [8, "hjid", [15, "g"], "hjsv", 7, "scriptSource", "gtm"]],
                ["d", [0, [0, "https://static.hotjar.com/c/hotjar-", ["c", ["e", [15, "g"]]]], ".js?sv=7"],
                    [17, [15, "a"], "gtmOnSuccess"],
                    [17, [15, "a"], "gtmOnFailure"]
                ]
            ]
        ],
        "permissions": {
            "__crto": {
                "access_globals": {
                    "keys": [{
                        "key": "criteo_q",
                        "read": true,
                        "write": true,
                        "execute": false
                    }]
                },
                "inject_script": {
                    "urls": ["https:\/\/static.criteo.net\/js\/ld\/ld.js"]
                }
            },
            "__hjtc": {
                "access_globals": {
                    "keys": [{
                        "key": "hj",
                        "read": true,
                        "write": true,
                        "execute": false
                    }, {
                        "key": "hj.q",
                        "read": true,
                        "write": true,
                        "execute": false
                    }, {
                        "key": "_hjSettings",
                        "read": true,
                        "write": true,
                        "execute": false
                    }]
                },
                "inject_script": {
                    "urls": ["https:\/\/static.hotjar.com\/c\/hotjar-*"]
                }
            }
        }

        ,
        "security_groups": {
            "nonGoogleScripts": ["__crto", "__hjtc"]
        }

    };

    var productSettings = {
        "AW-359197269": {
            "preAutoPii": true
        }
    };


    /*

     Copyright The Closure Library Authors.
     SPDX-License-Identifier: Apache-2.0
    */
    var aa, ca = function(a) {
            var b = 0;
            return function() {
                return b < a.length ? {
                    done: !1,
                    value: a[b++]
                } : {
                    done: !0
                }
            }
        },
        da = function(a) {
            var b = "undefined" != typeof Symbol && Symbol.iterator && a[Symbol.iterator];
            return b ? b.call(a) : {
                next: ca(a)
            }
        },
        ha = "function" == typeof Object.create ? Object.create : function(a) {
            var b = function() {};
            b.prototype = a;
            return new b
        },
        ia;
    if ("function" == typeof Object.setPrototypeOf) ia = Object.setPrototypeOf;
    else {
        var ja;
        a: {
            var ka = {
                    a: !0
                },
                la = {};
            try {
                la.__proto__ = ka;
                ja = la.a;
                break a
            } catch (a) {}
            ja = !1
        }
        ia = ja ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
            return a
        } : null
    }
    var ma = ia,
        pa = function(a, b) {
            a.prototype = ha(b.prototype);
            a.prototype.constructor = a;
            if (ma) ma(a, b);
            else
                for (var c in b)
                    if ("prototype" != c)
                        if (Object.defineProperties) {
                            var d = Object.getOwnPropertyDescriptor(b, c);
                            d && Object.defineProperty(a, c, d)
                        } else a[c] = b[c];
            a.dk = b.prototype
        },
        qa = this || self,
        ra = function(a) {
            return a
        };
    var sa = function(a, b) {
        this.g = a;
        this.o = b
    };
    var ta = function(a) {
            return "number" === typeof a && 0 <= a && isFinite(a) && 0 === a % 1 || "string" === typeof a && "-" !== a[0] && a === "" + parseInt(a, 10)
        },
        ua = function() {
            this.D = {};
            this.s = !1;
            this.F = {}
        },
        va = function(a, b) {
            var c = [],
                d;
            for (d in a.D)
                if (a.D.hasOwnProperty(d)) switch (d = d.substr(5), b) {
                    case 1:
                        c.push(d);
                        break;
                    case 2:
                        c.push(a.get(d));
                        break;
                    case 3:
                        c.push([d, a.get(d)])
                }
            return c
        };
    ua.prototype.get = function(a) {
        return this.D["dust." + a]
    };
    ua.prototype.set = function(a, b) {
        this.s || (a = "dust." + a, this.F.hasOwnProperty(a) || (this.D[a] = b))
    };
    ua.prototype.has = function(a) {
        return this.D.hasOwnProperty("dust." + a)
    };
    var xa = function(a, b) {
        b = "dust." + b;
        a.s || a.F.hasOwnProperty(b) || delete a.D[b]
    };
    ua.prototype.ub = function() {
        this.s = !0
    };
    var ya = function(a) {
        this.o = new ua;
        this.g = [];
        this.s = !1;
        a = a || [];
        for (var b in a) a.hasOwnProperty(b) && (ta(b) ? this.g[Number(b)] = a[Number(b)] : this.o.set(b, a[b]))
    };
    aa = ya.prototype;
    aa.toString = function(a) {
        if (a && 0 <= a.indexOf(this)) return "";
        for (var b = [], c = 0; c < this.g.length; c++) {
            var d = this.g[c];
            null === d || void 0 === d ? b.push("") : d instanceof ya ? (a = a || [], a.push(this), b.push(d.toString(a)), a.pop()) : b.push(d.toString())
        }
        return b.join(",")
    };
    aa.set = function(a, b) {
        if (!this.s)
            if ("length" === a) {
                if (!ta(b)) throw Error("RangeError: Length property must be a valid integer.");
                this.g.length = Number(b)
            } else ta(a) ? this.g[Number(a)] = b : this.o.set(a, b)
    };
    aa.get = function(a) {
        return "length" === a ? this.length() : ta(a) ? this.g[Number(a)] : this.o.get(a)
    };
    aa.length = function() {
        return this.g.length
    };
    aa.tb = function() {
        for (var a = va(this.o, 1), b = 0; b < this.g.length; b++) a.push(b + "");
        return new ya(a)
    };
    var za = function(a, b) {
        ta(b) ? delete a.g[Number(b)] : xa(a.o, b)
    };
    aa = ya.prototype;
    aa.pop = function() {
        return this.g.pop()
    };
    aa.push = function(a) {
        return this.g.push.apply(this.g, Array.prototype.slice.call(arguments))
    };
    aa.shift = function() {
        return this.g.shift()
    };
    aa.splice = function(a, b, c) {
        return new ya(this.g.splice.apply(this.g, arguments))
    };
    aa.unshift = function(a) {
        return this.g.unshift.apply(this.g, Array.prototype.slice.call(arguments))
    };
    aa.has = function(a) {
        return ta(a) && this.g.hasOwnProperty(a) || this.o.has(a)
    };
    aa.ub = function() {
        this.s = !0;
        Object.freeze(this.g);
        this.o.ub()
    };
    var Aa = function() {
        function a(f, g) {
            if (b[f]) {
                if (b[f].zd + g > b[f].max) throw Error("Quota exceeded");
                b[f].zd += g
            }
        }
        var b = {},
            c = void 0,
            d = void 0,
            e = {
                qj: function(f) {
                    c = f
                },
                xg: function() {
                    c && a(c, 1)
                },
                sj: function(f) {
                    d = f
                },
                vb: function(f) {
                    d && a(d, f)
                },
                Jj: function(f, g) {
                    b[f] = b[f] || {
                        zd: 0
                    };
                    b[f].max = g
                },
                Ui: function(f) {
                    return b[f] && b[f].zd || 0
                },
                reset: function() {
                    b = {}
                },
                Fi: a
            };
        e.onFnConsume = e.qj;
        e.consumeFn = e.xg;
        e.onStorageConsume = e.sj;
        e.consumeStorage = e.vb;
        e.setMax = e.Jj;
        e.getConsumed = e.Ui;
        e.reset = e.reset;
        e.consume = e.Fi;
        return e
    };
    var Ba = function(a, b) {
        this.s = a;
        this.N = function(c, d, e) {
            return c.apply(d, e)
        };
        this.D = b;
        this.o = new ua;
        this.g = this.F = void 0
    };
    Ba.prototype.add = function(a, b) {
        Da(this, a, b, !1)
    };
    var Da = function(a, b, c, d) {
        if (!a.o.s)
            if (a.s.vb(("string" === typeof b ? b.length : 1) + ("string" === typeof c ? c.length : 1)), d) {
                var e = a.o;
                e.set(b, c);
                e.F["dust." + b] = !0
            } else a.o.set(b, c)
    };
    Ba.prototype.set = function(a, b) {
        this.o.s || (!this.o.has(a) && this.D && this.D.has(a) ? this.D.set(a, b) : (this.s.vb(("string" === typeof a ? a.length : 1) + ("string" === typeof b ? b.length : 1)), this.o.set(a, b)))
    };
    Ba.prototype.get = function(a) {
        return this.o.has(a) ? this.o.get(a) : this.D ? this.D.get(a) : void 0
    };
    Ba.prototype.has = function(a) {
        return !!this.o.has(a) || !(!this.D || !this.D.has(a))
    };
    var Ea = function(a) {
        var b = new Ba(a.s, a);
        a.F && (b.F = a.F);
        b.N = a.N;
        b.g = a.g;
        return b
    };
    var Fa = function() {},
        Ga = function(a) {
            return "function" == typeof a
        },
        k = function(a) {
            return "string" == typeof a
        },
        Ha = function(a) {
            return "number" == typeof a && !isNaN(a)
        },
        Ia = Array.isArray,
        Ja = function(a, b) {
            if (Array.prototype.indexOf) {
                var c = a.indexOf(b);
                return "number" == typeof c ? c : -1
            }
            for (var d = 0; d < a.length; d++)
                if (a[d] === b) return d;
            return -1
        },
        Ka = function(a, b) {
            if (a && Ia(a))
                for (var c = 0; c < a.length; c++)
                    if (a[c] && b(a[c])) return a[c]
        },
        Na = function(a, b) {
            if (!Ha(a) || !Ha(b) || a > b) a = 0, b = 2147483647;
            return Math.floor(Math.random() * (b -
                a + 1) + a)
        },
        Pa = function(a, b) {
            for (var c = new Oa, d = 0; d < a.length; d++) c.set(a[d], !0);
            for (var e = 0; e < b.length; e++)
                if (c.get(b[e])) return !0;
            return !1
        },
        Qa = function(a, b) {
            for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b(c, a[c])
        },
        Ra = function(a) {
            return !!a && ("[object Arguments]" == Object.prototype.toString.call(a) || Object.prototype.hasOwnProperty.call(a, "callee"))
        },
        Ua = function(a) {
            return Math.round(Number(a)) || 0
        },
        Va = function(a) {
            return "false" == String(a).toLowerCase() ? !1 : !!a
        },
        Ya = function(a) {
            var b = [];
            if (Ia(a))
                for (var c =
                        0; c < a.length; c++) b.push(String(a[c]));
            return b
        },
        ab = function(a) {
            return a ? a.replace(/^\s+|\s+$/g, "") : ""
        },
        bb = function() {
            return new Date(Date.now())
        },
        cb = function() {
            return bb().getTime()
        },
        Oa = function() {
            this.prefix = "gtm.";
            this.values = {}
        };
    Oa.prototype.set = function(a, b) {
        this.values[this.prefix + a] = b
    };
    Oa.prototype.get = function(a) {
        return this.values[this.prefix + a]
    };
    var db = function(a, b, c) {
            return a && a.hasOwnProperty(b) ? a[b] : c
        },
        eb = function(a) {
            var b = a;
            return function() {
                if (b) {
                    var c = b;
                    b = void 0;
                    try {
                        c()
                    } catch (d) {}
                }
            }
        },
        fb = function(a, b) {
            for (var c in b) b.hasOwnProperty(c) && (a[c] = b[c])
        },
        gb = function(a) {
            for (var b in a)
                if (a.hasOwnProperty(b)) return !0;
            return !1
        },
        hb = function(a, b) {
            for (var c = [], d = 0; d < a.length; d++) c.push(a[d]), c.push.apply(c, b[a[d]] || []);
            return c
        },
        ib = function(a, b) {
            var c = m;
            b = b || [];
            for (var d = c, e = 0; e < a.length - 1; e++) {
                if (!d.hasOwnProperty(a[e])) return;
                d = d[a[e]];
                if (0 <=
                    Ja(b, d)) return
            }
            return d
        },
        jb = function(a, b) {
            for (var c = {}, d = c, e = a.split("."), f = 0; f < e.length - 1; f++) d = d[e[f]] = {};
            d[e[e.length - 1]] = b;
            return c
        },
        kb = /^\w{1,9}$/,
        lb = function(a, b) {
            a = a || {};
            b = b || ",";
            var c = [];
            Qa(a, function(d, e) {
                kb.test(d) && e && c.push(d)
            });
            return c.join(b)
        },
        mb = function(a, b) {
            function c() {
                ++d === b && (e(), e = null, c.done = !0)
            }
            var d = 0,
                e = a;
            c.done = !1;
            return c
        };
    var nb = function(a, b) {
        ua.call(this);
        this.N = a;
        this.La = b
    };
    pa(nb, ua);
    nb.prototype.toString = function() {
        return this.N
    };
    nb.prototype.tb = function() {
        return new ya(va(this, 1))
    };
    nb.prototype.g = function(a, b) {
        a.s.xg();
        return this.La.apply(new ob(this, a), Array.prototype.slice.call(arguments, 1))
    };
    nb.prototype.o = function(a, b) {
        try {
            return this.g.apply(this, Array.prototype.slice.call(arguments, 0))
        } catch (c) {}
    };
    var qb = function(a, b) {
            for (var c, d = 0; d < b.length && !(c = pb(a, b[d]), c instanceof sa); d++);
            return c
        },
        pb = function(a, b) {
            try {
                var c = a.get(String(b[0]));
                if (!(c && c instanceof nb)) throw Error("Attempting to execute non-function " + b[0] + ".");
                return c.g.apply(c, [a].concat(b.slice(1)))
            } catch (e) {
                var d = a.F;
                d && d(e, b.context ? {
                    id: b[0],
                    line: b.context.line
                } : null);
                throw e;
            }
        },
        ob = function(a, b) {
            this.o = a;
            this.g = b
        },
        A = function(a, b) {
            return Ia(b) ? pb(a.g, b) : b
        },
        G = function(a) {
            return a.o.N
        };
    var rb = function() {
        ua.call(this)
    };
    pa(rb, ua);
    rb.prototype.tb = function() {
        return new ya(va(this, 1))
    };
    var sb = {
        control: function(a, b) {
            return new sa(a, A(this, b))
        },
        fn: function(a, b, c) {
            var d = this.g,
                e = A(this, b);
            if (!(e instanceof ya)) throw Error("Error: non-List value given for Fn argument names.");
            var f = Array.prototype.slice.call(arguments, 2);
            this.g.s.vb(a.length + f.length);
            return new nb(a, function() {
                return function(g) {
                    var h = Ea(d);
                    void 0 === h.g && (h.g = this.g.g);
                    for (var l = Array.prototype.slice.call(arguments, 0), n = 0; n < l.length; n++)
                        if (l[n] = A(this, l[n]), l[n] instanceof sa) return l[n];
                    for (var p = e.get("length"), q =
                            0; q < p; q++) q < l.length ? h.add(e.get(q), l[q]) : h.add(e.get(q), void 0);
                    h.add("arguments", new ya(l));
                    var t = qb(h, f);
                    if (t instanceof sa) return "return" === t.g ? t.o : t
                }
            }())
        },
        list: function(a) {
            var b = this.g.s;
            b.vb(arguments.length);
            for (var c = new ya, d = 0; d < arguments.length; d++) {
                var e = A(this, arguments[d]);
                "string" === typeof e && b.vb(e.length ? e.length - 1 : 0);
                c.push(e)
            }
            return c
        },
        map: function(a) {
            for (var b = this.g.s, c = new rb, d = 0; d < arguments.length - 1; d += 2) {
                var e = A(this, arguments[d]) + "",
                    f = A(this, arguments[d + 1]),
                    g = e.length;
                g += "string" ===
                    typeof f ? f.length : 1;
                b.vb(g);
                c.set(e, f)
            }
            return c
        },
        undefined: function() {}
    };
    var tb = function() {
            this.s = Aa();
            this.g = new Ba(this.s)
        },
        xb = function(a, b, c) {
            var d = new nb(b, c);
            d.ub();
            a.g.set(b, d)
        },
        yb = function(a, b, c) {
            sb.hasOwnProperty(b) && xb(a, c || b, sb[b])
        };
    tb.prototype.execute = function(a, b) {
        var c = Array.prototype.slice.call(arguments, 0);
        return this.o(c)
    };
    tb.prototype.o = function(a) {
        for (var b, c = 0; c < arguments.length; c++) b = pb(this.g, arguments[c]);
        return b
    };
    tb.prototype.D = function(a, b) {
        var c = Ea(this.g);
        c.g = a;
        for (var d, e = 1; e < arguments.length; e++) d = d = pb(c, arguments[e]);
        return d
    };
    var zb, Ab = function() {
        if (void 0 === zb) {
            var a = null,
                b = qa.trustedTypes;
            if (b && b.createPolicy) {
                try {
                    a = b.createPolicy("goog#html", {
                        createHTML: ra,
                        createScript: ra,
                        createScriptURL: ra
                    })
                } catch (c) {
                    qa.console && qa.console.error(c.message)
                }
                zb = a
            } else zb = a
        }
        return zb
    };
    var Cb = function(a, b) {
        this.s = b === Bb ? a : ""
    };
    Cb.prototype.o = !0;
    Cb.prototype.g = function() {
        return this.s.toString()
    };
    Cb.prototype.toString = function() {
        return this.s + ""
    };
    var Bb = {},
        Eb = function(a) {
            var b = Ab(),
                c = b ? b.createScriptURL(a) : a;
            return new Cb(c, Bb)
        };
    var Gb = function(a, b) {
        this.s = b === Fb ? a : ""
    };
    Gb.prototype.o = !0;
    Gb.prototype.g = function() {
        return this.s.toString()
    };
    Gb.prototype.toString = function() {
        return this.s.toString()
    };
    var Hb = /^(?:(?:https?|mailto|ftp):|[^:/?#]*(?:[/?#]|$))/i,
        Fb = {};
    var Ib;
    a: {
        var Jb = qa.navigator;
        if (Jb) {
            var Kb = Jb.userAgent;
            if (Kb) {
                Ib = Kb;
                break a
            }
        }
        Ib = ""
    }

    function Lb(a) {
        return -1 != Ib.indexOf(a)
    };
    var Mb = {},
        Nb = function(a, b, c) {
            this.s = c === Mb ? a : "";
            this.o = !0
        };
    Nb.prototype.g = function() {
        return this.s.toString()
    };
    Nb.prototype.toString = function() {
        return this.s.toString()
    };
    var Ob = function(a) {
            return a instanceof Nb && a.constructor === Nb ? a.s : "type_error:SafeHtml"
        },
        Pb = function(a) {
            var b = Ab(),
                c = b ? b.createHTML(a) : a;
            return new Nb(c, null, Mb)
        },
        Qb = new Nb(qa.trustedTypes && qa.trustedTypes.emptyHTML || "", 0, Mb);
    /*

     SPDX-License-Identifier: Apache-2.0
    */
    function Rb(a, b) {
        a.src = b instanceof Cb && b.constructor === Cb ? b.s : "type_error:TrustedResourceUrl";
        var c, d, e = (a.ownerDocument && a.ownerDocument.defaultView || window).document,
            f = null === (d = e.querySelector) || void 0 === d ? void 0 : d.call(e, "script[nonce]");
        (c = f ? f.nonce || f.getAttribute("nonce") || "" : "") && a.setAttribute("nonce", c)
    };
    var Sb = function(a, b) {
            var c = function() {};
            c.prototype = a.prototype;
            var d = new c;
            a.apply(d, Array.prototype.slice.call(arguments, 1));
            return d
        },
        Tb = function(a) {
            var b = a;
            return function() {
                if (b) {
                    var c = b;
                    b = null;
                    c()
                }
            }
        };
    var Ub = function(a) {
        var b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    }(function() {
        var a = document.createElement("div"),
            b = document.createElement("div");
        b.appendChild(document.createElement("div"));
        a.appendChild(b);
        var c = a.firstChild.firstChild;
        a.innerHTML = Ob(Qb);
        return !c.parentElement
    });
    var m = window,
        H = document,
        Vb = navigator,
        Wb = H.currentScript && H.currentScript.src,
        Xb = function(a, b) {
            var c = m[a];
            m[a] = void 0 === c ? b : c;
            return m[a]
        },
        Yb = function(a) {
            var b = H.getElementsByTagName("script")[0] || H.body || H.head;
            b.parentNode.insertBefore(a, b)
        },
        Zb = function(a, b) {
            b && (a.addEventListener ? a.onload = b : a.onreadystatechange = function() {
                a.readyState in {
                    loaded: 1,
                    complete: 1
                } && (a.onreadystatechange = null, b())
            })
        },
        $b = {
            async: 1,
            nonce: 1,
            onerror: 1,
            onload: 1,
            src: 1,
            type: 1
        },
        bc = function(a, b, c, d) {
            var e = H.createElement("script");
            d && Qa(d, function(f, g) {
                f = f.toLowerCase();
                $b.hasOwnProperty(f) || e.setAttribute(f, g)
            });
            e.type = "text/javascript";
            e.async = !0;
            Rb(e, Eb(a));
            Zb(e, b);
            c && (e.onerror = c);
            Yb(e);
            return e
        },
        cc = function() {
            if (Wb) {
                var a = Wb.toLowerCase();
                if (0 === a.indexOf("https://")) return 2;
                if (0 === a.indexOf("http://")) return 3
            }
            return 1
        },
        dc = function(a, b) {
            var c = H.createElement("iframe");
            c.height = "0";
            c.width = "0";
            c.style.display = "none";
            c.style.visibility = "hidden";
            var d = H.body && H.body.lastChild || H.body || H.head;
            d.parentNode.insertBefore(c,
                d);
            Zb(c, b);
            void 0 !== a && (c.src = a);
            return c
        },
        ec = function(a, b, c) {
            var d = new Image(1, 1);
            d.onload = function() {
                d.onload = null;
                b && b()
            };
            d.onerror = function() {
                d.onerror = null;
                c && c()
            };
            d.src = a;
            return d
        },
        fc = function(a, b, c, d) {
            a.addEventListener ? a.addEventListener(b, c, !!d) : a.attachEvent && a.attachEvent("on" + b, c)
        },
        gc = function(a, b, c) {
            a.removeEventListener ? a.removeEventListener(b, c, !1) : a.detachEvent && a.detachEvent("on" + b, c)
        },
        I = function(a) {
            m.setTimeout(a, 0)
        },
        hc = function(a, b) {
            return a && b && a.attributes && a.attributes[b] ? a.attributes[b].value :
                null
        },
        ic = function(a) {
            var b = a.innerText || a.textContent || "";
            b && " " != b && (b = b.replace(/^[\s\xa0]+|[\s\xa0]+$/g, ""));
            b && (b = b.replace(/(\xa0+|\s{2,}|\n|\r\t)/g, " "));
            return b
        },
        jc = function(a) {
            var b = H.createElement("div"),
                c = Pb("A<div>" + a + "</div>"),
                d = b;
            if (Ub())
                for (; d.lastChild;) d.removeChild(d.lastChild);
            d.innerHTML = Ob(c);
            b = b.lastChild;
            for (var e = []; b.firstChild;) e.push(b.removeChild(b.firstChild));
            return e
        },
        kc = function(a, b, c) {
            c = c || 100;
            for (var d = {}, e = 0; e < b.length; e++) d[b[e]] = !0;
            for (var f = a, g = 0; f && g <= c; g++) {
                if (d[String(f.tagName).toLowerCase()]) return f;
                f = f.parentElement
            }
            return null
        },
        lc = function(a) {
            var b;
            try {
                b = Vb.sendBeacon && Vb.sendBeacon(a)
            } catch (c) {}
            b || ec(a)
        },
        mc = function(a, b) {
            var c = a[b];
            c && "string" === typeof c.animVal && (c = c.animVal);
            return c
        },
        nc = function(a) {
            var b = H.featurePolicy;
            return b && Ga(b.features) ? -1 !== b.features().indexOf(a) : !1
        },
        oc = function() {
            return Vb.userLanguage || Vb.language
        };
    var pc = function(a, b) {
            return A(this, a) && A(this, b)
        },
        qc = function(a, b) {
            return A(this, a) === A(this, b)
        },
        rc = function(a, b) {
            return A(this, a) || A(this, b)
        },
        sc = function(a, b) {
            a = A(this, a);
            b = A(this, b);
            return -1 < String(a).indexOf(String(b))
        },
        tc = function(a, b) {
            a = String(A(this, a));
            b = String(A(this, b));
            return a.substring(0, b.length) === b
        },
        zc = function(a, b) {
            a = A(this, a);
            b = A(this, b);
            switch (a) {
                case "pageLocation":
                    var c = m.location.href;
                    b instanceof rb && b.get("stripProtocol") && (c = c.replace(/^https?:\/\//, ""));
                    return c
            }
        };
    var Bc = function() {
        this.g = new tb;
        Ac(this)
    };
    Bc.prototype.execute = function(a) {
        return this.g.o(a)
    };
    var Ac = function(a) {
        yb(a.g, "map");
        var b = function(c, d) {
            xb(a.g, c, d)
        };
        b("and", pc);
        b("contains", sc);
        b("equals", qc);
        b("or", rc);
        b("startsWith", tc);
        b("variable", zc)
    };
    var Cc = function(a) {
        if (a instanceof Cc) return a;
        this.Qa = a
    };
    Cc.prototype.toString = function() {
        return String(this.Qa)
    };
    /*
     jQuery (c) 2005, 2012 jQuery Foundation, Inc. jquery.org/license. */
    var Dc = /\[object (Boolean|Number|String|Function|Array|Date|RegExp)\]/,
        Ec = function(a) {
            if (null == a) return String(a);
            var b = Dc.exec(Object.prototype.toString.call(Object(a)));
            return b ? b[1].toLowerCase() : "object"
        },
        Fc = function(a, b) {
            return Object.prototype.hasOwnProperty.call(Object(a), b)
        },
        Gc = function(a) {
            if (!a || "object" != Ec(a) || a.nodeType || a == a.window) return !1;
            try {
                if (a.constructor && !Fc(a, "constructor") && !Fc(a.constructor.prototype, "isPrototypeOf")) return !1
            } catch (c) {
                return !1
            }
            for (var b in a);
            return void 0 ===
                b || Fc(a, b)
        },
        J = function(a, b) {
            var c = b || ("array" == Ec(a) ? [] : {}),
                d;
            for (d in a)
                if (Fc(a, d)) {
                    var e = a[d];
                    "array" == Ec(e) ? ("array" != Ec(c[d]) && (c[d] = []), c[d] = J(e, c[d])) : Gc(e) ? (Gc(c[d]) || (c[d] = {}), c[d] = J(e, c[d])) : c[d] = e
                }
            return c
        };
    var Ic = function(a, b, c) {
            var d = [],
                e = [],
                f = function(h, l) {
                    for (var n = va(h, 1), p = 0; p < n.length; p++) l[n[p]] = g(h.get(n[p]))
                },
                g = function(h) {
                    var l = Ja(d, h);
                    if (-1 < l) return e[l];
                    if (h instanceof ya) {
                        var n = [];
                        d.push(h);
                        e.push(n);
                        for (var p = h.tb(), q = 0; q < p.length(); q++) n[p.get(q)] = g(h.get(p.get(q)));
                        return n
                    }
                    if (h instanceof rb) {
                        var t = {};
                        d.push(h);
                        e.push(t);
                        f(h, t);
                        return t
                    }
                    if (h instanceof nb) {
                        var u = function() {
                            for (var r = Array.prototype.slice.call(arguments, 0), v = 0; v < r.length; v++) r[v] = Hc(r[v], b, !!c);
                            var w = b ? b.s : Aa(),
                                y = new Ba(w);
                            b && (y.g = b.g);
                            return g(h.g.apply(h, [y].concat(r)))
                        };
                        d.push(h);
                        e.push(u);
                        f(h, u);
                        return u
                    }
                    switch (typeof h) {
                        case "boolean":
                        case "number":
                        case "string":
                        case "undefined":
                            return h;
                        case "object":
                            if (null === h) return null
                    }
                };
            return g(a)
        },
        Hc = function(a, b, c) {
            var d = [],
                e = [],
                f = function(h, l) {
                    for (var n in h) h.hasOwnProperty(n) && l.set(n, g(h[n]))
                },
                g = function(h) {
                    var l = Ja(d,
                        h);
                    if (-1 < l) return e[l];
                    if (Ia(h) || Ra(h)) {
                        var n = new ya([]);
                        d.push(h);
                        e.push(n);
                        for (var p in h) h.hasOwnProperty(p) && n.set(p, g(h[p]));
                        return n
                    }
                    if (Gc(h)) {
                        var q = new rb;
                        d.push(h);
                        e.push(q);
                        f(h, q);
                        return q
                    }
                    if ("function" === typeof h) {
                        var t = new nb("", function(r) {
                            for (var v = Array.prototype.slice.call(arguments, 0), w = 0; w < v.length; w++) v[w] = Ic(A(this, v[w]), b, !!c);
                            return g((0, this.g.N)(h, h, v))
                        });
                        d.push(h);
                        e.push(t);
                        f(h, t);
                        return t
                    }
                    var u = typeof h;
                    if (null === h || "string" === u || "number" === u || "boolean" === u) return h;
                };
            return g(a)
        };
    var Jc = function(a) {
            for (var b = [], c = 0; c < a.length(); c++) a.has(c) && (b[c] = a.get(c));
            return b
        },
        Kc = function(a) {
            if (void 0 === a || Ia(a) || Gc(a)) return !0;
            switch (typeof a) {
                case "boolean":
                case "number":
                case "string":
                case "function":
                    return !0
            }
            return !1
        };
    var Lc = {
        supportedMethods: "concat every filter forEach hasOwnProperty indexOf join lastIndexOf map pop push reduce reduceRight reverse shift slice some sort splice unshift toString".split(" "),
        concat: function(a, b) {
            for (var c = [], d = 0; d < this.length(); d++) c.push(this.get(d));
            for (var e = 1; e < arguments.length; e++)
                if (arguments[e] instanceof ya)
                    for (var f = arguments[e], g = 0; g < f.length(); g++) c.push(f.get(g));
                else c.push(arguments[e]);
            return new ya(c)
        },
        every: function(a, b) {
            for (var c = this.length(), d = 0; d < this.length() &&
                d < c; d++)
                if (this.has(d) && !b.g(a, this.get(d), d, this)) return !1;
            return !0
        },
        filter: function(a, b) {
            for (var c = this.length(), d = [], e = 0; e < this.length() && e < c; e++) this.has(e) && b.g(a, this.get(e), e, this) && d.push(this.get(e));
            return new ya(d)
        },
        forEach: function(a, b) {
            for (var c = this.length(), d = 0; d < this.length() && d < c; d++) this.has(d) && b.g(a, this.get(d), d, this)
        },
        hasOwnProperty: function(a, b) {
            return this.has(b)
        },
        indexOf: function(a, b, c) {
            var d = this.length(),
                e = void 0 === c ? 0 : Number(c);
            0 > e && (e = Math.max(d + e, 0));
            for (var f = e; f < d; f++)
                if (this.has(f) &&
                    this.get(f) === b) return f;
            return -1
        },
        join: function(a, b) {
            for (var c = [], d = 0; d < this.length(); d++) c.push(this.get(d));
            return c.join(b)
        },
        lastIndexOf: function(a, b, c) {
            var d = this.length(),
                e = d - 1;
            void 0 !== c && (e = 0 > c ? d + c : Math.min(c, e));
            for (var f = e; 0 <= f; f--)
                if (this.has(f) && this.get(f) === b) return f;
            return -1
        },
        map: function(a, b) {
            for (var c = this.length(), d = [], e = 0; e < this.length() && e < c; e++) this.has(e) && (d[e] = b.g(a, this.get(e), e, this));
            return new ya(d)
        },
        pop: function() {
            return this.pop()
        },
        push: function(a, b) {
            return this.push.apply(this,
                Array.prototype.slice.call(arguments, 1))
        },
        reduce: function(a, b, c) {
            var d = this.length(),
                e, f = 0;
            if (void 0 !== c) e = c;
            else {
                if (0 === d) throw Error("TypeError: Reduce on List with no elements.");
                for (var g = 0; g < d; g++)
                    if (this.has(g)) {
                        e = this.get(g);
                        f = g + 1;
                        break
                    }
                if (g === d) throw Error("TypeError: Reduce on List with no elements.");
            }
            for (var h = f; h < d; h++) this.has(h) && (e = b.g(a, e, this.get(h), h, this));
            return e
        },
        reduceRight: function(a, b, c) {
            var d = this.length(),
                e, f = d - 1;
            if (void 0 !== c) e = c;
            else {
                if (0 === d) throw Error("TypeError: ReduceRight on List with no elements.");
                for (var g = 1; g <= d; g++)
                    if (this.has(d - g)) {
                        e = this.get(d - g);
                        f = d - (g + 1);
                        break
                    }
                if (g > d) throw Error("TypeError: ReduceRight on List with no elements.");
            }
            for (var h = f; 0 <= h; h--) this.has(h) && (e = b.g(a, e, this.get(h), h, this));
            return e
        },
        reverse: function() {
            for (var a = Jc(this), b = a.length - 1, c = 0; 0 <= b; b--, c++) a.hasOwnProperty(b) ? this.set(c, a[b]) : za(this, c);
            return this
        },
        shift: function() {
            return this.shift()
        },
        slice: function(a, b, c) {
            var d = this.length();
            void 0 === b && (b = 0);
            b = 0 > b ? Math.max(d + b, 0) : Math.min(b, d);
            c = void 0 === c ? d : 0 > c ?
                Math.max(d + c, 0) : Math.min(c, d);
            c = Math.max(b, c);
            for (var e = [], f = b; f < c; f++) e.push(this.get(f));
            return new ya(e)
        },
        some: function(a, b) {
            for (var c = this.length(), d = 0; d < this.length() && d < c; d++)
                if (this.has(d) && b.g(a, this.get(d), d, this)) return !0;
            return !1
        },
        sort: function(a, b) {
            var c = Jc(this);
            void 0 === b ? c.sort() : c.sort(function(e, f) {
                return Number(b.g(a, e, f))
            });
            for (var d = 0; d < c.length; d++) c.hasOwnProperty(d) ? this.set(d, c[d]) : za(this, d);
            return this
        },
        splice: function(a, b, c, d) {
            return this.splice.apply(this, Array.prototype.splice.call(arguments,
                1, arguments.length - 1))
        },
        toString: function() {
            return this.toString()
        },
        unshift: function(a, b) {
            return this.unshift.apply(this, Array.prototype.slice.call(arguments, 1))
        }
    };
    var Mc = "charAt concat indexOf lastIndexOf match replace search slice split substring toLowerCase toLocaleLowerCase toString toUpperCase toLocaleUpperCase trim".split(" "),
        Nc = new sa("break"),
        Uc = new sa("continue"),
        Vc = function(a, b) {
            return A(this, a) + A(this, b)
        },
        Wc = function(a, b) {
            return A(this, a) && A(this, b)
        },
        Xc = function(a, b, c) {
            a = A(this, a);
            b = A(this, b);
            c = A(this, c);
            if (!(c instanceof ya)) throw Error("Error: Non-List argument given to Apply instruction.");
            if (null === a || void 0 === a) throw Error("TypeError: Can't read property " +
                b + " of " + a + ".");
            var d = "number" === typeof a;
            if ("boolean" === typeof a || d) {
                if ("toString" === b) {
                    var e = !0;
                    if (e && d && c.length()) {
                        var f = Ic(c.get(0));
                        try {
                            return a.toString(f)
                        } catch (t) {}
                    }
                    return a.toString()
                }
                throw Error("TypeError: " + a + "." + b + " is not a function.");
            }
            if ("string" === typeof a) {
                if (0 <= Ja(Mc, b)) {
                    var g = Ic(c);
                    return Hc(a[b].apply(a,
                        g), this.g)
                }
                throw Error("TypeError: " + b + " is not a function");
            }
            if (a instanceof ya) {
                if (a.has(b)) {
                    var h = a.get(b);
                    if (h instanceof nb) {
                        var l = Jc(c);
                        l.unshift(this.g);
                        return h.g.apply(h, l)
                    }
                    throw Error("TypeError: " + b + " is not a function");
                }
                if (0 <= Ja(Lc.supportedMethods, b)) {
                    var n = Jc(c);
                    n.unshift(this.g);
                    return Lc[b].apply(a, n)
                }
            }
            if (a instanceof nb || a instanceof rb) {
                if (a.has(b)) {
                    var p = a.get(b);
                    if (p instanceof nb) {
                        var q = Jc(c);
                        q.unshift(this.g);
                        return p.g.apply(p, q)
                    }
                    throw Error("TypeError: " + b + " is not a function");
                }
                if ("toString" === b) return a instanceof nb ? a.N : a.toString();
                if ("hasOwnProperty" === b) return a.has.apply(a, Jc(c))
            }
            if (a instanceof Cc && "toString" === b) return a.toString();
            throw Error("TypeError: Object has no '" + b + "' property.");
        },
        Yc = function(a, b) {
            a = A(this, a);
            if ("string" !== typeof a) throw Error("Invalid key name given for assignment.");
            var c = this.g;
            if (!c.has(a)) throw Error("Attempting to assign to undefined value " + b);
            var d = A(this, b);
            c.set(a, d);
            return d
        },
        Zc = function(a) {
            var b = Ea(this.g),
                c = qb(b, Array.prototype.slice.apply(arguments));
            if (c instanceof sa) return c
        },
        $c = function() {
            return Nc
        },
        ad = function(a) {
            for (var b = A(this, a), c = 0; c < b.length; c++) {
                var d = A(this, b[c]);
                if (d instanceof sa) return d
            }
        },
        bd = function(a) {
            for (var b = this.g, c = 0; c < arguments.length - 1; c += 2) {
                var d = arguments[c];
                if ("string" === typeof d) {
                    var e = A(this, arguments[c + 1]);
                    Da(b, d, e, !0)
                }
            }
        },
        cd = function() {
            return Uc
        },
        dd = function(a, b, c) {
            var d = new ya;
            b = A(this, b);
            for (var e = 0; e < b.length; e++) d.push(b[e]);
            var f = [51, a, d].concat(Array.prototype.splice.call(arguments, 2, arguments.length - 2));
            this.g.add(a, A(this, f))
        },
        ed = function(a, b) {
            return A(this, a) / A(this, b)
        },
        fd = function(a, b) {
            a = A(this, a);
            b = A(this, b);
            var c = a instanceof Cc,
                d = b instanceof Cc;
            return c || d ? c && d ? a.Qa == b.Qa : !1 : a == b
        },
        gd = function(a) {
            for (var b, c = 0; c < arguments.length; c++) b = A(this, arguments[c]);
            return b
        };

    function hd(a, b, c, d) {
        for (var e = 0; e < b(); e++) {
            var f = a(c(e)),
                g = qb(f, d);
            if (g instanceof sa) {
                if ("break" === g.g) break;
                if ("return" === g.g) return g
            }
        }
    }

    function id(a, b, c) {
        if ("string" === typeof b) return hd(a, function() {
            return b.length
        }, function(f) {
            return f
        }, c);
        if (b instanceof rb || b instanceof ya || b instanceof nb) {
            var d = b.tb(),
                e = d.length();
            return hd(a, function() {
                return e
            }, function(f) {
                return d.get(f)
            }, c)
        }
    }
    var md = function(a, b, c) {
            a = A(this, a);
            b = A(this, b);
            c = A(this, c);
            var d = this.g;
            return id(function(e) {
                d.set(a, e);
                return d
            }, b, c)
        },
        nd = function(a, b, c) {
            a = A(this, a);
            b = A(this, b);
            c = A(this, c);
            var d = this.g;
            return id(function(e) {
                var f = Ea(d);
                Da(f, a, e, !0);
                return f
            }, b, c)
        },
        od = function(a, b, c) {
            a = A(this, a);
            b = A(this, b);
            c = A(this, c);
            var d = this.g;
            return id(function(e) {
                var f = Ea(d);
                f.add(a, e);
                return f
            }, b, c)
        },
        qd = function(a, b, c) {
            a = A(this, a);
            b = A(this, b);
            c = A(this, c);
            var d = this.g;
            return pd(function(e) {
                d.set(a, e);
                return d
            }, b, c)
        },
        rd =
        function(a, b, c) {
            a = A(this, a);
            b = A(this, b);
            c = A(this, c);
            var d = this.g;
            return pd(function(e) {
                var f = Ea(d);
                Da(f, a, e, !0);
                return f
            }, b, c)
        },
        sd = function(a, b, c) {
            a = A(this, a);
            b = A(this, b);
            c = A(this, c);
            var d = this.g;
            return pd(function(e) {
                var f = Ea(d);
                f.add(a, e);
                return f
            }, b, c)
        };

    function pd(a, b, c) {
        if ("string" === typeof b) return hd(a, function() {
            return b.length
        }, function(d) {
            return b[d]
        }, c);
        if (b instanceof ya) return hd(a, function() {
            return b.length()
        }, function(d) {
            return b.get(d)
        }, c);
        throw new TypeError("The value is not iterable.");
    }
    var td = function(a, b, c, d) {
            function e(p, q) {
                for (var t = 0; t < f.length(); t++) {
                    var u = f.get(t);
                    q.add(u, p.get(u))
                }
            }
            var f = A(this, a);
            if (!(f instanceof ya)) throw Error("TypeError: Non-List argument given to ForLet instruction.");
            var g = this.g;
            d = A(this, d);
            var h = Ea(g);
            for (e(g, h); pb(h, b);) {
                var l = qb(h, d);
                if (l instanceof sa) {
                    if ("break" === l.g) break;
                    if ("return" === l.g) return l
                }
                var n = Ea(g);
                e(h, n);
                pb(n, c);
                h = n
            }
        },
        ud = function(a) {
            a = A(this, a);
            var b = this.g,
                c = !1;
            if (c && !b.has(a)) throw new ReferenceError(a + " is not defined.");
            return b.get(a)
        },
        vd = function(a, b) {
            var c;
            a = A(this, a);
            b = A(this, b);
            if (void 0 === a || null === a) throw Error("TypeError: cannot access property of " + a + ".");
            if (a instanceof rb || a instanceof ya || a instanceof nb) c = a.get(b);
            else if ("string" === typeof a) "length" === b ? c = a.length : ta(b) && (c = a[b]);
            else if (a instanceof Cc) return;
            return c
        },
        wd = function(a, b) {
            return A(this, a) > A(this,
                b)
        },
        xd = function(a, b) {
            return A(this, a) >= A(this, b)
        },
        yd = function(a, b) {
            a = A(this, a);
            b = A(this, b);
            a instanceof Cc && (a = a.Qa);
            b instanceof Cc && (b = b.Qa);
            return a === b
        },
        zd = function(a, b) {
            return !yd.call(this, a, b)
        },
        Ad = function(a, b, c) {
            var d = [];
            A(this, a) ? d = A(this, b) : c && (d = A(this, c));
            var e = qb(this.g, d);
            if (e instanceof sa) return e
        },
        Bd = function(a, b) {
            return A(this, a) < A(this, b)
        },
        Cd = function(a, b) {
            return A(this, a) <= A(this, b)
        },
        Dd = function(a, b) {
            return A(this, a) % A(this, b)
        },
        Ed = function(a, b) {
            return A(this, a) * A(this, b)
        },
        Fd = function(a) {
            return -A(this,
                a)
        },
        Gd = function(a) {
            return !A(this, a)
        },
        Hd = function(a, b) {
            return !fd.call(this, a, b)
        },
        Id = function() {
            return null
        },
        Jd = function(a, b) {
            return A(this, a) || A(this, b)
        },
        Kd = function(a, b) {
            var c = A(this, a);
            A(this, b);
            return c
        },
        Ld = function(a) {
            return A(this, a)
        },
        Td = function(a) {
            return Array.prototype.slice.apply(arguments)
        },
        Ud = function(a) {
            return new sa("return", A(this, a))
        },
        Vd = function(a, b, c) {
            a = A(this, a);
            b = A(this, b);
            c = A(this, c);
            if (null === a || void 0 === a) throw Error("TypeError: Can't set property " + b + " of " + a + ".");
            (a instanceof nb || a instanceof ya || a instanceof rb) && a.set(b, c);
            return c
        },
        Wd = function(a, b) {
            return A(this, a) - A(this, b)
        },
        Xd = function(a, b, c) {
            a = A(this, a);
            var d = A(this, b),
                e = A(this, c);
            if (!Ia(d) || !Ia(e)) throw Error("Error: Malformed switch instruction.");
            for (var f, g = !1, h = 0; h < d.length; h++)
                if (g || a === A(this, d[h]))
                    if (f = A(this, e[h]), f instanceof sa) {
                        var l = f.g;
                        if ("break" === l) return;
                        if ("return" === l || "continue" === l) return f
                    } else g = !0;
            if (e.length === d.length + 1 && (f = A(this, e[e.length - 1]), f instanceof sa && ("return" === f.g || "continue" ===
                    f.g))) return f
        },
        Yd = function(a, b, c) {
            return A(this, a) ? A(this, b) : A(this, c)
        },
        Zd = function(a) {
            a = A(this, a);
            return a instanceof nb ? "function" : typeof a
        },
        $d = function(a) {
            for (var b = this.g, c = 0; c < arguments.length; c++) {
                var d = arguments[c];
                "string" !== typeof d || b.add(d, void 0)
            }
        },
        ae = function(a, b, c, d) {
            var e = A(this, d);
            if (A(this, c)) {
                var f = qb(this.g, e);
                if (f instanceof sa) {
                    if ("break" === f.g) return;
                    if ("return" === f.g) return f
                }
            }
            for (; A(this, a);) {
                var g = qb(this.g, e);
                if (g instanceof sa) {
                    if ("break" === g.g) break;
                    if ("return" === g.g) return g
                }
                A(this,
                    b)
            }
        },
        be = function(a) {
            return ~Number(A(this, a))
        },
        ce = function(a, b) {
            return Number(A(this, a)) << Number(A(this, b))
        },
        de = function(a, b) {
            return Number(A(this, a)) >> Number(A(this, b))
        },
        ee = function(a, b) {
            return Number(A(this, a)) >>> Number(A(this, b))
        },
        fe = function(a, b) {
            return Number(A(this, a)) & Number(A(this, b))
        },
        ge = function(a, b) {
            return Number(A(this, a)) ^ Number(A(this, b))
        },
        he = function(a, b) {
            return Number(A(this, a)) | Number(A(this, b))
        };
    var je = function() {
        this.g = new tb;
        ie(this)
    };
    je.prototype.execute = function(a) {
        return ke(this.g.o(a))
    };
    var me = function(a, b) {
            return ke(le.g.D(a, b))
        },
        ie = function(a) {
            var b = function(d, e) {
                yb(a.g, d, String(e))
            };
            b("control", 49);
            b("fn", 51);
            b("list", 7);
            b("map", 8);
            b("undefined", 44);
            var c = function(d, e) {
                xb(a.g, String(d), e)
            };
            c(0, Vc);
            c(1, Wc);
            c(2, Xc);
            c(3, Yc);
            c(53, Zc);
            c(4, $c);
            c(5, ad);
            c(52, bd);
            c(6, cd);
            c(9, ad);
            c(50, dd);
            c(10, ed);
            c(12, fd);
            c(13, gd);
            c(47, md);
            c(54, nd);
            c(55, od);
            c(63, td);
            c(64, qd);
            c(65, rd);
            c(66, sd);
            c(15, ud);
            c(16, vd);
            c(17, vd);
            c(18, wd);
            c(19, xd);
            c(20, yd);
            c(21, zd);
            c(22, Ad);
            c(23, Bd);
            c(24, Cd);
            c(25, Dd);
            c(26, Ed);
            c(27,
                Fd);
            c(28, Gd);
            c(29, Hd);
            c(45, Id);
            c(30, Jd);
            c(32, Kd);
            c(33, Kd);
            c(34, Ld);
            c(35, Ld);
            c(46, Td);
            c(36, Ud);
            c(43, Vd);
            c(37, Wd);
            c(38, Xd);
            c(39, Yd);
            c(40, Zd);
            c(41, $d);
            c(42, ae);
            c(58, be);
            c(57, ce);
            c(60, de);
            c(61, ee);
            c(56, fe);
            c(62, ge);
            c(59, he)
        },
        oe = function() {
            var a = le,
                b = ne();
            xb(a.g, "require", b)
        },
        pe = function(a, b) {
            a.g.g.N = b
        };

    function ke(a) {
        if (a instanceof sa || a instanceof nb || a instanceof ya || a instanceof rb || a instanceof Cc || null === a || void 0 === a || "string" === typeof a || "number" === typeof a || "boolean" === typeof a) return a
    };
    var qe = function() {
        var a = function(b) {
            return {
                toString: function() {
                    return b
                }
            }
        };
        return {
            sh: a("consent"),
            Rd: a("consent_always_fire"),
            wf: a("convert_case_to"),
            xf: a("convert_false_to"),
            yf: a("convert_null_to"),
            zf: a("convert_true_to"),
            Af: a("convert_undefined_to"),
            Rj: a("debug_mode_metadata"),
            Tj: a("event_data_overrides"),
            sb: a("function"),
            fi: a("instance_name"),
            hi: a("live_only"),
            ii: a("malware_disabled"),
            ji: a("metadata"),
            Uj: a("original_activity_id"),
            Vj: a("original_vendor_template_id"),
            ni: a("once_per_event"),
            cg: a("once_per_load"),
            Xj: a("priority_override"),
            Yj: a("respected_consent_types"),
            gg: a("setup_tags"),
            ig: a("tag_id"),
            jg: a("teardown_tags")
        }
    }();
    var re = [],
        se = {
            "\x00": "&#0;",
            '"': "&quot;",
            "&": "&amp;",
            "'": "&#39;",
            "<": "&lt;",
            ">": "&gt;",
            "\t": "&#9;",
            "\n": "&#10;",
            "\x0B": "&#11;",
            "\f": "&#12;",
            "\r": "&#13;",
            " ": "&#32;",
            "-": "&#45;",
            "/": "&#47;",
            "=": "&#61;",
            "`": "&#96;",
            "\u0085": "&#133;",
            "\u00a0": "&#160;",
            "\u2028": "&#8232;",
            "\u2029": "&#8233;"
        },
        te = function(a) {
            return se[a]
        },
        ue = /[\x00\x22\x26\x27\x3c\x3e]/g;
    var ye = /[\x00\x08-\x0d\x22\x26\x27\/\x3c-\x3e\\\x85\u2028\u2029]/g,
        Fe = {
            "\x00": "\\x00",
            "\b": "\\x08",
            "\t": "\\t",
            "\n": "\\n",
            "\x0B": "\\x0b",
            "\f": "\\f",
            "\r": "\\r",
            '"': "\\x22",
            "&": "\\x26",
            "'": "\\x27",
            "/": "\\/",
            "<": "\\x3c",
            "=": "\\x3d",
            ">": "\\x3e",
            "\\": "\\\\",
            "\u0085": "\\x85",
            "\u2028": "\\u2028",
            "\u2029": "\\u2029",
            $: "\\x24",
            "(": "\\x28",
            ")": "\\x29",
            "*": "\\x2a",
            "+": "\\x2b",
            ",": "\\x2c",
            "-": "\\x2d",
            ".": "\\x2e",
            ":": "\\x3a",
            "?": "\\x3f",
            "[": "\\x5b",
            "]": "\\x5d",
            "^": "\\x5e",
            "{": "\\x7b",
            "|": "\\x7c",
            "}": "\\x7d"
        },
        Ge = function(a) {
            return Fe[a]
        };
    re[7] = function(a) {
        return String(a).replace(ye, Ge)
    };
    re[8] = function(a) {
        if (null == a) return " null ";
        switch (typeof a) {
            case "boolean":
            case "number":
                return " " + a + " ";
            default:
                return "'" + String(String(a)).replace(ye, Ge) + "'"
        }
    };
    var Me = /['()]/g,
        Ne = function(a) {
            return "%" + a.charCodeAt(0).toString(16)
        };
    re[12] = function(a) {
        var b =
            encodeURIComponent(String(a));
        Me.lastIndex = 0;
        return Me.test(b) ? b.replace(Me, Ne) : b
    };
    var Oe = /[\x00- \x22\x27-\x29\x3c\x3e\\\x7b\x7d\x7f\x85\xa0\u2028\u2029\uff01\uff03\uff04\uff06-\uff0c\uff0f\uff1a\uff1b\uff1d\uff1f\uff20\uff3b\uff3d]/g,
        Pe = {
            "\x00": "%00",
            "\u0001": "%01",
            "\u0002": "%02",
            "\u0003": "%03",
            "\u0004": "%04",
            "\u0005": "%05",
            "\u0006": "%06",
            "\u0007": "%07",
            "\b": "%08",
            "\t": "%09",
            "\n": "%0A",
            "\x0B": "%0B",
            "\f": "%0C",
            "\r": "%0D",
            "\u000e": "%0E",
            "\u000f": "%0F",
            "\u0010": "%10",
            "\u0011": "%11",
            "\u0012": "%12",
            "\u0013": "%13",
            "\u0014": "%14",
            "\u0015": "%15",
            "\u0016": "%16",
            "\u0017": "%17",
            "\u0018": "%18",
            "\u0019": "%19",
            "\u001a": "%1A",
            "\u001b": "%1B",
            "\u001c": "%1C",
            "\u001d": "%1D",
            "\u001e": "%1E",
            "\u001f": "%1F",
            " ": "%20",
            '"': "%22",
            "'": "%27",
            "(": "%28",
            ")": "%29",
            "<": "%3C",
            ">": "%3E",
            "\\": "%5C",
            "{": "%7B",
            "}": "%7D",
            "\u007f": "%7F",
            "\u0085": "%C2%85",
            "\u00a0": "%C2%A0",
            "\u2028": "%E2%80%A8",
            "\u2029": "%E2%80%A9",
            "\uff01": "%EF%BC%81",
            "\uff03": "%EF%BC%83",
            "\uff04": "%EF%BC%84",
            "\uff06": "%EF%BC%86",
            "\uff07": "%EF%BC%87",
            "\uff08": "%EF%BC%88",
            "\uff09": "%EF%BC%89",
            "\uff0a": "%EF%BC%8A",
            "\uff0b": "%EF%BC%8B",
            "\uff0c": "%EF%BC%8C",
            "\uff0f": "%EF%BC%8F",
            "\uff1a": "%EF%BC%9A",
            "\uff1b": "%EF%BC%9B",
            "\uff1d": "%EF%BC%9D",
            "\uff1f": "%EF%BC%9F",
            "\uff20": "%EF%BC%A0",
            "\uff3b": "%EF%BC%BB",
            "\uff3d": "%EF%BC%BD"
        },
        Qe = function(a) {
            return Pe[a]
        };
    re[16] = function(a) {
        return a
    };
    var Se;
    var Te = [],
        Ue = [],
        Ve = [],
        We = [],
        Xe = [],
        Ye = {},
        Ze, $e, af, bf = function(a, b) {
            var c = {};
            c["function"] = "__" + a;
            for (var d in b) b.hasOwnProperty(d) && (c["vtp_" + d] = b[d]);
            return c
        },
        cf = function(a, b) {
            var c = a["function"];
            if (!c) throw Error("Error: No function name given for function call.");
            var d = Ye[c],
                e = {},
                f;
            for (f in a)
                if (a.hasOwnProperty(f))
                    if (0 === f.indexOf("vtp_")) d && b && b.wg && b.wg(a[f]), e[void 0 !== d ? f : f.substr(4)] = a[f];
                    else if (f === qe.Rd.toString() && a[f]) {}
            d && b && b.vg && (e.vtp_gtmCachedValues = b.vg);
            return void 0 !== d ? d(e) : Se(c, e, b)
        },
        ef = function(a, b, c) {
            c = c || [];
            var d = {},
                e;
            for (e in a) a.hasOwnProperty(e) && (d[e] = df(a[e], b, c));
            return d
        },
        df = function(a, b, c) {
            if (Ia(a)) {
                var d;
                switch (a[0]) {
                    case "function_id":
                        return a[1];
                    case "list":
                        d = [];
                        for (var e = 1; e < a.length; e++) d.push(df(a[e], b, c));
                        return d;
                    case "macro":
                        var f =
                            a[1];
                        if (c[f]) return;
                        var g = Te[f];
                        if (!g || b.$e(g)) return;
                        c[f] = !0;
                        try {
                            var h = ef(g, b, c);
                            h.vtp_gtmEventId = b.id;
                            d = cf(h, b);
                            af && (d = af.Gi(d, h))
                        } catch (y) {
                            b.Qg && b.Qg(y, Number(f)), d = !1
                        }
                        c[f] = !1;
                        return d;
                    case "map":
                        d = {};
                        for (var l = 1; l < a.length; l += 2) d[df(a[l], b, c)] = df(a[l + 1], b, c);
                        return d;
                    case "template":
                        d = [];
                        for (var n = !1, p = 1; p < a.length; p++) {
                            var q = df(a[p], b, c);
                            $e && (n = n || q === $e.od);
                            d.push(q)
                        }
                        return $e && n ? $e.Ki(d) : d.join("");
                    case "escape":
                        d = df(a[1], b, c);
                        if ($e && Ia(a[1]) && "macro" === a[1][0] && $e.cj(a)) return $e.vj(d);
                        d =
                            String(d);
                        for (var t = 2; t < a.length; t++) re[a[t]] && (d = re[a[t]](d));
                        return d;
                    case "tag":
                        var u = a[1];
                        if (!We[u]) throw Error("Unable to resolve tag reference " + u + ".");
                        return d = {
                            Fg: a[2],
                            index: u
                        };
                    case "zb":
                        var r = {
                            arg0: a[2],
                            arg1: a[3],
                            ignore_case: a[5]
                        };
                        r["function"] = a[1];
                        var v = ff(r, b, c),
                            w = !!a[4];
                        return w || 2 !== v ? w !== (1 === v) : null;
                    default:
                        throw Error("Attempting to expand unknown Value type: " + a[0] + ".");
                }
            }
            return a
        },
        ff = function(a, b, c) {
            try {
                return Ze(ef(a, b, c))
            } catch (d) {
                JSON.stringify(a)
            }
            return 2
        };
    var gf = function(a, b, c) {
        var d;
        d = Error.call(this);
        this.message = d.message;
        "stack" in d && (this.stack = d.stack);
        this.o = a;
        this.g = c
    };
    pa(gf, Error);

    function hf(a, b) {
        if (Ia(a)) {
            Object.defineProperty(a, "context", {
                value: {
                    line: b[0]
                }
            });
            for (var c = 1; c < a.length; c++) hf(a[c], b[c])
        }
    };
    var jf = function(a, b) {
        var c;
        c = Error.call(this);
        this.message = c.message;
        "stack" in c && (this.stack = c.stack);
        this.s = a;
        this.o = b;
        this.g = []
    };
    pa(jf, Error);
    var lf = function() {
        return function(a, b) {
            a instanceof jf || (a = new jf(a, kf));
            b && a.g.push(b);
            throw a;
        }
    };

    function kf(a) {
        if (!a.length) return a;
        a.push({
            id: "main",
            line: 0
        });
        for (var b = a.length - 1; 0 < b; b--) Ha(a[b].id) && a.splice(b++, 1);
        for (var c = a.length - 1; 0 < c; c--) a[c].line = a[c - 1].line;
        a.splice(0, 1);
        return a
    };
    var of = function(a) {
        function b(t) {
            for (var u = 0; u < t.length; u++) d[t[u]] = !0
        }
        for (var c = [], d = [], e = mf(a), f = 0; f < Ue.length; f++) {
            var g = Ue[f],
                h = nf(g, e);
            if (h) {
                for (var l = g.add || [], n = 0; n < l.length; n++) c[l[n]] = !0;
                b(g.block || [])
            } else null === h && b(g.block || []);
        }
        for (var p = [], q = 0; q < We.length; q++) c[q] && !d[q] && (p[q] = !0);
        return p
    }, nf = function(a, b) {
        for (var c = a["if"] || [], d = 0; d < c.length; d++) {
            var e = b(c[d]);
            if (0 === e) return !1;
            if (2 === e) return null
        }
        for (var f =
                a.unless || [], g = 0; g < f.length; g++) {
            var h = b(f[g]);
            if (2 === h) return null;
            if (1 === h) return !1
        }
        return !0
    }, mf = function(a) {
        var b = [];
        return function(c) {
            void 0 === b[c] && (b[c] = ff(Ve[c], a));
            return b[c]
        }
    };
    var pf = {
        Gi: function(a, b) {
            b[qe.wf] && "string" === typeof a && (a = 1 == b[qe.wf] ? a.toLowerCase() : a.toUpperCase());
            b.hasOwnProperty(qe.yf) && null === a && (a = b[qe.yf]);
            b.hasOwnProperty(qe.Af) && void 0 === a && (a = b[qe.Af]);
            b.hasOwnProperty(qe.zf) && !0 === a && (a = b[qe.zf]);
            b.hasOwnProperty(qe.xf) && !1 === a && (a = b[qe.xf]);
            return a
        }
    };
    var qf = function() {
        this.g = {}
    };

    function rf(a, b, c, d) {
        if (a)
            for (var e = 0; e < a.length; e++) {
                var f = void 0,
                    g = "A policy function denied the permission request";
                try {
                    f = a[e].call(void 0, b, c, d), g += "."
                } catch (h) {
                    g = "string" === typeof h ? g + (": " + h) : h instanceof Error ? g + (": " + h.message) : g + "."
                }
                if (!f) throw new gf(c, d, g);
            }
    }

    function sf(a, b, c) {
        return function() {
            var d = arguments[0];
            if (d) {
                var e = a.g[d],
                    f = a.g.all;
                if (e || f) {
                    var g = c.apply(void 0, Array.prototype.slice.call(arguments, 0));
                    rf(e, b, d, g);
                    rf(f, b, d, g)
                }
            }
        }
    };
    var wf = function(a) {
            var b = tf.J,
                c = this;
            this.o = new qf;
            this.g = {};
            var d = {},
                e = sf(this.o, b, function() {
                    var f = arguments[0];
                    return f && d[f] ? d[f].apply(void 0, Array.prototype.slice.call(arguments, 0)) : {}
                });
            Qa(a, function(f, g) {
                var h = {};
                Qa(g, function(l, n) {
                    var p = uf(l, n);
                    h[l] = p.assert;
                    d[l] || (d[l] = p.T)
                });
                c.g[f] = function(l, n) {
                    var p = h[l];
                    if (!p) throw vf(l, {}, "The requested permission " + l + " is not configured.");
                    var q = Array.prototype.slice.call(arguments, 0);
                    p.apply(void 0, q);
                    e.apply(void 0, q)
                }
            })
        },
        yf = function(a) {
            return xf.g[a] ||
                function() {}
        };

    function uf(a, b) {
        var c = bf(a, b);
        c.vtp_permissionName = a;
        c.vtp_createPermissionError = vf;
        try {
            return cf(c)
        } catch (d) {
            return {
                assert: function(e) {
                    throw new gf(e, {}, "Permission " + e + " is unknown.");
                },
                T: function() {
                    for (var e = {}, f = 0; f < arguments.length; ++f) e["arg" + (f + 1)] = arguments[f];
                    return e
                }
            }
        }
    }

    function vf(a, b, c) {
        return new gf(a, b, c)
    };
    var zf = !1;
    var Af = {};
    Af.Qj = Va('');
    Af.Oi = Va('');
    var Bf = zf,
        Cf = Af.Oi,
        Df = Af.Qj;
    var Zf = function(a, b) {
            return a.length && b.length && a.lastIndexOf(b) === a.length - b.length
        },
        $f = function(a, b) {
            var c = "*" === b.charAt(b.length - 1) || "/" === b || "/*" === b;
            Zf(b, "/*") && (b = b.slice(0, -2));
            Zf(b, "?") && (b = b.slice(0, -1));
            var d = b.split("*");
            if (!c && 1 === d.length) return a === d[0];
            for (var e = -1, f = 0; f < d.length; f++) {
                var g = d[f];
                if (g) {
                    e = a.indexOf(g, e);
                    if (-1 === e || 0 === f && 0 !== e) return !1;
                    e += g.length
                }
            }
            if (c || e === a.length) return !0;
            var h = d[d.length - 1];
            return a.lastIndexOf(h) === a.length - h.length
        },
        ag = /^[a-z0-9-]+$/i,
        bg = /^https:\/\/(\*\.|)((?:[a-z0-9-]+\.)+[a-z0-9-]+)\/(.*)$/i,
        dg = function(a, b) {
            var c;
            if (!(c = !cg(a))) {
                var d;
                a: {
                    var e = a.hostname.split(".");
                    if (2 > e.length) d = !1;
                    else {
                        for (var f = 0; f < e.length; f++)
                            if (!ag.exec(e[f])) {
                                d = !1;
                                break a
                            }
                        d = !0
                    }
                }
                c = !d
            }
            if (c) return !1;
            for (var g = 0; g < b.length; g++) {
                var h;
                var l = a,
                    n = b[g];
                if (!bg.exec(n)) throw Error("Invalid Wildcard");
                var p = n.slice(8),
                    q = p.slice(0, p.indexOf("/")),
                    t;
                var u = l.hostname,
                    r = q;
                if (0 !== r.indexOf("*.")) t = u.toLowerCase() === r.toLowerCase();
                else {
                    r = r.slice(2);
                    var v = u.toLowerCase().indexOf(r.toLowerCase());
                    t = -1 === v ? !1 : u.length === r.length ?
                        !0 : u.length !== r.length + v ? !1 : "." === u[v - 1]
                }
                if (t) {
                    var w = p.slice(p.indexOf("/"));
                    h = $f(l.pathname + l.search, w) ? !0 : !1
                } else h = !1;
                if (h) return !0
            }
            return !1
        },
        cg = function(a) {
            return "https:" === a.protocol && (!a.port || "443" === a.port)
        };
    var eg = /^([a-z][a-z0-9]*):(!|\?)(\*|string|boolean|number|Fn|DustMap|List|OpaqueValue)$/i,
        fg = {
            Fn: "function",
            DustMap: "Object",
            List: "Array"
        },
        Q = function(a, b, c) {
            for (var d = 0; d < b.length; d++) {
                var e = eg.exec(b[d]);
                if (!e) throw Error("Internal Error in " + a);
                var f = e[1],
                    g = "!" === e[2],
                    h = e[3],
                    l = c[d],
                    n = typeof l;
                if (null === l || "undefined" === n) {
                    if (g) throw Error("Error in " + a + ". Required argument " + f + " not supplied.");
                } else if ("*" !== h) {
                    var p = typeof l;
                    l instanceof nb ? p = "Fn" : l instanceof ya ? p = "List" : l instanceof rb ? p = "DustMap" :
                        l instanceof Cc && (p = "OpaqueValue");
                    if (p != h) throw Error("Error in " + a + ". Argument " + f + " has type " + p + ", which does not match required type " + (fg[h] || h) + ".");
                }
            }
        };

    function gg(a) {
        return "" + a
    }

    function hg(a, b) {
        var c = [];
        return c
    };
    var ig = function(a, b) {
            var c = new nb(a, function() {
                for (var d = Array.prototype.slice.call(arguments, 0), e = 0; e < d.length; e++) d[e] = A(this, d[e]);
                return b.apply(this, d)
            });
            c.ub();
            return c
        },
        jg = function(a, b) {
            var c = new rb,
                d;
            for (d in b)
                if (b.hasOwnProperty(d)) {
                    var e = b[d];
                    Ga(e) ? c.set(d, ig(a + "_" + d, e)) : (Ha(e) || k(e) || "boolean" == typeof e) && c.set(d, e)
                }
            c.ub();
            return c
        };
    var kg = function(a, b) {
        Q(G(this), ["apiName:!string", "message:?string"], arguments);
        var c = {},
            d = new rb;
        return d = jg("AssertApiSubject", c)
    };
    var lg = function(a, b) {
        Q(G(this), ["actual:?*", "message:?string"], arguments);
        var c = {},
            d = new rb;
        return d = jg("AssertThatSubject", c)
    };

    function mg(a) {
        return function() {
            for (var b = [], c = this.g, d = 0; d < arguments.length; ++d) b.push(Ic(arguments[d], c));
            return Hc(a.apply(null, b))
        }
    }
    var og = function() {
        for (var a = Math, b = ng, c = {}, d = 0; d < b.length; d++) {
            var e = b[d];
            a.hasOwnProperty(e) && (c[e] = mg(a[e].bind(a)))
        }
        return c
    };
    var pg = function(a) {
        var b;
        return b
    };
    var qg = function(a) {
        var b;
        return b
    };
    var rg = function(a) {
        return encodeURI(a)
    };
    var sg = function(a) {
        return encodeURIComponent(a)
    };
    var tg = function(a) {
        Q(G(this), ["message:?string"], arguments);
    };
    var ug = function(a, b) {
        Q(G(this), ["min:!number", "max:!number"], arguments);
        return Na(a, b)
    };
    var vg = function(a, b, c) {
        var d = a.g.g;
        if (!d) throw Error("Missing program state.");
        d.Ai.apply(null, Array.prototype.slice.call(arguments, 1))
    };
    var wg = function() {
        vg(this, "read_container_data");
        var a = new rb;
        a.set("containerId", 'GTM-WJZQSJF');
        a.set("version", '296');
        a.set("environmentName", '');
        a.set("debugMode", Bf);
        a.set("previewMode", Df);
        a.set("environmentMode", Cf);
        a.ub();
        return a
    };
    var xg = {};
    xg.sstECEnableData = !0;
    xg.enableAdsEc = !0;
    xg.enableCrossDomain = !1;
    xg.enableCrossDomain = !0;
    xg.sstFFConversionEnabled = !0;
    xg.sstEnableAuid = !0;
    xg.enableGbraidUpdate = !0;
    xg.requireGtagUserDataTos = !0;

    function yg() {
        return Hc(xg)
    };
    var zg = function() {
        return (new Date).getTime()
    };
    var Ag = function(a) {
        if (null === a) return "null";
        if (a instanceof ya) return "array";
        if (a instanceof nb) return "function";
        if (a instanceof Cc) {
            a = a.Qa;
            if (void 0 === a.constructor || void 0 === a.constructor.name) {
                var b = String(a);
                return b.substring(8, b.length - 1)
            }
            return String(a.constructor.name)
        }
        return typeof a
    };
    var Bg = function(a) {
        function b(c) {
            return function(d) {
                try {
                    return c(d)
                } catch (e) {
                    (Bf || Df) && a.call(this, e.message)
                }
            }
        }
        return {
            parse: b(function(c) {
                return Hc(JSON.parse(c))
            }),
            stringify: b(function(c) {
                return JSON.stringify(Ic(c))
            })
        }
    };
    var Cg = function(a) {
        return Ua(Ic(a, this.g))
    };
    var Dg = function(a) {
        return Number(Ic(a, this.g))
    };
    var Eg = function(a) {
        return null === a ? "null" : void 0 === a ? "undefined" : a.toString()
    };
    var Fg = function(a, b, c) {
        var d = null,
            e = !1;
        return e ? d : null
    };
    var ng = "floor ceil round max min abs pow sqrt".split(" ");
    var Gg = function() {
            var a = {};
            return {
                Vi: function(b) {
                    return a.hasOwnProperty(b) ? a[b] : void 0
                },
                Kj: function(b, c) {
                    a[b] = c
                },
                reset: function() {
                    a = {}
                }
            }
        },
        Hg = function(a, b) {
            Q(G(this), ["apiName:!string", "mock:?*"], arguments);
        };
    var Ig = {};
    Ig.keys = function(a) {
        return new ya
    };
    Ig.values = function(a) {
        return new ya
    };
    Ig.entries = function(a) {
        return new ya
    };
    Ig.freeze = function(a) {
        return a
    };
    Ig.delete = function(a, b) {
        return !1
    };
    var Kg = function() {
        this.g = {};
        this.o = {};
    };
    Kg.prototype.get = function(a, b) {
        var c = this.g.hasOwnProperty(a) ? this.g[a] : void 0;
        return c
    };
    Kg.prototype.add = function(a, b, c) {
        if (this.g.hasOwnProperty(a)) throw "Attempting to add a function which already exists: " + a + ".";
        if (this.o.hasOwnProperty(a)) throw "Attempting to add an API with an existing private API name: " + a + ".";
        this.g[a] = c ? void 0 : Ga(b) ? ig(a, b) : jg(a, b)
    };
    var Mg = function(a, b, c) {
        if (a.o.hasOwnProperty(b)) throw "Attempting to add a private function which already exists: " + b + ".";
        if (a.g.hasOwnProperty(b)) throw "Attempting to add a private function with an existing API name: " + b + ".";
        a.o[b] = Ga(c) ? ig(b, c) : jg(b, c)
    };

    function Lg(a, b) {
        var c = void 0;
        return c
    };

    function Ng() {
        var a = {};
        return a
    };
    var R = {
        qc: "_ee",
        vd: "_syn_or_mod",
        Zj: "_uei",
        ue: "_eu",
        Wj: "_pci",
        Kb: "event_callback",
        dd: "event_timeout",
        Ba: "gtag.config",
        Ma: "gtag.get",
        va: "purchase",
        Ib: "refund",
        mb: "begin_checkout",
        Gb: "add_to_cart",
        Hb: "remove_from_cart",
        Bh: "view_cart",
        Cf: "add_to_wishlist",
        wa: "view_item",
        nb: "view_promotion",
        Zc: "select_promotion",
        Vd: "select_item",
        Ya: "view_item_list",
        Bf: "add_payment_info",
        Ah: "add_shipping_info",
        Oa: "value_key",
        Za: "value_callback",
        Ca: "allow_ad_personalization_signals",
        jc: "restricted_data_processing",
        bc: "allow_google_signals",
        Fa: "cookie_expires",
        fc: "cookie_update",
        mc: "session_duration",
        hd: "session_engaged_time",
        Pa: "user_properties",
        qa: "transport_url",
        V: "ads_data_redaction",
        xa: "user_data",
        hc: "first_party_collection",
        C: "ad_storage",
        I: "analytics_storage",
        Sd: "region",
        vf: "wait_for_update",
        Ea: "conversion_linker",
        Da: "conversion_cookie_prefix",
        da: "value",
        ca: "currency",
        Zf: "trip_type",
        X: "items",
        Sf: "passengers",
        Yd: "allow_custom_scripts",
        nc: "session_id",
        Xf: "quantity",
        cb: "transaction_id",
        qb: "language",
        bd: "country",
        $c: "allow_enhanced_conversions",
        ce: "aw_merchant_id",
        ae: "aw_feed_country",
        be: "aw_feed_language",
        $d: "discount",
        ba: "developer_id",
        jd: "delivery_postal_code",
        je: "estimated_delivery_date",
        he: "shipping",
        pe: "new_customer",
        de: "customer_lifetime_value",
        ie: "enhanced_conversions",
        ac: "page_view",
        oa: "linker",
        O: "domains",
        Nb: "decorate_forms",
        Pf: "enhanced_conversions_automatic_settings",
        Kh: "auto_detection_enabled",
        Qf: "ga_temp_client_id",
        Wd: "user_engagement",
        vh: "app_remove",
        wh: "app_store_refund",
        xh: "app_store_subscription_cancel",
        yh: "app_store_subscription_convert",
        zh: "app_store_subscription_renew",
        Ch: "first_open",
        Dh: "first_visit",
        Eh: "in_app_purchase",
        Fh: "session_start",
        Gh: "user_data_login",
        Hh: "user_data_logout",
        Ih: "allow_display_features",
        cc: "campaign",
        Ef: "campaign_content",
        Ff: "campaign_id",
        Gf: "campaign_medium",
        Hf: "campaign_name",
        If: "campaign_source",
        Jf: "campaign_term",
        Jb: "client_id",
        ma: "cookie_domain",
        ad: "cookie_name",
        ob: "cookie_path",
        Na: "cookie_flags",
        Kf: "custom_map",
        me: "groups",
        Sj: "non_interaction",
        Ob: "page_location",
        Rf: "page_path",
        ab: "page_referrer",
        qe: "page_title",
        kc: "send_page_view",
        rb: "send_to",
        se: "session_engaged",
        fd: "_logged_in_state",
        te: "session_number",
        bi: "tracking_id",
        eb: "url_passthrough",
        Mb: "accept_incoming",
        ic: "url_position",
        Vf: "phone_conversion_number",
        Tf: "phone_conversion_callback",
        Uf: "phone_conversion_css_class",
        Wf: "phone_conversion_options",
        Yh: "phone_conversion_ids",
        Xh: "phone_conversion_country_code",
        Df: "aw_remarketing",
        Zd: "aw_remarketing_only",
        Xd: "gclid",
        Jh: "auid",
        Ph: "affiliation",
        Of: "tax",
        fe: "list_name",
        Nf: "checkout_step",
        Mf: "checkout_option",
        Qh: "coupon",
        Rh: "promotions",
        Pb: "user_id",
        Zh: "retoken",
        na: "cookie_prefix",
        Lf: "disable_merchant_reported_purchases",
        Oh: "dc_natural_search",
        Nh: "dc_custom_params",
        Vh: "method",
        ai: "search_term",
        Mh: "content_type",
        Wh: "optimize_id",
        Sh: "experiments",
        $a: "google_signals",
        ed: "google_tld",
        kd: "update",
        ke: "firebase_id",
        Lb: "ga_restrict_domain",
        cd: "event_settings",
        ee: "dynamic_event_settings",
        oc: "user_data_settings",
        $h: "screen_name",
        Uh: "_x_19",
        pb: "_ecid",
        Th: "_x_20",
        oe: "internal_traffic_results",
        Yf: "traffic_type",
        gd: "referral_exclusion_definition",
        ne: "ignore_referrer",
        Lh: "content_group"
    };
    var Qg = {};
    R.ag = Object.freeze((Qg[R.Bf] = 1, Qg[R.Ah] = 1, Qg[R.Gb] = 1, Qg[R.Hb] = 1, Qg[R.Bh] = 1, Qg[R.mb] = 1, Qg[R.Vd] = 1, Qg[R.Ya] = 1, Qg[R.Zc] = 1, Qg[R.nb] = 1, Qg[R.va] = 1, Qg[R.Ib] = 1, Qg[R.wa] = 1, Qg[R.Cf] = 1, Qg));
    R.we = Object.freeze([R.Ca, R.bc, R.fc]);
    R.li = Object.freeze([].concat(R.we));
    R.xe = Object.freeze([R.Fa, R.dd, R.mc, R.hd]);
    R.mi = Object.freeze([].concat(R.xe));
    var Sg = {},
        Tg = function(a, b) {
            Sg[a] = Sg[a] || [];
            Sg[a][b] = !0
        },
        Ug = function(a) {
            for (var b = [], c = Sg[a] || [], d = 0; d < c.length; d++) c[d] && (b[Math.floor(d / 6)] ^= 1 << d % 6);
            for (var e = 0; e < b.length; e++) b[e] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_".charAt(b[e] || 0);
            return b.join("")
        };
    var Vg = function(a) {
        Tg("GTM", a)
    };
    var Wg = function(a) {
        this.g = a;
        this.defaultValue = !1
    };
    var Xg = new Wg(1933),
        Yg = new Wg(1956);
    var $g = function() {
        var a = Zg,
            b = "Ye";
        if (a.Ye && a.hasOwnProperty(b)) return a.Ye;
        var c = new a;
        a.Ye = c;
        a.hasOwnProperty(b);
        return c
    };
    var Zg = function() {
            var a = {};
            this.g = function(b, c) {
                return null != a[b] ? a[b] : c
            };
            this.o = function() {
                a[Xg.g] = !0
            }
        },
        ah = function(a) {
            return $g().g(a.g, a.defaultValue)
        };
    var bh = [];

    function ch() {
        var a = Xb("google_tag_data", {});
        a.ics || (a.ics = {
            entries: {},
            set: dh,
            update: eh,
            addListener: fh,
            notifyListeners: gh,
            active: !1,
            usedDefault: !1
        });
        return a.ics
    }

    function dh(a, b, c, d, e, f) {
        var g = ch();
        g.active = !0;
        g.usedDefault = !0;
        if (void 0 != b) {
            var h = g.entries,
                l = h[a] || {},
                n = l.region,
                p = c && k(c) ? c.toUpperCase() : void 0;
            d = d.toUpperCase();
            e = e.toUpperCase();
            if ("" === d || p === e || (p === d ? n !== e : !p && !n)) {
                var q = !!(f && 0 < f && void 0 === l.update),
                    t = {
                        region: p,
                        initial: "granted" === b,
                        update: l.update,
                        quiet: q
                    };
                if ("" !== d || !1 !== l.initial) h[a] = t;
                q && m.setTimeout(function() {
                    h[a] === t && t.quiet && (t.quiet = !1, hh(a), gh(), Tg("TAGGING", 2))
                }, f)
            }
        }
    }

    function eh(a, b) {
        var c = ch();
        c.active = !0;
        if (void 0 != b) {
            var d = ih(a),
                e = c.entries,
                f = e[a] = e[a] || {};
            f.update = "granted" === b;
            var g = ih(a);
            f.quiet ? (f.quiet = !1, hh(a)) : g !== d && hh(a)
        }
    }

    function fh(a, b) {
        bh.push({
            Oe: a,
            Ri: b
        })
    }

    function hh(a) {
        for (var b = 0; b < bh.length; ++b) {
            var c = bh[b];
            Ia(c.Oe) && -1 !== c.Oe.indexOf(a) && (c.Ug = !0)
        }
    }

    function gh(a) {
        for (var b = 0; b < bh.length; ++b) {
            var c = bh[b];
            if (c.Ug) {
                c.Ug = !1;
                try {
                    c.Ri({
                        consentEventId: a
                    })
                } catch (d) {}
            }
        }
    }
    var ih = function(a) {
            var b = ch().entries[a] || {};
            return void 0 !== b.update ? b.update : b.initial
        },
        jh = function(a) {
            return (ch().entries[a] || {}).initial
        },
        kh = function(a) {
            return !(ch().entries[a] || {}).quiet
        },
        lh = function() {
            return ah(Xg) ? ch().active : !1
        },
        mh = function() {
            return ch().usedDefault
        },
        nh = function(a, b) {
            ch().addListener(a, b)
        },
        oh = function(a) {
            ch().notifyListeners(a)
        },
        ph = function(a, b) {
            function c() {
                for (var e = 0; e < b.length; e++)
                    if (!kh(b[e])) return !0;
                return !1
            }
            if (c()) {
                var d = !1;
                nh(b, function(e) {
                    d || c() || (d = !0, a(e))
                })
            } else a({})
        },
        qh = function(a, b) {
            function c() {
                for (var f = [], g = 0; g < d.length; g++) {
                    var h = d[g];
                    !1 === ih(h) || e[h] || (f.push(h), e[h] = !0)
                }
                return f
            }
            var d = k(b) ? [b] : b,
                e = {};
            c().length !== d.length && nh(d, function(f) {
                var g = c();
                0 < g.length && (f.Oe = g, a(f))
            })
        };

    function rh(a) {
        for (var b = [], c = 0; c < sh.length; c++) {
            var d = a(sh[c]);
            b[c] = !0 === d ? "1" : !1 === d ? "0" : "-"
        }
        return b.join("")
    }
    var sh = [R.C, R.I],
        th = function(a) {
            var b = a[R.Sd];
            b && Vg(40);
            var c = a[R.vf];
            c && Vg(41);
            for (var d = Ia(b) ? b : [b], e = {
                    Xb: 0
                }; e.Xb < d.length; e = {
                    Xb: e.Xb
                }, ++e.Xb) Qa(a, function(f) {
                return function(g, h) {
                    if (g !== R.Sd && g !== R.vf) {
                        var l = d[f.Xb];
                        ch().set(g, h, l, "VN", "VN-33", c)
                    }
                }
            }(e))
        },
        uh = 0,
        vh = function(a, b) {
            Qa(a, function(e, f) {
                ch().update(e, f)
            });
            oh(b);
            var c = cb(),
                d = c - uh;
            uh && 0 <= d && 1E3 > d && Vg(66);
            uh = c
        },
        wh = function(a) {
            var b = ih(a);
            return void 0 != b ? b : !0
        },
        xh = function() {
            return "G1" + rh(ih)
        },
        yh = function() {
            return "G1" +
                rh(jh)
        },
        zh = function(a, b) {
            nh(a, b)
        },
        Ah = function(a, b) {
            qh(a, b)
        },
        Bh = function(a, b) {
            ph(a, b)
        };
    var Dh = function(a) {
            return Ch ? H.querySelectorAll(a) : null
        },
        Eh = function(a, b) {
            if (!Ch) return null;
            if (Element.prototype.closest) try {
                return a.closest(b)
            } catch (e) {
                return null
            }
            var c = Element.prototype.matches || Element.prototype.webkitMatchesSelector || Element.prototype.mozMatchesSelector || Element.prototype.msMatchesSelector || Element.prototype.oMatchesSelector,
                d = a;
            if (!H.documentElement.contains(d)) return null;
            do {
                try {
                    if (c.call(d, b)) return d
                } catch (e) {
                    break
                }
                d = d.parentElement || d.parentNode
            } while (null !== d && 1 === d.nodeType);
            return null
        },
        Fh = !1;
    if (H.querySelectorAll) try {
        var Lh = H.querySelectorAll(":root");
        Lh && 1 == Lh.length && Lh[0] == H.documentElement && (Fh = !0)
    } catch (a) {}
    var Ch = Fh;
    var Mh = function(a) {
            return void 0 === a || null === a ? "" : k(a) ? ab(String(a)) : "e0"
        },
        Oh = function(a) {
            return a.replace(Nh, "")
        },
        Qh = function(a) {
            return Ph(a.replace(/\s/g, ""))
        },
        Ph = function(a) {
            return ab(a.replace(Rh, "").toLowerCase())
        },
        Th = function(a) {
            a = a.replace(/[\s-()/.]/g, "");
            "+" !== a.charAt(0) && (a = "+" + a);
            return Sh.test(a) ? a : "e0"
        },
        Vh = function(a) {
            var b = a.toLowerCase().split("@");
            if (2 == b.length) {
                var c = b[0];
                /^(gmail|googlemail)\./.test(b[1]) && (c = c.replace(/\./g, ""));
                c = c + "@" + b[1];
                if (Uh.test(c)) return c
            }
            return "e0"
        },
        Yh = function(a, b) {
            window.Promise || b([]);
            Promise.all(a.map(function(c) {
                return c.value && -1 !== Wh.indexOf(c.name) ? Xh(c.value).then(function(d) {
                    c.value = d
                }) : Promise.resolve()
            })).then(function() {
                b(a)
            }).catch(function() {
                b([])
            })
        },
        Xh = function(a) {
            if ("" === a || "e0" === a) return Promise.resolve(a);
            if (m.crypto && m.crypto.subtle) try {
                var b = Zh(a);
                return m.crypto.subtle.digest("SHA-256", b).then(function(c) {
                    var d = Array.from(new Uint8Array(c)).map(function(e) {
                        return String.fromCharCode(e)
                    }).join("");
                    return m.btoa(d).replace(/\+/g,
                        "-").replace(/\//g, "_").replace(/=+$/, "")
                }).catch(function() {
                    return "e2"
                })
            } catch (c) {
                return Promise.resolve("e2")
            } else return Promise.resolve("e1")
        },
        Zh = function(a) {
            var b;
            if (m.TextEncoder) b = (new m.TextEncoder("utf-8")).encode(a);
            else {
                for (var c = [], d = 0; d < a.length; d++) {
                    var e = a.charCodeAt(d);
                    128 > e ? c.push(e) : 2048 > e ? c.push(192 | e >> 6, 128 | e & 63) : 55296 > e || 57344 <= e ? c.push(224 | e >> 12, 128 | e >> 6 & 63, 128 | e & 63) : (e = 65536 + ((e & 1023) << 10 | a.charCodeAt(++d) & 1023), c.push(240 | e >> 18, 128 | e >> 12 & 63, 128 | e >> 6 & 63, 128 | e & 63))
                }
                b = new Uint8Array(c)
            }
            return b
        },
        Rh = /[0-9`~!@#$%^&*()_\-+=:;<>,.?|/\\[\]]/g,
        Uh = /^\S+@\S+\.\S+$/,
        Sh = /^\+\d{11,15}$/,
        Nh = /[.~]/g,
        $h = {},
        ai = ($h.email = "em", $h.phone_number = "pn", $h.first_name = "fn", $h.last_name = "ln", $h.street = "sa", $h.city = "ct", $h.region = "rg", $h.country = "co", $h.postal_code = "pc", $h.error_code = "ec", $h),
        bi = function(a, b) {
            function c(n, p, q) {
                var t = n[p];
                Ia(t) || (t = [t]);
                for (var u = 0; u < t.length; ++u) {
                    var r = Mh(t[u]);
                    "" !== r && f.push({
                        name: p,
                        value: q(r),
                        index: void 0
                    })
                }
            }

            function d(n, p, q, t) {
                var u = Mh(n[p]);
                "" !== u && f.push({
                    name: p,
                    value: q(u),
                    index: t
                })
            }

            function e(n) {
                return function(p) {
                    Vg(64);
                    return n(p)
                }
            }
            var f = [];
            if ("https:" === m.location.protocol) {
                c(a, "email", Vh);
                c(a, "phone_number", Th);
                c(a, "first_name", e(Qh));
                c(a, "last_name", e(Qh));
                var g = a.home_address || {};
                c(g, "street", e(Ph));
                c(g, "city", e(Ph));
                c(g, "postal_code", e(Oh));
                c(g, "region", e(Ph));
                c(g, "country", e(Oh));
                var h = a.address || {};
                Ia(h) || (h = [h]);
                for (var l = 0; l < h.length; l++) d(h[l], "first_name", Qh, l), d(h[l], "last_name", Qh, l), d(h[l], "street", Ph, l), d(h[l], "city", Ph, l), d(h[l], "postal_code", Oh, l), d(h[l],
                    "region", Ph, l), d(h[l], "country", Oh, l);
                Yh(f, b)
            } else f.push({
                name: "error_code",
                value: "e3",
                index: void 0
            }), b(f)
        },
        ci = function(a, b) {
            bi(a, function(c) {
                for (var d = ["tv.1"], e = 0, f = 0; f < c.length; ++f) {
                    var g = c[f].name,
                        h = c[f].value,
                        l = c[f].index,
                        n = ai[g];
                    n && h && (-1 === Wh.indexOf(g) || /^e\d+$/.test(h) || /^[0-9A-Za-z_-]{43}$/.test(h)) && (void 0 !== l && (n += l), d.push(n + "." + h), e++)
                }
                1 === c.length && "error_code" === c[0].name && (e = 0);
                b(encodeURIComponent(d.join("~")), e)
            })
        },
        di = function(a) {
            if (m.Promise) try {
                return new Promise(function(b) {
                    ci(a,
                        function(c, d) {
                            b({
                                Kc: c,
                                ck: d
                            })
                        })
                })
            } catch (b) {}
        },
        Wh = Object.freeze(["email", "phone_number", "first_name", "last_name", "street"]);
    var ei = function() {
            this.eventModel = {};
            this.targetConfig = {};
            this.containerConfig = {};
            this.globalConfig = {};
            this.remoteConfig = {};
            this.onSuccess = function() {};
            this.onFailure = function() {};
            this.setContainerTypeLoaded = function() {};
            this.getContainerTypeLoaded = function() {};
            this.eventId = void 0;
            this.isGtmEvent = !1
        },
        fi = function(a) {
            var b = new ei;
            b.eventModel = a;
            return b
        },
        gi = function(a, b) {
            a.targetConfig = b;
            return a
        },
        hi = function(a, b) {
            a.containerConfig = b;
            return a
        },
        ii = function(a, b) {
            a.globalConfig = b;
            return a
        },
        ji = function(a,
            b) {
            a.remoteConfig = b;
            return a
        },
        ki = function(a, b) {
            a.onSuccess = b;
            return a
        },
        li = function(a, b) {
            a.setContainerTypeLoaded = b;
            return a
        },
        mi = function(a, b) {
            a.getContainerTypeLoaded = b;
            return a
        },
        ni = function(a, b) {
            a.onFailure = b;
            return a
        };
    ei.prototype.getWithConfig = function(a) {
        if (void 0 !== this.eventModel[a]) return this.eventModel[a];
        if (void 0 !== this.targetConfig[a]) return this.targetConfig[a];
        if (void 0 !== this.containerConfig[a]) return this.containerConfig[a];
        if (void 0 !== this.globalConfig[a]) return this.globalConfig[a];
        if (void 0 !== this.remoteConfig[a]) return this.remoteConfig[a]
    };
    var oi = function(a) {
            function b(d) {
                for (var e = Object.keys(d), f = 0; f < e.length; ++f) c[e[f]] = 1
            }
            var c = {};
            b(a.eventModel);
            b(a.targetConfig);
            b(a.containerConfig);
            b(a.globalConfig);
            return Object.keys(c)
        },
        pi = function(a, b, c) {
            function d(g) {
                Gc(g) && Qa(g, function(h, l) {
                    f = !0;
                    e[h] = l
                })
            }
            var e = {},
                f = !1;
            c && 1 !== c || (d(a.remoteConfig[b]), d(a.globalConfig[b]), d(a.containerConfig[b]), d(a.targetConfig[b]));
            c && 2 !== c || d(a.eventModel[b]);
            return f ? e : void 0
        },
        qi = function(a) {
            var b = [R.cc, R.Ef, R.Ff, R.Gf, R.Hf, R.If, R.Jf],
                c = {},
                d = !1,
                e = function(f) {
                    for (var g =
                            0; g < b.length; g++) void 0 !== f[b[g]] && (c[b[g]] = f[b[g]], d = !0);
                    return d
                };
            if (e(a.eventModel) || e(a.targetConfig) || e(a.containerConfig) || e(a.globalConfig)) return c;
            e(a.remoteConfig);
            return c
        };
    var tf = {},
        S = null,
        ri = Math.random();
    tf.J = "GTM-WJZQSJF";
    tf.td = "ak0";
    tf.uh = "ChEI8MLJiwYQ5NDawJD7q7fBARIkAIsVh5zphAdv53qQ5TjirWAHmmH1KYGMR27Vl05sXd06h9jmGgJyLQ\x3d\x3d";
    var si = {
            __cl: !0,
            __ecl: !0,
            __ehl: !0,
            __evl: !0,
            __fal: !0,
            __fil: !0,
            __fsl: !0,
            __hl: !0,
            __jel: !0,
            __lcl: !0,
            __sdl: !0,
            __tl: !0,
            __ytl: !0
        },
        ti = {
            __paused: !0,
            __tg: !0
        },
        ui;
    for (ui in si) si.hasOwnProperty(ui) && (ti[ui] = !0);
    tf.Td = "www.googletagmanager.com";
    var vi = tf.Td + "/gtm.js";
    var wi = vi,
        xi = Va(""),
        yi = null,
        zi = null,
        Ai = "https://www.googletagmanager.com/a?id=" + tf.J + "&cv=296",
        Bi = {},
        Ci = {},
        Di = function() {
            var a = S.sequence || 1;
            S.sequence = a + 1;
            return a
        };
    tf.th = "";
    var Ei = "";
    tf.ud = Ei;
    var Fi = {},
        Gi = new Oa,
        Hi = {},
        Ii = {},
        Li = {
            name: "dataLayer",
            set: function(a, b) {
                J(jb(a, b), Hi);
                Ji()
            },
            get: function(a) {
                return Ki(a, 2)
            },
            reset: function() {
                Gi = new Oa;
                Hi = {};
                Ji()
            }
        },
        Ki = function(a, b) {
            return 2 != b ? Gi.get(a) : Mi(a)
        },
        Mi = function(a, b) {
            var c = a.split(".");
            b = b || [];
            for (var d = Hi, e = 0; e < c.length; e++) {
                if (null === d) return !1;
                if (void 0 === d) break;
                d = d[c[e]];
                if (-1 !== Ja(b, d)) return
            }
            return d
        },
        Ni = function(a, b) {
            Ii.hasOwnProperty(a) || (Gi.set(a, b), J(jb(a, b), Hi), Ji())
        },
        Oi = function() {
            for (var a = ["gtm.allowlist", "gtm.blocklist",
                    "gtm.whitelist", "gtm.blacklist", "tagTypeBlacklist"
                ], b = 0; b < a.length; b++) {
                var c = a[b],
                    d = Ki(c, 1);
                if (Ia(d) || Gc(d)) d = J(d);
                Ii[c] = d
            }
        },
        Ji = function(a) {
            Qa(Ii, function(b, c) {
                Gi.set(b, c);
                J(jb(b, void 0), Hi);
                J(jb(b, c), Hi);
                a && delete Ii[b]
            })
        },
        Qi = function(a, b, c) {
            Fi[a] = Fi[a] || {};
            Fi[a][b] = Pi(b, c)
        },
        Pi = function(a, b) {
            var c, d = 1 !== (void 0 === b ? 2 : b) ? Mi(a) : Gi.get(a);
            "array" === Ec(d) || "object" === Ec(d) ? c = J(d) : c = d;
            return c
        },
        Ri = function(a, b) {
            if (Fi[a]) return Fi[a][b]
        },
        Si = function(a, b) {
            Fi[a] && delete Fi[a][b]
        };
    var Ti, Ui = !1;

    function Vi() {
        Ui = !0;
        Ti = productSettings, productSettings = void 0;
        Ti = Ti || {}
    }
    var Wi = function(a) {
        Ui || Vi();
        return Ti[a]
    };
    var Xi = function(a) {
        if (H.hidden) return !0;
        var b = a.getBoundingClientRect();
        if (b.top == b.bottom || b.left == b.right || !m.getComputedStyle) return !0;
        var c = m.getComputedStyle(a, null);
        if ("hidden" === c.visibility) return !0;
        for (var d = a, e = c; d;) {
            if ("none" === e.display) return !0;
            var f = e.opacity,
                g = e.filter;
            if (g) {
                var h = g.indexOf("opacity(");
                0 <= h && (g = g.substring(h + 8, g.indexOf(")", h)), "%" == g.charAt(g.length - 1) && (g = g.substring(0, g.length - 1)), f = Math.min(g, f))
            }
            if (void 0 !== f && 0 >= f) return !0;
            (d = d.parentElement) && (e = m.getComputedStyle(d,
                null))
        }
        return !1
    };
    var fj = /:[0-9]+$/,
        gj = function(a, b, c, d) {
            for (var e = [], f = a.split("&"), g = 0; g < f.length; g++) {
                var h = f[g].split("=");
                if (decodeURIComponent(h[0]).replace(/\+/g, " ") === b) {
                    var l = h.slice(1).join("=");
                    if (!c) return d ? l : decodeURIComponent(l).replace(/\+/g, " ");
                    e.push(d ? l : decodeURIComponent(l).replace(/\+/g, " "))
                }
            }
            return c ? e : void 0
        },
        jj = function(a, b, c, d, e) {
            b && (b = String(b).toLowerCase());
            if ("protocol" === b || "port" === b) a.protocol = hj(a.protocol) || hj(m.location.protocol);
            "port" === b ? a.port = String(Number(a.hostname ? a.port :
                m.location.port) || ("http" == a.protocol ? 80 : "https" == a.protocol ? 443 : "")) : "host" === b && (a.hostname = (a.hostname || m.location.hostname).replace(fj, "").toLowerCase());
            return ij(a, b, c, d, e)
        },
        ij = function(a, b, c, d, e) {
            var f, g = hj(a.protocol);
            b && (b = String(b).toLowerCase());
            switch (b) {
                case "url_no_fragment":
                    f = kj(a);
                    break;
                case "protocol":
                    f = g;
                    break;
                case "host":
                    f = a.hostname.replace(fj, "").toLowerCase();
                    if (c) {
                        var h = /^www\d*\./.exec(f);
                        h && h[0] && (f = f.substr(h[0].length))
                    }
                    break;
                case "port":
                    f = String(Number(a.port) || ("http" ==
                        g ? 80 : "https" == g ? 443 : ""));
                    break;
                case "path":
                    a.pathname || a.hostname || Tg("TAGGING", 1);
                    f = "/" == a.pathname.substr(0, 1) ? a.pathname : "/" + a.pathname;
                    var l = f.split("/");
                    0 <= Ja(d || [], l[l.length - 1]) && (l[l.length - 1] = "");
                    f = l.join("/");
                    break;
                case "query":
                    f = a.search.replace("?", "");
                    e && (f = gj(f, e, !1, void 0));
                    break;
                case "extension":
                    var n = a.pathname.split(".");
                    f = 1 < n.length ? n[n.length - 1] : "";
                    f = f.split("/")[0];
                    break;
                case "fragment":
                    f = a.hash.replace("#", "");
                    break;
                default:
                    f = a && a.href
            }
            return f
        },
        hj = function(a) {
            return a ? a.replace(":",
                "").toLowerCase() : ""
        },
        kj = function(a) {
            var b = "";
            if (a && a.href) {
                var c = a.href.indexOf("#");
                b = 0 > c ? a.href : a.href.substr(0, c)
            }
            return b
        },
        lj = function(a) {
            var b = H.createElement("a");
            a && (b.href = a);
            var c = b.pathname;
            "/" !== c[0] && (a || Tg("TAGGING", 1), c = "/" + c);
            var d = b.hostname.replace(fj, "");
            return {
                href: b.href,
                protocol: b.protocol,
                host: b.host,
                hostname: d,
                pathname: c,
                search: b.search,
                hash: b.hash,
                port: b.port
            }
        },
        mj = function(a) {
            function b(n) {
                var p = n.split("=")[0];
                return 0 > d.indexOf(p) ? n : p + "=0"
            }

            function c(n) {
                return n.split("&").map(b).filter(function(p) {
                    return void 0 !=
                        p
                }).join("&")
            }
            var d = "gclid dclid gbraid wbraid gclaw gcldc gclha gclgf gclgb _gl".split(" "),
                e = lj(a),
                f = a.split(/[?#]/)[0],
                g = e.search,
                h = e.hash;
            "?" === g[0] && (g = g.substring(1));
            "#" === h[0] && (h = h.substring(1));
            g = c(g);
            h = c(h);
            "" !== g && (g = "?" + g);
            "" !== h && (h = "#" + h);
            var l = "" + f + g + h;
            "/" === l[l.length - 1] && (l = l.substring(0, l.length - 1));
            return l
        };
    var nj = {};
    var qj = function(a) {
            if (0 == a.length) return null;
            var b;
            b = oj(a, function(c) {
                return !pj.test(c.Ja)
            });
            b = oj(b, function(c) {
                return "INPUT" === c.element.tagName.toUpperCase()
            });
            b = oj(b, function(c) {
                return !Xi(c.element)
            });
            return b[0]
        },
        oj = function(a, b) {
            if (1 >= a.length) return a;
            var c = a.filter(b);
            return 0 == c.length ? a : c
        },
        rj = function(a) {
            var b;
            if (a === H.body) b = "body";
            else {
                var c;
                if (a.id) c = "#" + a.id;
                else {
                    var d;
                    if (a.parentElement) {
                        var e;
                        a: {
                            var f = a.parentElement;
                            if (f) {
                                for (var g = 0; g < f.childElementCount; g++)
                                    if (f.children[g] === a) {
                                        e =
                                            g + 1;
                                        break a
                                    }
                                e = -1
                            } else e = 1
                        }
                        d = rj(a.parentElement) + ">:nth-child(" + e + ")"
                    } else d = "";
                    c = d
                }
                b = c
            }
            return b
        },
        sj = !0,
        tj = !1;
    nj.qh = "true";
    var uj = function(a) {
            if ("false" === nj.qh || !sj) return !1;
            if (tj) return !0;
            var b = Wi("AW-" +
                a);
            return !!b && !!b.preAutoPii
        },
        vj = new RegExp(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i),
        wj = new RegExp(/@(gmail|googlemail)\./i),
        pj = new RegExp(/support|noreply/i),
        xj = "SCRIPT STYLE IMG SVG PATH BR".split(" "),
        yj = ["BR"],
        zj = {},
        Aj = function(a) {
            a = a || {
                Jd: !0,
                Kd: !0
            };
            a.jb = a.jb || {
                email: !0,
                phone: !0,
                rg: !0
            };
            var b, c = a,
                d = !!c.Jd + "." + !!c.Kd;
            c && c.Ac && c.Ac.length && (d += "." + c.Ac.join("."));
            c && c.jb && (d += "." + c.jb.email + "." + c.jb.phone + "." + c.jb.rg);
            b = d;
            var e = zj[b];
            if (e && 200 > cb() - e.timestamp) return e.result;
            var f;
            var g = [],
                h = H.body;
            if (h) {
                for (var l = h.querySelectorAll("*"), n = 0; n < l.length && 1E4 > n; n++) {
                    var p = l[n];
                    if (!(0 <= xj.indexOf(p.tagName.toUpperCase())) && p.children instanceof HTMLCollection) {
                        for (var q = !1, t = 0; t < p.childElementCount && 1E4 > t; t++)
                            if (!(0 <= yj.indexOf(p.children[t].tagName.toUpperCase()))) {
                                q = !0;
                                break
                            }
                        q || g.push(p)
                    }
                }
                f = {
                    elements: g,
                    status: 1E4 < l.length ? "2" : "1"
                }
            } else f = {
                elements: g,
                status: "4"
            };
            var u = f,
                r = u.status,
                v;
            if (a.jb && a.jb.email) {
                for (var w = u.elements, y = [], x = 0; x < w.length; x++) {
                    var z = w[x],
                        B = z.textContent;
                    "INPUT" === z.tagName.toUpperCase() &&
                        z.value && (B = z.value);
                    if (B) {
                        var C = B.match(vj);
                        if (C) {
                            var F = C[0],
                                D;
                            if (m.location) {
                                var E = ij(m.location, "host", !0);
                                D = 0 <= F.toLowerCase().indexOf(E)
                            } else D = !1;
                            D || y.push({
                                element: z,
                                Ja: F
                            })
                        }
                    }
                }
                var O;
                var M = a && a.Ac;
                if (M && 0 !== M.length) {
                    for (var N = [], P = 0; P < y.length; P++) {
                        for (var L = !0, K = 0; K < M.length; K++) {
                            var ba = M[K];
                            if (ba && Eh(y[P].element, ba)) {
                                L = !1;
                                break
                            }
                        }
                        L && N.push(y[P])
                    }
                    O = N
                } else O = y;
                v = qj(O);
                10 < y.length && (r = "3")
            }
            var X = [];
            if (v) {
                var fa = v.element,
                    V = {
                        Ja: v.Ja,
                        tagName: fa.tagName,
                        type: 1
                    };
                a.Jd && (V.querySelector = rj(fa));
                a.Kd &&
                    (V.isVisible = !Xi(fa));
                X.push(V)
            }
            var ea = {
                elements: X,
                status: r
            };
            zj[b] = {
                timestamp: cb(),
                result: ea
            };
            return ea
        },
        Bj = function(a) {
            return a.tagName + ":" + a.isVisible + ":" + a.Ja.length + ":" + wj.test(a.Ja)
        };
    var Cj = function(a, b, c) {
            if (c) {
                var d = c.selector_type,
                    e = String(c.value),
                    f;
                if ("js_variable" === d) {
                    e = e.replace(/\["?'?/g, ".").replace(/"?'?\]/g, "");
                    for (var g = e.split(","), h = 0; h < g.length; h++) {
                        var l = g[h].trim();
                        if (l) {
                            if (0 === l.indexOf("dataLayer.")) f = Ki(l.substring(10));
                            else {
                                var n = l.split(".");
                                f = m[n.shift()];
                                for (var p = 0; p < n.length; p++) f = f && f[n[p]]
                            }
                            if (void 0 !== f) break
                        }
                    }
                } else if ("css_selector" === d && Ch) {
                    var q = Dh(e);
                    q && 0 < q.length && (f = ic(q[0]) || ab(q[0].value))
                }
                f && (a[b] = f)
            }
        },
        Dj = function(a) {
            if (a) {
                var b = {};
                Cj(b, "email",
                    a.email);
                Cj(b, "phone_number", a.phone);
                b.address = [];
                for (var c = a.name_and_address || [], d = 0; d < c.length; d++) {
                    var e = {};
                    Cj(e, "first_name", c[d].first_name);
                    Cj(e, "last_name", c[d].last_name);
                    Cj(e, "street", c[d].street);
                    Cj(e, "city", c[d].city);
                    Cj(e, "region", c[d].region);
                    Cj(e, "country", c[d].country);
                    Cj(e, "postal_code", c[d].postal_code);
                    b.address.push(e)
                }
                return b
            }
        },
        Ej = function(a) {
            if (a) switch (a.mode) {
                case "selectors":
                    return Dj(a.selectors);
                case "auto_detect":
                    var b;
                    var c = a.auto_detect;
                    if (c) {
                        var d = Aj({
                                Jd: !1,
                                Kd: !1,
                                Ac: c.exclude_element_selectors,
                                jb: {
                                    email: !!c.email,
                                    phone: !!c.phone,
                                    rg: !!c.address
                                }
                            }).elements,
                            e = {};
                        if (0 < d.length)
                            for (var f = 0; f < d.length; f++) {
                                var g = d[f];
                                if (1 === g.type) {
                                    e.email = g.Ja;
                                    break
                                }
                            }
                        b = e
                    } else b = void 0;
                    return b
            }
        },
        Fj = function(a) {
            switch (a.enhanced_conversions_mode) {
                case "manual":
                    var b = a.enhanced_conversions_manual_var;
                    return void 0 !== b ? b : m.enhanced_conversion_data;
                case "automatic":
                    return Dj(a[R.Pf])
            }
        };
    var Gj = {},
        Hj = function(a, b) {
            if (m._gtmexpgrp && m._gtmexpgrp.hasOwnProperty(a)) return m._gtmexpgrp[a];
            void 0 === Gj[a] && (Gj[a] = Math.floor(Math.random() * b));
            return Gj[a]
        };
    var Ij = function(a) {
        var b = 1,
            c, d, e;
        if (a)
            for (b = 0, d = a.length - 1; 0 <= d; d--) e = a.charCodeAt(d), b = (b << 6 & 268435455) + e + (e << 14), c = b & 266338304, b = 0 != c ? b ^ c >> 21 : b;
        return b
    };
    var Jj = function(a, b, c) {
        for (var d = [], e = b.split(";"), f = 0; f < e.length; f++) {
            var g = e[f].split("="),
                h = g[0].replace(/^\s*|\s*$/g, "");
            if (h && h == a) {
                var l = g.slice(1).join("=").replace(/^\s*|\s*$/g, "");
                l && c && (l = decodeURIComponent(l));
                d.push(l)
            }
        }
        return d
    };

    function Kj(a) {
        return "null" !== a.origin
    };
    var Nj = function(a, b, c, d) {
            return Lj(d) ? Jj(a, String(b || Mj()), c) : []
        },
        Qj = function(a, b, c, d, e) {
            if (Lj(e)) {
                var f = Oj(a, d, e);
                if (1 === f.length) return f[0].id;
                if (0 !== f.length) {
                    f = Pj(f, function(g) {
                        return g.Cd
                    }, b);
                    if (1 === f.length) return f[0].id;
                    f = Pj(f, function(g) {
                        return g.Lc
                    }, c);
                    return f[0] ? f[0].id : void 0
                }
            }
        };

    function Rj(a, b, c, d) {
        var e = Mj(),
            f = window;
        Kj(f) && (f.document.cookie = a);
        var g = Mj();
        return e != g || void 0 != c && 0 <= Nj(b, g, !1, d).indexOf(c)
    }
    var Vj = function(a, b, c, d) {
            function e(w, y, x) {
                if (null == x) return delete h[y], w;
                h[y] = x;
                return w + "; " + y + "=" + x
            }

            function f(w, y) {
                if (null == y) return delete h[y], w;
                h[y] = !0;
                return w + "; " + y
            }
            if (!Lj(c.Ia)) return 2;
            var g;
            void 0 == b ? g = a + "=deleted; expires=" + (new Date(0)).toUTCString() : (c.encode && (b = encodeURIComponent(b)), b = Sj(b), g = a + "=" + b);
            var h = {};
            g = e(g, "path", c.path);
            var l;
            c.expires instanceof Date ? l = c.expires.toUTCString() : null != c.expires && (l = "" + c.expires);
            g = e(g, "expires", l);
            g = e(g, "max-age", c.nj);
            g = e(g, "samesite",
                c.Ej);
            c.Gj && (g = f(g, "secure"));
            var n = c.domain;
            if (n && "auto" === n.toLowerCase()) {
                for (var p = Tj(), q = void 0, t = !1, u = 0; u < p.length; ++u) {
                    var r = "none" !== p[u] ? p[u] : void 0,
                        v = e(g, "domain", r);
                    v = f(v, c.flags);
                    try {
                        d && d(a, h)
                    } catch (w) {
                        q = w;
                        continue
                    }
                    t = !0;
                    if (!Uj(r, c.path) && Rj(v, a, b, c.Ia)) return 0
                }
                if (q && !t) throw q;
                return 1
            }
            n && "none" !== n.toLowerCase() && (g = e(g, "domain", n));
            g = f(g, c.flags);
            d && d(a, h);
            return Uj(n, c.path) ? 1 : Rj(g, a, b, c.Ia) ? 0 : 1
        },
        Wj = function(a, b, c) {
            null == c.path && (c.path = "/");
            c.domain || (c.domain = "auto");
            return Vj(a,
                b, c)
        };

    function Pj(a, b, c) {
        for (var d = [], e = [], f, g = 0; g < a.length; g++) {
            var h = a[g],
                l = b(h);
            l === c ? d.push(h) : void 0 === f || l < f ? (e = [h], f = l) : l === f && e.push(h)
        }
        return 0 < d.length ? d : e
    }

    function Oj(a, b, c) {
        for (var d = [], e = Nj(a, void 0, void 0, c), f = 0; f < e.length; f++) {
            var g = e[f].split("."),
                h = g.shift();
            if (!b || -1 !== b.indexOf(h)) {
                var l = g.shift();
                l && (l = l.split("-"), d.push({
                    id: g.join("."),
                    Cd: 1 * l[0] || 1,
                    Lc: 1 * l[1] || 1
                }))
            }
        }
        return d
    }
    var Sj = function(a) {
            a && 1200 < a.length && (a = a.substring(0, 1200));
            return a
        },
        Xj = /^(www\.)?google(\.com?)?(\.[a-z]{2})?$/,
        Yj = /(^|\.)doubleclick\.net$/i,
        Uj = function(a, b) {
            return Yj.test(window.document.location.hostname) || "/" === b && Xj.test(a)
        },
        Mj = function() {
            return Kj(window) ? window.document.cookie : ""
        },
        Tj = function() {
            var a = [],
                b = window.document.location.hostname.split(".");
            if (4 === b.length) {
                var c = b[b.length - 1];
                if (parseInt(c, 10).toString() === c) return ["none"]
            }
            for (var d = b.length - 2; 0 <= d; d--) a.push(b.slice(d).join("."));
            var e = window.document.location.hostname;
            Yj.test(e) || Xj.test(e) || a.push("none");
            return a
        },
        Lj = function(a) {
            if (!ah(Xg) || !a || !lh()) return !0;
            if (!kh(a)) return !1;
            var b = ih(a);
            return null == b ? !0 : !!b
        };
    var Zj = function(a) {
            var b = Math.round(2147483647 * Math.random()),
                c = b;
            a && (c = b ^ Ij(a) & 2147483647);
            return [c, Math.round(cb() / 1E3)].join(".")
        },
        ck = function(a, b, c, d, e) {
            var f = ak(b);
            return Qj(a, f, bk(c), d, e)
        },
        dk = function(a, b, c, d) {
            var e = "" + ak(c),
                f = bk(d);
            1 < f && (e += "-" + f);
            return [b, e, a].join(".")
        },
        ak = function(a) {
            if (!a) return 1;
            a = 0 === a.indexOf(".") ? a.substr(1) : a;
            return a.split(".").length
        },
        bk = function(a) {
            if (!a || "/" === a) return 1;
            "/" !== a[0] && (a = "/" + a);
            "/" !== a[a.length - 1] && (a += "/");
            return a.split("/").length - 1
        };

    function ek(a, b, c) {
        var d, e = Number(null != a.kb ? a.kb : void 0);
        0 !== e && (d = new Date((b || cb()) + 1E3 * (e || 7776E3)));
        return {
            path: a.path,
            domain: a.domain,
            flags: a.flags,
            encode: !!c,
            expires: d
        }
    };
    var fk = ["1"],
        gk = {},
        jk = function(a, b) {
            b = void 0 === b ? !0 : b;
            var c = hk(a.prefix);
            if (!gk[c] && !ik(c, a.path, a.domain) && b) {
                var d = hk(a.prefix),
                    e = Zj(),
                    f = dk(e, "1", a.domain, a.path),
                    g = ek(a);
                g.Ia = "ad_storage";
                if (0 === Wj(d, f, g)) {
                    var h = Xb("google_tag_data", {});
                    h._gcl_au ? Tg("GTM", 57) : h._gcl_au = e
                }
                ik(c, a.path, a.domain)
            }
        };

    function ik(a, b, c) {
        var d = ck(a, b, c, fk, "ad_storage");
        if (!d) return !1;
        var e = d.split(".");
        5 === e.length ? (gk[a] = e.slice(0, 2).join("."), e.slice(2, 4).join(".")) : 3 === e.length ? e.slice(0, 2).join(".") : gk[a] = d;
        return !0
    }

    function hk(a) {
        return (a || "_gcl") + "_au"
    };
    var kk = function(a) {
        for (var b = [], c = H.cookie.split(";"), d = new RegExp("^\\s*" + (a || "_gac") + "_(UA-\\d+-\\d+)=\\s*(.+?)\\s*$"), e = 0; e < c.length; e++) {
            var f = c[e].match(d);
            f && b.push({
                sf: f[1],
                value: f[2],
                timestamp: Number(f[2].split(".")[1]) || 0
            })
        }
        b.sort(function(g, h) {
            return h.timestamp - g.timestamp
        });
        return b
    };

    function lk(a, b) {
        var c = kk(a),
            d = {};
        if (!c || !c.length) return d;
        for (var e = 0; e < c.length; e++) {
            var f = c[e].value.split(".");
            if (!("1" !== f[0] || b && 3 > f.length || !b && 3 !== f.length) && Number(f[1])) {
                d[c[e].sf] || (d[c[e].sf] = []);
                var g = {
                    version: f[0],
                    timestamp: 1E3 * Number(f[1]),
                    ra: f[2]
                };
                b && 3 < f.length && (g.labels = f.slice(3));
                d[c[e].sf].push(g)
            }
        }
        return d
    };

    function mk() {
        for (var a = nk, b = {}, c = 0; c < a.length; ++c) b[a[c]] = c;
        return b
    }

    function ok() {
        var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        a += a.toLowerCase() + "0123456789-_";
        return a + "."
    }
    var nk, pk;

    function qk(a) {
        nk = nk || ok();
        pk = pk || mk();
        for (var b = [], c = 0; c < a.length; c += 3) {
            var d = c + 1 < a.length,
                e = c + 2 < a.length,
                f = a.charCodeAt(c),
                g = d ? a.charCodeAt(c + 1) : 0,
                h = e ? a.charCodeAt(c + 2) : 0,
                l = f >> 2,
                n = (f & 3) << 4 | g >> 4,
                p = (g & 15) << 2 | h >> 6,
                q = h & 63;
            e || (q = 64, d || (p = 64));
            b.push(nk[l], nk[n], nk[p], nk[q])
        }
        return b.join("")
    }

    function rk(a) {
        function b(l) {
            for (; d < a.length;) {
                var n = a.charAt(d++),
                    p = pk[n];
                if (null != p) return p;
                if (!/^[\s\xa0]*$/.test(n)) throw Error("Unknown base64 encoding at char: " + n);
            }
            return l
        }
        nk = nk || ok();
        pk = pk || mk();
        for (var c = "", d = 0;;) {
            var e = b(-1),
                f = b(0),
                g = b(64),
                h = b(64);
            if (64 === h && -1 === e) return c;
            c += String.fromCharCode(e << 2 | f >> 4);
            64 != g && (c += String.fromCharCode(f << 4 & 240 | g >> 2), 64 != h && (c += String.fromCharCode(g << 6 & 192 | h)))
        }
    };
    var sk, tk = function(a) {
        var b;
        if (!(b = sk)) {
            for (var c = Array(256), d = 0; 256 > d; d++) {
                for (var e = d, f = 0; 8 > f; f++) e = e & 1 ? e >>> 1 ^ 3988292384 : e >>> 1;
                c[d] = e
            }
            b = c
        }
        sk = b;
        for (var g = 4294967295, h = 0; h < a.length; h++) g = g >>> 8 ^ sk[(g ^ a.charCodeAt(h)) & 255];
        return (g ^ -1) >>> 0
    };
    var xk = function() {
            var a = uk,
                b = vk,
                c = wk(),
                d = function(g) {
                    a(g.target || g.srcElement || {})
                },
                e = function(g) {
                    b(g.target || g.srcElement || {})
                };
            if (!c.init) {
                fc(H, "mousedown", d);
                fc(H, "keyup", d);
                fc(H, "submit", e);
                var f = HTMLFormElement.prototype.submit;
                HTMLFormElement.prototype.submit = function() {
                    b(this);
                    f.call(this)
                };
                c.init = !0
            }
        },
        yk = function(a, b, c, d, e) {
            var f = {
                callback: a,
                domains: b,
                fragment: 2 === c,
                placement: c,
                forms: d,
                sameHost: e
            };
            wk().decorators.push(f)
        },
        zk = function(a, b, c) {
            for (var d = wk().decorators, e = {}, f = 0; f < d.length; ++f) {
                var g =
                    d[f],
                    h;
                if (h = !c || g.forms) a: {
                    var l = g.domains,
                        n = a,
                        p = !!g.sameHost;
                    if (l && (p || n !== H.location.hostname))
                        for (var q = 0; q < l.length; q++)
                            if (l[q] instanceof RegExp) {
                                if (l[q].test(n)) {
                                    h = !0;
                                    break a
                                }
                            } else if (0 <= n.indexOf(l[q]) || p && 0 <= l[q].indexOf(n)) {
                        h = !0;
                        break a
                    }
                    h = !1
                }
                if (h) {
                    var t = g.placement;
                    void 0 == t && (t = g.fragment ? 2 : 1);
                    t === b && fb(e, g.callback())
                }
            }
            return e
        };

    function wk() {
        var a = Xb("google_tag_data", {}),
            b = a.gl;
        b && b.decorators || (b = {
            decorators: []
        }, a.gl = b);
        return b
    };
    var Ak = /(.*?)\*(.*?)\*(.*)/,
        Bk = /^https?:\/\/([^\/]*?)\.?cdn\.ampproject\.org\/?(.*)/,
        Ck = /^(?:www\.|m\.|amp\.)+/,
        Dk = /([^?#]+)(\?[^#]*)?(#.*)?/;

    function Ek(a) {
        return new RegExp("(.*?)(^|&)" + a + "=([^&]*)&?(.*)")
    }
    var Hk = function(a, b) {
        var c = [],
            d;
        for (d in a)
            if (a.hasOwnProperty(d)) {
                var e = a[d];
                void 0 !== e && e === e && null !== e && "[object Object]" !== e.toString() && (c.push(d), c.push(qk(String(e))))
            }
        var f = c.join("*");
        if (void 0 !== b) {
            var g = "xp_" + b,
                h = Fk[b](f);
            f = f + "*" + [g, qk(String(h))].join("*")
        }
        return ["1", Gk(f), f].join("*")
    };

    function Gk(a, b) {
        var c = [m.navigator.userAgent, (new Date).getTimezoneOffset(), oc(), Math.floor(cb() / 60 / 1E3) - (void 0 === b ? 0 : b), a].join("*");
        return tk(c).toString(36)
    }
    var Ik = {},
        Fk = (Ik[1] = Jk, Ik[2] = Kk, Ik);

    function Jk(a, b) {
        var c = [(new Date).getTimezoneOffset(), oc(), Math.floor(cb() / 60 / 1E3) - (void 0 === b ? 0 : b), a].join("*");
        return tk(c).toString(36)
    }

    function Kk(a, b) {
        if (Vb.userAgentData) {
            var c = [(new Date).getTimezoneOffset(), oc(), Math.floor(cb() / 60 / 1E3) - (void 0 === b ? 0 : b), Vb.userAgentData.brands, Vb.userAgentData.mobile, Vb.userAgentData.platform, a].join("*");
            return tk(c).toString(36)
        }
    }

    function Lk() {
        return function(a) {
            var b = lj(m.location.href),
                c = b.search.replace("?", ""),
                d = gj(c, "_gl", !1, !0) || "";
            a.query = Mk(d) || {};
            var e = jj(b, "fragment").match(Ek("_gl"));
            a.fragment = Mk(e && e[3] || "") || {}
        }
    }
    var Nk = function(a) {
            var b = Lk(),
                c = wk();
            c.data || (c.data = {
                query: {},
                fragment: {}
            }, b(c.data));
            var d = {},
                e = c.data;
            e && (fb(d, e.query), a && fb(d, e.fragment));
            return d
        },
        Mk = function(a) {
            var b;
            b = void 0 === b ? 3 : b;
            try {
                if (a) {
                    var c;
                    a: {
                        for (var d = a, e = 0; 3 > e; ++e) {
                            var f = Ak.exec(d);
                            if (f) {
                                c = f;
                                break a
                            }
                            d = decodeURIComponent(d)
                        }
                        c = void 0
                    }
                    var g = c;
                    if (g && "1" === g[1]) {
                        var h = g[3],
                            l;
                        a: {
                            for (var n = g[2], p = 0; p < b; ++p)
                                if (n === Gk(h, p)) {
                                    l = !0;
                                    break a
                                }
                            l = !1
                        }
                        if (l) {
                            for (var q = {}, t = h ? h.split("*") : [], u = 0; u < t.length; u += 2) q[t[u]] = rk(t[u + 1]);
                            return q
                        }
                    }
                }
            } catch (r) {}
        };

    function Ok(a, b, c, d) {
        function e(p) {
            var q = p,
                t = Ek(a).exec(q),
                u = q;
            if (t) {
                var r = t[2],
                    v = t[4];
                u = t[1];
                v && (u = u + r + v)
            }
            p = u;
            var w = p.charAt(p.length - 1);
            p && "&" !== w && (p += "&");
            return p + n
        }
        d = void 0 === d ? !1 : d;
        var f = Dk.exec(c);
        if (!f) return "";
        var g = f[1],
            h = f[2] || "",
            l = f[3] || "",
            n = a + "=" + b;
        d ? l = "#" + e(l.substring(1)) : h = "?" + e(h.substring(1));
        return "" + g + h + l
    }

    function Pk(a, b) {
        var c = "FORM" === (a.tagName || "").toUpperCase(),
            d = zk(b, 1, c),
            e = zk(b, 2, c),
            f = zk(b, 3, c);
        if (gb(d)) {
            var g = Hk(d, void 0);
            c ? Qk("_gl", g, a) : Rk("_gl", g, a, !1)
        }
        if (!c && gb(e)) {
            var h = Hk(e);
            Rk("_gl", h, a, !0)
        }
        for (var l in f)
            if (f.hasOwnProperty(l)) a: {
                var n = l,
                    p = f[l],
                    q = a;
                if (q.tagName) {
                    if ("a" === q.tagName.toLowerCase()) {
                        Rk(n, p, q, void 0);
                        break a
                    }
                    if ("form" === q.tagName.toLowerCase()) {
                        Qk(n, p, q);
                        break a
                    }
                }
                "string" == typeof q && Ok(n, p, q, void 0)
            }
    }

    function Rk(a, b, c, d) {
        if (c.href) {
            var e = Ok(a, b, c.href, void 0 === d ? !1 : d);
            Hb.test(e) && (c.href = e)
        }
    }

    function Qk(a, b, c) {
        if (c && c.action) {
            var d = (c.method || "").toLowerCase();
            if ("get" === d) {
                for (var e = c.childNodes || [], f = !1, g = 0; g < e.length; g++) {
                    var h = e[g];
                    if (h.name === a) {
                        h.setAttribute("value", b);
                        f = !0;
                        break
                    }
                }
                if (!f) {
                    var l = H.createElement("input");
                    l.setAttribute("type", "hidden");
                    l.setAttribute("name", a);
                    l.setAttribute("value", b);
                    c.appendChild(l)
                }
            } else if ("post" === d) {
                var n = Ok(a, b, c.action);
                Hb.test(n) && (c.action = n)
            }
        }
    }

    function uk(a) {
        try {
            var b;
            a: {
                for (var c = a, d = 100; c && 0 < d;) {
                    if (c.href && c.nodeName.match(/^a(?:rea)?$/i)) {
                        b = c;
                        break a
                    }
                    c = c.parentNode;
                    d--
                }
                b = null
            }
            var e = b;
            if (e) {
                var f = e.protocol;
                "http:" !== f && "https:" !== f || Pk(e, e.hostname)
            }
        } catch (g) {}
    }

    function vk(a) {
        try {
            if (a.action) {
                var b = jj(lj(a.action), "host");
                Pk(a, b)
            }
        } catch (c) {}
    }
    var Sk = function(a, b, c, d) {
            xk();
            yk(a, b, "fragment" === c ? 2 : 1, !!d, !1)
        },
        Tk = function(a, b) {
            xk();
            yk(a, [ij(m.location, "host", !0)], b, !0, !0)
        },
        Uk = function() {
            var a = H.location.hostname,
                b = Bk.exec(H.referrer);
            if (!b) return !1;
            var c = b[2],
                d = b[1],
                e = "";
            if (c) {
                var f = c.split("/"),
                    g = f[1];
                e = "s" === g ? decodeURIComponent(f[2]) : decodeURIComponent(g)
            } else if (d) {
                if (0 === d.indexOf("xn--")) return !1;
                e = d.replace(/-/g, ".").replace(/\.\./g, "-")
            }
            var h = a.replace(Ck, ""),
                l = e.replace(Ck, ""),
                n;
            if (!(n = h === l)) {
                var p = "." + l;
                n = h.substring(h.length - p.length,
                    h.length) === p
            }
            return n
        },
        Vk = function(a, b) {
            return !1 === a ? !1 : a || b || Uk()
        };
    var Wk = {};
    var Xk = /^\w+$/,
        Yk = /^[\w-]+$/,
        Zk = {
            aw: "_aw",
            dc: "_dc",
            gf: "_gf",
            ha: "_ha",
            gp: "_gp",
            gb: "_gb"
        },
        $k = function() {
            if (!ah(Xg) || !lh()) return !0;
            var a = ih("ad_storage");
            return null == a ? !0 : !!a
        },
        al = function(a, b) {
            kh("ad_storage") ? $k() ? a() : qh(a, "ad_storage") : b ? Tg("TAGGING", 3) : ph(function() {
                al(a, !0)
            }, ["ad_storage"])
        },
        cl = function(a) {
            return bl(a).map(function(b) {
                return b.ra
            })
        },
        bl = function(a) {
            var b = [];
            if (!Kj(m) || !H.cookie) return b;
            var c = Nj(a, H.cookie, void 0, "ad_storage");
            if (!c || 0 == c.length) return b;
            for (var d = {}, e = 0; e < c.length; d = {
                    Vc: d.Vc
                }, e++) {
                var f = dl(c[e]);
                if (null != f) {
                    var g = f,
                        h = g.version;
                    d.Vc = g.ra;
                    var l = g.timestamp,
                        n = g.labels,
                        p = Ka(b, function(q) {
                            return function(t) {
                                return t.ra === q.Vc
                            }
                        }(d));
                    p ? (p.timestamp = Math.max(p.timestamp, l), p.labels = el(p.labels, n || [])) : b.push({
                        version: h,
                        ra: d.Vc,
                        timestamp: l,
                        labels: n
                    })
                }
            }
            b.sort(function(q, t) {
                return t.timestamp - q.timestamp
            });
            return fl(b)
        };

    function el(a, b) {
        for (var c = {}, d = [], e = 0; e < a.length; e++) c[a[e]] = !0, d.push(a[e]);
        for (var f = 0; f < b.length; f++) c[b[f]] || d.push(b[f]);
        return d
    }

    function gl(a) {
        return a && "string" == typeof a && a.match(Xk) ? a : "_gcl"
    }
    var il = function() {
            var a = lj(m.location.href),
                b = jj(a, "query", !1, void 0, "gclid"),
                c = jj(a, "query", !1, void 0, "gclsrc"),
                d = jj(a, "query", !1, void 0, "wbraid"),
                e = jj(a, "query", !1, void 0, "dclid");
            if (!b || !c || !d) {
                var f = a.hash.replace("#", "");
                b = b || gj(f, "gclid", !1, void 0);
                c = c || gj(f, "gclsrc", !1, void 0);
                d = d || gj(f, "wbraid", !1, void 0)
            }
            return hl(b, c, e, d)
        },
        hl = function(a, b, c, d) {
            var e = {},
                f = function(g, h) {
                    e[h] || (e[h] = []);
                    e[h].push(g)
                };
            e.gclid = a;
            e.gclsrc = b;
            e.dclid = c;
            void 0 !== d && Yk.test(d) && (e.gbraid = d, f(d, "gb"));
            if (void 0 !==
                a && a.match(Yk)) switch (b) {
                case void 0:
                    f(a, "aw");
                    break;
                case "aw.ds":
                    f(a, "aw");
                    f(a, "dc");
                    break;
                case "ds":
                    f(a, "dc");
                    break;
                case "3p.ds":
                    f(a, "dc");
                    break;
                case "gf":
                    f(a, "gf");
                    break;
                case "ha":
                    f(a, "ha")
            }
            c && f(c, "dc");
            return e
        },
        kl = function(a) {
            var b = il();
            al(function() {
                jl(b, !1, a)
            })
        };

    function jl(a, b, c, d, e) {
        function f(w, y) {
            var x = ll(w, g);
            x && (Wj(x, y, h), l = !0)
        }
        c = c || {};
        e = e || [];
        var g = gl(c.prefix);
        d = d || cb();
        var h = ek(c, d, !0);
        h.Ia = "ad_storage";
        var l = !1,
            n = Math.round(d / 1E3),
            p = function(w) {
                var y = ["GCL", n, w];
                0 < e.length && y.push(e.join("."));
                return y.join(".")
            };
        a.aw && f("aw", p(a.aw[0]));
        a.dc && f("dc", p(a.dc[0]));
        a.gf && f("gf", p(a.gf[0]));
        a.ha && f("ha", p(a.ha[0]));
        a.gp && f("gp", p(a.gp[0]));
        if ((void 0 == Wk.enable_gbraid_cookie_write ? 0 : Wk.enable_gbraid_cookie_write) && !l && a.gb) {
            var q = a.gb[0],
                t = ll("gb",
                    g),
                u = !1;
            if (!b)
                for (var r = bl(t), v = 0; v < r.length; v++) r[v].ra === q && r[v].labels && 0 < r[v].labels.length && (u = !0);
            u || f("gb", p(q))
        }
    }
    var nl = function(a, b) {
            var c = Nk(!0);
            al(function() {
                for (var d = gl(b.prefix), e = 0; e < a.length; ++e) {
                    var f = a[e];
                    if (void 0 !== Zk[f]) {
                        var g = ll(f, d),
                            h = c[g];
                        if (h) {
                            var l = Math.min(ml(h), cb()),
                                n;
                            b: {
                                var p = l;
                                if (Kj(m))
                                    for (var q = Nj(g, H.cookie, void 0, "ad_storage"), t = 0; t < q.length; ++t)
                                        if (ml(q[t]) > p) {
                                            n = !0;
                                            break b
                                        }
                                n = !1
                            }
                            if (!n) {
                                var u = ek(b, l, !0);
                                u.Ia = "ad_storage";
                                Wj(g, h, u)
                            }
                        }
                    }
                }
                jl(hl(c.gclid, c.gclsrc), !1, b)
            })
        },
        ll = function(a, b) {
            var c = Zk[a];
            if (void 0 !== c) return b + c
        },
        ml = function(a) {
            return 0 !== ol(a.split(".")).length ? 1E3 * (Number(a.split(".")[1]) ||
                0) : 0
        };

    function dl(a) {
        var b = ol(a.split("."));
        return 0 === b.length ? null : {
            version: b[0],
            ra: b[2],
            timestamp: 1E3 * (Number(b[1]) || 0),
            labels: b.slice(3)
        }
    }

    function ol(a) {
        return 3 > a.length || "GCL" !== a[0] && "1" !== a[0] || !/^\d+$/.test(a[1]) || !Yk.test(a[2]) ? [] : a
    }
    var pl = function(a, b, c, d, e) {
            if (Ia(b) && Kj(m)) {
                var f = gl(e),
                    g = function() {
                        for (var h = {}, l = 0; l < a.length; ++l) {
                            var n = ll(a[l], f);
                            if (n) {
                                var p = Nj(n, H.cookie, void 0, "ad_storage");
                                p.length && (h[n] = p.sort()[p.length - 1])
                            }
                        }
                        return h
                    };
                al(function() {
                    Sk(g, b, c, d)
                })
            }
        },
        fl = function(a) {
            return a.filter(function(b) {
                return Yk.test(b.ra)
            })
        },
        ql = function(a, b) {
            if (Kj(m)) {
                for (var c = gl(b.prefix), d = {}, e = 0; e < a.length; e++) Zk[a[e]] && (d[a[e]] = Zk[a[e]]);
                al(function() {
                    Qa(d, function(f, g) {
                        var h = Nj(c + g, H.cookie, void 0, "ad_storage");
                        h.sort(function(u,
                            r) {
                            return ml(r) - ml(u)
                        });
                        if (h.length) {
                            var l = h[0],
                                n = ml(l),
                                p = 0 !== ol(l.split(".")).length ? l.split(".").slice(3) : [],
                                q = {},
                                t;
                            t = 0 !== ol(l.split(".")).length ? l.split(".")[2] : void 0;
                            q[f] = [t];
                            jl(q, !0, b, n, p)
                        }
                    })
                })
            }
        };

    function rl(a, b) {
        for (var c = 0; c < b.length; ++c)
            if (a[b[c]]) return !0;
        return !1
    }
    var sl = function(a) {
        function b(e, f, g) {
            g && (e[f] = g)
        }
        if (lh()) {
            var c = il();
            if (rl(c, a)) {
                var d = {};
                b(d, "gclid", c.gclid);
                b(d, "dclid", c.dclid);
                b(d, "gclsrc", c.gclsrc);
                b(d, "wbraid", c.gbraid);
                Tk(function() {
                    return d
                }, 3);
                Tk(function() {
                    var e = {};
                    return e._up = "1", e
                }, 1)
            }
        }
    };

    function tl(a, b) {
        var c = gl(b),
            d = ll(a, c);
        if (!d) return 0;
        for (var e = bl(d), f = 0, g = 0; g < e.length; g++) f = Math.max(f, e[g].timestamp);
        return f
    }

    function ul(a) {
        var b = 0,
            c;
        for (c in a)
            for (var d = a[c], e = 0; e < d.length; e++) b = Math.max(b, Number(d[e].timestamp));
        return b
    };
    var vl = function(a) {
            var b = [];
            Qa(a, function(c, d) {
                d = fl(d);
                for (var e = [], f = 0; f < d.length; f++) e.push(d[f].ra);
                e.length && b.push(c + ":" + e.join(","))
            });
            return b.join(";")
        },
        xl = function(a, b, c) {
            if ("aw" === a || "dc" === a || "gb" === a) {
                var d = wl("gcl" + a);
                if (d) return d.split(".")
            }
            var e = gl(b);
            if ("_gcl" == e) {
                c = void 0 === c ? !0 : c;
                var f = !wh(R.C) && c,
                    g;
                g = il()[a] || [];
                if (0 < g.length) return f ? ["0"] : g
            }
            var h = ll(a, e);
            return h ? cl(h) : []
        },
        wl = function(a) {
            var b = lj(m.location.href),
                c = jj(b, "host", !1);
            if (c && c.match(yl)) {
                var d = jj(b, "path").split(a +
                    "=");
                if (1 < d.length) return d[1].split(";")[0].split("?")[0]
            }
        },
        zl = function(a, b) {
            kh(R.C) ? wh(R.C) ? a() : qh(a, R.C) : b ? Vg(42) : Bh(function() {
                zl(a, !0)
            }, [R.C])
        },
        yl = /^\d+\.fls\.doubleclick\.net$/,
        Al = function(a, b) {
            return xl("aw", a, b)
        },
        Bl = function(a, b) {
            return xl("dc", a, b)
        },
        Cl = function(a) {
            var b = wl("gac");
            return b ? !wh(R.C) && a ? "0" : decodeURIComponent(b) : vl($k() ? lk() : {})
        },
        Dl = function(a) {
            var b = wl("gacgb");
            return b ? !wh(R.C) && a ? "0" : decodeURIComponent(b) : vl($k() ? lk("_gac_gb", !0) : {})
        },
        El = function(a) {
            var b = il(),
                c = [],
                d = b.gclid,
                e = b.dclid,
                f = b.gclsrc || "aw";
            !d || "aw.ds" !== f && "aw" !== f && "ds" !== f || c.push({
                ra: d,
                Ve: f
            });
            e && c.push({
                ra: e,
                Ve: "ds"
            });
            zl(function() {
                jk(a);
                var g = gk[hk(a.prefix)];
                if (g && 0 < c.length)
                    for (var h = S.joined_auid = S.joined_auid || {}, l = 0; l < c.length; l++) {
                        var n =
                            c[l],
                            p = n.ra,
                            q = n.Ve,
                            t = (a.prefix || "_gcl") + "." + q + "." + p;
                        if (!h[t]) {
                            var u = "https://adservice.google.com/pagead/regclk";
                            u = "gb" === q ? u + "?gbraid=" + p + "&auid=" + g : u + "?gclid=" + p + "&auid=" + g + "&gclsrc=" + q;
                            lc(u);
                            h[t] = !0
                        }
                    }
            })
        },
        Fl = function(a) {
            var b;
            if (wl("gclaw") || wl("gac") || 0 < (il().aw || []).length) b = !1;
            else {
                var c;
                if (0 < (il().gb || []).length) c = !0;
                else {
                    var d = Math.max(tl("aw", a), ul($k() ? lk() : {}));
                    c = Math.max(tl("gb", a), ul($k() ? lk("_gac_gb", !0) : {})) > d
                }
                b = c
            }
            return b
        };
    var Gl = function(a) {
        var b = Vb && Vb.userAgent || "";
        if (0 > b.indexOf("Safari") || /Chrome|Coast|Opera|Edg|Silk|Android/.test(b)) return !1;
        var c = (/Version\/([\d\.]+)/.exec(b) || [])[1] || "";
        if ("" === c) return !1;
        for (var d = a.split("."), e = c.split("."), f = 0; f < e.length; f++) {
            if (void 0 === d[f]) return !0;
            if (e[f] != d[f]) return Number(e[f]) > Number(d[f])
        }
        return e.length >= d.length
    };
    var Il = function(a) {
            var b = a ? Fj(a) : m.enhanced_conversion_data,
                c = (a || {}).enhanced_conversions_mode,
                d = void 0;
            if ("manual" === c && b) switch (b._tag_mode) {
                case "CODE":
                    d = "c";
                    break;
                case "AUTO":
                    d = "a";
                    break;
                case "MANUAL":
                    d = "m";
                    break;
                default:
                    d = "c"
            } else d = "automatic" === c ? Hl(a) ? "a" : "m" : "c";
            if (m.Promise) try {
                return b ? di(b).then(function(e) {
                    e.Te = d;
                    return e
                }) : Promise.resolve({
                    Kc: "",
                    Te: void 0
                })
            } catch (e) {}
        },
        Hl = function(a) {
            var b = a && a[R.Pf];
            return b && b[R.Kh]
        },
        Jl = function(a) {
            if (wh(R.C)) return a;
            a = a.replace(/&url=([^&#]+)/,
                function(b, c) {
                    var d = mj(decodeURIComponent(c));
                    return "&url=" + encodeURIComponent(d)
                });
            a = a.replace(/&ref=([^&#]+)/, function(b, c) {
                var d = mj(decodeURIComponent(c));
                return "&ref=" + encodeURIComponent(d)
            });
            return a
        },
        Kl = function() {
            if (xi || !0 !== m._gtmdgs && !Gl("11")) return -1;
            var a = Ua('1');
            return Hj(1, 100) < a ? Hj(2, 2) : -1
        },
        Ll = function() {
            return -1 !== Vb.userAgent.toLowerCase().indexOf("firefox")
        },
        Ml = function(a) {
            var b;
            if (!a || !a.length) return;
            for (var c = [], d = 0; d < a.length; ++d) {
                var e = a[d];
                e && e.estimated_delivery_date ? c.push("" + e.estimated_delivery_date) : c.push("")
            }
            b = c.join(",");
            return b
        },
        Nl = function() {
            var a = !1;
            return a
        };
    var Ol = new RegExp(/^(.*\.)?(google|youtube|blogger|withgoogle)(\.com?)?(\.[a-z]{2})?\.?$/),
        Pl = {
            cl: ["ecl"],
            customPixels: ["nonGooglePixels"],
            ecl: ["cl"],
            ehl: ["hl"],
            hl: ["ehl"],
            html: ["customScripts", "customPixels", "nonGooglePixels", "nonGoogleScripts", "nonGoogleIframes"],
            customScripts: ["html", "customPixels", "nonGooglePixels", "nonGoogleScripts", "nonGoogleIframes"],
            nonGooglePixels: [],
            nonGoogleScripts: ["nonGooglePixels"],
            nonGoogleIframes: ["nonGooglePixels"]
        },
        Ql = {
            cl: ["ecl"],
            customPixels: ["customScripts", "html"],
            ecl: ["cl"],
            ehl: ["hl"],
            hl: ["ehl"],
            html: ["customScripts"],
            customScripts: ["html"],
            nonGooglePixels: ["customPixels", "customScripts", "html", "nonGoogleScripts", "nonGoogleIframes"],
            nonGoogleScripts: ["customScripts", "html"],
            nonGoogleIframes: ["customScripts", "html", "nonGoogleScripts"]
        },
        Rl = "google customPixels customScripts html nonGooglePixels nonGoogleScripts nonGoogleIframes".split(" ");
    var Sl = function() {
            var a = !1;
            return a
        },
        Ul = function(a) {
            var b = Ki("gtm.allowlist") || Ki("gtm.whitelist");
            b && Vg(9);
            Sl() && (b = "google gtagfl lcl zone oid op".split(" "));
            var c = b && hb(Ya(b), Pl),
                d = Ki("gtm.blocklist") ||
                Ki("gtm.blacklist");
            d || (d = Ki("tagTypeBlacklist")) && Vg(3);
            d ? Vg(8) : d = [];
            Tl() && (d = Ya(d), d.push("nonGooglePixels", "nonGoogleScripts", "sandboxedScripts"));
            0 <= Ja(Ya(d), "google") && Vg(2);
            var e = d && hb(Ya(d), Ql),
                f = {};
            return function(g) {
                var h = g && g[qe.sb];
                if (!h || "string" != typeof h) return !0;
                h = h.replace(/^_*/, "");
                if (void 0 !== f[h]) return f[h];
                var l = Ci[h] || [],
                    n = a(h, l);
                if (b) {
                    var p;
                    if (p =
                        n) a: {
                        if (0 > Ja(c, h))
                            if (l && 0 < l.length)
                                for (var q = 0; q < l.length; q++) {
                                    if (0 > Ja(c, l[q])) {
                                        Vg(11);
                                        p = !1;
                                        break a
                                    }
                                } else {
                                    p = !1;
                                    break a
                                }
                        p = !0
                    }
                    n = p
                }
                var t = !1;
                if (d) {
                    var u = 0 <= Ja(e, h);
                    if (u) t = u;
                    else {
                        var r = Pa(e, l || []);
                        r && Vg(10);
                        t = r
                    }
                }
                var v = !n || t;
                v || !(0 <= Ja(l, "sandboxedScripts")) || c && -1 !== Ja(c, "sandboxedScripts") || (v = Pa(e, Rl));
                return f[h] = v
            }
        },
        Tl = function() {
            return Ol.test(m.location && m.location.hostname)
        };
    var Vl = !1,
        Wl = 0,
        Xl = [];

    function Yl(a) {
        if (!Vl) {
            var b = H.createEventObject,
                c = "complete" == H.readyState,
                d = "interactive" == H.readyState;
            if (!a || "readystatechange" != a.type || c || !b && d) {
                Vl = !0;
                for (var e = 0; e < Xl.length; e++) I(Xl[e])
            }
            Xl.push = function() {
                for (var f = 0; f < arguments.length; f++) I(arguments[f]);
                return 0
            }
        }
    }

    function Zl() {
        if (!Vl && 140 > Wl) {
            Wl++;
            try {
                H.documentElement.doScroll("left"), Yl()
            } catch (a) {
                m.setTimeout(Zl, 50)
            }
        }
    }
    var $l = function(a) {
        Vl ? a() : Xl.push(a)
    };
    var bm = function(a, b) {
            this.g = !1;
            this.D = [];
            this.F = {
                tags: []
            };
            this.N = !1;
            this.o = this.s = 0;
            am(this, a, b)
        },
        cm = function(a, b, c, d) {
            if (ti.hasOwnProperty(b) || "__zone" === b) return -1;
            var e = {};
            Gc(d) && (e = J(d, e));
            e.id = c;
            e.status = "timeout";
            return a.F.tags.push(e) - 1
        },
        dm = function(a, b, c, d) {
            var e = a.F.tags[b];
            e && (e.status = c, e.executionTime = d)
        },
        em = function(a) {
            if (!a.g) {
                for (var b = a.D, c = 0; c < b.length; c++) b[c]();
                a.g = !0;
                a.D.length = 0
            }
        },
        am = function(a, b, c) {
            Ga(b) && a.vc(b);
            c && m.setTimeout(function() {
                return em(a)
            }, Number(c))
        };
    bm.prototype.vc = function(a) {
        var b = this,
            c = eb(function() {
                return I(function() {
                    a(tf.J, b.F)
                })
            });
        this.g ? c() : this.D.push(c)
    };
    var fm = function(a) {
        a.s++;
        return eb(function() {
            a.o++;
            a.N && a.o >= a.s && em(a)
        })
    };
    var gm = function() {
            function a(d) {
                return !Ha(d) || 0 > d ? 0 : d
            }
            if (!S._li && m.performance && m.performance.timing) {
                var b = m.performance.timing.navigationStart,
                    c = Ha(Li.get("gtm.start")) ? Li.get("gtm.start") : 0;
                S._li = {
                    cst: a(c - b),
                    cbt: a(zi - b)
                }
            }
        },
        hm = function(a) {
            m.performance && m.performance.mark(tf.J + "_" + a + "_start")
        },
        im = function(a) {
            if (m.performance) {
                var b = tf.J + "_" + a + "_start",
                    c = tf.J + "_" + a + "_duration";
                m.performance.measure(c, b);
                var d = m.performance.getEntriesByName(c)[0];
                m.performance.clearMarks(b);
                m.performance.clearMeasures(c);
                var e = S._p || {};
                void 0 === e[a] && (e[a] = d.duration, S._p = e);
                return d.duration
            }
        },
        jm = function() {
            if (m.performance && m.performance.now) {
                var a = S._p || {};
                a.PAGEVIEW = m.performance.now();
                S._p = a
            }
        };
    var km = {},
        lm = function() {
            return m.GoogleAnalyticsObject && m[m.GoogleAnalyticsObject]
        },
        mm = !1;
    var nm = function(a) {
            m.GoogleAnalyticsObject || (m.GoogleAnalyticsObject = a || "ga");
            var b = m.GoogleAnalyticsObject;
            if (m[b]) m.hasOwnProperty(b) || Vg(12);
            else {
                var c = function() {
                    c.q = c.q || [];
                    c.q.push(arguments)
                };
                c.l = Number(bb());
                m[b] = c
            }
            gm();
            return m[b]
        },
        om = function(a, b, c, d) {
            b = String(b).replace(/\s+/g, "").split(",");
            var e = lm();
            e(a + "require", "linker");
            e(a + "linker:autoLink", b, c, d)
        },
        pm = function(a) {
            if (!lh()) return;
            var b = lm();
            b(a + "require", "linker");
            b(a + "linker:passthrough", !0);
        };

    function qm() {
        return m.GoogleAnalyticsObject || "ga"
    }
    var rm = function(a) {},
        sm = function(a, b) {
            return function() {
                var c = lm(),
                    d = c && c.getByName && c.getByName(a);
                if (d) {
                    var e = d.get("sendHitTask");
                    d.set("sendHitTask", function(f) {
                        var g = f.get("hitPayload"),
                            h = f.get("hitCallback"),
                            l = 0 > g.indexOf("&tid=" + b);
                        l && (f.set("hitPayload", g.replace(/&tid=UA-[0-9]+-[0-9]+/, "&tid=" + b), !0), f.set("hitCallback", void 0, !0));
                        e(f);
                        l && (f.set("hitPayload",
                            g, !0), f.set("hitCallback", h, !0), f.set("_x_19", void 0, !0), e(f))
                    })
                }
            }
        };
    var zm = function(a) {},
        Dm = function(a) {},
        Em =
        function() {
            return "&tc=" + We.filter(function(a) {
                return a
            }).length
        },
        Hm = function() {
            2022 <= Fm().length && Gm()
        },
        Im = function(a) {
            return 0 === a.indexOf("gtm.") ? encodeURIComponent(a) : "*"
        },
        Km = function() {
            Jm || (Jm = m.setTimeout(Gm, 500))
        },
        Gm = function() {
            Jm && (m.clearTimeout(Jm), Jm = void 0);
            void 0 === Lm || Mm[Lm] && !Nm && !Om || (Pm[Lm] || Qm.dj() || 0 >= Rm-- ? (Vg(1), Pm[Lm] = !0) : (Qm.Aj(), ec(Fm(!0)), Mm[Lm] = !0, Sm = Tm = Um = Om = Nm = ""))
        },
        Fm = function(a) {
            var b = Lm;
            if (void 0 === b) return "";
            var c = Ug("GTM"),
                d = Ug("TAGGING");
            return [Vm, Mm[b] ? "" : "&es=1",
                Wm[b], zm(b), c ? "&u=" + c : "", d ? "&ut=" + d : "", Em(), Nm, Om, Um, Tm, Dm(a), Sm, "&z=0"
            ].join("")
        },
        Ym = function() {
            Vm = Xm()
        },
        Xm = function() {
            return [Ai, "&v=3&t=t", "&pid=" + Na(), "&rv=" + tf.td].join("")
        },
        Cm = ["L", "S", "Y"],
        ym = ["S", "E"],
        Zm = {
            sampleRate: "0.005000",
            mh: "",
            lh: Number("5")
        },
        $m = 0 <= H.location.search.indexOf("?gtm_latency=") || 0 <= H.location.search.indexOf("&gtm_latency="),
        an;
    if (!(an = $m)) {
        var bn = Math.random(),
            cn = Zm.sampleRate;
        an = bn < cn
    }
    var dn = an,
        en = {
            label: tf.J + " Container",
            children: [{
                label: "Initialization",
                children: []
            }]
        },
        Vm = Xm(),
        Mm = {},
        Nm = "",
        Om = "",
        Sm = "",
        Tm = "",
        Bm = {},
        Am = !1,
        xm = {},
        fn = {},
        Um = "",
        Lm = void 0,
        Wm = {},
        Pm = {},
        Jm = void 0,
        gn = 5;
    0 < Zm.lh && (gn = Zm.lh);
    var Qm = function(a, b) {
            for (var c = 0, d = [], e = 0; e < a; ++e) d.push(0);
            return {
                dj: function() {
                    return c < a ? !1 : cb() - d[c % a] < b
                },
                Aj: function() {
                    var f = c++ % a;
                    d[f] = cb()
                }
            }
        }(gn, 1E3),
        Rm = 1E3,
        jn = function(a, b) {
            if (dn && !Pm[a] && Lm !==
                a) {
                Gm();
                Lm = a;
                Sm = Nm = "";
                Wm[a] = "&e=" + Im(b) + "&eid=" + a;
                Km();
            }
        },
        kn = function(a, b, c, d) {
            if (dn && b) {
                var e, f = String(b[qe.sb] || "").replace(/_/g, "");
                0 === f.indexOf("cvt") && (f = "cvt");
                e = f;
                var g = c + e;
                if (!Pm[a]) {
                    a !== Lm && (Gm(), Lm = a);
                    Nm = Nm ? Nm + "." + g : "&tr=" + g;
                    var h = b["function"];
                    if (!h) throw Error("Error: No function name given for function call.");
                    var l = (Ye[h] ? "1" : "2") + e;
                    Sm = Sm ? Sm + "." + l : "&ti=" + l;
                    Km();
                    Hm()
                }
            }
        };
    var rn = function(a, b, c) {
            if (dn && !Pm[a]) {
                a !== Lm && (Gm(), Lm = a);
                var d = c + b;
                Om = Om ? Om + "." + d : "&epr=" + d;
                Km();
                Hm()
            }
        },
        sn = function(a, b, c) {};
    var tn = {
            active: !0,
            isAllowed: function() {
                return !0
            }
        },
        un = function(a) {
            var b = S.zones;
            return b ? b.checkState(tf.J, a) : tn
        },
        vn = function(a) {
            var b = S.zones;
            !b && a && (b = S.zones = a());
            return b
        };

    function wn() {}

    function xn() {};

    function yn(a, b, c, d) {
        var e = We[a],
            f = zn(a, b, c, d);
        if (!f) return null;
        var g = df(e[qe.gg], c, []);
        if (g && g.length) {
            var h = g[0];
            f = yn(h.index, {
                onSuccess: f,
                onFailure: 1 === h.Fg ? b.terminate : f,
                terminate: b.terminate
            }, c, d)
        }
        return f
    }

    function zn(a, b, c, d) {
        function e() {
            if (f[qe.ii]) h();
            else {
                var w = ef(f, c, []);
                var y = w[qe.sh];
                if (null != y)
                    for (var x = 0; x < y.length; x++)
                        if (!wh(y[x])) {
                            h();
                            return
                        }
                var z = cm(c.ib, String(f[qe.sb]), Number(f[qe.ig]), w[qe.ji]),
                    B = !1;
                w.vtp_gtmOnSuccess = function() {
                    if (!B) {
                        B = !0;
                        var D = cb() - F;
                        kn(c.id, We[a], "5", D);
                        dm(c.ib, z, "success",
                            D);
                        g()
                    }
                };
                w.vtp_gtmOnFailure = function() {
                    if (!B) {
                        B = !0;
                        var D = cb() - F;
                        kn(c.id, We[a], "6", D);
                        dm(c.ib, z, "failure", D);
                        h()
                    }
                };
                w.vtp_gtmTagId = f.tag_id;
                w.vtp_gtmEventId = c.id;
                kn(c.id, f, "1");
                var C = function() {
                    var D = cb() - F;
                    kn(c.id, f, "7", D);
                    dm(c.ib, z, "exception", D);
                    B || (B = !0, h())
                };
                var F = cb();
                try {
                    cf(w, c)
                } catch (D) {
                    C(D)
                }
            }
        }
        var f = We[a],
            g = b.onSuccess,
            h = b.onFailure,
            l = b.terminate;
        if (c.$e(f)) return null;
        var n = df(f[qe.jg], c, []);
        if (n && n.length) {
            var p = n[0],
                q = yn(p.index, {
                    onSuccess: g,
                    onFailure: h,
                    terminate: l
                }, c, d);
            if (!q) return null;
            g = q;
            h = 2 === p.Fg ? l : q
        }
        if (f[qe.cg] || f[qe.ni]) {
            var t = f[qe.cg] ? Xe :
                c.Lj,
                u = g,
                r = h;
            if (!t[a]) {
                e = eb(e);
                var v = An(a, t, e);
                g = v.onSuccess;
                h = v.onFailure
            }
            return function() {
                t[a](u, r)
            }
        }
        return e
    }

    function An(a, b, c) {
        var d = [],
            e = [];
        b[a] = Bn(d, e, c);
        return {
            onSuccess: function() {
                b[a] = Cn;
                for (var f = 0; f < d.length; f++) d[f]()
            },
            onFailure: function() {
                b[a] = Dn;
                for (var f = 0; f < e.length; f++) e[f]()
            }
        }
    }

    function Bn(a, b, c) {
        return function(d, e) {
            a.push(d);
            b.push(e);
            c()
        }
    }

    function Cn(a) {
        a()
    }

    function Dn(a, b) {
        b()
    };
    var Gn = function(a, b) {
        for (var c = [], d = 0; d < We.length; d++)
            if (a[d]) {
                var e = We[d];
                var f = fm(b.ib);
                try {
                    var g = yn(d, {
                        onSuccess: f,
                        onFailure: f,
                        terminate: f
                    }, b, d);
                    if (g) {
                        var h = c,
                            l = h.push,
                            n = d,
                            p = e["function"];
                        if (!p) throw "Error: No function name given for function call.";
                        var q = Ye[p];
                        l.call(h, {
                            eh: n,
                            Vg: q ? q.priorityOverride || 0 : 0,
                            execute: g
                        })
                    } else En(d, b), f()
                } catch (r) {
                    f()
                }
            }
        var t = b.ib;
        t.N = !0;
        t.o >= t.s && em(t);
        c.sort(Fn);
        for (var u = 0; u < c.length; u++) c[u].execute();
        return 0 < c.length
    };

    function Fn(a, b) {
        var c, d = b.Vg,
            e = a.Vg;
        c = d > e ? 1 : d < e ? -1 : 0;
        var f;
        if (0 !== c) f = c;
        else {
            var g = a.eh,
                h = b.eh;
            f = g > h ? 1 : g < h ? -1 : 0
        }
        return f
    }

    function En(a, b) {
        if (!dn) return;
        var c = function(d) {
            var e = b.$e(We[d]) ? "3" : "4",
                f = df(We[d][qe.gg], b, []);
            f && f.length && c(f[0].index);
            kn(b.id, We[d], e);
            var g = df(We[d][qe.jg], b, []);
            g && g.length && c(g[0].index)
        };
        c(a);
    }
    var Hn = !1,
        Nn = function(a) {
            var b = cb(),
                c = a["gtm.uniqueEventId"],
                d = a.event;
            if ("gtm.js" === d) {
                if (Hn) return !1;
                Hn = !0;
            }
            var g = un(c),
                h = !1;
            if (!g.active) {
                if ("gtm.js" !== d) return !1;
                h = !0;
                g = un(Number.MAX_SAFE_INTEGER)
            }
            jn(c, d);
            var l = a.eventCallback,
                n = a.eventTimeout,
                p = l;
            var q = {
                id: c,
                name: d,
                $e: Ul(g.isAllowed),
                Lj: [],
                Qg: function() {
                    Vg(6)
                },
                wg: In(c),
                ib: new bm(p, n)
            };
            q.vg = Jn();
            Kn(c, q.ib);
            var t = of (q);
            h && (t = Ln(t));
            var u = Gn(t, q);
            "gtm.js" !== d && "gtm.sync" !== d || rm(tf.J);
            return Mn(t, u)
        };

    function In(a) {
        return function(b) {
            dn && (Kc(b) || sn(a, "input", b))
        }
    }

    function Kn(a, b) {
        Qi(a, "event", 1);
        Qi(a, "ecommerce", 1);
        Qi(a, "gtm");
        Qi(a, "eventModel");
    }

    function Jn() {
        var a = {};
        a.event = Pi("event", 1);
        a.ecommerce = Pi("ecommerce", 1);
        a.gtm = Pi("gtm");
        a.eventModel = Pi("eventModel");
        return a
    }

    function Ln(a) {
        for (var b = [], c = 0; c < a.length; c++) a[c] && si[String(We[c][qe.sb])] && (b[c] = !0);
        return b
    }

    function Mn(a, b) {
        if (!b) return b;
        for (var c = 0; c < a.length; c++)
            if (a[c] && We[c] && !ti[String(We[c][qe.sb])]) return !0;
        return !1
    }

    function On(a, b) {
        if (a) {
            var c = "" + a;
            0 !== c.indexOf("http://") && 0 !== c.indexOf("https://") && (c = "https://" + c);
            "/" === c[c.length - 1] && (c = c.substring(0, c.length - 1));
            return lj("" + c + b).href
        }
    }

    function Pn(a, b) {
        return Qn() ? On(a, b) : void 0
    }

    function Qn() {
        var a = !1;
        return a
    }

    function Rn() {
        return !!tf.ud && "SGTM_TOKEN" !== tf.ud.replaceAll("@@", "")
    };
    var Sn = function() {
        var a = !1;
        return a
    };
    var Tn;
    if (3 === tf.td.length) Tn = "g";
    else {
        var Un = "G";
        Tn = Un
    }
    var Vn = {
            "": "n",
            UA: "u",
            AW: "a",
            DC: "d",
            G: "e",
            GF: "f",
            HA: "h",
            GTM: Tn,
            OPT: "o"
        },
        Wn = function(a) {
            var b = tf.J.split("-"),
                c = b[0].toUpperCase(),
                d = Vn[c] || "i",
                e = a && "GTM" === c ? b[1] : "OPT" === c ? b[1] : "",
                f;
            if (3 === tf.td.length) {
                var g = "w";
                f = "2" + g
            } else f = "";
            return f + d + tf.td + e
        };

    function Xn(a, b) {
        if ("" === a) return b;
        var c = Number(a);
        return isNaN(c) ? b : c
    };
    var Yn = function(a, b) {
        a.addEventListener && a.addEventListener.call(a, "message", b, !1)
    };

    function Zn() {
        return Lb("iPhone") && !Lb("iPod") && !Lb("iPad")
    };
    Lb("Opera");
    Lb("Trident") || Lb("MSIE");
    Lb("Edge");
    !Lb("Gecko") || -1 != Ib.toLowerCase().indexOf("webkit") && !Lb("Edge") || Lb("Trident") || Lb("MSIE") || Lb("Edge"); - 1 != Ib.toLowerCase().indexOf("webkit") && !Lb("Edge") && Lb("Mobile");
    Lb("Macintosh");
    Lb("Windows");
    Lb("Linux") || Lb("CrOS");
    var $n = qa.navigator || null;
    $n && ($n.appVersion || "").indexOf("X11");
    Lb("Android");
    Zn();
    Lb("iPad");
    Lb("iPod");
    Zn() || Lb("iPad") || Lb("iPod");
    Ib.toLowerCase().indexOf("kaios");
    var ao = function(a, b) {
            for (var c = a, d = 0; 50 > d; ++d) {
                var e;
                try {
                    e = !(!c.frames || !c.frames[b])
                } catch (h) {
                    e = !1
                }
                if (e) return c;
                var f;
                a: {
                    try {
                        var g = c.parent;
                        if (g && g != c) {
                            f = g;
                            break a
                        }
                    } catch (h) {}
                    f = null
                }
                if (!(c = f)) break
            }
            return null
        },
        bo = function(a) {
            var b = H;
            b = void 0 === b ? window.document : b;
            if (!a || !b.head) return null;
            var c, d, e;
            e = void 0 === e ? document : e;
            d = "META";
            "application/xhtml+xml" === (null == e ? void 0 : e.contentType) && (d = d.toLowerCase());
            c = e.createElement(d);
            b.head.appendChild(c);
            c.httpEquiv = "origin-trial";
            c.content = a;
            return c
        };
    var co = function() {};
    var eo = function(a) {
            void 0 !== a.addtlConsent && "string" !== typeof a.addtlConsent && (a.addtlConsent = void 0);
            void 0 !== a.gdprApplies && "boolean" !== typeof a.gdprApplies && (a.gdprApplies = void 0);
            return void 0 !== a.tcString && "string" !== typeof a.tcString || void 0 !== a.listenerId && "number" !== typeof a.listenerId ? 2 : a.cmpStatus && "error" !== a.cmpStatus ? 0 : 3
        },
        fo = function(a, b) {
            this.o = a;
            this.g = null;
            this.D = {};
            this.N = 0;
            this.F = void 0 === b ? 500 : b;
            this.s = null
        };
    pa(fo, co);
    var ho = function(a) {
        return "function" === typeof a.o.__tcfapi || null != go(a)
    };
    fo.prototype.addEventListener = function(a) {
        var b = {},
            c = Tb(function() {
                return a(b)
            }),
            d = 0; - 1 !== this.F && (d = setTimeout(function() {
            b.tcString = "tcunavailable";
            b.internalErrorState = 1;
            c()
        }, this.F));
        var e = function(f, g) {
            clearTimeout(d);
            f ? (b = f, b.internalErrorState = eo(b), g && 0 === b.internalErrorState || (b.tcString = "tcunavailable", g || (b.internalErrorState = 3))) : (b.tcString = "tcunavailable", b.internalErrorState = 3);
            a(b)
        };
        try {
            io(this, "addEventListener", e)
        } catch (f) {
            b.tcString = "tcunavailable", b.internalErrorState = 3, d && (clearTimeout(d),
                d = 0), c()
        }
    };
    fo.prototype.removeEventListener = function(a) {
        a && a.listenerId && io(this, "removeEventListener", null, a.listenerId)
    };
    var ko = function(a, b, c) {
            var d;
            d = void 0 === d ? "755" : d;
            var e;
            a: {
                if (a.publisher && a.publisher.restrictions) {
                    var f = a.publisher.restrictions[b];
                    if (void 0 !== f) {
                        e = f[void 0 === d ? "755" : d];
                        break a
                    }
                }
                e = void 0
            }
            var g = e;
            if (0 === g) return !1;
            var h = c;
            2 === c ? (h = 0, 2 === g && (h = 1)) : 3 === c && (h = 1, 1 === g && (h = 0));
            var l;
            if (0 === h)
                if (a.purpose && a.vendor) {
                    var n = jo(a.vendor.consents, void 0 === d ? "755" : d);
                    l = n && "1" === b && a.purposeOneTreatment && ((ah(Yg) ? 0 : "DE" === a.publisherCC) || "CH" === a.publisherCC) ? !0 : n && jo(a.purpose.consents, b)
                } else l = !0;
            else l =
                1 === h ? a.purpose && a.vendor ? jo(a.purpose.legitimateInterests, b) && jo(a.vendor.legitimateInterests, void 0 === d ? "755" : d) : !0 : !0;
            return l
        },
        jo = function(a, b) {
            return !(!a || !a[b])
        },
        io = function(a, b, c, d) {
            c || (c = function() {});
            if ("function" === typeof a.o.__tcfapi) {
                var e = a.o.__tcfapi;
                e(b, 2, c, d)
            } else if (go(a)) {
                lo(a);
                var f = ++a.N;
                a.D[f] = c;
                if (a.g) {
                    var g = {};
                    a.g.postMessage((g.__tcfapiCall = {
                        command: b,
                        version: 2,
                        callId: f,
                        parameter: d
                    }, g), "*")
                }
            } else c({}, !1)
        },
        go = function(a) {
            if (a.g) return a.g;
            a.g = ao(a.o, "__tcfapiLocator");
            return a.g
        },
        lo = function(a) {
            a.s || (a.s = function(b) {
                try {
                    var c;
                    c = ("string" === typeof b.data ? JSON.parse(b.data) : b.data).__tcfapiReturn;
                    a.D[c.callId](c.returnValue, c.success)
                } catch (d) {}
            }, Yn(a.o, a.s))
        };
    var mo = !0;
    mo = !1;
    var no = {
            1: 0,
            3: 0,
            4: 0,
            7: 3,
            9: 3,
            10: 3
        },
        oo = Xn("", 550),
        po = Xn("", 500);

    function qo() {
        var a = S.tcf || {};
        return S.tcf = a
    }
    var ro = function(a, b) {
            this.s = a;
            this.g = b;
            this.o = cb();
        },
        so = function(a) {},
        to = function(a) {},
        zo = function() {
            var a = qo(),
                b = new fo(m, mo ? 3E3 : -1),
                c = new ro(b, a);
            if ((uo() ? !0 === m.gtag_enable_tcf_support : !1 !== m.gtag_enable_tcf_support) && !a.active && ("function" === typeof m.__tcfapi || ho(b))) {
                a.active = !0;
                a.Oc = {};
                vo();
                var d = null;
                mo ? d = m.setTimeout(function() {
                    wo(a);
                    xo(a);
                    d = null
                }, po) : a.tcString = "tcunavailable";
                try {
                    b.addEventListener(function(e) {
                        d && (clearTimeout(d), d = null);
                        if (0 !== e.internalErrorState) wo(a), xo(a), so(c);
                        else {
                            var f;
                            a.gdprApplies = e.gdprApplies;
                            if (!1 === e.gdprApplies) f = yo(), b.removeEventListener(e);
                            else if ("tcloaded" === e.eventStatus || "useractioncomplete" === e.eventStatus || "cmpuishown" === e.eventStatus) {
                                var g = {},
                                    h;
                                for (h in no)
                                    if (no.hasOwnProperty(h))
                                        if ("1" === h) {
                                            var l, n = e,
                                                p = !0;
                                            p = void 0 === p ? !1 : p;
                                            var q;
                                            var t = n;
                                            !1 === t.gdprApplies ? q = !0 : (void 0 === t.internalErrorState && (t.internalErrorState = eo(t)), q = "error" === t.cmpStatus || 0 !== t.internalErrorState || "loaded" === t.cmpStatus && ("tcloaded" === t.eventStatus || "useractioncomplete" ===
                                                t.eventStatus) ? !0 : !1);
                                            l = q ? !1 === n.gdprApplies || "tcunavailable" === n.tcString || void 0 === n.gdprApplies && !p || "string" !== typeof n.tcString || !n.tcString.length ? !0 : ko(n, "1", 0) : !1;
                                            g["1"] = l
                                        } else g[h] = ko(e, h, no[h]);
                                f = g
                            }
                            f && (a.tcString = e.tcString || "tcempty", a.Oc = f, xo(a), so(c))
                        }
                    }), to(c)
                } catch (e) {
                    d && (clearTimeout(d), d = null), wo(a), xo(a)
                }
            }
        };

    function wo(a) {
        a.type = "e";
        a.tcString = "tcunavailable";
        mo && (a.Oc = yo())
    }

    function vo() {
        var a = {},
            b = (a.ad_storage = "denied", a.wait_for_update = oo, a);
        th(b)
    }
    var uo = function() {
        var a = !1;
        a = !0;
        return a
    };

    function yo() {
        var a = {},
            b;
        for (b in no) no.hasOwnProperty(b) && (a[b] = !0);
        return a
    }

    function xo(a) {
        var b = {},
            c = (b.ad_storage = a.Oc["1"] ? "granted" : "denied", b);
        Ao();
        vh(c, 0)
    }
    var Bo = function() {
            var a = qo();
            if (a.active && void 0 !== a.loadTime) return Number(a.loadTime)
        },
        Ao = function() {
            var a = qo();
            return a.active ? a.tcString || "" : ""
        },
        Co = function() {
            var a = qo();
            return a.active && void 0 !== a.gdprApplies ? a.gdprApplies ? "1" : "0" : ""
        },
        Do = function(a) {
            if (!no.hasOwnProperty(String(a))) return !0;
            var b = qo();
            return b.active && b.Oc ? !!b.Oc[String(a)] : !0
        };
    var Eo = function(a, b) {
            var c = a && !wh(R.C);
            return b && c ? "0" : b
        },
        Io = function(a) {
            function b(r) {
                var v;
                S.reported_gclid || (S.reported_gclid = {});
                v = S.reported_gclid;
                var w;
                w = !g || lh() && !wh(R.C) ? l + (r ? "gcu" : "gcs") : l + "." + (f.prefix || "_gcl") + (r ? "gcu" : "gcs");
                if (!v[w]) {
                    v[w] = !0;
                    var y = [],
                        x = {},
                        z = function(M, N) {
                            N && (y.push(M + "=" + encodeURIComponent(N)), x[M] = !0)
                        },
                        B = "https://www.google.com";
                    if (lh()) {
                        var C = wh(R.C);
                        z("gcs", xh());
                        r && z("gcu", "1");
                        mh() && z("gcd", yh());
                        S.dedupe_gclid || (S.dedupe_gclid = "" + Zj());
                        z("rnd", S.dedupe_gclid);
                        if ((!l || n && "aw.ds" !== n) && wh(R.C)) {
                            var F = cl("_gcl_aw");
                            z("gclaw", F.join("."))
                        }
                        z("url", String(m.location).split(/[?#]/)[0]);
                        z("dclid", Eo(d, p));
                        var D = !1;
                        D = !0;
                        C || !d && !D || (B = "https://pagead2.googlesyndication.com")
                    }
                    z("gdpr_consent",
                        Ao()), z("gdpr", Co());
                    "1" === Nk(!1)._up && z("gtm_up", "1");
                    z("gclid", Eo(d, l));
                    z("gclsrc", n);
                    if (!(x.gclid || x.dclid || x.gclaw) && (z("gbraid", Eo(d, q)), !x.gbraid && lh() && wh(R.C))) {
                        var E = cl("_gcl_gb");
                        z("gclgb", E.join("."))
                    }
                    z("gtm", Wn(!e));
                    g && wh(R.C) && (jk(f || {}), z("auid", gk[hk(f.prefix)] || ""));
                    Go || a.Bd &&
                        z("did", a.Bd), Ho && (a.Tb && z("gdid", a.Tb), a.Sb && z("edid", a.Sb));
                    var O = B + "/pagead/landing?" + y.join("&");
                    lc(O)
                }
            }
            var c = !!a.Ne,
                d = !!a.Ha,
                e = a.U,
                f = void 0 === a.wb ? {} : a.wb,
                g = void 0 === a.Id ? !0 : a.Id,
                h = il(),
                l = h.gclid || "",
                n = h.gclsrc,
                p = h.dclid || "",
                q = h.gbraid || "",
                t = !c && ((!l || n && "aw.ds" !== n ? !1 : !0) || q),
                u = lh();
            if (t || u) u ? Bh(function() {
                b();
                wh(R.C) || Ah(function(r) {
                    return b(!0, r.consentEventId)
                }, R.C)
            }, [R.C]) : b()
        },
        Fo = function(a) {
            var b = String(m.location).split(/[?#]/)[0],
                c = tf.uh || m._CONSENT_MODE_SALT;
            return a ? c ? String(Ij(b + a + c)) : "0" : ""
        },
        Go = !1;
    var Ho = !1;
    var Ko = function(a) {
            if (!lh() || ih(R.C)) {
                var b = Jo(a);
                if (b && !(18E5 < cb() - b.Og)) return b.Cg
            }
        },
        Jo = function(a) {
            a = a || {};
            if (Kj(m) && H.cookie) {
                var b = ck(gl(a.prefix) + "_ec", a.domain, a.path, ["1"], R.C);
                if (b) {
                    var c = b.split(".");
                    if (3 === c.length) {
                        var d = 1E3 * Number(c[1]) || 0;
                        if (0 !== d) return {
                            Cg: c[0] + "." + c[1],
                            Li: d,
                            Og: 1E3 * Number(c[2]) || 0
                        }
                    }
                }
            }
        };
    var Lo = !1;
    var Mo = function() {
            this.g = {}
        },
        No = function(a, b, c) {
            null != c && (a.g[b] = c)
        },
        Oo = function(a) {
            return Object.keys(a.g).map(function(b) {
                return encodeURIComponent(b) + "=" + encodeURIComponent(a.g[b])
            }).join("&")
        },
        Qo = function(a, b, c, d, e) {};
    var So = /[A-Z]+/,
        To = /\s/,
        Uo = function(a) {
            if (k(a)) {
                a = ab(a);
                var b = a.indexOf("-");
                if (!(0 > b)) {
                    var c = a.substring(0, b);
                    if (So.test(c)) {
                        var d = !1;
                        d = !0;
                        for (var e = a.substring(b + 1).split("/"), f = 0; f < e.length; f++)
                            if (!e[f] || To.test(e[f]) && ("AW" !== c || 1 !== f || !d)) return;
                        return {
                            id: a,
                            prefix: c,
                            containerId: c + "-" + e[0],
                            M: e
                        }
                    }
                }
            }
        },
        Wo = function(a) {
            for (var b = {}, c = 0; c < a.length; ++c) {
                var d =
                    Uo(a[c]);
                d && (b[d.id] = d)
            }
            Vo(b);
            var e = [];
            Qa(b, function(f, g) {
                e.push(g)
            });
            return e
        };

    function Vo(a) {
        var b = [],
            c;
        for (c in a)
            if (a.hasOwnProperty(c)) {
                var d = a[c];
                "AW" === d.prefix && d.M[1] && b.push(d.containerId)
            }
        for (var e = 0; e < b.length; ++e) delete a[b[e]]
    };
    var Yo = function(a, b, c, d) {
            return (2 === Xo() || d || "http:" != m.location.protocol ? a : b) + c
        },
        Xo = function() {
            var a = cc(),
                b;
            if (1 === a) a: {
                var c = wi;c = c.toLowerCase();
                for (var d = "https://" + c, e = "http://" + c, f = 1, g = H.getElementsByTagName("script"), h = 0; h < g.length && 100 > h; h++) {
                    var l = g[h].src;
                    if (l) {
                        l = l.toLowerCase();
                        if (0 === l.indexOf(e)) {
                            b = 3;
                            break a
                        }
                        1 === f && 0 === l.indexOf(d) && (f = 2)
                    }
                }
                b = f
            }
            else b = a;
            return b
        };
    var $o = function(a, b, c) {
            if (m[a.functionName]) return b.ff && I(b.ff), m[a.functionName];
            var d = Zo();
            m[a.functionName] = d;
            if (a.xd)
                for (var e = 0; e < a.xd.length; e++) m[a.xd[e]] = m[a.xd[e]] || Zo();
            a.Hd && void 0 === m[a.Hd] && (m[a.Hd] = c);
            bc(Yo("https://", "http://", a.qf), b.ff, b.rj);
            return d
        },
        Zo = function() {
            var a = function() {
                a.q = a.q || [];
                a.q.push(arguments)
            };
            return a
        },
        ap = {
            functionName: "_googWcmImpl",
            Hd: "_googWcmAk",
            qf: "www.gstatic.com/wcm/loader.js"
        },
        bp = {
            functionName: "_gaPhoneImpl",
            Hd: "ga_wpid",
            qf: "www.gstatic.com/gaphone/loader.js"
        },
        cp = {
            rh: "",
            oi: "5"
        },
        dp = {
            functionName: "_googCallTrackingImpl",
            xd: [bp.functionName, ap.functionName],
            qf: "www.gstatic.com/call-tracking/call-tracking_" + (cp.rh || cp.oi) + ".js"
        },
        ep = {},
        fp = function(a, b, c, d) {
            Vg(22);
            if (c) {
                d = d || {};
                var e = $o(ap, d, a),
                    f = {
                        ak: a,
                        cl: b
                    };
                void 0 === d.Ta && (f.autoreplace = c);
                e(2, d.Ta, f, c, 0, bb(), d.options)
            }
        },
        gp = function(a, b, c, d) {
            Vg(21);
            if (b && c) {
                d = d || {};
                for (var e = {
                        countryNameCode: c,
                        destinationNumber: b,
                        retrievalTime: bb()
                    }, f = 0; f < a.length; f++) {
                    var g = a[f];
                    ep[g.id] ||
                        (g && "AW" === g.prefix && !e.adData && 2 <= g.M.length ? (e.adData = {
                            ak: g.M[0],
                            cl: g.M[1]
                        }, ep[g.id] = !0) : g && "UA" === g.prefix && !e.gaData && (e.gaData = {
                            gaWpid: g.containerId
                        }, ep[g.id] = !0))
                }(e.gaData || e.adData) && $o(dp, d)(d.Ta, e, d.options)
            }
        },
        hp = function() {
            var a = !1;
            return a
        },
        ip = function(a, b) {
            if (a)
                if (Sn()) {} else {
                    if (k(a)) {
                        var c =
                            Uo(a);
                        if (!c) return;
                        a = c
                    }
                    var d = void 0,
                        e = !1,
                        f = b.getWithConfig(R.Yh);
                    if (f && Ia(f)) {
                        d = [];
                        for (var g = 0; g < f.length; g++) {
                            var h = Uo(f[g]);
                            h && (d.push(h), (a.id === h.id || a.id === a.containerId && a.containerId === h.containerId) && (e = !0))
                        }
                    }
                    if (!d || e) {
                        var l = b.getWithConfig(R.Vf),
                            n;
                        if (l) {
                            Ia(l) ? n = l : n = [l];
                            var p = b.getWithConfig(R.Tf),
                                q = b.getWithConfig(R.Uf),
                                t = b.getWithConfig(R.Wf),
                                u = b.getWithConfig(R.Xh),
                                r = p || q,
                                v = 1;
                            "UA" !== a.prefix || d || (v = 5);
                            for (var w = 0; w < n.length; w++)
                                if (w < v)
                                    if (d) gp(d, n[w], u, {
                                        Ta: r,
                                        options: t
                                    });
                                    else if ("AW" === a.prefix &&
                                a.M[1]) hp() ? gp([a], n[w], u || "US", {
                                Ta: r,
                                options: t
                            }) : fp(a.M[0], a.M[1], n[w], {
                                Ta: r,
                                options: t
                            });
                            else if ("UA" === a.prefix)
                                if (hp()) gp([a], n[w], u || "US", {
                                    Ta: r
                                });
                                else {
                                    var y = a.containerId,
                                        x = n[w],
                                        z = {
                                            Ta: r
                                        };
                                    Vg(23);
                                    if (x) {
                                        z = z || {};
                                        var B = $o(bp, z, y),
                                            C = {};
                                        void 0 !== z.Ta ? C.receiver = z.Ta : C.replace = x;
                                        C.ga_wpid = y;
                                        C.destination = x;
                                        B(2, bb(), C)
                                    }
                                }
                        }
                    }
                }
        };
    var kp = function() {
            var a = S.floc;
            if (a) {
                var b = a.ts,
                    c = a.floc;
                if (b && c && 1E3 > cb() - b) return Promise.resolve(c)
            }
            var d = void 0;
            try {
                d = Promise.race([H.interestCohort().then(function(e) {
                    S.floc = {
                        ts: cb(),
                        floc: e
                    };
                    return e
                }), new Promise(function(e) {
                    m.setTimeout(function() {
                        return e()
                    }, jp)
                })]).catch(function() {})
            } catch (e) {
                return
            }
            return d
        },
        mp = function() {
            if (!m.Promise) return !1;
            Ga(H.interestCohort) || lp || (lp = !0, bo("A489+ZNTpP/HCOD+k3I13nobRVH7eyh5fz5LGhYvQlNf9WauHk/0awCtXOEoWTIK9JN8bgzgn2SfPdaFXe5O9QkAAACKeyJvcmlnaW4iOiJodHRwczovL3d3dy5nb29nbGV0YWdtYW5hZ2VyLmNvbTo0NDMiLCJmZWF0dXJlIjoiSW50ZXJlc3RDb2hvcnRBUEkiLCJleHBpcnkiOjE2MjYyMjA3OTksImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9"));
            return Ga(H.interestCohort)
        },
        lp = !1,
        jp = Number("200");
    var op = function(a, b) {
            var c = a.Pg,
                d = a.ih;
            a.Ad && (Vk(c[R.Mb], !!c[R.O]) && nl(np, b), kl(b), ql(np, b), El(b));
            c[R.O] && pl(np, c[R.O], c[R.ic], !!c[R.Nb], b.prefix);
            d && sl(["aw", "dc", "gb"])
        },
        pp = function(a, b, c, d) {
            var e = a.kh,
                f = a.callback,
                g = a.Rg;
            if ("function" === typeof f)
                if (e === R.Xd && void 0 === g) {
                    var h = d(b.prefix, c);
                    0 === h.length ? f(void 0) : 1 === h.length ? f(h[0]) : f(h)
                } else e === R.Jh ? (Vg(65), jk(b, !1), f(gk[hk(b.prefix)])) : f(g)
        },
        np = ["aw", "dc", "gb"];
    var Mp = function() {
            if (!wh(R.C) || !Lp && !bo("A7pIQvxLYo3CR+raAuUI8Rfr81qhL4u1c7JIHkL6Clt5Jq0Xi/EH8+lTm0ZzKyi+618U2BxGlpKmCTclb793+AUAAACKeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXRhZ21hbmFnZXIuY29tOjQ0MyIsImZlYXR1cmUiOiJDb252ZXJzaW9uTWVhc3VyZW1lbnQiLCJleHBpcnkiOjE2MzQwODMxOTksImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9")) return !1;
            Lp = !0;
            if (nc("attribution-reporting") || nc("conversion-measurement")) return !0;
            return !1
        },
        Np = function(a) {
            return !(void 0 === a || null === a || 0 === (a + "").length)
        },
        Op = function(a, b) {
            var c;
            if (2 === b.Ra) return a("ord", Na(1E11, 1E13)), !0;
            if (3 === b.Ra) return a("ord", "1"), a("num", Na(1E11, 1E13)), !0;
            if (4 === b.Ra) return Np(b.sessionId) &&
                a("ord", b.sessionId), !0;
            if (5 === b.Ra) c = "1";
            else if (6 === b.Ra) c = b.zj;
            else return !1;
            Np(c) && a("qty", c);
            Np(b.yg) && a("cost", b.yg);
            Np(b.transactionId) && a("ord", b.transactionId);
            return !0
        },
        Tp = function(a, b) {
            function c(L, K, ba) {
                r.hasOwnProperty(L) || (K = String(K), u.push(";" + L + "=" + (ba ? K : Pp(K))))
            }

            function d(L, K) {
                K && c(L, K)
            }

            function e() {
                if (Np(a.Sg)) {
                    var L = a.Sg || "";
                    p || l || !a.Ha || (L = mj(L));
                    c("~oref", L)
                }
                var K = h + u.join("") + "?";
                g ? dc(K, a.onSuccess) : ec(K, a.onSuccess,
                    a.onFailure);
                O && ec("https://" + f + ".fls.doubleclick.net/activityi;register_conversion=1" + u.join("") + "?");
            }
            var f = a.Qi,
                g = a.Hj,
                h = a.protocol,
                l = a.$i,
                n = [],
                p = wh(R.C);
            h += g ? "//" + f + ".fls.doubleclick.net/activityi" : "//ad.doubleclick.net/activity";
            var q = ";",
                t = !1;
            t = !0;
            wh(R.C) ||
                l || !a.Ha && !t || (h = "https://ade.googlesyndication.com/ddm/activity", q = "/", g = !1);
            var u = [q, "src=" + Pp(f), ";type=" + Pp(a.Zi), ";cat=" + Pp(a.Ie)],
                r = a.Mi || {};
            Qa(r, function(L, K) {
                u.push(";" + Pp(L) + "=" + Pp(K + ""))
            });
            if (Op(c, a)) {
                Np(a.hh) && c("u", a.hh);
                Np(a.gh) && c("tran", a.gh);
                c("gtm", Wn());
                lh() && !l && (c("gcs", xh()), b && c("gcu", "1"));
                d("gdpr_consent", Ao()), d("gdpr", Co());
                "1" === Nk(!1)._up && c("gtm_up", "1");
                !1 === a.xi && c("npa", "1");
                if (a.Ad) {
                    var v =
                        void 0 === a.Ha ? !0 : !!a.Ha,
                        w = Bl(a.xb, v),
                        y = !1;
                    w && w.length && (c("gcldc", w.join(".")), y = !0);
                    var x = !0;
                    x = g;
                    if (x) {
                        var z = "_gcl" !== gl(a.xb);
                        if (Qp && !y && Fl(a.xb)) {
                            var B = xl("gb", a.xb, v);
                            B.length && c("gclgb", B.join("."));
                            if (!z || !Rp) {
                                var C = Dl(v);
                                C && c("gacgb", C)
                            }
                        } else {
                            var F = Al(a.xb, v);
                            F && F.length && (c("gclaw", F.join(".")), Vg(59));
                            var D = Cl(v);
                            D && (z ? (Vg(60), Rp || c("gac", D)) : c("gac", D))
                        }
                    }
                    jk({
                        prefix: a.xb,
                        kb: a.Ii,
                        domain: a.Hi,
                        flags: a.$j
                    });
                    var E = gk[hk(a.xb)];
                    E && c("auiddc", E)
                }
                Np(a.Wg) && c("prd", a.Wg, !0);
                Qa(a.Pj, function(L, K) {
                    c(L, K)
                });
                u.push("");
                Sp && (Np(a.Tb) && c("gdid", a.Tb), Np(a.Sb) && c("edid", a.Sb));
                var O = Mp();
                O && u.push(";ps=1");
                var M = !1;
                if (M && a.Ja) {
                    var N = di(a.Ja);
                    N && (N = N.then(function(L) {
                        Np(L.Kc) && c("em", L.Kc, !0)
                    }), n.push(N))
                }
                if (n.length) try {
                    Promise.all(n).then(function() {
                        e()
                    });
                    return
                } catch (L) {}
                e()
            } else I(a.onFailure)
        },
        Qp = !1;
    Qp = !0;
    var Rp = !1;
    var Sp = !1;
    var Pp = encodeURIComponent,
        Lp = !1,
        Up = function(a) {
            !lh() || a.$i ? Tp(a) : Bh(function() {
                Tp(a);
                wh(R.C) || Ah(function() {
                    Tp(a, !0)
                }, R.C)
            }, [R.C])
        };
    var Vp = function(a, b, c, d) {
            function e() {
                var f = {
                    config: a,
                    gtm: Wn()
                };
                c && (jk(d), f.auiddc = gk[hk(d.prefix)]);
                b && (f.loadInsecure = b);
                void 0 === m.__dc_ns_processor && (m.__dc_ns_processor = []);
                m.__dc_ns_processor.push(f);
                bc((b ? "http" : "https") + "://www.googletagmanager.com/dclk/ns/v1.js")
            }
            wh(R.C) ? e() : qh(e, R.C)
        },
        Wp = function(a) {
            var b = /^u([1-9]\d?|100)$/,
                c = a.getWithConfig(R.Kf) || {},
                d = oi(a),
                e = {},
                f = {};
            if (Gc(c))
                for (var g in c)
                    if (c.hasOwnProperty(g) && b.test(g)) {
                        var h = c[g];
                        k(h) && (e[g] = h)
                    }
            for (var l = 0; l < d.length; l++) {
                var n =
                    d[l];
                b.test(n) && (e[n] = n)
            }
            for (var p in e) e.hasOwnProperty(p) && (f[p] = a.getWithConfig(e[p]));
            return f
        },
        Xp = function(a, b) {
            function c(n, p, q) {
                void 0 !== q && 0 !== (q + "").length && e.push(n + p + ":" + d(q + ""))
            }
            var d = encodeURIComponent,
                e = [],
                f = a(R.X) || [];
            if (Ia(f))
                for (var g = 0; g < f.length; g++) {
                    var h = f[g],
                        l = g + 1;
                    c("i", l, h.id);
                    c("p", l, h.price);
                    c("q", l, h.quantity);
                    c("c", l, b ? h[R.bd] : a(R.bd));
                    c("l", l, b ? h[R.qb] : a(R.qb));
                    b && c("a", l, h.accountId)
                }
            return e.join("|")
        },
        Yp = function(a) {
            var b = /^DC-(\d+)(\/([\w-]+)\/([\w-]+)\+(\w+))?$/.exec(a);
            if (b) {
                var c = {
                    standard: 2,
                    unique: 3,
                    per_session: 4,
                    transactions: 5,
                    items_sold: 6,
                    "": 1
                }[(b[5] || "").toLowerCase()];
                if (c) return {
                    containerId: "DC-" + b[1],
                    U: b[3] ? a : "",
                    vi: b[1],
                    ui: b[3] || "",
                    Ie: b[4] || "",
                    Ra: c
                }
            }
        },
        $p = function(a, b, c, d) {
            var e = Yp(a);
            if (e) {
                var f = function(L) {
                        return d.getWithConfig(L)
                    },
                    g = !1 !== f(R.Ea),
                    h = f(R.Da) || f(R.na),
                    l = f(R.ma),
                    n = f(R.Fa),
                    p = f(R.Na),
                    q = {
                        prefix: h,
                        domain: l,
                        kb: n,
                        flags: p
                    },
                    t = f(R.Oh),
                    u = void 0 != f(R.V) && !1 !== f(R.V) && (!d.isGtmEvent || !wh(R.C)),
                    r = 3 === Xo();
                var B = {},
                    C = f(R.Nh);
                if (Gc(C))
                    for (var F in C)
                        if (C.hasOwnProperty(F)) {
                            var D =
                                C[F];
                            void 0 !== D && null !== D && (B[F] = D)
                        }
                var E = "";
                if (5 === e.Ra || 6 === e.Ra) E = Xp(f, d.isGtmEvent);
                var O = Wp(d),
                    M = !0 === f(R.Yd);
                if (Sn() && M) {
                    M = !1
                }
                var N = d.isGtmEvent ? "" : r ? "http:" : "https:",
                    P = {
                        Ie: e.Ie,
                        Ad: g,
                        Hi: l,
                        Ii: n,
                        xb: h,
                        yg: f(R.da),
                        Ra: e.Ra,
                        Mi: B,
                        Qi: e.vi,
                        Zi: e.ui,
                        onFailure: d.onFailure,
                        onSuccess: d.onSuccess,
                        Sg: d.isGtmEvent ? f("oref") : kj(lj(m.location.href)),
                        Wg: E,
                        protocol: N,
                        zj: f(R.Xf),
                        Hj: M,
                        sessionId: f(R.nc),
                        gh: d.isGtmEvent ? f("tran") : void 0,
                        transactionId: f(R.cb),
                        hh: d.isGtmEvent ? f("u") : void 0,
                        Ja: d.isGtmEvent ? f(R.xa) : void 0,
                        Pj: O,
                        xi: !1 !== f(R.Ca),
                        eventId: d.eventId,
                        Ha: u
                    };
                Zp && (P.Tb = lb(pi(d, R.ba, 1), "."), P.Sb = lb(pi(d, R.ba, 2), "."));
                Up(P)
            } else I(d.onFailure)
        },
        Zp = !1;
    var oq = function() {
            var a = !0;
            Do(7) && Do(9) && Do(10) || (a = !1);
            var b = !0;
            b = !1;
            b && !nq() && (a = !1);
            return a
        },
        nq = function() {
            var a = !0;
            Do(3) && Do(4) || (a = !1);
            return a
        };
    var sq = function(a, b) {},
        tq = function(a, b) {
            var c = a[R.ic];
            om(b + ".", a[R.O] || "", void 0 === c ? !!a.use_anchor : "fragment" === c, !!a[R.Nb])
        },
        xq = function(a, b, c) {
            if (lh() && (!c.isGtmEvent || !uq[a])) {
                var d = !wh(R.I),
                    e = function() {
                        var f, g, h = lm(),
                            l = vq(b, "", c),
                            n, p = l.ia._useUp;
                        if (c.isGtmEvent || wq(b, l.ia)) {
                            var q = !0;
                            if (c.isGtmEvent) {
                                f = "gtm" + Di();
                                g = l.ia;
                                l.gtmTrackerName && (g.name = f);
                                q = !1;
                                q = !0;
                            }
                            q && h(function() {
                                var u = h.getByName(b);
                                u && (n = u.get("clientId"));
                                c.isGtmEvent || h.remove(b)
                            });
                            h("create", a, c.isGtmEvent ? g : l.ia);
                            d && wh(R.I) && (d = !1, h(function() {
                                var u = lm().getByName(c.isGtmEvent ? f : b);
                                !u || u.get("clientId") == n && p || (c.isGtmEvent ? l.Bc["&gcu"] = "1" : l.ja["&gcu"] = "1", u.set(l.Bc), c.isGtmEvent ? u.send("pageview") : u.send("pageview", l.ja))
                            }));
                            c.isGtmEvent && h(function() {
                                h.remove(f)
                            })
                        }
                    };
                qh(e, R.I);
                qh(e, R.C);
                c.isGtmEvent &&
                    (uq[a] = !0)
            }
        },
        Gq = function(a, b, c) {
            function d() {
                var O = c.getWithConfig("custom_map");
                h(function() {
                    if (!c.isGtmEvent && Gc(O)) {
                        var M = r.ja,
                            N = l().getByName(n),
                            P;
                        for (P in O)
                            if (O.hasOwnProperty(P) && /^(dimension|metric)\d+$/.test(P) && void 0 != O[P]) {
                                var L = N.get(rq(O[P]));
                                yq(M, P, L)
                            }
                    }
                })
            }

            function e() {
                if (r.displayfeatures) {
                    var O = "_dc_gtm_" + f.replace(/[^A-Za-z0-9-]/g, "");
                    p("require", "displayfeatures", void 0, {
                        cookieName: O
                    })
                }
            }
            var f = a,
                g = "https://www.google-analytics.com/analytics.js",
                h = c.isGtmEvent ? nm(c.getWithConfig("gaFunctionName")) :
                nm();
            if (Ga(h)) {
                var l = lm,
                    n;
                c.isGtmEvent ? n = c.getWithConfig("name") || c.getWithConfig("gtmTrackerName") : n = "gtag_" + f.split("-").join("_");
                var p = function(O) {
                        var M = [].slice.call(arguments, 0);
                        M[0] = n ? n + "." + M[0] : "" + M[0];
                        h.apply(window, M)
                    },
                    q = function(O) {
                        var M = function(X, fa) {
                                for (var V = 0; fa && V < fa.length; V++) p(X, fa[V])
                            },
                            N = c.isGtmEvent,
                            P = N ? zq(r) : Aq(b, c);
                        if (P) {
                            var L = {};
                            Rn() && O && (L._x_19 = O);
                            p("require", "ec", "ec.js", L);
                            N && P.Pe && p("set", "&cu", P.Pe);
                            var K = P.action;
                            if (N || "impressions" === K)
                                if (M("ec:addImpression", P.Mg), !N) return;
                            if ("promo_click" === K || "promo_view" === K || N && P.Nc) {
                                var ba = P.Nc;
                                M("ec:addPromo", ba);
                                if (ba && 0 < ba.length && "promo_click" === K) {
                                    N ? p("ec:setAction", K, P.fb) : p("ec:setAction", K);
                                    return
                                }
                                if (!N) return
                            }
                            "promo_view" !== K && "impressions" !== K && (M("ec:addProduct", P.Ab), p("ec:setAction", K, P.fb))
                        }
                    },
                    t = function(O) {
                        if (O) {
                            var M = {};
                            if (Gc(O))
                                for (var N in Bq) Bq.hasOwnProperty(N) && Cq(Bq[N], N, O[N], M);
                            p("require", "linkid", M)
                        }
                    },
                    u = function() {
                        if (Sn()) {} else {
                            var O =
                                c.getWithConfig(R.Wh);
                            O && (p("require", O, {
                                dataLayer: "dataLayer"
                            }), p("require", "render"))
                        }
                    },
                    r = vq(n, b, c),
                    v = function(O, M, N) {
                        N && (M = "" + M);
                        r.ja[O] = M
                    };
                !c.isGtmEvent && wq(n, r.ia) && (h(function() {
                    l() && l().remove(n)
                }), Dq[n] = !1);
                h("create", f, r.ia);
                if (r.ia._x_19 && !c.isGtmEvent) {
                    var w = Pn(r.ia._x_19, "/analytics.js");
                    w && (g = w)
                }
                if (c.isGtmEvent ? r.Bc._x_19 : r.ia._x_19) {
                    var y = c.isGtmEvent ? r.Bc._x_20 : r.ia._x_20;
                    y && !Dq[n] && (Dq[n] = !0, h(sm(n, y)))
                }
                c.isGtmEvent ? r.enableRecaptcha && p("require", "recaptcha", "recaptcha.js") : (d(),
                    t(r.linkAttribution));
                var x = r[R.oa];
                x && x[R.O] && tq(x, n);
                p("set", r.Bc);
                c.isGtmEvent && r.enableLinkId && p("require", "linkid", "linkid.js");
                c.isGtmEvent && lh() && xq(f, n, c);
                var z = r.ia._x_19 ? r.ia._x_19 : void 0;
                if (b === R.ac)
                    if (c.isGtmEvent) {
                        e();
                        if (r.remarketingLists) {
                            var B = "_dc_gtm_" + f.replace(/[^A-Za-z0-9-]/g, "");
                            p("require", "adfeatures", {
                                cookieName: B
                            })
                        }
                        q(z);
                        p("send", "pageview");
                        r.ia._useUp && pm(n + ".")
                    } else u(), p("send", "pageview", r.ja);
                else b === R.Ba ? (u(), ip(f, c), c.getWithConfig(R.eb) && (sl(["aw", "dc"]), pm(n + ".")),
                    0 != r.sendPageView && p("send", "pageview", r.ja), xq(f, n, c)) : b === R.Ma ? sq(n, c) : "screen_view" === b ? p("send", "screenview", r.ja) : "timing_complete" === b ? (r.ja.hitType = "timing", v("timingCategory", r.eventCategory, !0), c.isGtmEvent ? v("timingVar", r.timingVar, !0) : v("timingVar", r.name, !0), v("timingValue", Ua(r.value)), void 0 !== r.eventLabel && v("timingLabel", r.eventLabel, !0), p("send", r.ja)) : "exception" === b ? p("send", "exception", r.ja) : "optimize.callback" === b || "" === b && c.isGtmEvent || ("track_social" === b && c.isGtmEvent ? (r.ja.hitType =
                    "social", v("socialNetwork", r.socialNetwork, !0), v("socialAction", r.socialAction, !0), v("socialTarget", r.socialTarget, !0)) : ((c.isGtmEvent || Eq[b]) && q(z), c.isGtmEvent && e(), r.ja.hitType = "event", v("eventCategory", r.eventCategory, !0), v("eventAction", r.eventAction || b, !0), void 0 !== r.eventLabel && v("eventLabel", r.eventLabel, !0), void 0 !== r.value && v("eventValue", Ua(r.value))), p("send", r.ja));
                var C = !1;
                var F = Fq;
                C && (F = c.getContainerTypeLoaded("UA"));
                if (!F && !c.isGtmEvent) {
                    Fq = !0;
                    C && c.setContainerTypeLoaded("UA", !0);
                    gm();
                    var D = function() {
                            C && c.setContainerTypeLoaded("UA", !1);
                            c.onFailure()
                        },
                        E = function() {
                            l().loaded || D()
                        };
                    Sn() ? I(E) : bc(g, E, D)
                }
            } else I(c.onFailure)
        },
        Hq = function(a, b, c, d) {
            Bh(function() {
                Gq(a, b, d)
            }, [R.I, R.C])
        },
        Jq = function(a, b) {
            function c(f) {
                function g(p, q) {
                    for (var t = 0; t < q.length; t++) {
                        var u = q[t];
                        if (f[u]) {
                            l[p] = f[u];
                            break
                        }
                    }
                }

                function h() {
                    if (f.category) l.category = f.category;
                    else {
                        for (var p = "", q = 0; q <
                            Iq.length; q++) void 0 !== f[Iq[q]] && (p && (p += "/"), p += f[Iq[q]]);
                        p && (l.category = p)
                    }
                }
                var l = J(f),
                    n = !1;
                if (n || b) g("id", ["id", "item_id", "promotion_id"]), g("name", ["name", "item_name", "promotion_name"]), g("brand", ["brand", "item_brand"]), g("variant", ["variant", "item_variant"]), g("list", ["list_name", "item_list_name"]), g("position", ["list_position", "creative_slot", "index"]),
                    h();
                g("listPosition", ["list_position"]);
                g("creative", ["creative_name"]);
                g("list", ["list_name"]);
                g("position", ["list_position", "creative_slot"]);
                return l
            }
            b = void 0 === b ? !1 : b;
            for (var d = [], e = 0; a && e < a.length; e++) a[e] && Gc(a[e]) && d.push(c(a[e]));
            return d.length ? d : void 0
        },
        Kq = function(a) {
            return wh(a)
        },
        Lq = !1;
    var Mq = !1;
    var Fq, Dq = {},
        uq = {},
        pq = Object.freeze({
            client_id: 1,
            client_storage: "storage",
            conversion_linker: "storeGac",
            cookie_domain: 1,
            cookie_expires: 1,
            cookie_flags: 1,
            cookie_name: 1,
            cookie_path: 1,
            cookie_update: 1,
            sample_rate: 1,
            site_speed_sample_rate: 1,
            store_gac: 1,
            use_amp_client_id: 1
        }),
        Nq = Object.freeze({
            _cd2l: 1,
            _cs: 1,
            _useUp: 1,
            allowAnchor: 1,
            allowLinker: 1,
            alwaysSendReferrer: 1,
            clientId: 1,
            cookieDomain: 1,
            cookieExpires: 1,
            cookieFlags: 1,
            cookieName: 1,
            cookiePath: 1,
            cookieUpdate: 1,
            legacyCookieDomain: 1,
            legacyHistoryImport: 1,
            name: 1,
            sampleRate: 1,
            siteSpeedSampleRate: 1,
            storage: 1,
            storeGac: 1,
            useAmpClientId: 1
        }),
        Oq = {
            anonymize_ip: 1
        },
        qq = Object.freeze({
            campaign: {
                content: "campaignContent",
                id: "campaignId",
                medium: "campaignMedium",
                name: "campaignName",
                source: "campaignSource",
                term: "campaignKeyword"
            },
            app_id: 1,
            app_installer_id: 1,
            app_name: 1,
            app_version: 1,
            currency: "currencyCode",
            description: "exDescription",
            fatal: "exFatal",
            language: 1,
            non_interaction: 1,
            page_hostname: "hostname",
            page_location: "location",
            page_path: "page",
            page_referrer: "referrer",
            page_title: "title",
            screen_name: 1,
            transport_type: "transport",
            user_id: 1
        }),
        Pq = Object.freeze({
            content_id: 1,
            event_action: 1,
            event_category: 1,
            event_label: 1,
            link_attribution: 1,
            linker: 1,
            method: 1,
            name: 1,
            send_page_view: 1,
            value: 1
        }),
        Qq = Object.freeze({
            displayfeatures: 1,
            enableLinkId: 1,
            enableRecaptcha: 1,
            eventAction: 1,
            eventCategory: 1,
            eventLabel: 1,
            gaFunctionName: 1,
            gtmEcommerceData: 1,
            gtmTrackerName: 1,
            linker: 1,
            remarketingLists: 1,
            socialAction: 1,
            socialNetwork: 1,
            socialTarget: 1,
            timingVar: 1,
            value: 1
        }),
        Iq = Object.freeze(["item_category", "item_category2",
            "item_category3", "item_category4", "item_category5"
        ]),
        Bq = Object.freeze({
            cookie_expires: "duration",
            cookie_name: 1,
            levels: 1
        }),
        Rq = Object.freeze({
            anonymize_ip: 1,
            conversion_linker: 1,
            fatal: 1,
            non_interaction: 1,
            send_page_view: 1,
            store_gac: 1,
            use_amp_client_id: 1
        }),
        Cq = function(a, b, c, d) {
            if (void 0 !== c)
                if (Rq[b] && (c = Va(c)), "anonymize_ip" !== b || c || (c = void 0), 1 === a) d[rq(b)] = c;
                else if (k(a)) d[a] = c;
            else
                for (var e in a) a.hasOwnProperty(e) && void 0 !== c[e] && (d[a[e]] = c[e])
        },
        rq = function(a) {
            return a && k(a) ? a.replace(/(_[a-z])/g,
                function(b) {
                    return b[1].toUpperCase()
                }) : a
        },
        Sq = {},
        Eq = Object.freeze((Sq.checkout_progress = 1, Sq.select_content = 1, Sq.set_checkout_option = 1, Sq[R.Gb] = 1, Sq[R.Hb] = 1, Sq[R.mb] = 1, Sq[R.Ya] = 1, Sq[R.nb] = 1, Sq[R.va] = 1, Sq[R.Ib] = 1, Sq[R.wa] = 1, Sq)),
        Tq = {},
        Uq = Object.freeze((Tq.checkout_progress = 1, Tq.set_checkout_option = 1, Tq[R.Bf] = 1, Tq[R.Gb] = 1, Tq[R.Hb] = 1, Tq[R.mb] = 1, Tq[R.va] = 1, Tq[R.Ib] = 1, Tq[R.Cf] = 1, Tq)),
        Vq = {},
        Wq = Object.freeze((Vq.generate_lead = 1, Vq.login = 1, Vq.search = 1, Vq.select_content = 1, Vq.share = 1, Vq.sign_up = 1, Vq.view_search_results =
            1, Vq[R.Ya] = 1, Vq[R.nb] = 1, Vq[R.wa] = 1, Vq)),
        Xq = function(a) {
            var b = "general";
            Uq[a] ? b = "ecommerce" : Wq[a] ? b = "engagement" : "exception" === a && (b = "error");
            return b
        },
        Yq = {},
        Zq = Object.freeze((Yq.view_search_results = 1, Yq[R.Ya] = 1, Yq[R.nb] = 1, Yq[R.wa] = 1, Yq)),
        yq = function(a, b, c) {
            a.hasOwnProperty(b) || (a[b] = c)
        },
        $q = function(a) {
            if (Ia(a)) {
                for (var b = [], c = 0; c < a.length; c++) {
                    var d = a[c];
                    if (void 0 != d) {
                        var e = d.id,
                            f = d.variant;
                        void 0 != e && void 0 != f && b.push(String(e) + "." + String(f))
                    }
                }
                return 0 < b.length ? b.join("!") : void 0
            }
        },
        vq = function(a,
            b, c) {
            function d(N, P) {
                void 0 !== P && (h[N] = P)
            }
            var e = function(N) {
                    return c.getWithConfig(N)
                },
                f = {},
                g = {},
                h = {},
                l = {},
                n = $q(e(R.Sh));
            !c.isGtmEvent && n && yq(g, "exp", n);
            h["&gtm"] = Wn(!0);
            lh() && (l._cs = Kq);
            var p = e("custom_map");
            if (!c.isGtmEvent && Gc(p))
                for (var q in p)
                    if (p.hasOwnProperty(q) && /^(dimension|metric)\d+$/.test(q) && void 0 != p[q]) {
                        var t = e(String(p[q]));
                        void 0 !== t && yq(g, q, t)
                    }
            for (var u = oi(c), r = 0; r < u.length; ++r) {
                var v = u[r];
                if (c.isGtmEvent) {
                    var w = e(v);
                    Qq.hasOwnProperty(v) ? f[v] = w : Nq.hasOwnProperty(v) ? l[v] = w : "currencyCode" !=
                        v && (h[v] = w)
                } else {
                    var y = void 0;
                    y = v !== R.ba ? e(v) : pi(c, v);
                    if (Pq.hasOwnProperty(v)) Cq(Pq[v], v, y, f);
                    else if (Oq.hasOwnProperty(v)) Cq(Oq[v], v, y, h);
                    else if (qq.hasOwnProperty(v)) Cq(qq[v], v, y, g);
                    else if (pq.hasOwnProperty(v)) Cq(pq[v], v, y, l);
                    else if (/^(dimension|metric|content_group)\d+$/.test(v)) Cq(1, v, y, g);
                    else if (v === R.ba) {
                        if (!Lq) {
                            var x = lb(y);
                            x && (g["&did"] = x)
                        }
                        if (Mq) {
                            var z = lb(pi(c, v, 1), ".");
                            z && (g["&gdid"] = z);
                            var B = lb(pi(c, v, 2), ".");
                            B && (g["&edid"] = B)
                        }
                    } else v === R.na && 0 > Ja(u, R.ad) && (l.cookieName = y + "_ga")
                }
            }!1 !==
                e(R.Ih) && !1 !== e(R.bc) && oq() || (h.allowAdFeatures = !1);
            if (!1 === e(R.Ca) || !nq()) {
                var C = c.isGtmEvent ? "allowAdPersonalizationSignals" : "allowAdFeatures";
                C = "allowAdPersonalizationSignals";
                h[C] = !1
            }!c.isGtmEvent && e(R.eb) && (l._useUp = !0);
            if (c.isGtmEvent) {
                l.name = l.name || f.gtmTrackerName;
                var F = h.hitCallback;
                h.hitCallback = function() {
                    Ga(F) && F();
                    c.onSuccess()
                }
            } else {
                yq(l, "cookieDomain", "auto");
                yq(h, "forceSSL", !0);
                yq(f,
                    "eventCategory", Xq(b));
                Zq[b] && yq(g, "nonInteraction", !0);
                "login" === b || "sign_up" === b || "share" === b ? yq(f, "eventLabel", e(R.Vh)) : "search" === b || "view_search_results" === b ? yq(f, "eventLabel", e(R.ai)) : "select_content" === b && yq(f, "eventLabel", e(R.Mh));
                var D = f[R.oa] || {},
                    E = D[R.Mb];
                E || 0 != E && D[R.O] ? l.allowLinker = !0 : !1 === E && yq(l, "useAmpClientId", !1);
                g.hitCallback = c.onSuccess;
                l.name = a
            }
            lh() && (h["&gcs"] = xh(), wh(R.I) || (l.storage = "none"), wh(R.C) || (h.allowAdFeatures = !1, l.storeGac = !1));
            var O = e(R.qa) || e(R.Uh),
                M = e(R.Th);
            if (O) {
                c.isGtmEvent || (l._x_19 = O);
                l._cd2l = !0;
            }
            M &&
                !c.isGtmEvent && (l._x_20 = M);
            f.ja = g;
            f.Bc = h;
            f.ia = l;
            return f
        },
        zq = function(a) {
            var b = a.gtmEcommerceData;
            if (!b) return null;
            var c = {};
            b.currencyCode && (c.Pe = b.currencyCode);
            if (b.impressions) {
                c.action = "impressions";
                var d = b.impressions;
                c.Mg = "impressions" === b.translateIfKeyEquals ? Jq(d, !0) : d
            }
            if (b.promoView) {
                c.action = "promo_view";
                var e = b.promoView.promotions;
                c.Nc = "promoView" === b.translateIfKeyEquals ? Jq(e, !0) : e
            }
            if (b.promoClick) {
                c.action = "promo_click";
                var f = b.promoClick.promotions;
                c.Nc = "promoClick" === b.translateIfKeyEquals ?
                    Jq(f, !0) : f;
                c.fb = b.promoClick.actionField;
                return c
            }
            for (var g in b)
                if (b.hasOwnProperty(g) && "translateIfKeyEquals" !== g && "impressions" !== g && "promoView" !== g && "promoClick" !== g && "currencyCode" !== g) {
                    c.action = g;
                    var h = b[g].products;
                    c.Ab = "products" === b.translateIfKeyEquals ? Jq(h, !0) : h;
                    c.fb = b[g].actionField;
                    break
                }
            return Object.keys(c).length ? c : null
        },
        Aq = function(a, b) {
            function c(u) {
                return {
                    id: d(R.cb),
                    affiliation: d(R.Ph),
                    revenue: d(R.da),
                    tax: d(R.Of),
                    shipping: d(R.he),
                    coupon: d(R.Qh),
                    list: d(R.fe) || u
                }
            }
            for (var d = function(u) {
                        return b.getWithConfig(u)
                    },
                    e = d(R.X), f, g = 0; e && g < e.length && !(f = e[g][R.fe]); g++);
            var h = d("custom_map");
            if (Gc(h))
                for (var l = 0; e && l < e.length; ++l) {
                    var n = e[l],
                        p;
                    for (p in h) h.hasOwnProperty(p) && /^(dimension|metric)\d+$/.test(p) && void 0 != h[p] && yq(n, p, n[h[p]])
                }
            var q = null,
                t = d(R.Rh);
            a === R.va || a === R.Ib ? q = {
                    action: a,
                    fb: c(),
                    Ab: Jq(e)
                } : a === R.Gb ? q = {
                    action: "add",
                    Ab: Jq(e)
                } : a === R.Hb ? q = {
                    action: "remove",
                    Ab: Jq(e)
                } : a === R.wa ? q = {
                    action: "detail",
                    fb: c(f),
                    Ab: Jq(e)
                } : a === R.Ya ? q = {
                    action: "impressions",
                    Mg: Jq(e)
                } : "view_promotion" === a ? q = {
                    action: "promo_view",
                    Nc: Jq(t)
                } :
                "select_content" === a && t && 0 < t.length ? q = {
                    action: "promo_click",
                    Nc: Jq(t)
                } : "select_content" === a ? q = {
                    action: "click",
                    fb: {
                        list: d(R.fe) || f
                    },
                    Ab: Jq(e)
                } : a === R.mb || "checkout_progress" === a ? q = {
                    action: "checkout",
                    Ab: Jq(e),
                    fb: {
                        step: a === R.mb ? 1 : d(R.Nf),
                        option: d(R.Mf)
                    }
                } : "set_checkout_option" === a && (q = {
                    action: "checkout_option",
                    fb: {
                        step: d(R.Nf),
                        option: d(R.Mf)
                    }
                });
            q && (q.Pe = d(R.ca));
            return q
        },
        ar = {},
        wq = function(a, b) {
            var c = ar[a];
            ar[a] = J(b);
            if (!c) return !1;
            for (var d in b)
                if (b.hasOwnProperty(d) && b[d] !== c[d]) return !0;
            for (var e in c)
                if (c.hasOwnProperty(e) &&
                    c[e] !== b[e]) return !0;
            return !1
        };
    var br = !1;
    br = !0;

    function cr() {
        var a = S;
        return a.gcq = a.gcq || new dr
    }
    var er = function(a, b, c) {
            cr().register(a, b, c)
        },
        fr = function(a, b, c, d) {
            cr().push("event", [b, a], c, d)
        },
        gr = function(a, b) {
            cr().push("config", [a], b)
        },
        hr = function(a, b, c, d) {
            cr().push("get", [a, b], c, d)
        },
        ir = function(a) {
            return cr().getRemoteConfig(a)
        },
        jr = {},
        kr = function() {
            this.status = 1;
            this.containerConfig = {};
            this.targetConfig = {};
            this.remoteConfig = {};
            this.o = {};
            this.s = null;
            this.g = !1
        },
        lr = function(a, b, c, d, e) {
            this.type = a;
            this.s = b;
            this.U = c || "";
            this.g = d;
            this.o = e
        },
        dr = function() {
            this.o = {};
            this.s = {};
            this.g = [];
            this.D = {
                AW: !1,
                UA: !1
            }
        },
        mr = function(a, b) {
            var c = Uo(b);
            return a.o[c.containerId] = a.o[c.containerId] || new kr
        },
        nr = function(a, b, c) {
            if (b) {
                var d = Uo(b);
                if (d && 1 === mr(a, b).status) {
                    mr(a, b).status = 2;
                    var e = {};
                    dn && (e.timeoutId = m.setTimeout(function() {
                        Vg(38);
                        Km()
                    }, 3E3));
                    a.push("require", [e], d.containerId);
                    jr[d.containerId] = cb();
                    if (Sn()) {} else {
                        var g = "/gtag/js?id=" + encodeURIComponent(d.containerId) + "&l=dataLayer&cx=c";
                        Rn() && (g += "&sign=" + tf.ud);
                        var h = ("http:" != m.location.protocol ? "https:" : "http:") + ("//www.googletagmanager.com" + g),
                            l = Pn(c, g) || h;
                        bc(l)
                    }
                }
            }
        },
        or = function(a, b, c, d) {
            if (d.U) {
                var e = mr(a, d.U),
                    f = e.s;
                if (f) {
                    var g = J(c),
                        h = J(e.targetConfig[d.U]),
                        l = J(e.containerConfig),
                        n = J(e.remoteConfig),
                        p = J(a.s),
                        q = Ki("gtm.uniqueEventId"),
                        t = Uo(d.U).prefix,
                        u = eb(function() {
                            var v = g[R.Kb];
                            v && I(v)
                        }),
                        r = mi(li(ni(ki(ii(ji(hi(gi(fi(g), h), l), n), p), function() {
                            rn(q, t, "2");
                            br && u()
                        }), function() {
                            rn(q, t, "3");
                            br && u()
                        }), function(v, w) {
                            a.D[v] = w
                        }), function(v) {
                            return a.D[v]
                        });
                    try {
                        rn(q, t, "1");
                        f(d.U, b, d.s, r)
                    } catch (v) {
                        rn(q, t, "4");
                    }
                }
            }
        };
    dr.prototype.register = function(a, b, c) {
        var d = mr(this, a);
        if (3 !== d.status) {
            d.s = b;
            d.status = 3;
            c && (J(d.remoteConfig, c), d.remoteConfig = c);
            var e = Uo(a),
                f = jr[e.containerId];
            if (void 0 !== f) {
                var g = S[e.containerId].bootstrap,
                    h = e.prefix.toUpperCase();
                S[e.containerId]._spx && (h = h.toLowerCase());
                var l = Ki("gtm.uniqueEventId"),
                    n = h,
                    p = cb() - g;
                if (dn && !Pm[l]) {
                    l !== Lm && (Gm(), Lm = l);
                    var q = n + "." + Math.floor(g - f) + "." + Math.floor(p);
                    Tm = Tm ? Tm + "," + q : "&cl=" + q
                }
                delete jr[e.containerId]
            }
            this.flush()
        }
    };
    dr.prototype.push = function(a, b, c, d) {
        var e = Math.floor(cb() / 1E3);
        nr(this, c, b[0][R.qa] || this.s[R.qa]);
        c && mr(this, c).g && (d = !1);
        this.g.push(new lr(a, e, c, b, d));
        d || this.flush()
    };
    dr.prototype.insert = function(a, b, c) {
        var d = Math.floor(cb() / 1E3);
        0 < this.g.length ? this.g.splice(1, 0, new lr(a, d, c, b, !1)) : this.g.push(new lr(a, d, c, b, !1))
    };
    dr.prototype.flush = function(a) {
        for (var b = this, c = [], d = !1, e = {}; this.g.length;) {
            var f = this.g[0];
            if (f.o) !f.U || mr(this, f.U).g ? (f.o = !1, this.g.push(f)) : c.push(f), this.g.shift();
            else {
                switch (f.type) {
                    case "require":
                        if (3 !== mr(this, f.U).status && !a) {
                            this.g.push.apply(this.g, c);
                            return
                        }
                        dn && m.clearTimeout(f.g[0].timeoutId);
                        break;
                    case "set":
                        Qa(f.g[0], function(t, u) {
                            J(jb(t, u), b.s)
                        });
                        break;
                    case "config":
                        e.Ka = {};
                        Qa(f.g[0], function(t) {
                            return function(u, r) {
                                J(jb(u, r), t.Ka)
                            }
                        }(e));
                        var g = !!e.Ka[R.kd];
                        delete e.Ka[R.kd];
                        var h =
                            mr(this, f.U),
                            l = Uo(f.U),
                            n = l.containerId === l.id;
                        g || (n ? h.containerConfig = {} : h.targetConfig[f.U] = {});
                        h.g && g || or(this, R.Ba, e.Ka, f);
                        h.g = !0;
                        delete e.Ka[R.qc];
                        n ? J(e.Ka, h.containerConfig) : J(e.Ka, h.targetConfig[f.U]);
                        d = !0;
                        break;
                    case "event":
                        e.Uc = {};
                        Qa(f.g[0], function(t) {
                            return function(u, r) {
                                J(jb(u, r), t.Uc)
                            }
                        }(e));
                        or(this, f.g[1], e.Uc, f);
                        break;
                    case "get":
                        var p = {},
                            q = (p[R.Oa] = f.g[0], p[R.Za] = f.g[1], p);
                        or(this, R.Ma, q, f)
                }
                this.g.shift();
                pr(this, f)
            }
            e = {
                Ka: e.Ka,
                Uc: e.Uc
            }
        }
        this.g.push.apply(this.g, c);
        d && this.flush()
    };
    var pr = function(a, b) {
        if ("require" !== b.type)
            if (b.U)
                for (var c = a.getCommandListeners(b.U)[b.type] || [], d = 0; d < c.length; d++) c[d]();
            else
                for (var e in a.o)
                    if (a.o.hasOwnProperty(e)) {
                        var f = a.o[e];
                        if (f && f.o)
                            for (var g = f.o[b.type] || [], h = 0; h < g.length; h++) g[h]()
                    }
    };
    dr.prototype.getRemoteConfig = function(a) {
        return mr(this, a).remoteConfig
    };
    dr.prototype.getCommandListeners = function(a) {
        return mr(this, a).o
    };

    function qr(a, b) {
        var c = this;
    };

    function rr(a, b, c) {};

    function sr(a, b, c, d) {};

    function tr(a) {};
    var ur = function(a, b, c) {
            var d = {
                event: b,
                "gtm.element": a,
                "gtm.elementClasses": mc(a, "className"),
                "gtm.elementId": a["for"] || hc(a, "id") || "",
                "gtm.elementTarget": a.formTarget || mc(a, "target") || ""
            };
            c && (d["gtm.triggers"] = c.join(","));
            d["gtm.elementUrl"] = (a.attributes && a.attributes.formaction ? a.formAction : "") || a.action || mc(a, "href") || a.src || a.code || a.codebase || "";
            return d
        },
        vr = function(a) {
            S.hasOwnProperty("autoEventsSettings") || (S.autoEventsSettings = {});
            var b = S.autoEventsSettings;
            b.hasOwnProperty(a) || (b[a] = {});
            return b[a]
        },
        wr = function(a, b, c) {
            vr(a)[b] = c
        },
        xr = function(a, b, c, d) {
            var e = vr(a),
                f = db(e, b, d);
            e[b] = c(f)
        },
        yr = function(a, b, c) {
            var d = vr(a);
            return db(d, b, c)
        };

    function Hr(a) {};
    var Ir = {},
        Jr = [],
        Kr = {},
        Lr = 0,
        Mr = 0;

    function Tr(a, b) {}

    function $r(a, b) {};

    function es(a) {};
    var fs = {},
        gs = [];
    var ns = function(a, b) {};

    function us(a, b) {};
    var vs = /^\s*$/,
        ws, xs = !1;

    function Is(a, b) {}

    function Js(a, b, c) {};
    var Os = ["www.youtube.com", "www.youtube-nocookie.com"],
        Ps, Qs = !1,
        Rs = 0;

    function at(a, b) {}

    function bt(a, b) {
        return !0
    };

    function ct(a, b, c) {};

    function dt(a, b) {
        var c;
        return c
    };

    function et(a) {};

    function ft(a) {};
    var gt = !1,
        ht = [];

    function it() {
        if (!gt) {
            gt = !0;
            for (var a = 0; a < ht.length; a++) I(ht[a])
        }
    }
    var jt = function(a) {
        gt ? I(a) : ht.push(a)
    };

    function kt(a) {
        Q(G(this), ["listener:!Fn"], arguments);
        vg(this, "process_dom_events", "window", "load");
        jt(Ic(a))
    };

    function lt(a) {
        var b;
        return b
    };

    function mt(a, b) {
        var c;
        var d = !1;
        var e = Hc(c, this.g, d);
        void 0 === e && void 0 !== c && Vg(45);
        return e
    };

    function nt(a) {
        var b;
        return b
    };

    function ot(a, b) {
        var c = null,
            d = !1;
        Q(G(this), ["functionPath:!string", "arrayPath:!string"], arguments);
        vg(this, "access_globals", "readwrite", a);
        vg(this, "access_globals", "readwrite", b);
        var e = [m, H],
            f = a.split("."),
            g = ib(f, e),
            h = f[f.length - 1];
        if (void 0 === g) throw Error("Path " + a + " does not exist.");
        var l = g[h];
        if (l && !Ga(l)) return null;
        if (l) return Hc(l, this.g, d);
        var n;
        l = function() {
            if (!Ga(n.push)) throw Error("Object at " + b + " in window is not an array.");
            n.push.call(n, arguments)
        };
        g[h] = l;
        var p = b.split("."),
            q = ib(p, e),
            t = p[p.length - 1];
        if (void 0 === q) throw Error("Path " + p + " does not exist.");
        n = q[t];
        void 0 === n && (n = [], q[t] = n);
        c = function() {
            l.apply(l, Array.prototype.slice.call(arguments, 0))
        };
        return Hc(c, this.g, d)
    };

    function pt(a) {
        var b;
        Q(G(this), ["path:!string"], arguments);
        vg(this, "access_globals", "readwrite", a);
        var c = a.split("."),
            d = ib(c, [m, H]),
            e = c[c.length - 1];
        if (void 0 === d) throw Error("Path " + a + " does not exist.");
        var f = d[e];
        void 0 === f && (f = [], d[e] = f);
        b = function() {
            if (!Ga(f.push)) throw Error("Object at " + a + " in window is not an array.");
            f.push.apply(f, Array.prototype.slice.call(arguments, 0))
        };
        var g = !1;
        return Hc(b, this.g, g)
    };

    function qt(a, b) {
        a = String(a);
        b = String(b);
        var c = a.length - b.length;
        return 0 <= c && a.indexOf(b, c) == c
    }
    var rt = new Oa;

    function st(a, b, c) {
        var d = c ? "i" : void 0;
        try {
            var e = String(b) + d,
                f = rt.get(e);
            f || (f = new RegExp(b, d), rt.set(e, f));
            return f.test(a)
        } catch (g) {
            return !1
        }
    }

    function tt(a, b) {
        function c(g) {
            var h = lj(g),
                l = jj(h, "protocol"),
                n = jj(h, "host", !0),
                p = jj(h, "port"),
                q = jj(h, "path").toLowerCase().replace(/\/$/, "");
            if (void 0 === l || "http" == l && "80" == p || "https" == l && "443" == p) l = "web", p = "default";
            return [l, n, p, q]
        }
        for (var d = c(String(a)), e = c(String(b)), f = 0; f < d.length; f++)
            if (d[f] !== e[f]) return !1;
        return !0
    }

    function ut(a) {
        return vt(a) ? 1 : 0
    }

    function vt(a) {
        var b = a.arg0,
            c = a.arg1;
        if (a.any_of && Ia(c)) {
            for (var d = 0; d < c.length; d++) {
                var e = J(a, {});
                J({
                    arg1: c[d],
                    any_of: void 0
                }, e);
                if (ut(e)) return !0
            }
            return !1
        }
        switch (a["function"]) {
            case "_cn":
                return 0 <= String(b).indexOf(String(c));
            case "_css":
                var f;
                a: {
                    if (b) {
                        var g = ["matches", "webkitMatchesSelector", "mozMatchesSelector", "msMatchesSelector", "oMatchesSelector"];
                        try {
                            for (var h = 0; h < g.length; h++)
                                if (b[g[h]]) {
                                    f = b[g[h]](c);
                                    break a
                                }
                        } catch (n) {}
                    }
                    f = !1
                }
                return f;
            case "_ew":
                return qt(b, c);
            case "_eq":
                return String(b) ==
                    String(c);
            case "_ge":
                return Number(b) >= Number(c);
            case "_gt":
                return Number(b) > Number(c);
            case "_lc":
                var l;
                l = String(b).split(",");
                return 0 <= Ja(l, String(c));
            case "_le":
                return Number(b) <= Number(c);
            case "_lt":
                return Number(b) < Number(c);
            case "_re":
                return st(b, c, a.ignore_case);
            case "_sw":
                return 0 == String(b).indexOf(String(c));
            case "_um":
                return tt(b, c)
        }
        return !1
    };

    function wt(a) {
        return !1
    }
    var xt;

    function yt(a) {
        var b = !1;
        return b
    };
    var zt = function(a) {
        var b;
        return b
    };

    function At(a, b) {
        b = void 0 === b ? !0 : b;
        var c;
        return c
    };

    function Bt() {
        var a = [];
        return Hc(a)
    };

    function Ct(a) {
        var b = null;
        return b
    };

    function Dt(a, b) {
        var c;
        return c
    };

    function Et(a, b) {
        var c;
        return c
    };

    function Ft(a, b) {
        var c;
        return c
    };

    function Gt(a) {
        var b = "";
        return b
    };

    function Ht(a, b) {
        var c;
        return c
    };

    function It(a) {
        var b = "";
        return b
    };

    function Jt() {
        vg(this, "get_user_agent");
        return m.navigator.userAgent
    };

    function Kt(a, b) {};
    var Lt = {};

    function Mt(a, b, c, d, e, f) {
        f ? e[f] ? (e[f][0].push(c), e[f][1].push(d)) : (e[f] = [
            [c],
            [d]
        ], bc(a, function() {
            for (var g = e[f][0], h = 0; h < g.length; h++) I(g[h]);
            g.push = function(l) {
                I(l);
                return 0
            }
        }, function() {
            for (var g = e[f][1], h = 0; h < g.length; h++) I(g[h]);
            e[f] = null
        }, b)) : bc(a, c, d, b)
    }

    function Nt(a, b, c, d) {
        Q(G(this), ["url:!string", "onSuccess:?Fn", "onFailure:?Fn", "cacheToken:?string"], arguments);
        vg(this, "inject_script", a);
        var e = this.g;
        Mt(a, void 0, function() {
            b && b.o(e)
        }, function() {
            c && c.o(e)
        }, Lt, d);
    }
    var Ot = Object.freeze({
            dl: 1,
            id: 1
        }),
        Pt = {};

    function Qt(a, b, c, d) {};

    function Rt(a) {
        var b = !0;
        return b
    };
    var St = function() {
            return !1
        },
        Tt = {
            getItem: function(a) {
                var b = null;
                return b
            },
            setItem: function(a,
                b) {
                return !1
            },
            removeItem: function(a) {}
        };
    var Ut = ["textContent", "value", "tagName", "children", "childElementCount"];

    function Vt(a) {
        var b;
        return b
    };

    function Wt() {};

    function Xt(a, b) {
        var c;
        return c
    };

    function Yt(a) {
        var b = void 0;
        return b
    };

    function Zt(a, b) {
        var c = !1;
        return c
    };

    function $t() {
        var a = "";
        return a
    };

    function au() {
        var a = "";
        return a
    };
    var bu = ["set", "get", "config", "event"];

    function cu(a, b, c) {};

    function du() {};

    function eu(a, b, c, d) {
        d = void 0 === d ? !1 : d;
    };

    function fu(a, b, c) {};

    function gu(a, b, c, d) {
        var e = this;
        d = void 0 === d ? !0 : d;
        var f = !1;
        return f
    };

    function hu(a) {
        Q(G(this), ["consentSettings:!DustMap"], arguments);
        for (var b = a.tb(), c = b.length(), d = 0; d < c; d++) {
            var e = b.get(d);
            e !== R.Sd && vg(this, "access_consent", e, "write")
        }
        th(Ic(a))
    };

    function iu(a, b, c) {
        Q(G(this), ["path:!string", "value:?*", "overrideExisting:?boolean"], arguments);
        vg(this, "access_globals", "readwrite", a);
        var d = !1;
        var e = a.split("."),
            f = ib(e, [m, H]),
            g = e.pop();
        if (f && (void 0 === f[g] || c)) return f[g] = Ic(b, this.g, d), !0;
        return !1
    };

    function ju(a, b, c) {};

    function ku(a, b, c) {};
    var lu = function(a) {
        for (var b = [], c = 0, d = 0; d < a.length; d++) {
            var e = a.charCodeAt(d);
            128 > e ? b[c++] = e : (2048 > e ? b[c++] = e >> 6 | 192 : (55296 == (e & 64512) && d + 1 < a.length && 56320 == (a.charCodeAt(d + 1) & 64512) ? (e = 65536 + ((e & 1023) << 10) + (a.charCodeAt(++d) & 1023), b[c++] = e >> 18 | 240, b[c++] = e >> 12 & 63 | 128) : b[c++] = e >> 12 | 224, b[c++] = e >> 6 & 63 | 128), b[c++] = e & 63 | 128)
        }
        return b
    };

    function mu(a, b, c, d) {
        var e = this;
    };

    function nu(a, b, c) {};
    var ou = {},
        pu = {};
    ou.getItem = function(a) {
        var b = null;
        return b
    };
    ou.setItem = function(a, b) {};
    ou.removeItem = function(a) {};
    ou.clear = function() {};
    var qu = function(a) {
        var b;
        return b
    };

    function ru(a) {
        Q(G(this), ["consentSettings:!DustMap"], arguments);
        var b = Ic(a),
            c;
        for (c in b) b.hasOwnProperty(c) && vg(this, "access_consent", c, "write");
        vh(b)
    };
    var ne = function() {
        var a = new Kg;
        Sn() ? (a.add("injectHiddenIframe", Fa), a.add("injectScript", Fa)) : (a.add("injectHiddenIframe", Kt), a.add("injectScript", Nt));
        var b = fu;
        a.add("Math", og());
        a.add("Object", Ig);
        a.add("TestHelper", Ng());
        a.add("addConsentListener", qr);
        a.add("addEventCallback", tr);
        a.add("aliasInWindow", bt);
        a.add("assertApi",
            kg);
        a.add("assertThat", lg);
        a.add("callInWindow", dt);
        a.add("callLater", et);
        a.add("copyFromDataLayer", mt);
        a.add("copyFromWindow", nt);
        a.add("createArgumentsQueue", ot);
        a.add("createQueue", pt);
        a.add("decodeUri", pg);
        a.add("decodeUriComponent", qg);
        a.add("encodeUri", rg);
        a.add("encodeUriComponent", sg);
        a.add("fail", tg);
        a.add("fromBase64", zt, !("atob" in m));
        a.add("generateRandom", ug);
        a.add("getContainerVersion", wg);
        a.add("getCookieValues", At);
        a.add("getQueryParameters", Et);
        a.add("getReferrerQueryParameters",
            Ft);
        a.add("getReferrerUrl", Gt);
        a.add("getTimestamp", zg);
        a.add("getTimestampMillis", zg);
        a.add("getType", Ag);
        a.add("getUrl", It);
        a.add("localStorage", Tt, !St());
        a.add("isConsentGranted", Rt);
        a.add("logToConsole", Wt);
        a.add("makeInteger", Cg);
        a.add("makeNumber", Dg);
        a.add("makeString", Eg);
        a.add("makeTableMap", Fg);
        a.add("mock", Hg);
        a.add("parseUrl", Yt);
        a.add("queryPermission", Zt);
        a.add("readCharacterSet", $t);
        a.add("readTitle", au);
        a.add("sendPixel", b);
        a.add("setCookie", gu);
        a.add("setDefaultConsentState", hu);
        a.add("setInWindow", iu);
        a.add("sha256", mu);
        a.add("templateStorage", ou);
        a.add("toBase64", qu, !("btoa" in m));
        a.add("updateConsentState", ru);
        Mg(a, "callOnWindowLoad", kt);
        a.add("JSON", Bg(function(c) {
            var d = this.g.g;
            d && d.log.call(this, "error", c)
        }));
        Mg(a, "internal.addHistoryChangeListener", ns);
        Mg(a, "internal.sendGtagEvent", eu);
        Sn() ? Mg(a, "internal.injectScript", Fa) : Mg(a, "internal.injectScript", Qt);
        Mg(a, "internal.locateUserData", Vt);
        Mg(a, "internal.addFormInteractionListener", Tr);
        Mg(a, "internal.addFormSubmitListener", $r);
        Mg(a, "internal.getFlags", yg);
        return function(c) {
            var d;
            if (a.g.hasOwnProperty(c)) d = a.get(c, this);
            else {
                var e;
                if (e = a.o.hasOwnProperty(c)) {
                    var f = !1,
                        g = this.g.g;
                    if (g) {
                        var h = g.Ec();
                        if (h) {
                            0 !== h.indexOf("__cvt_") && (f = !0);
                        }
                    }
                    e = f
                }
                if (e) {
                    var l = a.o.hasOwnProperty(c) ? a.o[c] : void 0;
                    d = l
                } else throw Error(c + " is not a valid API name.");
            }
            return d
        }
    };
    var su = function() {
            return !1
        },
        tu = function() {
            var a = {};
            return function(b, c, d) {}
        };
    var le, xf;

    function uu() {
        var a = data.runtime || [],
            b = data.runtime_lines;
        le = new je;
        vu();
        Se = function(e, f, g) {
            wu(f);
            var h = new rb;
            Qa(f, function(u, r) {
                var v = Hc(r);
                void 0 === v && void 0 !== r && Vg(44);
                h.set(u, v)
            });
            le.g.g.F = lf();
            var l = {
                Ai: yf(e),
                eventId: void 0 !== g ? g.id : void 0,
                vc: void 0 !== g ? function(u) {
                    return g.ib.vc(u)
                } : void 0,
                Ec: function() {
                    return e
                },
                log: function() {}
            };
            if (su()) {
                var n = tu(),
                    p = void 0,
                    q = void 0;
                l.Aa = {
                    wc: {},
                    Ub: function(u, r, v) {
                        1 === r && (p = u);
                        7 === r && (q = v);
                        n(u, r, v)
                    },
                    df: Gg()
                };
                l.log = function(u, r) {
                    if (p) {
                        var v = Array.prototype.slice.call(arguments, 1);
                        n(p, 4, {
                            level: u,
                            source: q,
                            message: v
                        })
                    }
                }
            }
            var t = me(l, [e, h]);
            le.g.g.F = void 0;
            t instanceof sa && "return" === t.g && (t = t.o);
            return Ic(t)
        };
        oe();
        for (var c = 0; c < a.length; c++) {
            var d = a[c];
            if (!Ia(d) || 3 > d.length) {
                if (0 === d.length) continue;
                break
            }
            b && b[c] && b[c].length && hf(d, b[c]);
            le.execute(d)
        }
    }

    function wu(a) {
        var b = a.gtmOnSuccess,
            c = a.gtmOnFailure;
        Ga(b) && (a.gtmOnSuccess = function() {
            I(b)
        });
        Ga(c) && (a.gtmOnFailure = function() {
            I(c)
        })
    }

    function vu() {
        var a = le;
        S.SANDBOXED_JS_SEMAPHORE = S.SANDBOXED_JS_SEMAPHORE || 0;
        pe(a, function(b, c, d) {
            S.SANDBOXED_JS_SEMAPHORE++;
            try {
                return b.apply(c, d)
            } finally {
                S.SANDBOXED_JS_SEMAPHORE--
            }
        })
    }

    function xu(a) {
        void 0 !== a && Qa(a, function(b, c) {
            for (var d = 0; d < c.length; d++) {
                var e = c[d].replace(/^_*/, "");
                Ci[e] = Ci[e] || [];
                Ci[e].push(b)
            }
        })
    };
    var Bu = "HA GF G UA AW DC".split(" "),
        Cu = !1;
    Cu = !0;
    var Du = !1,
        Eu = !1;

    function Fu(a, b) {
        var c = {
            event: a
        };
        b && (c.eventModel = J(b), b[R.Kb] && (c.eventCallback = b[R.Kb]), b[R.dd] && (c.eventTimeout = b[R.dd]));
        return c
    }

    function Gu(a) {
        a.hasOwnProperty("gtm.uniqueEventId") || Object.defineProperty(a, "gtm.uniqueEventId", {
            value: Di()
        });
        return a["gtm.uniqueEventId"]
    }

    function Hu() {
        return Du
    }
    var Iu = {
            config: function(a) {
                var b, c = Gu(a);
                return b
            },
            consent: function(a) {
                function b() {
                    Hu() && J(a[2], {
                        subcommand: a[1]
                    })
                }
                if (3 === a.length) {
                    Vg(39);
                    var c = Di(),
                        d = a[1];
                    "default" === d ? (b(), th(a[2])) : "update" === d && (b(), vh(a[2], c))
                }
            },
            event: function(a) {
                var b = a[1];
                if (!(2 > a.length) && k(b)) {
                    var c;
                    if (2 < a.length) {
                        if (!Gc(a[2]) && void 0 != a[2] || 3 < a.length) return;
                        c = a[2]
                    }
                    var d = Fu(b, c),
                        e = Gu(a);
                    d["gtm.uniqueEventId"] = e;
                    return d
                }
            },
            get: function(a) {},
            js: function(a) {
                if (2 == a.length && a[1].getTime) {
                    Eu = !0;
                    Hu();
                    var b = {};
                    return b.event = "gtm.js", b["gtm.start"] = a[1].getTime(), b["gtm.uniqueEventId"] = Gu(a), b
                }
            },
            policy: function(a) {
                if (3 === a.length) {
                    var b = a[1],
                        c = a[2],
                        d = xf.o;
                    d.g[b] ?
                        d.g[b].push(c) : d.g[b] = [c]
                }
            },
            set: function(a) {
                var b;
                2 == a.length && Gc(a[1]) ? b = J(a[1]) : 3 == a.length && k(a[1]) && (b = {}, Gc(a[2]) || Ia(a[2]) ? b[a[1]] = J(a[2]) : b[a[1]] = a[2]);
                if (b) {
                    b._clear = !0;
                    return b
                }
            }
        },
        Ju = {
            policy: !0
        };
    var Ku = function(a, b) {
            var c = a.hide;
            if (c && void 0 !== c[b] && c.end) {
                c[b] = !1;
                var d = !0,
                    e;
                for (e in c)
                    if (c.hasOwnProperty(e) && !0 === c[e]) {
                        d = !1;
                        break
                    }
                d && (c.end(), c.end = null)
            }
        },
        Mu = function(a) {
            var b = Lu(),
                c = b && b.hide;
            c && c.end && (c[a] = !0)
        };
    var cv = function(a) {
        if (bv(a)) return a;
        this.g = a
    };
    cv.prototype.Yi = function() {
        return this.g
    };
    var bv = function(a) {
        return !a || "object" !== Ec(a) || Gc(a) ? !1 : "getUntrustedUpdateValue" in a
    };
    cv.prototype.getUntrustedUpdateValue = cv.prototype.Yi;
    var dv = [],
        ev = !1,
        fv = !1,
        gv = function(a) {
            return m["dataLayer"].push(a)
        },
        hv = function(a, b) {
            var c = S["dataLayer"],
                d = c ? c.subscribers : 1,
                e = 0,
                f = !1,
                g = void 0;
            b && (g = m.setTimeout(function() {
                f || (f = !0, a());
                g = void 0
            }, b));
            return function() {
                ++e === d && (g && (m.clearTimeout(g), g = void 0), f || (a(), f = !0))
            }
        };

    function iv(a) {
        var b = a._clear;
        Qa(a, function(d, e) {
            "_clear" !== d && (b && Ni(d, void 0), Ni(d, e))
        });
        yi || (yi = a["gtm.start"]);
        var c = a["gtm.uniqueEventId"];
        if (!a.event) return !1;
        c || (c = Di(), a["gtm.uniqueEventId"] = c, Ni("gtm.uniqueEventId", c));
        return Nn(a)
    }

    function jv() {
        var a = dv[0];
        if (null == a || "object" !== typeof a) return !1;
        if (a.event) return !0;
        if (Ra(a)) {
            var b = a[0];
            if ("config" === b || "event" === b || "js" === b) return !0
        }
        return !1
    }

    function kv() {
        for (var a = !1; !fv && 0 < dv.length;) {
            if (!ev && jv()) {
                var b = {},
                    c = (b.event = "gtm.init_consent", b),
                    d = {},
                    e = (d.event = "gtm.init", d),
                    f = dv[0]["gtm.uniqueEventId"];
                f && (c["gtm.uniqueEventId"] = f - 2, e["gtm.uniqueEventId"] = f - 1);
                dv.unshift(c, e);
                ev = !0
            }
            fv = !0;
            delete Hi.eventModel;
            Ji();
            var g = dv.shift();
            if (null != g) {
                var h = bv(g);
                if (h) {
                    var l = g;
                    g = bv(l) ? l.getUntrustedUpdateValue() : void 0;
                    Oi()
                }
                try {
                    if (Ga(g)) try {
                        g.call(Li)
                    } catch (w) {} else if (Ia(g)) {
                        var n =
                            g;
                        if (k(n[0])) {
                            var p = n[0].split("."),
                                q = p.pop(),
                                t = n.slice(1),
                                u = Ki(p.join("."), 2);
                            if (void 0 !== u && null !== u) try {
                                u[q].apply(u, t)
                            } catch (w) {}
                        }
                    } else {
                        if (Ra(g)) {
                            a: {
                                var r = g;
                                if (r.length && k(r[0])) {
                                    var v = Iu[r[0]];
                                    if (v && (!h || !Ju[r[0]])) {
                                        g = v(r);
                                        break a
                                    }
                                }
                                g = void 0
                            }
                            if (!g) {
                                fv = !1;
                                continue
                            }
                        }
                        a = iv(g) || a
                    }
                } finally {
                    h && Ji(!0)
                }
            }
            fv = !1
        }
        return !a
    }

    function lv() {
        var b = kv();
        try {
            Ku(m["dataLayer"], tf.J)
        } catch (c) {}
        return b
    }
    var nv = function() {
            var a = Xb("dataLayer", []),
                b = Xb("google_tag_manager", {});
            b = b["dataLayer"] = b["dataLayer"] || {};
            $l(function() {
                b.gtmDom || (b.gtmDom = !0, a.push({
                    event: "gtm.dom"
                }))
            });
            jt(function() {
                b.gtmLoad || (b.gtmLoad = !0, a.push({
                    event: "gtm.load"
                }))
            });
            b.subscribers = (b.subscribers || 0) + 1;
            var c = a.push;
            a.push = function() {
                var e;
                if (0 < S.SANDBOXED_JS_SEMAPHORE) {
                    e = [];
                    for (var f = 0; f < arguments.length; f++) e[f] = new cv(arguments[f])
                } else e = [].slice.call(arguments, 0);
                var g = c.apply(a, e);
                dv.push.apply(dv, e);
                if (300 <
                    this.length)
                    for (Vg(4); 300 < this.length;) this.shift();
                var h = "boolean" !== typeof g || g;
                return kv() && h
            };
            var d = a.slice(0);
            dv.push.apply(dv, d);
            if (mv()) {
                I(lv)
            }
        },
        mv = function() {
            var a = !0;
            return a
        };
    var ov = {};
    ov.od = new String("undefined");
    var pv = function(a) {
        this.g = function(b) {
            for (var c = [], d = 0; d < a.length; d++) c.push(a[d] === ov.od ? b : a[d]);
            return c.join("")
        }
    };
    pv.prototype.toString = function() {
        return this.g("undefined")
    };
    pv.prototype.valueOf = pv.prototype.toString;
    ov.ri = pv;
    ov.Ge = {};
    ov.Ki = function(a) {
        return new pv(a)
    };
    var qv = {};
    ov.Bj = function(a, b) {
        var c = Di();
        qv[c] = [a, b];
        return c
    };
    ov.zg = function(a) {
        var b = a ? 0 : 1;
        return function(c) {
            var d = qv[c];
            if (d && "function" === typeof d[b]) d[b]();
            qv[c] = void 0
        }
    };
    ov.cj = function(a) {
        for (var b = !1, c = !1, d = 2; d < a.length; d++) b =
            b || 8 === a[d], c = c || 16 === a[d];
        return b && c
    };
    ov.vj = function(a) {
        if (a === ov.od) return a;
        var b = Di();
        ov.Ge[b] = a;
        return 'google_tag_manager["' + tf.J + '"].macro(' + b + ")"
    };
    ov.oj = function(a, b, c) {
        a instanceof ov.ri && (a = a.g(ov.Bj(b, c)), b = Fa);
        return {
            aj: a,
            onSuccess: b
        }
    };
    var Bv = m.clearTimeout,
        Cv = m.setTimeout,
        U = function(a, b, c, d) {
            if (Sn()) {
                b && I(b)
            } else return bc(a, b, c, d)
        },
        Dv = function() {
            return new Date
        },
        Ev = function() {
            return m.location.href
        },
        Fv = function(a) {
            return jj(lj(a), "fragment")
        },
        Gv = function(a) {
            return kj(lj(a))
        },
        Hv = function(a, b) {
            return Ki(a, b || 2)
        },
        Iv = function(a, b, c) {
            var d;
            b ? (a.eventCallback = b, c && (a.eventTimeout = c), d = gv(a)) : d = gv(a);
            return d
        },
        Jv = function(a, b) {
            m[a] = b
        },
        W = function(a, b,
            c) {
            b && (void 0 === m[a] || c && !m[a]) && (m[a] = b);
            return m[a]
        },
        Kv = function(a, b, c) {
            return Nj(a, b, void 0 === c ? !0 : !!c)
        },
        Lv = function(a, b, c) {
            return 0 === Wj(a, b, c)
        },
        Mv = function(a, b) {
            if (Sn()) {
                b && I(b)
            } else dc(a, b)
        },
        Nv = function(a) {
            return !!yr(a, "init", !1)
        },
        Ov = function(a) {
            wr(a, "init", !0)
        },
        Pv = function(a) {
            var b = wi,
                c = "?id=" + encodeURIComponent(a) + "&l=dataLayer";
            Rn() && (c += "&sign=" + tf.ud, Wb && (b = Wb.replace(/^(?:https?:\/\/)?/i, "").split(/[?#]/)[0]));
            var d = Yo("https://", "http://", b + c);
            U(d)
        },
        Qv = function(a, b, c) {
            dn && (Kc(a) || sn(c, b, a))
        };
    var Rv = ov.oj;
    var nw = encodeURI,
        Y = encodeURIComponent,
        ow = ec;
    var pw = function(a, b) {
        if (!a) return !1;
        var c = jj(lj(a), "host");
        if (!c) return !1;
        for (var d = 0; b && d < b.length; d++) {
            var e = b[d] && b[d].toLowerCase();
            if (e) {
                var f = c.length - e.length;
                0 < f && "." != e.charAt(0) && (f--, e = "." + e);
                if (0 <= f && c.indexOf(e, f) == f) return !0
            }
        }
        return !1
    };
    var qw = function(a, b, c) {
        for (var d = {}, e = !1, f = 0; a && f < a.length; f++) a[f] && a[f].hasOwnProperty(b) && a[f].hasOwnProperty(c) && (d[a[f][b]] = a[f][c], e = !0);
        return e ? d : null
    };
    var rw = function(a, b, c) {
        for (var d = 0; d < b.length; d++) a.hasOwnProperty(b[d]) && (a[b[d]] = c(a[b[d]]))
    };

    function Zx() {
        return m.gaGlobal = m.gaGlobal || {}
    }
    var $x = function() {
            var a = Zx();
            a.hid = a.hid || Na();
            return a.hid
        },
        ay = function(a, b) {
            var c = Zx();
            if (void 0 == c.vid || b && !c.from_cookie) c.vid = a, c.from_cookie = b
        };
    var By = function() {
        if (Ga(m.__uspapi)) {
            var a = "";
            try {
                m.__uspapi("getUSPData", 1, function(b, c) {
                    if (c && b) {
                        var d = b.uspString;
                        d && RegExp("^[\\da-zA-Z-]{1,20}$").test(d) && (a = d)
                    }
                })
            } catch (b) {}
            return a
        }
    };
    var az = window,
        bz = document,
        cz = function(a) {
            var b = az._gaUserPrefs;
            if (b && b.ioo && b.ioo() || a && !0 === az["ga-disable-" + a]) return !0;
            try {
                var c = az.external;
                if (c && c._gaUserPrefs && "oo" == c._gaUserPrefs) return !0
            } catch (f) {}
            for (var d = Jj("AMP_TOKEN", String(bz.cookie), !0), e = 0; e < d.length; e++)
                if ("$OPT_OUT" == d[e]) return !0;
            return bz.getElementById("__gaOptOutExtension") ? !0 : !1
        };
    var dz = {};

    function gz(a) {
        delete a.eventModel[R.qc];
        iz(a.eventModel)
    }
    var iz = function(a) {
        Qa(a, function(c) {
            "_" === c.charAt(0) && delete a[c]
        });
        var b = a[R.Pa] || {};
        Qa(b, function(c) {
            "_" === c.charAt(0) && delete b[c]
        })
    };
    var lz = function(a, b, c) {
            fr(b, c, a)
        },
        mz = function(a, b, c) {
            fr(b, c, a, !0)
        },
        qz = function(a, b) {};

    function nz(a, b) {}
    var Z = {
        h: {}
    };
    Z.h.gaawc = ["google"],
        function() {
            (function(a) {
                Z.__gaawc = a;
                Z.__gaawc.m = "gaawc";
                Z.__gaawc.isVendorTemplate = !0;
                Z.__gaawc.priorityOverride = 10
            })(function(a) {
                var b = String(a.vtp_measurementId);
                if (k(b) && 0 === b.indexOf("G-")) {
                    var c = qw(a.vtp_fieldsToSet, "name", "value") || {};
                    if (c.hasOwnProperty(R.Pa) || a.vtp_userProperties) {
                        var d = c[R.Pa] || {};
                        J(qw(a.vtp_userProperties, "name", "value"), d);
                        c[R.Pa] = d
                    }
                    a.vtp_enableSendToServerContainer && a.vtp_serverContainerUrl && (c[R.qa] = a.vtp_serverContainerUrl, c[R.hc] = !0);
                    var e = a.vtp_userDataVariable;
                    e && (c[R.xa] = e);
                    rw(c, R.we, function(f) {
                        return Va(f)
                    });
                    rw(c, R.xe, function(f) {
                        return Number(f)
                    });
                    c.send_page_view = a.vtp_sendPageView;
                    gr(c, b);
                    I(a.vtp_gtmOnSuccess)
                } else I(a.vtp_gtmOnFailure)
            })
        }();




    Z.h.jsm = ["customScripts"],
        function() {
            (function(a) {
                Z.__jsm = a;
                Z.__jsm.m = "jsm";
                Z.__jsm.isVendorTemplate = !0;
                Z.__jsm.priorityOverride = 0
            })(function(a) {
                if (void 0 !== a.vtp_javascript) {
                    var b = a.vtp_javascript;
                    try {
                        var c = W("google_tag_manager");
                        var d = c && c.e && c.e(b);
                        Qv(d, "jsm", a.vtp_gtmEventId);
                        return d
                    } catch (e) {}
                }
            })
        }();

    Z.h.flc = [],
        function() {
            (function(a) {
                Z.__flc = a;
                Z.__flc.m = "flc";
                Z.__flc.isVendorTemplate = !0;
                Z.__flc.priorityOverride = 0
            })(function(a) {
                var b = !a.hasOwnProperty("vtp_enableConversionLinker") || !!a.vtp_enableConversionLinker,
                    c = qw(a.vtp_customVariable || [], "key", "value") || {},
                    d = {},
                    e = (d[R.V] = Hv(R.V), d[R.Yd] = !0 === a.vtp_useImageTag ? !1 : !0, d[R.Da] = a.vtp_conversionCookiePrefix || void 0, d[R.Ea] = b, d[R.nc] = a.vtp_sessionId, d.oref = a.vtp_useImageTag ? void 0 : a.vtp_url, d.tran = a.vtp_transactionVariable, d.u = a.vtp_userVariable,
                        d[R.xa] = a.vtp_userDataVariable, d),
                    f;
                for (f in c) c.hasOwnProperty(f) && (e[f] = c[f]);
                var g = "DC-" + a.vtp_advertiserId + "/" + a.vtp_groupTag + "/" + (a.vtp_activityTag + "+" + ({
                        UNIQUE: "unique",
                        SESSION: "per_session"
                    }[a.vtp_ordinalType] || "standard")),
                    h = ni(ki(fi(e), a.vtp_gtmOnSuccess), a.vtp_gtmOnFailure);
                h.isGtmEvent = !0;
                $p(g, "", Date.now(), h)
            })
        }();
    Z.h.e = ["google"],
        function() {
            (function(a) {
                Z.__e = a;
                Z.__e.m = "e";
                Z.__e.isVendorTemplate = !0;
                Z.__e.priorityOverride = 0
            })(function(a) {
                var b = String(Ri(a.vtp_gtmEventId, "event"));
                a.vtp_gtmCachedValues && (b = String(a.vtp_gtmCachedValues.event));
                return b
            })
        }();
    Z.h.f = ["google"],
        function() {
            (function(a) {
                Z.__f = a;
                Z.__f.m = "f";
                Z.__f.isVendorTemplate = !0;
                Z.__f.priorityOverride = 0
            })(function(a) {
                var b = Hv("gtm.referrer", 1) || H.referrer;
                return b ? a.vtp_component && "URL" != a.vtp_component ? jj(lj(String(b)), a.vtp_component, a.vtp_stripWww, a.vtp_defaultPages, a.vtp_queryKey) : Gv(String(b)) : String(b)
            })
        }();
    Z.h.cl = ["google"],
        function() {
            function a(b) {
                var c = b.target;
                if (c) {
                    var d = ur(c, "gtm.click");
                    Iv(d)
                }
            }(function(b) {
                Z.__cl = b;
                Z.__cl.m = "cl";
                Z.__cl.isVendorTemplate = !0;
                Z.__cl.priorityOverride = 0
            })(function(b) {
                if (!Nv("cl")) {
                    var c = W("document");
                    fc(c, "click", a, !0);
                    Ov("cl")
                }
                I(b.vtp_gtmOnSuccess)
            })
        }();
    Z.h.j = ["google"],
        function() {
            (function(a) {
                Z.__j = a;
                Z.__j.m = "j";
                Z.__j.isVendorTemplate = !0;
                Z.__j.priorityOverride = 0
            })(function(a) {
                for (var b = String(a.vtp_name).split("."), c = W(b.shift()), d = 0; d < b.length; d++) c = c && c[b[d]];
                Qv(c, "j", a.vtp_gtmEventId);
                return c
            })
        }();
    Z.h.k = ["google"],
        function() {
            (function(a) {
                Z.__k = a;
                Z.__k.m = "k";
                Z.__k.isVendorTemplate = !0;
                Z.__k.priorityOverride = 0
            })(function(a) {
                return Kv(a.vtp_name, Hv("gtm.cookie", 1), !!a.vtp_decodeCookie)[0]
            })
        }();

    Z.h.fls = [],
        function() {
            (function(a) {
                Z.__fls = a;
                Z.__fls.m = "fls";
                Z.__fls.isVendorTemplate = !0;
                Z.__fls.priorityOverride = 0
            })(function(a) {
                var b = [];
                if (a.vtp_enableProductReporting) switch (a.vtp_dataSource) {
                    case "DATA_LAYER":
                        b = Hv("ecommerce.purchase.products");
                        break;
                    case "JSON":
                        b = a.vtp_productData;
                        break;
                    case "STRING":
                        for (var c = (a.vtp_productData || "").split("|"), d = 0; d < c.length; d++) {
                            var e = c[d].split(":");
                            e[1] = e[1] && Y(e[1]) || "";
                            c[d] = e.join(":");
                            var f = {
                                    i: "id",
                                    p: "price",
                                    q: "quantity",
                                    c: "country",
                                    l: "language",
                                    a: "accountId"
                                },
                                g = e[0][0],
                                h = Number(e[0].slice(1)) - 1,
                                l = b[h] || {};
                            f.hasOwnProperty(g) && (l[f[g]] = e[1]);
                            b[h] = l
                        }
                }
                var n = !a.hasOwnProperty("vtp_enableConversionLinker") || !!a.vtp_enableConversionLinker,
                    p = qw(a.vtp_customVariable || [], "key", "value") || {},
                    q = {},
                    t = (q[R.V] = Hv(R.V), q[R.Yd] = !a.vtp_useImageTag, q[R.X] = b, q[R.Da] = a.vtp_conversionCookiePrefix || void 0, q[R.Ea] = n, q[R.Xf] = a.vtp_quantity,
                        q[R.cb] = a.vtp_orderId, q[R.da] = a.vtp_revenue, q.oref = a.vtp_useImageTag ? void 0 : a.vtp_url, q.tran = a.vtp_transactionVariable, q.u = a.vtp_userVariable, q[R.xa] = a.vtp_userDataVariable, q),
                    u;
                for (u in p) p.hasOwnProperty(u) && (t[u] = p[u]);
                var r = "DC-" + a.vtp_advertiserId + "/" + a.vtp_groupTag + "/" + (a.vtp_activityTag + "+" + ("ITEM_SOLD" === a.vtp_countingMethod ? "items_sold" : "transactions")),
                    v = ni(ki(fi(t), a.vtp_gtmOnSuccess), a.vtp_gtmOnFailure);
                v.isGtmEvent = !0;
                $p(r, "", Date.now(), v)
            })
        }();
    Z.h.access_globals = ["google"],
        function() {
            function a(b, c, d) {
                var e = {
                    key: d,
                    read: !1,
                    write: !1,
                    execute: !1
                };
                switch (c) {
                    case "read":
                        e.read = !0;
                        break;
                    case "write":
                        e.write = !0;
                        break;
                    case "readwrite":
                        e.read = e.write = !0;
                        break;
                    case "execute":
                        e.execute = !0;
                        break;
                    default:
                        throw Error("Invalid " + b + " request " + c);
                }
                return e
            }(function(b) {
                Z.__access_globals = b;
                Z.__access_globals.m = "access_globals";
                Z.__access_globals.isVendorTemplate = !0;
                Z.__access_globals.priorityOverride = 0
            })(function(b) {
                for (var c = b.vtp_keys || [], d = b.vtp_createPermissionError,
                        e = [], f = [], g = [], h = 0; h < c.length; h++) {
                    var l = c[h],
                        n = l.key;
                    l.read && e.push(n);
                    l.write && f.push(n);
                    l.execute && g.push(n)
                }
                return {
                    assert: function(p, q, t) {
                        if (!k(t)) throw d(p, {}, "Key must be a string.");
                        if ("read" === q) {
                            if (-1 < Ja(e, t)) return
                        } else if ("write" === q) {
                            if (-1 < Ja(f, t)) return
                        } else if ("readwrite" === q) {
                            if (-1 < Ja(f, t) && -1 < Ja(e, t)) return
                        } else if ("execute" === q) {
                            if (-1 < Ja(g, t)) return
                        } else throw d(p, {}, "Operation must be either 'read', 'write', or 'execute', was " + q);
                        throw d(p, {}, "Prohibited " + q + " on global variable: " +
                            t + ".");
                    },
                    T: a
                }
            })
        }();
    Z.h.r = ["google"],
        function() {
            (function(a) {
                Z.__r = a;
                Z.__r.m = "r";
                Z.__r.isVendorTemplate = !0;
                Z.__r.priorityOverride = 0
            })(function(a) {
                return Na(a.vtp_min, a.vtp_max)
            })
        }();
    Z.h.t = ["google"],
        function() {
            (function(a) {
                Z.__t = a;
                Z.__t.m = "t";
                Z.__t.isVendorTemplate = !0;
                Z.__t.priorityOverride = 0
            })(function() {
                return Dv().getTime()
            })
        }();
    Z.h.u = ["google"],
        function() {
            var a = function(b) {
                return {
                    toString: function() {
                        return b
                    }
                }
            };
            (function(b) {
                Z.__u = b;
                Z.__u.m = "u";
                Z.__u.isVendorTemplate = !0;
                Z.__u.priorityOverride = 0
            })(function(b) {
                var c;
                c = (c = b.vtp_customUrlSource ? b.vtp_customUrlSource : Hv("gtm.url", 1)) || Ev();
                var d = b[a("vtp_component")];
                if (!d || "URL" == d) return Gv(String(c));
                var e = lj(String(c)),
                    f;
                if ("QUERY" === d) a: {
                    var g = b[a("vtp_multiQueryKeys").toString()],
                        h = b[a("vtp_queryKey").toString()] || "",
                        l = b[a("vtp_ignoreEmptyQueryParam").toString()],
                        n;g ? Ia(h) ?
                    n = h : n = String(h).replace(/\s+/g, "").split(",") : n = [String(h)];
                    for (var p = 0; p < n.length; p++) {
                        var q = jj(e, "QUERY", void 0, void 0, n[p]);
                        if (void 0 != q && (!l || "" !== q)) {
                            f = q;
                            break a
                        }
                    }
                    f = void 0
                }
                else f = jj(e, d, "HOST" == d ? b[a("vtp_stripWww")] : void 0, "PATH" == d ? b[a("vtp_defaultPages")] : void 0, void 0);
                return f
            })
        }();
    Z.h.v = ["google"],
        function() {
            (function(a) {
                Z.__v = a;
                Z.__v.m = "v";
                Z.__v.isVendorTemplate = !0;
                Z.__v.priorityOverride = 0
            })(function(a) {
                var b = a.vtp_name;
                if (!b || !b.replace) return !1;
                var c = Hv(b.replace(/\\\./g, "."), a.vtp_dataLayerVersion || 1),
                    d = void 0 !== c ? c : a.vtp_defaultValue;
                Qv(d, "v", a.vtp_gtmEventId);
                return d
            })
        }();
    Z.h.tl = ["google"],
        function() {
            function a(b) {
                return function() {
                    if (b.cf && b.ef >= b.cf) b.Ze && W("self").clearInterval(b.Ze);
                    else {
                        b.ef++;
                        var c = Dv().getTime();
                        Iv({
                            event: b.eventName,
                            "gtm.timerId": b.Ze,
                            "gtm.timerEventNumber": b.ef,
                            "gtm.timerInterval": b.interval,
                            "gtm.timerLimit": b.cf,
                            "gtm.timerStartTime": b.dh,
                            "gtm.timerCurrentTime": c,
                            "gtm.timerElapsedTime": c - b.dh,
                            "gtm.triggers": b.Oj
                        })
                    }
                }
            }(function(b) {
                Z.__tl = b;
                Z.__tl.m = "tl";
                Z.__tl.isVendorTemplate = !0;
                Z.__tl.priorityOverride = 0
            })(function(b) {
                I(b.vtp_gtmOnSuccess);
                if (!isNaN(b.vtp_interval)) {
                    var c = {
                        eventName: b.vtp_eventName,
                        ef: 0,
                        interval: Number(b.vtp_interval),
                        cf: isNaN(b.vtp_limit) ? 0 : Number(b.vtp_limit),
                        Oj: String(b.vtp_uniqueTriggerId || "0"),
                        dh: Dv().getTime()
                    };
                    c.Ze = W("self").setInterval(a(c), 0 > Number(b.vtp_interval) ? 0 : Number(b.vtp_interval))
                }
            })
        }();
    Z.h.ua = ["google"],
        function() {
            function a(r) {
                return wh(r)
            }

            function b(r, v, w) {
                var y = !1;
                if (lh() && !y && !f[r]) {
                    var x = !wh(R.I),
                        z = function() {
                            var B = lm(),
                                C = "gtm" + Di(),
                                F = q(v);
                            F["&gtm"] = Wn(!0);
                            var D = {
                                name: C
                            };
                            p(F, D, !0);
                            var E = void 0,
                                O = D._useUp;
                            B(function() {
                                var M = B.getByName(w);
                                M && (E = M.get("clientId"))
                            });
                            B("create", r, D);
                            x && wh(R.I) && (x = !1, B(function() {
                                var M = lm().getByName(C);
                                !M || M.get("clientId") === E && O || (F["&gcs"] = xh(), F["&gcu"] = "1", M.set(F), M.send("pageview"))
                            }));
                            B(function() {
                                B.remove(C)
                            })
                        };
                    qh(z, R.I);
                    qh(z, R.C);
                    f[r] = !0
                }
            }
            var c = !1;
            c = !0;
            var d, e = {},
                f = {},
                g = {
                    name: !0,
                    clientId: !0,
                    sampleRate: !0,
                    siteSpeedSampleRate: !0,
                    alwaysSendReferrer: !0,
                    allowAnchor: !0,
                    allowLinker: !0,
                    cookieName: !0,
                    cookieDomain: !0,
                    cookieExpires: !0,
                    cookiePath: !0,
                    cookieUpdate: !0,
                    cookieFlags: !0,
                    legacyCookieDomain: !0,
                    legacyHistoryImport: !0,
                    storage: !0,
                    useAmpClientId: !0,
                    storeGac: !0,
                    _cd2l: !0,
                    _useUp: !0,
                    _cs: !0
                },
                h = {
                    allowAnchor: !0,
                    allowLinker: !0,
                    alwaysSendReferrer: !0,
                    anonymizeIp: !0,
                    cookieUpdate: !0,
                    exFatal: !0,
                    forceSSL: !0,
                    javaEnabled: !0,
                    legacyHistoryImport: !0,
                    nonInteraction: !0,
                    useAmpClientId: !0,
                    useBeacon: !0,
                    storeGac: !0,
                    allowAdFeatures: !0,
                    allowAdPersonalizationSignals: !0,
                    _cd2l: !0
                },
                l = {
                    urlPassthrough: !0
                };
            var n = function(r, v) {
                if (r)
                    for (var w in r)
                        if (!l[w] && r.hasOwnProperty(w)) {
                            var y = h[w] ? Va(r[w]) : r[w];
                            "anonymizeIp" != w || y || (y = void 0);
                            v[w] = y
                        }
            };
            var p = function(r, v, w) {
                    var y = 0;
                    if (r)
                        for (var x in r)
                            if (!l[x] &&
                                r.hasOwnProperty(x) && (w && g[x] || !w && void 0 === g[x])) {
                                var z = h[x] ? Va(r[x]) : r[x];
                                "anonymizeIp" != x || z || (z = void 0);
                                v[x] = z;
                                y++
                            }
                    return y
                },
                q = function(r) {
                    var v = {};
                    r.vtp_gaSettings && J(qw(r.vtp_gaSettings.vtp_fieldsToSet, "fieldName", "value"), v);
                    J(qw(r.vtp_fieldsToSet, "fieldName", "value"), v);
                    Va(v.urlPassthrough) && (v._useUp = !0);
                    r.vtp_transportUrl && (v._x_19 = r.vtp_transportUrl);
                    if (!c) {
                        v._x_19 && (v._cd2l = !0);
                        wh(R.I) || (v.storage = "none");
                        wh(R.C) || (v.allowAdFeatures = !1, v.storeGac = !1);
                        oq() || (v.allowAdFeatures = !1);
                        nq() || (v.allowAdPersonalizationSignals = !1);
                        if (Va(v.urlPassthrough)) {
                            var w = !1;
                            lh() && !w && (v._cs = a)
                        }
                    }
                    return v
                },
                t = function(r, v) {},
                u = function(r) {
                    function v(Ca, oa) {
                        void 0 !== r[oa] && P("set", Ca, r[oa])
                    }

                    function w() {
                        if (r.vtp_doubleClick || "DISPLAY_FEATURES" == r.vtp_advertisingFeaturesType) {
                            var Ca = "_dc_gtm_" + String(r.vtp_trackingId).replace(/[^A-Za-z0-9-]/g, "");
                            P("require", "displayfeatures", void 0, {
                                cookieName: Ca
                            })
                        }
                    }
                    var y = {},
                        x = {},
                        z = {},
                        B = {};
                    if (r.vtp_gaSettings) {
                        var C = r.vtp_gaSettings;
                        J(qw(C.vtp_contentGroup, "index", "group"), x);
                        J(qw(C.vtp_dimension, "index", "dimension"), z);
                        J(qw(C.vtp_metric, "index", "metric"), B);
                        var F = J(C);
                        F.vtp_fieldsToSet =
                            void 0;
                        F.vtp_contentGroup = void 0;
                        F.vtp_dimension = void 0;
                        F.vtp_metric = void 0;
                        r = J(r, F)
                    }
                    J(qw(r.vtp_contentGroup, "index", "group"), x);
                    J(qw(r.vtp_dimension, "index", "dimension"), z);
                    J(qw(r.vtp_metric, "index", "metric"), B);
                    var D = q(r),
                        E = "",
                        O = nm(r.vtp_functionName);
                    if (Ga(O)) {
                        var M = "",
                            N = "";
                        r.vtp_setTrackerName && "string" == typeof r.vtp_trackerName ? "" !== r.vtp_trackerName && (N = r.vtp_trackerName, M = N + ".") : (N = "gtm" + Di(), M = N + ".");
                        var P = function(Ca) {
                                var oa = [].slice.call(arguments, 0);
                                oa[0] = M + oa[0];
                                O.apply(window, oa)
                            },
                            L =
                            function(Ca, oa) {
                                return void 0 === oa ? oa : Ca(oa)
                            },
                            K = function(Ca, oa) {
                                if (oa)
                                    for (var Za in oa) oa.hasOwnProperty(Za) && (c ? D[Ca + Za] = oa[Za] : P("set", Ca + Za, oa[Za]))
                            },
                            ba = function() {
                                var Ca = {
                                        transaction_id: "id",
                                        affiliation: "affiliation",
                                        value: "revenue",
                                        tax: "tax",
                                        shipping: "shipping",
                                        coupon: "coupon",
                                        item_list_name: "list"
                                    },
                                    oa = {},
                                    Za = (oa[R.Vd] = "click", oa[R.wa] = "detail", oa[R.Gb] = "add", oa[R.Hb] = "remove", oa[R.mb] = "checkout", oa[R.va] = "purchase", oa[R.Ib] =
                                        "refund", oa),
                                    Qc = {
                                        item_id: "id",
                                        item_name: "name",
                                        item_list_name: "list",
                                        item_brand: "brand",
                                        item_variant: "variant",
                                        index: "position",
                                        promotion_id: "id",
                                        promotion_name: "name",
                                        creative_name: "creative",
                                        creative_slot: "position"
                                    },
                                    jd = {
                                        item_category: 0,
                                        item_category2: 1,
                                        item_category3: 2,
                                        item_category4: 3,
                                        item_category5: 4
                                    },
                                    ub = function(wb, $a, Sa) {
                                        var Ta = c ? Sa : wb,
                                            Db;
                                        for (Db in wb) Ca.hasOwnProperty(Db) && (Ta[$a] = Ta[$a] || {}, Ta[$a].actionField = Ta[$a].actionField || {}, Ta[$a].actionField[Ca[Db]] = wb[Db])
                                    },
                                    ac = function(wb, $a) {
                                        for (var Sa =
                                                "", Ta = 0; Ta < $a.length; Ta++) void 0 !== $a[Ta] && ("" !== Sa && (Sa += "/"), Sa += $a[Ta]);
                                        wb.category = Sa
                                    },
                                    vb = function(wb) {
                                        for (var $a = [], Sa = {}, Ta = 0; Ta < wb.length; Sa = {
                                                Db: Sa.Db,
                                                Yb: Sa.Yb
                                            }, Ta++) {
                                            Sa.Db = {};
                                            var Db = wb[Ta];
                                            Sa.Yb = [];
                                            Qa(Db, function(Ee) {
                                                return function(Tc, Sd) {
                                                    Qc.hasOwnProperty(Tc) ? Ee.Db[Qc[Tc]] = Sd : jd.hasOwnProperty(Tc) ? Ee.Yb[jd[Tc]] = Sd : Ee.Db[Tc] = Sd
                                                }
                                            }(Sa));
                                            0 < Sa.Yb.length && ac(Sa.Db, Sa.Yb);
                                            $a.push(Sa.Db)
                                        }
                                        return $a
                                    },
                                    Xa = function(wb, $a, Sa) {
                                        if (!Gc($a)) return !1;
                                        for (var Ta = db(Object($a), Sa, []), Db = 0; Ta && Db < Ta.length; Db++) P(wb,
                                            Ta[Db]);
                                        return !!Ta && 0 < Ta.length
                                    },
                                    T;
                                if (r.vtp_useEcommerceDataLayer) {
                                    var Pd = !1;
                                    if (r.vtp_useGA4SchemaForEcommerce) {
                                        r.vtp_gtmCachedValues && (T = r.vtp_gtmCachedValues.eventModel);
                                        T = T || Ri(r.vtp_gtmEventId, "eventModel");
                                        Pd = !!T
                                    }
                                    Pd || (T = Hv("ecommerce", 1))
                                } else r.vtp_ecommerceMacroData && (T = r.vtp_ecommerceMacroData.ecommerce, !T && r.vtp_useGA4SchemaForEcommerce && (T = r.vtp_ecommerceMacroData));
                                if (!Gc(T)) return null;
                                T = Object(T);
                                r.vtp_gtmCachedValues && (E = r.vtp_gtmCachedValues.event);
                                E = E || String(Ri(r.vtp_gtmEventId, "event"));
                                if (!c && r.vtp_useGA4SchemaForEcommerce)
                                    if (T = J(T), E === R.Ya && !T.impressions && T.items) T.impressions = vb(T.items);
                                    else if (E === R.nb && !T.promoView && T.items) T.promoView = {}, T.promoView.promotions = vb(T.items);
                                else if (E === R.Zc && !T.promoClick) T.items && (T.promoClick = {}, T.promoClick.promotions = vb(T.items)), ub(T, "promoClick");
                                else if (Za.hasOwnProperty(E)) {
                                    var Be = Za[E];
                                    T[Be] || (T.items && (T[Be] = {}, T[Be].products = vb(T.items)), ub(T, Be))
                                }
                                var Ma = {},
                                    Kf = T.currencyCode;
                                r.vtp_useGA4SchemaForEcommerce &&
                                    (Kf = Kf || T.currency);
                                var Qd = db(D, "currencyCode", Kf);
                                if (c) {
                                    Qd && (Ma.currencyCode = Qd);
                                    T.impressions && (Ma.impressions = T.impressions);
                                    T.promoView && (Ma.promoView = T.promoView);
                                    if (r.vtp_useGA4SchemaForEcommerce) {
                                        if (E === R.Ya && !T.impressions) T.items && (Ma.impressions = T.items, Ma.translateIfKeyEquals = "impressions");
                                        else if (E === R.nb && !T.promoView) T.promoView = {}, T.items && (Ma.promoView = {}, Ma.promoView.promotions = T.items, Ma.translateIfKeyEquals = "promoView");
                                        else if (E === R.Zc && !T.promoClick) T.promoClick = {}, T.items &&
                                            (Ma.promoClick = {}, Ma.promoClick.promotions = T.items, Ma.translateIfKeyEquals = "promoClick", ub(T, "promoClick", Ma));
                                        else if (Za.hasOwnProperty(E)) {
                                            var kd = Za[E];
                                            !T[kd] && T.items && (Ma[kd] = {}, Ma[kd].products = T.items, Ma.translateIfKeyEquals = "products", ub(T, kd, Ma))
                                        }
                                        var Ce = Ma.translateIfKeyEquals;
                                        if ("promoClick" === Ce || "products" === Ce) return Ma
                                    }
                                    if (T.promoClick) return Ma.promoClick = T.promoClick, Ma
                                } else if (void 0 !== Qd && P("set", "&cu", Qd), Xa("ec:addImpression", T, "impressions"), Xa("ec:addPromo", T[T.promoClick ? "promoClick" :
                                        "promoView"], "promotions") && T.promoClick) return P("ec:setAction", "promo_click", T.promoClick.actionField), null;
                                for (var Rc = "detail checkout checkout_option click add remove purchase refund".split(" "), De = "refund purchase remove checkout checkout_option add click detail".split(" "), Sc = 0; Sc < Rc.length; Sc++) {
                                    var Rd = T[Rc[Sc]];
                                    if (Rd) {
                                        c ? Ma[Rc[Sc]] = Rd : (Xa("ec:addProduct", Rd, "products"), P("ec:setAction", Rc[Sc], Rd.actionField));
                                        if (dn)
                                            for (var Lf = 0; Lf < De.length; Lf++) {
                                                var Jh = T[De[Lf]];
                                                if (Jh) {
                                                    Jh !== Rd && Vg(13);
                                                    break
                                                }
                                            }
                                        return Ma
                                    }
                                }
                                c &&
                                    r.vtp_useGA4SchemaForEcommerce && Za.hasOwnProperty(E) && ub(T, Za[E], Ma);
                                return Ma;
                                return null
                            },
                            X = function(Ca, oa) {
                                return void 0 === r[Ca] ? y[oa] : r[Ca]
                            },
                            fa = String(r.vtp_trackingId || y.trackingId || "");
                        if (c) {
                            var V = function() {
                                if (r.vtp_doubleClick || "DISPLAY_FEATURES" == r.vtp_advertisingFeaturesType) D.displayfeatures = !0
                            };
                            K("contentGroup", x);
                            K("dimension", z);
                            K("metric", B);
                            var ea = {};
                            r.vtp_enableEcommerce && (D.gtmEcommerceData = ba());
                            if ("TRACK_EVENT" === r.vtp_trackType) E = "track_event", V(), D.eventCategory = String(X("vtp_eventCategory", "category")), D.eventAction = String(X("vtp_eventAction", "action")), D.eventLabel = L(String, X("vtp_eventLabel", "label")), D.value = L(Ua, X("vtp_eventValue", "value"));
                            else if ("TRACK_PAGEVIEW" == r.vtp_trackType) {
                                if (E = R.ac, V(), "DISPLAY_FEATURES_WITH_REMARKETING_LISTS" == r.vtp_advertisingFeaturesType && (D.remarketingLists = !0), r.vtp_autoLinkDomains) {
                                    var na = {};
                                    na[R.O] =
                                        r.vtp_autoLinkDomains;
                                    na.use_anchor = r.vtp_useHashAutoLink;
                                    na[R.Nb] = r.vtp_decorateFormsAutoLink;
                                    D[R.oa] = na
                                }
                            } else "TRACK_SOCIAL" === r.vtp_trackType ? (E = "track_social", D.socialNetwork = String(r.vtp_socialNetwork), D.socialAction = String(r.vtp_socialAction), D.socialTarget = String(r.vtp_socialActionTarget)) : "TRACK_TIMING" == r.vtp_trackType && (E = "timing_complete", D.eventCategory = String(X("vtp_timingCategory", "category")), D.timingVar = String(X("vtp_timingVar", "name")), D.value = Ua(X("vtp_timingValue", "value")), D.eventLabel =
                                L(String, X("vtp_timingLabel", "label")));
                            r.vtp_enableRecaptcha && (D.enableRecaptcha = !0);
                            r.vtp_enableLinkId && (D.enableLinkId = !0);
                            n(D, ea);
                            D.name || (ea.gtmTrackerName = N);
                            ea.gaFunctionName = r.vtp_functionName;
                            void 0 !== r.vtp_nonInteraction && (ea.nonInteraction = r.vtp_nonInteraction);
                            var wa = ni(ki(fi(ea), r.vtp_gtmOnSuccess), r.vtp_gtmOnFailure);
                            wa.isGtmEvent = !0;
                            Hq(fa, E, Date.now(), wa)
                        }
                        if (!c) {
                            var La = function(Ca, oa) {
                                    void 0 !== oa && P("set", Ca, oa)
                                },
                                Wa = {
                                    name: N
                                };
                            p(D, Wa, !0);
                            O("create", fa, Wa);
                            P("set", "&gtm", Wn(!0));
                            K("contentGroup", x);
                            K("dimension", z);
                            K("metric", B);
                            var Md = !1;
                            lh() && !Md && (P("set", "&gcs", xh()), b(fa, r, N));
                            D._x_19 && D._x_20 && !e[N] && (e[N] = !0, O(sm(N, String(D._x_20))));
                            r.vtp_enableRecaptcha && P("require", "recaptcha", "recaptcha.js");
                            v("nonInteraction", "vtp_nonInteraction");
                            var Hf = {};
                            p(D, Hf, !1) && P("set", Hf);
                            r.vtp_enableLinkId && P("require", "linkid", "linkid.js");
                            P("set", "hitCallback", function() {
                                var Ca = D && D.hitCallback;
                                Ga(Ca) && Ca();
                                r.vtp_gtmOnSuccess()
                            })
                        }
                        var uc;
                        if ("TRACK_EVENT" == r.vtp_trackType) {
                            if (!c) {
                                if (r.vtp_enableEcommerce) {
                                    var If = {};
                                    Rn() && D._x_19 && (If._x_19 = D._x_19);
                                    P("require", "ec", "ec.js", If);
                                    ba()
                                }
                                w();
                                var ze = {
                                    hitType: "event",
                                    eventCategory: String(X("vtp_eventCategory", "category")),
                                    eventAction: String(X("vtp_eventAction", "action")),
                                    eventLabel: L(String, X("vtp_eventLabel", "label")),
                                    eventValue: L(Ua, X("vtp_eventValue", "value"))
                                };
                                p(uc, ze, !1);
                                P("send", ze);
                            }
                        } else if ("TRACK_SOCIAL" == r.vtp_trackType) {
                            if (!c) {}
                        } else if ("TRACK_TRANSACTION" == r.vtp_trackType) {} else if ("TRACK_TIMING" == r.vtp_trackType) {
                            if (!c) {}
                        } else if ("DECORATE_LINK" == r.vtp_trackType) {} else if ("DECORATE_FORM" == r.vtp_trackType) {} else if ("TRACK_DATA" == r.vtp_trackType) {} else if (!c) {
                            if (r.vtp_enableEcommerce) {
                                var Ae = {};
                                Rn() && D._x_19 && (Ae._x_19 = D._x_19);
                                P("require", "ec", "ec.js", Ae);
                                ba()
                            }
                            w();
                            if ("DISPLAY_FEATURES_WITH_REMARKETING_LISTS" == r.vtp_advertisingFeaturesType) {
                                var Hh =
                                    "_dc_gtm_" + String(r.vtp_trackingId).replace(/[^A-Za-z0-9-]/g, "");
                                P("require", "adfeatures", {
                                    cookieName: Hh
                                })
                            }
                            uc ? P("send", "pageview", uc) : P("send", "pageview");
                            t(r, M);
                            Va(D.urlPassthrough) && pm(M)
                        }
                        if (!d) {
                            var yc = r.vtp_useDebugVersion ? "u/analytics_debug.js" : "analytics.js";
                            r.vtp_useInternalVersion && !r.vtp_useDebugVersion && (yc = "internal/" + yc);
                            d = !0;
                            var Pc = Pn(D._x_19, "/analytics.js"),
                                Ih = Yo("https:", "http:", "//www.google-analytics.com/" + yc, D && !!D.forceSSL);
                            U("analytics.js" === yc && Pc ? Pc : Ih, function() {
                                var Ca = lm();
                                Ca && Ca.loaded || r.vtp_gtmOnFailure();
                            }, r.vtp_gtmOnFailure)
                        }
                    } else I(r.vtp_gtmOnFailure)
                };
            (function(r) {
                Z.__ua = r;
                Z.__ua.m = "ua";
                Z.__ua.isVendorTemplate = !0;
                Z.__ua.priorityOverride = 0
            })(function(r) {
                Bh(function() {
                    u(r)
                }, [R.I, R.C])
            })
        }();
    Z.h.inject_script = ["google"],
        function() {
            function a(b, c) {
                return {
                    url: c
                }
            }(function(b) {
                Z.__inject_script = b;
                Z.__inject_script.m = "inject_script";
                Z.__inject_script.isVendorTemplate = !0;
                Z.__inject_script.priorityOverride = 0
            })(function(b) {
                var c = b.vtp_urls || [],
                    d = b.vtp_createPermissionError;
                return {
                    assert: function(e, f) {
                        if (!k(f)) throw d(e, {}, "Script URL must be a string.");
                        try {
                            if (dg(lj(f), c)) return
                        } catch (g) {
                            throw d(e, {}, "Invalid script URL filter.");
                        }
                        throw d(e, {}, "Prohibited script URL: " + f);
                    },
                    T: a
                }
            })
        }();

    Z.h.cid = ["google"],
        function() {
            (function(a) {
                Z.__cid = a;
                Z.__cid.m = "cid";
                Z.__cid.isVendorTemplate = !0;
                Z.__cid.priorityOverride = 0
            })(function() {
                return tf.J
            })
        }();

    Z.h.gclidw = ["google"],
        function() {
            var a = ["aw", "dc", "gf", "ha", "gb"];
            (function(b) {
                Z.__gclidw = b;
                Z.__gclidw.m = "gclidw";
                Z.__gclidw.isVendorTemplate = !0;
                Z.__gclidw.priorityOverride = 100
            })(function(b) {
                I(b.vtp_gtmOnSuccess);
                var c, d, e, f;
                b.vtp_enableCookieOverrides && (e = b.vtp_cookiePrefix, c = b.vtp_path, d = b.vtp_domain, b.vtp_enableCookieFlagsFeature && (f = b.vtp_cookieFlags));
                var g = {
                    prefix: e,
                    path: c,
                    domain: d,
                    flags: f
                };
                b.vtp_enableCrossDomainFeature && (b.vtp_enableCrossDomain && !1 === b.vtp_acceptIncoming || (b.vtp_enableCrossDomain ||
                    Uk()) && nl(a, g));
                kl(g);
                ql(["aw", "dc"], g);
                El(g);
                var h = e;
                if (b.vtp_enableCrossDomainFeature && b.vtp_enableCrossDomain && b.vtp_linkerDomains) {
                    var l = b.vtp_linkerDomains.toString().replace(/\s+/g, "").split(",");
                    pl(a, l, b.vtp_urlPosition, !!b.vtp_formDecoration, h)
                }
                var n = Hv(R.V);
                Io({
                    Ne: !1,
                    Ha: void 0 != n && !1 !== n,
                    wb: g,
                    Id: !0
                });
                b.vtp_enableUrlPassthrough && sl(["aw", "dc", "gb"])
            })
        }();
    Z.h.aev = ["google"],
        function() {
            function a(u, r, v) {
                var w = u || Ri(r, "gtm");
                if (w) return w[v]
            }

            function b(u, r, v, w, y) {
                y || (y = "element");
                var x = r + "." + v,
                    z;
                if (p.hasOwnProperty(x)) z = p[x];
                else {
                    var B = a(u, r, y);
                    if (B && (z = w(B), p[x] = z, q.push(x), 35 < q.length)) {
                        var C = q.shift();
                        delete p[C]
                    }
                }
                return z
            }

            function c(u, r, v, w) {
                var y = a(u, r, t[v]);
                return void 0 !== y ? y : w
            }

            function d(u, r) {
                if (!u) return !1;
                var v = e(Ev());
                Ia(r) || (r = String(r || "").replace(/\s+/g, "").split(","));
                for (var w = [v], y = 0; y < r.length; y++) {
                    var x = r[y];
                    if (x.hasOwnProperty("is_regex"))
                        if (x.is_regex) try {
                            x =
                                new RegExp(x.domain)
                        } catch (B) {
                            continue
                        } else x = x.domain;
                    if (x instanceof RegExp) {
                        if (x.test(u)) return !1
                    } else {
                        var z = x;
                        if (0 != z.length) {
                            if (0 <= e(u).indexOf(z)) return !1;
                            w.push(e(z))
                        }
                    }
                }
                return !pw(u, w)
            }

            function e(u) {
                n.test(u) || (u = "http://" + u);
                return jj(lj(u), "HOST", !0)
            }

            function f(u, r, v, w) {
                switch (u) {
                    case "SUBMIT_TEXT":
                        return b(r, v, "FORM." + u, g, "formSubmitElement") || w;
                    case "LENGTH":
                        var y = b(r, v, "FORM." + u, h);
                        return void 0 === y ? w : y;
                    case "INTERACTED_FIELD_ID":
                        return l(r, v, "id", w);
                    case "INTERACTED_FIELD_NAME":
                        return l(r,
                            v, "name", w);
                    case "INTERACTED_FIELD_TYPE":
                        return l(r, v, "type", w);
                    case "INTERACTED_FIELD_POSITION":
                        var x = a(r, v, "interactedFormFieldPosition");
                        return void 0 === x ? w : x;
                    case "INTERACT_SEQUENCE_NUMBER":
                        var z = a(r, v, "interactSequenceNumber");
                        return void 0 === z ? w : z;
                    default:
                        return w
                }
            }

            function g(u) {
                switch (u.tagName.toLowerCase()) {
                    case "input":
                        return hc(u, "value");
                    case "button":
                        return ic(u);
                    default:
                        return null
                }
            }

            function h(u) {
                if ("form" === u.tagName.toLowerCase() && u.elements) {
                    for (var r = 0, v = 0; v < u.elements.length; v++) Br(u.elements[v]) &&
                        r++;
                    return r
                }
            }

            function l(u, r, v, w) {
                var y = a(u, r, "interactedFormField");
                return y && hc(y, v) || w
            }
            var n = /^https?:\/\//i,
                p = {},
                q = [],
                t = {
                    ATTRIBUTE: "elementAttribute",
                    CLASSES: "elementClasses",
                    ELEMENT: "element",
                    ID: "elementId",
                    HISTORY_CHANGE_SOURCE: "historyChangeSource",
                    HISTORY_NEW_STATE: "newHistoryState",
                    HISTORY_NEW_URL_FRAGMENT: "newUrlFragment",
                    HISTORY_OLD_STATE: "oldHistoryState",
                    HISTORY_OLD_URL_FRAGMENT: "oldUrlFragment",
                    TARGET: "elementTarget"
                };
            (function(u) {
                Z.__aev = u;
                Z.__aev.m = "aev";
                Z.__aev.isVendorTemplate = !0;
                Z.__aev.priorityOverride = 0
            })(function(u) {
                var r = u.vtp_gtmEventId,
                    v = u.vtp_defaultValue,
                    w = u.vtp_varType,
                    y;
                u.vtp_gtmCachedValues && (y = u.vtp_gtmCachedValues.gtm);
                switch (w) {
                    case "TAG_NAME":
                        var x = a(y, r, "element");
                        return x && x.tagName || v;
                    case "TEXT":
                        return b(y, r, w, ic) || v;
                    case "URL":
                        var z;
                        a: {
                            var B = String(a(y, r, "elementUrl") || v || ""),
                                C = lj(B),
                                F = String(u.vtp_component || "URL");
                            switch (F) {
                                case "URL":
                                    z = B;
                                    break a;
                                case "IS_OUTBOUND":
                                    z = d(B, u.vtp_affiliatedDomains);
                                    break a;
                                default:
                                    z = jj(C, F, u.vtp_stripWww, u.vtp_defaultPages, u.vtp_queryKey)
                            }
                        }
                        return z;
                    case "ATTRIBUTE":
                        var D;
                        if (void 0 === u.vtp_attribute) D = c(y, r, w, v);
                        else {
                            var E = u.vtp_attribute,
                                O = a(y, r, "element");
                            D = O && hc(O, E) || v || ""
                        }
                        return D;
                    case "MD":
                        var M = u.vtp_mdValue,
                            N = b(y, r, "MD", xv);
                        return M && N ? Av(N, M) || v : N || v;
                    case "FORM":
                        return f(String(u.vtp_component || "SUBMIT_TEXT"), y, r, v);
                    default:
                        var P = c(y, r, w, v);
                        Qv(P, "aev", u.vtp_gtmEventId);
                        return P
                }
            })
        }();

    Z.h.gas = ["google"],
        function() {
            (function(a) {
                Z.__gas = a;
                Z.__gas.m = "gas";
                Z.__gas.isVendorTemplate = !0;
                Z.__gas.priorityOverride = 0
            })(function(a) {
                var b = J(a),
                    c = b;
                c[qe.sb] = null;
                c[qe.fi] = null;
                var d = b = c;
                d.vtp_fieldsToSet = d.vtp_fieldsToSet || [];
                var e = d.vtp_cookieDomain;
                void 0 !== e && (d.vtp_fieldsToSet.push({
                    fieldName: "cookieDomain",
                    value: e
                }), delete d.vtp_cookieDomain);
                return b
            })
        }();

    Z.h.hl = ["google"],
        function() {
            function a(f) {
                return f.target && f.target.location && f.target.location.href ? f.target.location.href : Ev()
            }

            function b(f, g) {
                fc(f, "hashchange", function(h) {
                    var l = a(h);
                    g({
                        source: "hashchange",
                        state: null,
                        url: Gv(l),
                        P: Fv(l)
                    })
                })
            }

            function c(f, g) {
                fc(f, "popstate", function(h) {
                    var l = a(h);
                    g({
                        source: "popstate",
                        state: h.state,
                        url: Gv(l),
                        P: Fv(l)
                    })
                })
            }

            function d(f, g, h) {
                var l = g.history,
                    n = l[f];
                if (Ga(n)) try {
                    l[f] = function(p, q, t) {
                        n.apply(l, [].slice.call(arguments, 0));
                        h({
                            source: f,
                            state: p,
                            url: Gv(Ev()),
                            P: Fv(Ev())
                        })
                    }
                } catch (p) {}
            }

            function e() {
                var f = {
                    source: null,
                    state: W("history").state || null,
                    url: Gv(Ev()),
                    P: Fv(Ev())
                };
                return function(g) {
                    var h = f,
                        l = {};
                    l[h.source] = !0;
                    l[g.source] = !0;
                    if (!l.popstate || !l.hashchange || h.P != g.P) {
                        var n = {
                            event: "gtm.historyChange",
                            "gtm.historyChangeSource": g.source,
                            "gtm.oldUrlFragment": f.P,
                            "gtm.newUrlFragment": g.P,
                            "gtm.oldHistoryState": f.state,
                            "gtm.newHistoryState": g.state,
                            "gtm.oldUrl": f.url,
                            "gtm.newUrl": g.url
                        };
                        f = g;
                        Iv(n)
                    }
                }
            }(function(f) {
                Z.__hl = f;
                Z.__hl.m = "hl";
                Z.__hl.isVendorTemplate = !0;
                Z.__hl.priorityOverride = 0
            })(function(f) {
                var g = W("self");
                if (!Nv("hl")) {
                    var h = e();
                    b(g, h);
                    c(g, h);
                    d("pushState", g, h);
                    d("replaceState", g, h);
                    Ov("hl")
                }
                I(f.vtp_gtmOnSuccess)
            })
        }();
    Z.h.awct = ["google"],
        function() {
            var a = !1;
            var b = !1,
                c = [],
                d = function(h) {
                    var l = W("google_trackConversion"),
                        n = h.gtm_onFailure;
                    "function" == typeof l ? l(h) || n() : n()
                },
                e = function() {
                    for (; 0 < c.length;) d(c.shift())
                },
                f = function() {
                    return function() {
                        e();
                        b = !1
                    }
                },
                g = function() {
                    return function() {
                        e();
                        c = {
                            push: d
                        };
                    }
                };
            (function(h) {
                Z.__awct = h;
                Z.__awct.m = "awct";
                Z.__awct.isVendorTemplate = !0;
                Z.__awct.priorityOverride = 0
            })(function(h) {
                function l(V) {
                    E.google_gtm_experiments = E.google_gtm_experiments || {};
                    E.google_gtm_experiments[V] = !0
                }

                function n(V, ea, na) {
                    return "DATA_LAYER" === V ? Hv(na) : h[ea]
                }

                function p() {
                    L("gdpr_consent", Ao()), L("gdpr", Co());
                }

                function q() {
                    if (uj(h.vtp_conversionId)) {
                        var V = cb(),
                            ea = Aj();
                        if (0 !== ea.elements.length) {
                            for (var na = [], wa = [], La = 0; La < ea.elements.length; ++La) {
                                var Wa = ea.elements[La];
                                na.push(Wa.querySelector);
                                wa.push(Bj(Wa))
                            }
                            var Md = cb();
                            L("ec_sel", na.join(","));
                            L("ec_meta", wa.join(","));
                            L("ec_lat", String(Md - V));
                            L("ec_s", ea.status)
                        }
                    }
                }

                function t() {
                    if (h.vtp_enableEnhancedConversion) {
                        var V;
                        void 0 === h.vtp_dataSource ? V = h.vtp_cssProvidedEnhancedConversionValue ||
                            h.vtp_enhancedConversionObject : "DATA_OBJECT" === h.vtp_dataSource ? V = h.vtp_enhancedConversionObject : "INDIVIDUAL_FIELDS" === h.vtp_dataSource && (V = h.vtp_cssProvidedEnhancedConversionValue);
                        if (V) return {
                            enhanced_conversions_mode: "manual",
                            enhanced_conversions_manual_var: V
                        }
                    }
                }

                function u(V) {
                    var ea = [];
                    if (V) {
                        q();
                        if (r) {
                            var na = {};
                            h.vtp_conversionCookiePrefix && (na.prefix = h.vtp_conversionCookiePrefix);
                            jk(na);
                            L("auid", gk[hk(na.prefix)])
                        }
                    }
                    if ((h.vtp_enableEnhancedConversions || h.vtp_enableEnhancedConversion) && V) {
                        var La = Il(t());
                        La && ea.push(La.then(function(Wa) {
                            L("em", Wa.Kc);
                            L("ec_mode", Wa.Te)
                        }))
                    }
                    if (ea.length) try {
                        Promise.all(ea).then(function() {
                            c.push(E)
                        });
                        return
                    } catch (Wa) {}
                    c.push(E)
                }
                var r = !h.hasOwnProperty("vtp_enableConversionLinker") || !!h.vtp_enableConversionLinker,
                    v = !!h.vtp_enableEnhancedConversions || !!h.vtp_enableEnhancedConversion;
                if (a) {} else {
                    gm();
                    var E = {
                            google_basket_transaction_type: "purchase",
                            google_conversion_domain: "",
                            google_conversion_id: h.vtp_conversionId,
                            google_conversion_label: h.vtp_conversionLabel,
                            google_conversion_value: h.vtp_conversionValue || 0,
                            google_remarketing_only: !1,
                            onload_callback: h.vtp_gtmOnSuccess,
                            gtm_onFailure: h.vtp_gtmOnFailure,
                            google_gtm: Wn()
                        },
                        O = Nl();
                    O && l("apcm");
                    if (!O) {
                        l("capi");
                    }
                    h.vtp_rdp && (E.google_restricted_data_processing = !0);
                    void 0 != Hv(R.V) && !1 !== Hv(R.V) && (E.google_gtm_url_processor = function(V) {
                        return V = Jl(V)
                    });
                    var M = function(V) {
                            return function(ea, na, wa) {
                                var La = n(V, na, wa);
                                La && (E[ea] = La)
                            }
                        },
                        N = M("JSON");
                    N("google_conversion_currency",
                        "vtp_currencyCode");
                    N("google_conversion_order_id", "vtp_orderId");
                    h.vtp_enableProductReporting && (N = M(h.vtp_productReportingDataSource), N("google_conversion_merchant_id", "vtp_awMerchantId", "aw_merchant_id"), N("google_basket_feed_country", "vtp_awFeedCountry", "aw_feed_country"), N("google_basket_feed_language", "vtp_awFeedLanguage", "aw_feed_language"), N("google_basket_discount", "vtp_discount", "discount"), N("google_conversion_items", "vtp_items", "items"), E.google_conversion_items && E.google_conversion_items.map &&
                        (E.google_conversion_items = E.google_conversion_items.map(function(V) {
                            return {
                                value: V.price,
                                quantity: V.quantity,
                                item_id: V.id
                            }
                        })));
                    var P = function(V, ea) {
                            (E.google_additional_params = E.google_additional_params || {})[V] = ea
                        },
                        L = function(V, ea) {
                            void 0 !== ea && ((E.google_additional_conversion_params = E.google_additional_conversion_params || {})[V] = ea)
                        },
                        K = function(V) {
                            return function(ea, na, wa, La) {
                                var Wa = n(V, na, wa);
                                La(Wa) && L(ea, Wa)
                            }
                        };
                    var ba = Hv("developer_id"),
                        X =
                        lb(Gc(ba) ? ba : {});
                    X && L("did", X);
                    (function() {
                        if (!h.vtp_enableShippingData) return;
                        L("delopc", h.vtp_deliveryPostalCode);
                        L("oedeld", h.vtp_estimatedDeliveryDate);
                        L("delc", h.vtp_deliveryCountry);
                        L("shf", h.vtp_shippingFee);
                        if (h.vtp_enableProductReporting) {
                            var V = n(h.vtp_productReportingDataSource, "vtp_items", "items");
                            L("iedeld", Ml(V))
                        }
                    })();
                    h.vtp_transportUrl &&
                        (E.google_transport_url = h.vtp_transportUrl);
                    var fa = Pn(h.vtp_transportUrl, "/pagead/conversion_async.js");
                    fa || (fa = Ll() ? "https://www.google.com/pagead/conversion_async.js" : "//www.googleadservices.com/pagead/conversion_async.js");
                    h.vtp_enableNewCustomerReporting && (N = K(h.vtp_newCustomerReportingDataSource), N("vdnc", "vtp_awNewCustomer", "new_customer", function(V) {
                        return void 0 != V && "" !== V
                    }), N("vdltv", "vtp_awCustomerLTV", "customer_lifetime_value", function(V) {
                        return void 0 != V && "" !== V
                    }));
                    r ? (h.vtp_conversionCookiePrefix &&
                        (E.google_gcl_cookie_prefix = h.vtp_conversionCookiePrefix), E.google_read_gcl_cookie_opt_out = !1) : E.google_read_gcl_cookie_opt_out = !0;
                    "1" === Nk(!1)._up && L("gtm_up", "1");
                    p();
                    (function() {})();
                    (function() {
                        var V = !1;
                        !lh() || V ? u(!0) : Bh(function() {
                            p();
                            var ea = wh(R.C),
                                na = void 0 != Hv(R.V) && !1 !== Hv(R.V),
                                wa = !1;
                            wa = !0;
                            h.vtp_transportUrl || ea || !na && !wa || (E.google_transport_url = "https://pagead2.googlesyndication.com/");
                            L("gcs", xh());
                            mh() && L("gcd", yh());
                            u(ea);
                            ea || Ah(function() {
                                E = J(E);
                                p();
                                !h.vtp_transportUrl && E.google_transport_url && delete E.google_transport_url;
                                L("gcs", xh());
                                mh() && L("gcd", yh());
                                L("gcu", "1");
                                u(!0)
                            }, R.C)
                        }, [R.C])
                    })();
                    b || (b = !0, U(fa, g(), f(fa)))
                }
            })
        }();
    Z.h.remm = ["google"],
        function() {
            (function(a) {
                Z.__remm = a;
                Z.__remm.m = "remm";
                Z.__remm.isVendorTemplate = !0;
                Z.__remm.priorityOverride = 0
            })(function(a) {
                for (var b = a.vtp_input, c = a.vtp_map || [], d = a.vtp_fullMatch, e = a.vtp_ignoreCase ? "gi" : "g", f = a.vtp_defaultValue, g = 0; g < c.length; g++) {
                    var h = c[g].key || "";
                    d && (h = "^" + h + "$");
                    var l = new RegExp(h, e);
                    if (l.test(b)) {
                        var n = c[g].value;
                        a.vtp_replaceAfterMatch && (n = String(b).replace(l, n));
                        f = n;
                        break
                    }
                }
                Qv(f, "remm", a.vtp_gtmEventId);
                return f
            })
        }();




    Z.h.paused = [],
        function() {
            (function(a) {
                Z.__paused = a;
                Z.__paused.m = "paused";
                Z.__paused.isVendorTemplate = !0;
                Z.__paused.priorityOverride = 0
            })(function(a) {
                I(a.vtp_gtmOnFailure)
            })
        }();

    Z.h.html = ["customScripts"],
        function() {
            function a(d, e, f, g) {
                return function() {
                    try {
                        if (0 < e.length) {
                            var h = e.shift(),
                                l = a(d, e, f, g);
                            if ("SCRIPT" == String(h.nodeName).toUpperCase() && "text/gtmscript" == h.type) {
                                var n = H.createElement("script");
                                n.async = !1;
                                n.type = "text/javascript";
                                n.id = h.id;
                                n.text = h.text || h.textContent || h.innerHTML || "";
                                h.charset && (n.charset = h.charset);
                                var p = h.getAttribute("data-gtmsrc");
                                p && (n.src = p, Zb(n, l));
                                d.insertBefore(n, null);
                                p || l()
                            } else if (h.innerHTML && 0 <= h.innerHTML.toLowerCase().indexOf("<script")) {
                                for (var q = []; h.firstChild;) q.push(h.removeChild(h.firstChild));
                                d.insertBefore(h, null);
                                a(h, q, l, g)()
                            } else d.insertBefore(h, null), l()
                        } else f()
                    } catch (t) {
                        I(g)
                    }
                }
            }
            var c = function(d) {
                if (H.body) {
                    var e =
                        d.vtp_gtmOnFailure,
                        f = Rv(d.vtp_html, d.vtp_gtmOnSuccess, e),
                        g = f.aj,
                        h = f.onSuccess;
                    if (d.vtp_useIframe) {} else d.vtp_supportDocumentWrite ? b(g, h, e) : a(H.body, jc(g), h, e)()
                } else Cv(function() {
                        c(d)
                    },
                    200)
            };
            Z.__html = c;
            Z.__html.m = "html";
            Z.__html.isVendorTemplate = !0;
            Z.__html.priorityOverride = 0
        }();








    Z.h.lcl = [],
        function() {
            function a() {
                var c = W("document"),
                    d = 0,
                    e = function(f) {
                        var g = f.target;
                        if (g && 3 !== f.which && !(f.af || f.timeStamp && f.timeStamp === d)) {
                            d = f.timeStamp;
                            g = kc(g, ["a", "area"], 100);
                            if (!g) return f.returnValue;
                            var h = f.defaultPrevented || !1 === f.returnValue,
                                l = yr("lcl", h ? "nv.mwt" : "mwt", 0),
                                n;
                            n = h ? yr("lcl", "nv.ids", []) : yr("lcl", "ids", []);
                            if (n.length) {
                                var p = ur(g, "gtm.linkClick", n);
                                if (b(f, g, c) && !h && l && g.href) {
                                    var q = !!Ka(String(mc(g, "rel") || "").split(" "), function(v) {
                                        return "noreferrer" === v.toLowerCase()
                                    });
                                    q && Vg(36);
                                    var t = W((mc(g, "target") || "_self").substring(1)),
                                        u = !0,
                                        r = hv(function() {
                                            var v;
                                            if (v = u && t) {
                                                var w;
                                                a: if (q) {
                                                    var y;
                                                    try {
                                                        y = new MouseEvent(f.type, {
                                                            bubbles: !0
                                                        })
                                                    } catch (x) {
                                                        if (!c.createEvent) {
                                                            w = !1;
                                                            break a
                                                        }
                                                        y = c.createEvent("MouseEvents");
                                                        y.initEvent(f.type, !0, !0)
                                                    }
                                                    y.af = !0;
                                                    f.target.dispatchEvent(y);
                                                    w = !0
                                                } else w = !1;
                                                v = !w
                                            }
                                            v && (t.location.href = mc(g, "href"))
                                        }, l);
                                    if (Iv(p, r, l)) u = !1;
                                    else return f.preventDefault && f.preventDefault(), f.returnValue = !1
                                } else Iv(p, function() {}, l || 2E3);
                                return !0
                            }
                        }
                    };
                fc(c, "click", e, !1);
                fc(c, "auxclick",
                    e, !1)
            }

            function b(c, d, e) {
                if (2 === c.which || c.ctrlKey || c.shiftKey || c.altKey || c.metaKey) return !1;
                var f = mc(d, "href"),
                    g = f.indexOf("#"),
                    h = mc(d, "target");
                if (h && "_self" !== h && "_parent" !== h && "_top" !== h || 0 === g) return !1;
                if (0 < g) {
                    var l = Gv(f),
                        n = Gv(e.location);
                    return l !== n
                }
                return !0
            }(function(c) {
                Z.__lcl = c;
                Z.__lcl.m = "lcl";
                Z.__lcl.isVendorTemplate = !0;
                Z.__lcl.priorityOverride = 0
            })(function(c) {
                var d = void 0 === c.vtp_waitForTags ? !0 : c.vtp_waitForTags,
                    e = void 0 === c.vtp_checkValidation ? !0 : c.vtp_checkValidation,
                    f = Number(c.vtp_waitForTagsTimeout);
                if (!f || 0 >= f) f = 2E3;
                var g = c.vtp_uniqueTriggerId || "0";
                if (d) {
                    var h = function(n) {
                        return Math.max(f, n)
                    };
                    xr("lcl", "mwt", h, 0);
                    e || xr("lcl", "nv.mwt", h, 0)
                }
                var l = function(n) {
                    n.push(g);
                    return n
                };
                xr("lcl", "ids", l, []);
                e || xr("lcl", "nv.ids", l, []);
                Nv("lcl") || (a(), Ov("lcl"));
                I(c.vtp_gtmOnSuccess)
            })
        }();
    var rz = {};
    rz.macro = function(a) {
        if (ov.Ge.hasOwnProperty(a)) return ov.Ge[a]
    }, rz.onHtmlSuccess = ov.zg(!0), rz.onHtmlFailure = ov.zg(!1);
    rz.dataLayer = Li;
    rz.callback = function(a) {
        Bi.hasOwnProperty(a) && Ga(Bi[a]) && Bi[a]();
        delete Bi[a]
    };
    rz.bootstrap = 0;
    rz._spx = !1;

    function sz() {
        S[tf.J] = rz;
        fb(Ci, Z.h);
        $e = $e || ov;
        af = pf
    }

    function tz() {
        var a = !1;
        a && hm("INIT");
        $g().o();
        S = m.google_tag_manager = m.google_tag_manager || {};
        zo();
        Wk.enable_gbraid_cookie_write = !0;
        var b = !!S[tf.J];
        if (b) {
            var c = S.zones;
            c && c.unregisterChild(tf.J);
        } else {
            for (var d = data.resource || {}, e = d.macros || [], f = 0; f < e.length; f++) Te.push(e[f]);
            for (var g = d.tags || [], h = 0; h < g.length; h++) We.push(g[h]);
            for (var l = d.predicates || [], n = 0; n < l.length; n++) Ve.push(l[n]);
            for (var p = d.rules || [], q = 0; q < p.length; q++) {
                for (var t = p[q], u = {}, r = 0; r < t.length; r++) u[t[r][0]] = Array.prototype.slice.call(t[r], 1);
                Ue.push(u)
            }
            Ye = Z;
            Ze = ut;
            var v = data.permissions || {},
                w = data.sandboxed_scripts,
                y = data.security_groups;
            uu();
            xf = new wf(v);
            if (void 0 !== w)
                for (var x = ["sandboxedScripts"], z = 0; z < w.length; z++) {
                    var B = w[z].replace(/^_*/, "");
                    Ci[B] = x
                }
            xu(y);
            sz();
            nv();
            Vl = !1;
            Wl = 0;
            if ("interactive" ==
                H.readyState && !H.createEventObject || "complete" == H.readyState) Yl();
            else {
                fc(H, "DOMContentLoaded", Yl);
                fc(H, "readystatechange", Yl);
                if (H.createEventObject && H.documentElement.doScroll) {
                    var C = !0;
                    try {
                        C = !m.frameElement
                    } catch (M) {}
                    C && Zl()
                }
                fc(m, "load", Yl)
            }
            gt = !1;
            "complete" === H.readyState ? it() : fc(m, "load", it);
            dn &&
                m.setInterval(Ym, 864E5);
            zi = (new Date).getTime();
            if (a) {
                var O = im("INIT");
            }
        }
    }
    (function(a) {
        function b(u) {
            if (null == u || 0 === u.length) return !1;
            var r = Number(u),
                v = cb();
            return r < v + 3E5 && r > v - 9E5
        }
        if (!m["__TAGGY_INSTALLED"]) {
            var c = !1;
            if (H.referrer) {
                var d = lj(H.referrer);
                c = "cct.google" === ij(d, "host")
            }
            if (!c) {
                var e = Nj("googTaggyReferrer");
                c = e.length && e[0].length
            }
            c && (m["__TAGGY_INSTALLED"] = !0, bc("https://cct.google/taggy/agent.js"))
        }
        var g = function(u) {
                var r = "GTM",
                    v = "GTM";
                var w = m["google.tagmanager.debugui2.queue"];
                w || (w = [], m["google.tagmanager.debugui2.queue"] = w, bc("https://" + tf.Td + "/debug/bootstrap?id=" + tf.J + "&src=" + v +
                    "&cond=" + u + "&gtm=" + Wn()));
                var y = {
                    messageType: "CONTAINER_STARTING",
                    data: {
                        scriptSource: Wb,
                        containerProduct: r,
                        debug: !1,
                        id: tf.J
                    }
                };
                y.data.resume = function() {
                    a()
                };
                tf.th && (y.data.initialPublish = !0);
                w.push(y)
            },
            h = void 0,
            l = jj(m.location, "query", !1, void 0, "gtm_debug"),
            n = !0;
        n = !1;
        n && "x" === l && (h = 1);
        !h && b(l) && (h = 2);
        if (!h && H.referrer) {
            var p = lj(H.referrer);
            "tagassistant.google.com" ===
            ij(p, "host") && (h = 3)
        }
        if (!h) {
            var q = Nj("__TAG_ASSISTANT");
            q.length && q[0].length && (h = 4)
        }
        if (!h && H.documentElement.hasAttribute("data-tag-assistant-present")) {
            h = 5;
            var t = H.documentElement.getAttribute("data-tag-assistant-present");
            h = b(t) ? 5 : void 0;
        }
        h && Wb ? g(h) : a()
    })(tz);

})()