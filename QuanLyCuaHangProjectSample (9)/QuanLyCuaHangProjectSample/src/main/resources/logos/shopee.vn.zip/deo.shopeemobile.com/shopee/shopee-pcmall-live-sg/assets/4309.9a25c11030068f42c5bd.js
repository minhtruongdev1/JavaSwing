(("undefined" != typeof self ? self : this).webpackChunkshopee_pc = ("undefined" != typeof self ? self : this).webpackChunkshopee_pc || []).push([
    [4309], {
        67360: function(e, t, a) {
            "use strict";
            a.d(t, {
                fE: function() {
                    return B
                },
                PR: function() {
                    return R
                },
                ZP: function() {
                    return J
                }
            });
            var n = a(27378),
                r = a.n(n),
                o = a(60042),
                l = a.n(o),
                i = a(88289);

            function s() {
                return (s = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var a = arguments[t];
                        for (var n in a) Object.prototype.hasOwnProperty.call(a, n) && (e[n] = a[n])
                    }
                    return e
                }).apply(this, arguments)
            }
            var c = function(e) {
                return r().createElement("svg", s({
                    viewBox: "0 0 25 68.1"
                }, e), r().createElement("path", {
                    fillRule: "evenodd",
                    strokeLinecap: "round",
                    strokeWidth: ".945",
                    d: "M12.1 18.4v49.7H25V0L0 13v11.9l12.1-6.5z"
                }))
            };

            function m() {
                return (m = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var a = arguments[t];
                        for (var n in a) Object.prototype.hasOwnProperty.call(a, n) && (e[n] = a[n])
                    }
                    return e
                }).apply(this, arguments)
            }
            var u = function(e) {
                return r().createElement("svg", m({
                    viewBox: "0 0 42.3 67.703"
                }, e), r().createElement("path", {
                    fillRule: "evenodd",
                    strokeLinecap: "round",
                    strokeWidth: ".945",
                    d: "M21.6 56.403l12.5-18.3c5.081-7.491 7.492-12.684 8.063-17.877a22.986 22.986 0 0 0 .137-2.523A17.062 17.062 0 0 0 30.133 1.242 24.304 24.304 0 0 0 22.3.003a23.551 23.551 0 0 0-9.787 1.948C5.323 5.212 1.199 12.42 1.199 22.443a36.776 36.776 0 0 0 .001.26H13a70.067 70.067 0 0 1 .052-1.368c.118-2.398.351-3.497.948-5.032a7.181 7.181 0 0 1 5.187-4.431 9.74 9.74 0 0 1 2.313-.269c4.599 0 7.899 3.099 7.9 7.398a5.467 5.467 0 0 1 0 .002 11.162 11.162 0 0 1-.092 1.496c-.29 2.167-1.352 4.335-4.331 9.011a261.731 261.731 0 0 1-1.677 2.593L0 67.703h40.5v-11.3H21.6z"
                }))
            };

            function d() {
                return (d = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var a = arguments[t];
                        for (var n in a) Object.prototype.hasOwnProperty.call(a, n) && (e[n] = a[n])
                    }
                    return e
                }).apply(this, arguments)
            }
            var p = function(e) {
                return r().createElement("svg", d({
                    viewBox: "0 0 43 67"
                }, e), r().createElement("path", {
                    fillRule: "evenodd",
                    strokeLinecap: "round",
                    strokeWidth: ".945",
                    d: "M22.5 11L7.3 31.3l7.2 6.1c1.9-1.2 3.8-1.7 6.1-1.7a10.732 10.732 0 0 1 5.741 1.573c2.816 1.762 4.559 4.87 4.559 8.627a10.175 10.175 0 0 1-2.626 6.924A10.165 10.165 0 0 1 20.7 56.1c-4.086 0-7.199-2.156-8.584-5.887A12.3 12.3 0 0 1 11.5 47.8L0 48.2c.595 4.955 1.386 7.553 3.347 10.52a24.795 24.795 0 0 0 .053.08 19.859 19.859 0 0 0 13.535 8.466A24.541 24.541 0 0 0 21 67.6c11.745 0 20.628-8.083 22.012-19.459A25.999 25.999 0 0 0 43.2 45a22.484 22.484 0 0 0-2.049-9.694c-2.825-5.949-8.41-9.794-15.751-10.406L43.9 0H3.3v11h19.2z"
                }))
            };

            function C() {
                return (C = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var a = arguments[t];
                        for (var n in a) Object.prototype.hasOwnProperty.call(a, n) && (e[n] = a[n])
                    }
                    return e
                }).apply(this, arguments)
            }
            var _ = function(e) {
                return r().createElement("svg", C({
                    viewBox: "0 0 42.9 66.9"
                }, e), r().createElement("path", {
                    fillRule: "evenodd",
                    strokeLinecap: "round",
                    strokeWidth: ".945",
                    d: "M24.5 53.2v13.7h12.3V53.2h6.1v-11h-6.1V0H23.4L0 42.5v10.7h24.5zm0-11h-14l14-24.8v24.8z"
                }))
            };

            function f() {
                return (f = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var a = arguments[t];
                        for (var n in a) Object.prototype.hasOwnProperty.call(a, n) && (e[n] = a[n])
                    }
                    return e
                }).apply(this, arguments)
            }
            var h = function(e) {
                return r().createElement("svg", f({
                    viewBox: "0 0 42.8 67.6"
                }, e), r().createElement("path", {
                    fillRule: "evenodd",
                    strokeLinecap: "round",
                    strokeWidth: ".945",
                    d: "M15.2 11.6h22.3V0h-34v39.5h8.4a13.796 13.796 0 0 1 2.081-2.256A9.364 9.364 0 0 1 20.4 35c5.6 0 9.9 4.5 9.9 10.3 0 5.8-4.3 10.2-9.8 10.2a9.594 9.594 0 0 1-3.975-.775c-2.283-1.024-3.971-3.081-5.231-6.281a22.17 22.17 0 0 1-.094-.244L0 52.4a62.066 62.066 0 0 0 .565 1.425c1.46 3.548 2.682 5.38 4.659 7.484a37.124 37.124 0 0 0 .276.291 21.422 21.422 0 0 0 13.729 5.945 25.179 25.179 0 0 0 1.671.055 21.976 21.976 0 0 0 13.258-4.2c4.31-3.202 7.279-8.057 8.275-13.942A26.715 26.715 0 0 0 42.8 45c0-11.9-8.3-20.9-19.4-20.9a20.186 20.186 0 0 0-2.2.112c-1.856.203-3.576.691-5.716 1.57a41.606 41.606 0 0 0-.284.118V11.6z"
                }))
            };

            function v() {
                return (v = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var a = arguments[t];
                        for (var n in a) Object.prototype.hasOwnProperty.call(a, n) && (e[n] = a[n])
                    }
                    return e
                }).apply(this, arguments)
            }
            var g = function(e) {
                return r().createElement("svg", v({
                    viewBox: "0 0 43.402 67.6"
                }, e), r().createElement("path", {
                    fillRule: "evenodd",
                    strokeLinecap: "round",
                    strokeWidth: ".945",
                    d: "M38.501 0h-14.6l-16.6 26.2a87.112 87.112 0 0 0-2.841 4.806C1.956 35.606.636 39.352.184 43.098A25.786 25.786 0 0 0 .001 46.2c0 11.983 8.875 21.071 20.561 21.391a23.329 23.329 0 0 0 .639.009c12.3 0 22.2-9.9 22.2-22.2a20.356 20.356 0 0 0-5.04-13.557 17.916 17.916 0 0 0-13.46-6.143c-1.043 0-1.817.09-3.26.526a26.98 26.98 0 0 0-.24.074L38.501 0zm-7.326 44.352a9.309 9.309 0 0 0-9.274-8.052 10.442 10.442 0 0 0-.638.019A9.653 9.653 0 0 0 12.101 46a10.844 10.844 0 0 0 .031.817c.196 2.596 1.324 4.831 3.063 6.396a9.473 9.473 0 0 0 6.406 2.387c5.4 0 9.7-4.3 9.7-9.6a10.703 10.703 0 0 0-.126-1.648z"
                }))
            };

            function b() {
                return (b = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var a = arguments[t];
                        for (var n in a) Object.prototype.hasOwnProperty.call(a, n) && (e[n] = a[n])
                    }
                    return e
                }).apply(this, arguments)
            }
            var E = function(e) {
                return r().createElement("svg", b({
                    viewBox: "0 0 39.5 66.3"
                }, e), r().createElement("path", {
                    fillRule: "evenodd",
                    strokeLinecap: "round",
                    strokeWidth: ".945",
                    d: "M21.6 11.6L0 66.3h13.3L39.5 0H.1v11.6h21.5z"
                }))
            };

            function w() {
                return (w = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var a = arguments[t];
                        for (var n in a) Object.prototype.hasOwnProperty.call(a, n) && (e[n] = a[n])
                    }
                    return e
                }).apply(this, arguments)
            }
            var y = function(e) {
                return r().createElement("svg", w({
                    viewBox: "0 0 43.204 69.004"
                }, e), r().createElement("path", {
                    fillRule: "evenodd",
                    strokeLinecap: "round",
                    strokeWidth: ".945",
                    d: "M33.603 32.802a31.686 31.686 0 0 0 .79-.423c2.107-1.169 3.051-2.091 4.378-4.03a32.68 32.68 0 0 0 .032-.047c1.9-2.9 2.8-6.1 2.8-9.7 0-10.8-8.2-18.6-19.6-18.6-11.335 0-19.479 7.414-19.976 17.97a21.882 21.882 0 0 0-.024 1.03 17.926 17.926 0 0 0 1.016 6.155 13.457 13.457 0 0 0 6.884 7.645C4.606 35.049 1.434 38.971.389 44.62a24.628 24.628 0 0 0-.386 4.482c0 11.8 8.7 19.9 21.4 19.9a24.237 24.237 0 0 0 11.074-2.514c6.306-3.218 10.335-9.304 10.699-16.947a23.948 23.948 0 0 0 .027-1.139 20.81 20.81 0 0 0-.846-6.134c-1.294-4.206-4.073-7.299-8.337-9.278a20.642 20.642 0 0 0-.417-.188zm-11.9 6.1c4.9 0 9.1 4.2 9.1 9.3 0 5.1-4.1 9.2-9.2 9.2a9.644 9.644 0 0 1-5.269-1.484c-2.255-1.453-3.734-3.872-3.991-6.794a10.51 10.51 0 0 1-.04-.922 9.237 9.237 0 0 1 2.404-6.318c1.703-1.853 4.18-2.982 6.996-2.982zm.2-27.9c4.5 0 8.4 3.8 8.4 8.2 0 4.4-4 8.2-8.5 8.2-4.6 0-8.2-3.7-8.2-8.4a7.892 7.892 0 0 1 1.919-5.273c1.232-1.404 2.986-2.353 5.055-2.638a9.726 9.726 0 0 1 1.326-.089z"
                }))
            };

            function V() {
                return (V = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var a = arguments[t];
                        for (var n in a) Object.prototype.hasOwnProperty.call(a, n) && (e[n] = a[n])
                    }
                    return e
                }).apply(this, arguments)
            }
            var H = function(e) {
                return r().createElement("svg", V({
                    viewBox: "0 0 43.503 67.701"
                }, e), r().createElement("path", {
                    fillRule: "evenodd",
                    strokeLinecap: "round",
                    strokeWidth: ".945",
                    d: "M5.501 67.701h14.4l16.4-26.1c4.512-7.165 6.676-12.531 7.115-17.896a25.743 25.743 0 0 0 .085-2.104c0-11.759-8.183-20.64-19.519-21.527a24.115 24.115 0 0 0-1.881-.073c-12.5 0-22.1 9.5-22.1 22 0 11.3 8.3 19.9 19.3 19.9.851 0 1.523-.089 2.777-.352a55.135 55.135 0 0 0 .223-.048l-16.8 26.2zm25.797-46.447a9.47 9.47 0 0 0-9.297-9.353 10.339 10.339 0 0 0-.503.013 9.524 9.524 0 0 0-9.197 9.487c0 5.4 4.1 9.6 9.4 9.6 2.785 0 5.25-1.09 6.985-2.886a9.421 9.421 0 0 0 2.615-6.614 10.005 10.005 0 0 0-.003-.247z",
                    vectorEffect: "non-scaling-stroke"
                }))
            };

            function L() {
                return (L = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var a = arguments[t];
                        for (var n in a) Object.prototype.hasOwnProperty.call(a, n) && (e[n] = a[n])
                    }
                    return e
                }).apply(this, arguments)
            }
            var N = function(e) {
                return r().createElement("svg", L({
                    viewBox: "0 0 41.701 69.001"
                }, e), r().createElement("path", {
                    fillRule: "evenodd",
                    strokeLinecap: "round",
                    strokeWidth: ".945",
                    d: "M.001 23.201v21.3a86.087 86.087 0 0 0 .141 5.239c.24 3.911.8 6.807 1.788 9.131a13.986 13.986 0 0 0 3.071 4.53c3.183 3.183 8.009 5.116 13.716 5.52a32.308 32.308 0 0 0 2.284.08 27.934 27.934 0 0 0 6.391-.693c2.999-.704 5.593-1.942 7.767-3.697a17.608 17.608 0 0 0 1.042-.91 16.219 16.219 0 0 0 4.725-8.397c.365-1.533.594-3.225.702-5.11a47.264 47.264 0 0 0 .073-2.693v-25.9c0-4.153-.458-7.389-1.5-10.073a15.929 15.929 0 0 0-4.5-6.327A20.063 20.063 0 0 0 26.805.689a27.077 27.077 0 0 0-6.204-.688c-6.7 0-12.5 2.2-16.1 6.2C1.536 9.443.202 13.886.022 21.359a76.328 76.328 0 0 0-.021 1.842zm29.1-.6v23.2a49.403 49.403 0 0 1-.043 2.168c-.07 1.589-.23 2.783-.497 3.768a8.197 8.197 0 0 1-.86 2.064 7.193 7.193 0 0 1-3.81 2.919 8.858 8.858 0 0 1-2.89.481 8.941 8.941 0 0 1-5.066-1.538 6.167 6.167 0 0 1-1.634-1.662 8.307 8.307 0 0 1-.297-.421c-.937-1.425-1.103-2.85-1.103-7.679v-22.7c0-2.681.162-4.465.54-5.847a8.234 8.234 0 0 1 .86-2.053c1.2-2.1 3.7-3.3 6.7-3.3a9.192 9.192 0 0 1 3.315.591 7.04 7.04 0 0 1 2.785 1.909 6.754 6.754 0 0 1 1.558 2.985c.316 1.252.442 2.856.442 5.115z"
                }))
            };
            var O = (0, i.Z)(c, "zoom"),
                M = (0, i.Z)(u, "zoom"),
                k = (0, i.Z)(p, "zoom"),
                x = (0, i.Z)(_, "zoom"),
                Z = (0, i.Z)(h, "zoom"),
                D = (0, i.Z)(g, "zoom"),
                T = (0, i.Z)(E, "zoom"),
                A = (0, i.Z)(y, "zoom"),
                z = (0, i.Z)(H, "zoom"),
                S = (0, i.Z)(N, "zoom"),
                j = function(e) {
                    var t = e.number,
                        a = function(e, t) {
                            if (null == e) return {};
                            var a, n, r = {},
                                o = Object.keys(e);
                            for (n = 0; n < o.length; n++) a = o[n], t.indexOf(a) >= 0 || (r[a] = e[a]);
                            return r
                        }(e, ["number"]);
                    switch (t) {
                        case 1:
                            return n.createElement(O, a);
                        case 2:
                            return n.createElement(M, a);
                        case 3:
                            return n.createElement(k, a);
                        case 4:
                            return n.createElement(x, a);
                        case 5:
                            return n.createElement(Z, a);
                        case 6:
                            return n.createElement(D, a);
                        case 7:
                            return n.createElement(T, a);
                        case 8:
                            return n.createElement(A, a);
                        case 9:
                            return n.createElement(z, a);
                        case 0:
                            return n.createElement(S, a)
                    }
                };
            var P = a(36023),
                R = {
                    COUNT_UP: -1,
                    COUNT_DOWN: 1
                },
                B = {
                    HOUR: 36e5,
                    MINUTE: 6e4,
                    SECOND: 1e3
                };

            function I(e, t) {
                return (I = Object.setPrototypeOf || function(e, t) {
                    return e.__proto__ = t, e
                })(e, t)
            }
            var G = {
                    SENARY: [0, 5, 4, 3, 2, 1, 0],
                    DECIMAL: [0, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
                },
                U = function(e) {
                    var t = e.colonState,
                        a = e.theme,
                        r = e.style;
                    return n.createElement("div", {
                        className: l()("shopee-countdown-timer__colon", "shopee-countdown-timer__colon--flashing-" + t, a && "shopee-countdown-timer__colon--" + a),
                        style: r || void 0
                    }, n.createElement("div", {
                        className: "colon-dot__wrapper"
                    }, n.createElement("span", {
                        className: "colon-dot"
                    })), n.createElement("div", {
                        className: "colon-dot__wrapper"
                    }, n.createElement("span", {
                        className: "colon-dot"
                    })))
                },
                W = function(e) {
                    var t, a;

                    function r() {
                        for (var t, a = arguments.length, n = new Array(a), r = 0; r < a; r++) n[r] = arguments[r];
                        return (t = e.call.apply(e, [this].concat(n)) || this).countdownEndTimer = 0, t.state = {
                            isCountdownEnded: 1e3 * t.props.targetTimeInSeconds - (new Date).getTime() <= 0
                        }, t.onSafariVisibilityChange = function() {
                            t.setState({
                                isCountdownEnded: document.hidden || 1e3 * t.props.targetTimeInSeconds - (new Date).getTime() <= 0
                            })
                        }, t
                    }
                    a = e, (t = r).prototype = Object.create(a.prototype), t.prototype.constructor = t, I(t, a);
                    var o = r.prototype;
                    return o.componentDidMount = function() {
                        var e = this,
                            t = 1e3 * this.props.targetTimeInSeconds - (new Date).getTime();
                        t < 2147483647 && (this.countdownEndTimer = window.setTimeout((function() {
                            e.state.isCountdownEnded || (e.setState({
                                isCountdownEnded: !0
                            }), e.props.onCountdownEnded && e.props.onCountdownEnded())
                        }), t)), (0, P.G6)() && document.addEventListener("visibilitychange", this.onSafariVisibilityChange, !1)
                    }, o.componentWillUnmount = function() {
                        clearTimeout(this.countdownEndTimer), (0, P.G6)() && document.removeEventListener("visibilitychange", this.onSafariVisibilityChange, !1)
                    }, o.render = function() {
                        var e = this.props,
                            t = e.flipRate,
                            a = e.nonFlashing,
                            r = e.flipBoardStyle,
                            o = e.colonStyle,
                            i = e.numberStyle,
                            s = e.targetTimeInSeconds,
                            c = this.state.isCountdownEnded,
                            m = +new Date,
                            u = function(e) {
                                var t = Math.floor(e / 1e3),
                                    a = Math.floor(t / 3600);
                                return t %= 3600, {
                                    hour: a || 0,
                                    minute: Math.floor(t / 60) || 0,
                                    second: t % 60 || 0
                                }
                            }(Math.max(0, (1e3 * s - m) * this.props.type)),
                            d = u.hour,
                            p = u.minute,
                            C = u.second,
                            _ = F(d, p, C),
                            f = _.hourHundDelay,
                            h = _.hourDecaDelay,
                            v = _.hourHexaDelay,
                            g = _.minuteDecaDelay,
                            b = _.minuteHexaDelay,
                            E = _.secondDecaDelay,
                            w = _.secondHexaDelay,
                            y = a ? "on" : "off";
                        return n.createElement("div", {
                            className: l()("shopee-countdown-timer", this.props.classNames)
                        }, n.createElement("div", {
                            className: "shopee-countdown-timer__number",
                            style: r || void 0
                        }, d > 99 && n.createElement("div", {
                            className: l()("shopee-countdown-timer__number__hexa", c ? "" : "shopee-countdown-timer__number__hund--hour"),
                            style: {
                                animationDelay: f
                            },
                            key: f
                        }, G.DECIMAL.map((function(e, t) {
                            return n.createElement("div", {
                                className: l()("shopee-countdown-timer__number__item"),
                                key: t
                            }, n.createElement(j, {
                                number: e,
                                iconStyle: i || void 0
                            }))
                        }))), n.createElement("div", {
                            className: l()("shopee-countdown-timer__number__hexa", c ? "" : "shopee-countdown-timer__number__hexa--hour"),
                            style: {
                                animationDelay: v
                            },
                            key: v
                        }, G.DECIMAL.map((function(e, t) {
                            return n.createElement("div", {
                                className: l()("shopee-countdown-timer__number__item"),
                                key: t
                            }, n.createElement(j, {
                                number: e,
                                iconStyle: i || void 0
                            }))
                        }))), n.createElement("div", {
                            className: l()("shopee-countdown-timer__number__deca", c ? "" : "shopee-countdown-timer__number__deca--hour"),
                            style: {
                                animationDelay: h
                            },
                            key: h
                        }, G.DECIMAL.map((function(e, t) {
                            return n.createElement("div", {
                                className: l()("shopee-countdown-timer__number__item"),
                                key: t
                            }, n.createElement(j, {
                                number: e,
                                iconStyle: i || void 0
                            }))
                        })))), t <= B.MINUTE && [n.createElement(U, {
                            key: "colon-before-minute",
                            colonState: y,
                            theme: this.props.theme,
                            style: o
                        }), n.createElement("div", {
                            key: "digit-minute",
                            className: "shopee-countdown-timer__number",
                            style: r || void 0
                        }, n.createElement("div", {
                            className: l()("shopee-countdown-timer__number__hexa", c ? "" : "shopee-countdown-timer__number__hexa--minute"),
                            style: {
                                animationDelay: b
                            },
                            key: b
                        }, G.SENARY.map((function(e, t) {
                            return n.createElement("div", {
                                className: l()("shopee-countdown-timer__number__item"),
                                key: t
                            }, n.createElement(j, {
                                number: e,
                                iconStyle: i || void 0
                            }))
                        }))), n.createElement("div", {
                            className: l()("shopee-countdown-timer__number__deca", c ? "" : "shopee-countdown-timer__number__deca--minute"),
                            style: {
                                animationDelay: g
                            },
                            key: g
                        }, G.DECIMAL.map((function(e, t) {
                            return n.createElement("div", {
                                className: l()("shopee-countdown-timer__number__item"),
                                key: t
                            }, n.createElement(j, {
                                number: e,
                                iconStyle: i || void 0
                            }))
                        }))))], t <= B.SECOND && [n.createElement(U, {
                            key: "colon-before-second",
                            colonState: y,
                            theme: this.props.theme,
                            style: o
                        }), n.createElement("div", {
                            key: "digit-second",
                            className: "shopee-countdown-timer__number",
                            style: r || void 0
                        }, n.createElement("div", {
                            className: l()("shopee-countdown-timer__number__hexa", c ? "" : "shopee-countdown-timer__number__hexa--second"),
                            style: {
                                animationDelay: w
                            },
                            key: w
                        }, G.SENARY.map((function(e, t) {
                            return n.createElement("div", {
                                className: l()("shopee-countdown-timer__number__item"),
                                key: t
                            }, n.createElement(j, {
                                number: e,
                                iconStyle: i || void 0
                            }))
                        }))), n.createElement("div", {
                            className: l()("shopee-countdown-timer__number__deca", c ? "" : "shopee-countdown-timer__number__deca--second"),
                            style: {
                                animationDelay: E
                            },
                            key: E
                        }, G.DECIMAL.map((function(e, t) {
                            return n.createElement("div", {
                                className: l()("shopee-countdown-timer__number__item"),
                                key: t
                            }, n.createElement(j, {
                                number: e,
                                iconStyle: i || void 0
                            }))
                        }))))])
                    }, r
                }(n.PureComponent);
            W.defaultProps = {
                type: R.COUNT_DOWN,
                flipRate: B.SECOND
            };
            var F = function(e, t, a) {
                    return {
                        secondDecaDelay: a % 10 - 9 + "s",
                        secondHexaDelay: a - 68 + "s",
                        minuteDecaDelay: t % 10 * 60 + a - 658 + "s",
                        minuteHexaDelay: 60 * t + a - 4198 + "s",
                        hourDecaDelay: e % 10 * 3600 + 60 * t + a - 39598 + "s",
                        hourHexaDelay: e % 100 * 3600 + 60 * t + a - 395998 + "s",
                        hourHundDelay: e % 1e3 * 3600 + 60 * t + a - 3959998 + "s"
                    }
                },
                J = W
        },
        57722: function(e, t, a) {
            "use strict";
            var n, r = a(47029);

            function o(e) {
                return "" + parseFloat(((100 - e) / 10).toFixed(1))
            }

            function l(e) {
                return "-" + e + "%"
            }
            var i = ((n = {})[r.a2["zh-Hant"]] = o, n[r.a2["zh-Hans"]] = o, n[r.a2.pl] = l, n[r.a2["es-ES"]] = l, n);
            t.Z = function(e, t) {
                if ("string" == typeof e || e instanceof String) return e;
                var a = i[t];
                return "function" == typeof a ? a(e) : function(e) {
                    return e + "%"
                }(e)
            }
        },
        51816: function(e, t, a) {
            "use strict";
            a.d(t, {
                js: function() {
                    return M
                },
                Q8: function() {
                    return B
                },
                b5: function() {
                    return T
                },
                z3: function() {
                    return w
                },
                TE: function() {
                    return E
                },
                ZM: function() {
                    return Y
                },
                tI: function() {
                    return g
                },
                l: function() {
                    return b
                },
                OO: function() {
                    return h
                },
                JA: function() {
                    return U
                },
                Cf: function() {
                    return v
                },
                VL: function() {
                    return O
                }
            });
            var n = a(27378),
                r = a.n(n),
                o = a(60042),
                l = a.n(o),
                i = a(97953),
                s = a.p + "037a843c564907ecca5b62f5f3ea1fa5.png",
                c = a.p + "483071c49603aa7163a7f51708bff61b.png",
                m = a.p + "51e62874414d9b3e8dc721d82d8fc2c1.png",
                u = a(57722),
                d = a(6976),
                p = {
                    "horizontal-badge": "_1x8-jJ",
                    "horizontal-badge--no-triangle": "_34VdaU",
                    "shopee-preferred-seller-badge": "_12TgA3",
                    "icon-tick": "JJx6wy",
                    "shopee-badge-official-shop": "UbaH27",
                    "shopee-badge-official-shop--text-label": "_1waju3",
                    "shopee-badge-official-shop--tw": "Z1iw7H",
                    "shopee-badge-official-shop--all": "_17IP43",
                    "badge-coins-back": "NpI-WE",
                    "badge-coins-back--large": "_1SADTq",
                    "badge-coins-back--standalone": "_3ah-xq",
                    "shopee-badge-wholesale": "_46SJyi",
                    "wholesale-popup": "EaJicf",
                    "icon-down-arrow-filled": "oscAjM",
                    "wholesale-popup__row": "_4Nghud",
                    "wholesale-popup__price": "_2DJclp",
                    "installment-badge": "_2rChF4",
                    "shopee-simple-badge": "tPtd76",
                    "shopee-simple-badge--rounded-square": "_1nv-y4",
                    "shopee-simple-badge--primary": "_2S1UlU",
                    "shopee-simple-badge--round": "_2m47AD",
                    "shopee-badge": "_3iRehQ",
                    "shopee-badge--fixed-width": "_36vTKx",
                    "shopee-badge--promotion": "_2xY8te",
                    "shopee-badge--promotion__label-wrapper": "_2TDZGE",
                    "shopee-badge--promotion__label-wrapper--zh-Hant": "_1_rpwN",
                    "shopee-badge--promotion__label-wrapper--th": "_26VpFE",
                    "shopee-badge--promotion__label-wrapper--pl": "u-N6Aa",
                    "shopee-badge--promotion__label-wrapper--es-ES": "_3cGNur",
                    "shopee-badge--promotion__label-wrapper__off-label": "_17XqBU",
                    "shopee-badge--promotion__label-wrapper__off-label--zh-Hant": "_1mAUMg",
                    "shopee-badge--promotion__label-wrapper__off-label--pl": "lvVj9u",
                    "shopee-badge--promotion__label-wrapper__off-label--es-ES": "Hy2Ai6",
                    "official-shop-new-badge--tw": "_2QEBil",
                    "official-shop-new-badge--br": "_2u_38J",
                    "official-shop-new-badge--all": "qutJvu"
                },
                C = (0, d.of)(),
                _ = (0, d.Kd)(),
                f = function(e) {
                    var t = e.badgeType,
                        a = e.children;
                    return n.createElement("div", {
                        className: l()(p["shopee-badge"], p["shopee-badge--fixed-width"], p["shopee-badge--" + t], "shopee-badge")
                    }, a)
                },
                h = function(e) {
                    var t = e.language,
                        a = e.rawDiscount,
                        r = e.offText;
                    return n.createElement(f, {
                        badgeType: "promotion"
                    }, n.createElement("div", {
                        className: l()(p["shopee-badge--promotion__label-wrapper"], p["shopee-badge--promotion__label-wrapper--" + t])
                    }, n.createElement("span", {
                        className: "percent"
                    }, (0, u.Z)(a, C)), n.createElement("span", {
                        className: l()(p["shopee-badge--promotion__label-wrapper__off-label"], p["shopee-badge--promotion__label-wrapper__off-label--" + t])
                    }, r)))
                };
            h.defaultProps = {
                language: "en",
                discountText: "15%",
                offText: "OFF"
            };
            var v = function(e) {
                var t = e.language,
                    a = e.soldText,
                    r = e.outText;
                return n.createElement(f, {
                    badgeType: "soldout"
                }, n.createElement("div", {
                    className: l()(p["shopee-badge--soldout__sold-label"], p["shopee-badge--soldout__sold-label--" + t])
                }, a), n.createElement("div", {
                    className: l()(p["shopee-badge--soldout__out-label"], p["shopee-badge--soldout__out-label--" + t])
                }, r))
            };
            v.defaultProps = {
                language: "en",
                soldText: "SOLD",
                outText: "OUT"
            };
            var g = function(e) {
                    var t = e.noTriangle,
                        a = e.className,
                        r = e.text;
                    return n.createElement("div", {
                        className: l()(p["horizontal-badge"], p["shopee-preferred-seller-badge"], t && p["horizontal-badge--no-triangle"], a)
                    }, r || i.oc.t("label_preferred_for_preferred_seller"))
                },
                b = function(e) {
                    var t = e.noTriangle,
                        a = e.className,
                        r = e.text,
                        o = "TH" === _;
                    return n.createElement("div", {
                        className: l()(p["horizontal-badge"], p["shopee-preferred-seller-badge"], t && p["horizontal-badge--no-triangle"], a)
                    }, r || (o ? i.oc.t("label_preferred_for_preferred_seller") : i.oc.t("plt_label_preferred_plus")))
                };

            function E() {
                return n.createElement("div", {
                    className: "official-shop-new-badge"
                }, "TW" === _ ? n.createElement("img", {
                    className: p["official-shop-new-badge--tw"],
                    src: s,
                    loading: "lazy",
                    width: "50",
                    height: "16"
                }) : "BR" === _ ? n.createElement("img", {
                    className: p["official-shop-new-badge--br"],
                    src: m,
                    loading: "lazy",
                    width: "50",
                    height: "16"
                }) : n.createElement("img", {
                    className: p["official-shop-new-badge--all"],
                    src: c,
                    loading: "lazy",
                    width: "64",
                    height: "16"
                }))
            }
            var w = function() {
                    return n.createElement("div", {
                        className: l()(p["horizontal-badge"], p["horizontal-badge--no-triangle"], p["installment-badge"], "text-trunc-1")
                    }, i.oc.t("label_installment_tag"))
                },
                y = "_3Le-yL",
                V = "_193T00",
                H = "_2u_2ej",
                L = "_11MMde",
                N = "_1D5TvO",
                O = function(e) {
                    var t = e.className,
                        a = e.soldOutText,
                        n = e.useLandingPageLayout;
                    return r().createElement("div", {
                        className: l()(y, t)
                    }, r().createElement("div", {
                        className: l()(V, n ? L : H)
                    }, r().createElement("div", {
                        className: N
                    }, a || i.oc.t("label_sold_out"))))
                };

            function M(e) {
                var t = e.text,
                    a = e.affixed,
                    n = e.large;
                if (!t) return null;
                var o = l()("center", p["horizontal-badge"], !a && p["horizontal-badge--no-triangle"], p["badge-coins-back"], n && p["badge-coins-back--large"], !a && p["badge-coins-back--standalone"]);
                return r().createElement("div", {
                    className: o
                }, t)
            }

            function k() {
                return (k = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var a = arguments[t];
                        for (var n in a) Object.prototype.hasOwnProperty.call(a, n) && (e[n] = a[n])
                    }
                    return e
                }).apply(this, arguments)
            }
            var x = function(e) {
                    return r().createElement("svg", k({
                        viewBox: "0 0 12 12"
                    }, e), r().createElement("defs", null, r().createElement("linearGradient", {
                        x1: "50%",
                        y1: "2.87578064%",
                        x2: "50%",
                        y2: "100%",
                        id: "1"
                    }, r().createElement("stop", {
                        stopColor: "#FFF",
                        offset: "0%"
                    }), r().createElement("stop", {
                        stopColor: "#FFF5E8",
                        offset: "100%"
                    }))), r().createElement("g", null, r().createElement("path", {
                        fill: "url(#1)",
                        d: "M9.01433703,3.91520208 C9.01289646,3.91499025 9.01181411,3.91445948 9.01110241,3.91359928 C8.2690921,3.01677238 7.38900806,2.57464812 6.35918627,2.57464812 C5.37490226,2.57464812 4.55639903,2.90546463 3.89019337,3.57211998 C3.22549655,4.22546938 2.89446917,5.04087002 2.89446917,6.03020701 C2.89446917,7.048964 3.26253848,7.88009352 4.00288327,8.5369975 C4.70010999,9.15101608 5.44715207,9.45452215 6.25111252,9.45452215 C6.93136867,9.45452215 7.53973764,9.23003657 8.08339855,8.77757138 C8.56066218,8.37693949 8.84886613,7.91293914 8.95341645,7.37993706 L6.56054533,7.37993706 C6.55163316,7.38020264 6.54268787,7.38033638 6.53371135,7.38033638 C6.04526057,7.38033638 5.64929298,6.98436879 5.64929298,6.49591801 C5.64929298,6.00746724 6.04526057,5.61149965 6.53371135,5.61149965 C6.53658656,5.61149965 6.53945857,5.61151337 6.54232732,5.61154074 L10.5096452,5.61154074 C10.8365484,5.61154074 11,5.78442283 11,6.13018701 C11,6.87391778 10.9104728,7.53498205 10.7295275,8.11619037 C10.551218,8.65951347 10.2510192,9.16660347 9.82976829,9.63732 C8.87966509,10.6884818 7.66505043,11.2166697 6.20025429,11.2166697 C4.77243905,11.2166697 3.54428279,10.7076924 2.52688619,9.69467639 C1.51047876,8.67832098 1,7.45323467 1,6.03020701 C1,4.57749372 1.51939233,3.33919789 2.55354471,2.32702629 C3.58782474,1.31040306 4.85173707,0.800003052 6.33375715,0.800003052 C7.13054263,0.800003052 7.87642513,0.960514986 8.57252114,1.28304527 C9.21649274,1.59531441 9.84535592,2.0927656 10.4603528,2.77384116 C10.4606949,2.77421999 10.4604496,2.77506992 10.4596401,2.77637133 C10.5851785,2.93364473 10.6602229,3.13299598 10.6602229,3.34987478 C10.6602229,3.85798155 10.248321,4.26988347 9.74021421,4.26988347 C9.44524516,4.26988347 9.18269813,4.13106837 9.01433703,3.91520208 Z"
                    })))
                },
                Z = (0, a(53713).Z)({
                    Icon: x
                }),
                D = {
                    badgeGroupBuy: "_2aTDvB",
                    badgeGroupBuyPlaceholder: "_20Dcfr",
                    small: "_3ETN7d",
                    iconContainer: "_2sVQIq",
                    text: "_3F0HGe"
                };

            function T(e) {
                var t = e.groupSize,
                    a = e.className,
                    n = e.useShortText,
                    o = e.small,
                    s = e.showGroupSize,
                    c = void 0 === s || s;
                return !t && c ? r().createElement("div", {
                    className: l()(D.badgeGroupBuy, D.badgeGroupBuyPlaceholder)
                }) : r().createElement("div", {
                    className: l()(D.badgeGroupBuy, a, o && D.small)
                }, r().createElement("div", {
                    className: l()(D.iconContainer, "center")
                }, r().createElement(Z, {
                    className: D.icon
                })), r().createElement("div", {
                    className: D.text
                }, i.oc.t(c ? n ? "label_group_buy_badge" : "label_group_buy_badge_long" : "label_group_deal", {
                    size: t
                })))
            }
            var A = a(53082),
                z = a(67139),
                S = "_1mF3C6",
                j = "cXKGwm",
                P = "_2AwyOv",
                R = "_2k7Dnn",
                B = function(e) {
                    var t = e.backgroundColor,
                        a = e.isMember,
                        n = void 0 !== a && a;
                    return r().createElement("div", {
                        style: {
                            borderColor: t
                        },
                        className: l()(S, e.className)
                    }, r().createElement("div", {
                        style: {
                            backgroundColor: t
                        },
                        className: j
                    }, e.label), !n && r().createElement("div", {
                        className: P
                    }, r().createElement("div", {
                        style: {
                            borderTopColor: t
                        },
                        className: R
                    }), r().createElement("span", null, (0, A.x)((0, d.Kd)(), (0, z.o)(e.price)))))
                };

            function I() {
                return r().createElement("svg", {
                    width: "68",
                    height: "16",
                    viewBox: "0 0 68 16",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg"
                }, r().createElement("rect", {
                    width: "68",
                    height: "16",
                    rx: "2",
                    fill: "#066BC8"
                }), r().createElement("path", {
                    d: "M7.13833 11.1517C6.54722 11.1517 6.02611 11.0583 5.575 10.8717C5.13167 10.6772 4.72333 10.4167 4.35 10.09L4.96833 9.22667C5.32611 9.52222 5.66833 9.73611 5.995 9.86833C6.32944 10.0006 6.69111 10.0628 7.08 10.055C7.29778 10.055 7.50389 10.0317 7.69833 9.985C7.89278 9.93833 8.06 9.87222 8.2 9.78667C8.34778 9.70111 8.46444 9.59611 8.55 9.47167C8.63556 9.33944 8.67833 9.18778 8.67833 9.01667C8.67056 8.83 8.60056 8.66278 8.46833 8.515C8.34389 8.36722 8.18833 8.23889 8.00167 8.13C7.815 8.01333 7.62056 7.91611 7.41833 7.83833C7.21611 7.76056 7.03722 7.69444 6.88167 7.64C6.59389 7.53889 6.31389 7.43 6.04167 7.31333C5.76944 7.18889 5.52444 7.045 5.30667 6.88167C5.09667 6.71056 4.92556 6.50833 4.79333 6.275C4.66889 6.04167 4.60667 5.76167 4.60667 5.435C4.60667 5.14722 4.665 4.88278 4.78167 4.64167C4.90611 4.39278 5.07722 4.17889 5.295 4C5.52056 3.81333 5.785 3.66944 6.08833 3.56833C6.39167 3.46722 6.72222 3.41667 7.08 3.41667C7.36 3.41667 7.62056 3.44389 7.86167 3.49833C8.11056 3.545 8.33222 3.60722 8.52667 3.685C8.72889 3.76278 8.90778 3.84833 9.06333 3.94167C9.21889 4.02722 9.34722 4.11278 9.44833 4.19833L8.83 5.06167C8.74444 5.00722 8.63944 4.94889 8.515 4.88667C8.39056 4.82444 8.25056 4.76611 8.095 4.71167C7.93944 4.65722 7.77611 4.61056 7.605 4.57167C7.43389 4.53278 7.25889 4.51333 7.08 4.51333C6.68333 4.50556 6.35278 4.58333 6.08833 4.74667C5.83167 4.91 5.70333 5.12778 5.70333 5.4C5.70333 5.54778 5.74222 5.68 5.82 5.79667C5.90556 5.91333 6.01056 6.01444 6.135 6.1C6.25944 6.18556 6.39944 6.26333 6.555 6.33333C6.71833 6.39556 6.87389 6.45389 7.02167 6.50833L7.16167 6.56667C7.44944 6.66778 7.745 6.78444 8.04833 6.91667C8.35944 7.04889 8.64333 7.20833 8.9 7.395C9.15667 7.58167 9.36667 7.80722 9.53 8.07167C9.70111 8.32833 9.78667 8.63556 9.78667 8.99333C9.78667 9.30444 9.72833 9.59222 9.61167 9.85667C9.495 10.1211 9.32389 10.3506 9.09833 10.545C8.88056 10.7317 8.60444 10.8794 8.27 10.9883C7.94333 11.0972 7.56611 11.1517 7.13833 11.1517ZM12.8162 11.1167C12.1862 11.1167 11.6651 10.9378 11.2529 10.58C10.8407 10.2222 10.6034 9.70889 10.5412 9.04C10.5334 8.97 10.5257 8.88056 10.5179 8.77167C10.5179 8.66278 10.514 8.55 10.5062 8.43333C10.5062 8.31667 10.5062 8.20389 10.5062 8.095C10.5062 7.98611 10.5062 7.89667 10.5062 7.82667V5.94833H11.6029V7.82667C11.6029 7.90444 11.6029 7.99778 11.6029 8.10667C11.6029 8.21556 11.6029 8.32444 11.6029 8.43333C11.6107 8.54222 11.6146 8.64333 11.6146 8.73667C11.6223 8.83 11.6301 8.90389 11.6379 8.95833C11.669 9.25389 11.7779 9.51056 11.9646 9.72833C12.1512 9.93833 12.4351 10.0433 12.8162 10.0433C13.1973 10.0433 13.4812 9.93833 13.6679 9.72833C13.8546 9.51833 13.9634 9.26556 13.9946 8.97C14.0023 8.90778 14.0062 8.82611 14.0062 8.725C14.014 8.61611 14.0179 8.50333 14.0179 8.38667C14.0179 8.26222 14.0179 8.14167 14.0179 8.025C14.0179 7.90833 14.0179 7.81111 14.0179 7.73333V5.94833H15.1146V7.73333C15.1146 7.81889 15.1146 7.92389 15.1146 8.04833C15.1146 8.165 15.1146 8.28556 15.1146 8.41C15.1146 8.53444 15.1107 8.655 15.1029 8.77167C15.1029 8.88056 15.099 8.97389 15.0912 9.05167C15.029 9.73611 14.7918 10.2533 14.3796 10.6033C13.9673 10.9456 13.4462 11.1167 12.8162 11.1167ZM16.1497 5.995H17.2347V6.625C17.437 6.38389 17.6742 6.20111 17.9464 6.07667C18.2186 5.95222 18.5181 5.89 18.8447 5.89C19.1947 5.89 19.5175 5.95222 19.8131 6.07667C20.1164 6.20111 20.377 6.37611 20.5947 6.60167C20.8125 6.82722 20.9836 7.09944 21.1081 7.41833C21.2325 7.72944 21.2947 8.07944 21.2947 8.46833C21.2947 8.84944 21.2325 9.19944 21.1081 9.51833C20.9836 9.83722 20.8125 10.1133 20.5947 10.3467C20.377 10.5722 20.1164 10.7472 19.8131 10.8717C19.5175 10.9961 19.1947 11.0583 18.8447 11.0583C18.5181 11.0583 18.2186 10.9961 17.9464 10.8717C17.6742 10.7472 17.437 10.5644 17.2347 10.3233V13.5667H16.1497V5.995ZM20.2097 8.49167C20.2097 8.25833 20.1709 8.04444 20.0931 7.85C20.0153 7.65556 19.9064 7.48833 19.7664 7.34833C19.6342 7.20833 19.4786 7.09944 19.2997 7.02167C19.1209 6.94389 18.9303 6.905 18.7281 6.905C18.3081 6.905 17.962 7.03722 17.6897 7.30167C17.4175 7.55833 17.2659 7.90056 17.2347 8.32833V8.55C17.2659 9.02444 17.4136 9.39 17.6781 9.64667C17.9425 9.90333 18.2925 10.0317 18.7281 10.0317C18.9303 10.0317 19.1209 9.99667 19.2997 9.92667C19.4786 9.85667 19.6342 9.75944 19.7664 9.635C19.9064 9.50278 20.0153 9.33944 20.0931 9.145C20.1709 8.95056 20.2097 8.73278 20.2097 8.49167ZM21.8771 8.45667C21.8771 8.09889 21.9354 7.76444 22.0521 7.45333C22.1688 7.13444 22.336 6.85833 22.5538 6.625C22.7716 6.38389 23.036 6.19722 23.3471 6.065C23.666 5.925 24.0238 5.855 24.4204 5.855C24.7704 5.855 25.0971 5.925 25.4004 6.065C25.7116 6.19722 25.9799 6.38778 26.2054 6.63667C26.431 6.87778 26.606 7.17333 26.7304 7.52333C26.8549 7.87333 26.9054 8.25833 26.8821 8.67833L26.8704 8.97L23.0204 8.98167C23.0593 9.17611 23.1254 9.34333 23.2188 9.48333C23.3121 9.61556 23.421 9.72444 23.5454 9.81C23.6777 9.89556 23.8216 9.96167 23.9771 10.0083C24.1327 10.0472 24.2843 10.0706 24.4321 10.0783C24.8443 10.0861 25.1982 10.0239 25.4938 9.89167C25.7893 9.75944 26.0382 9.60778 26.2404 9.43667L26.7888 10.2067C26.6566 10.3233 26.5127 10.4361 26.3571 10.545C26.2093 10.6461 26.0421 10.7394 25.8554 10.825C25.6688 10.9106 25.4549 10.9767 25.2138 11.0233C24.9804 11.0778 24.7082 11.105 24.3971 11.105C24.0549 11.105 23.7321 11.0428 23.4288 10.9183C23.1254 10.7939 22.8571 10.615 22.6238 10.3817C22.3982 10.1483 22.2154 9.86833 22.0754 9.54167C21.9432 9.215 21.8771 8.85333 21.8771 8.45667ZM25.7738 8.03667C25.7349 7.71778 25.591 7.44944 25.3421 7.23167C25.0932 7.00611 24.7704 6.88944 24.3738 6.88167C24.2027 6.88167 24.0354 6.91278 23.8721 6.975C23.7166 7.02944 23.5766 7.11111 23.4521 7.22C23.3277 7.32111 23.2227 7.44167 23.1371 7.58167C23.0593 7.72167 23.0127 7.87722 22.9971 8.04833L25.7738 8.03667ZM27.8866 5.94833H28.9483V6.82333C29.1271 6.55111 29.3527 6.33722 29.6249 6.18167C29.8971 6.01833 30.2238 5.93667 30.6049 5.93667V7.03333C30.3016 7.03333 30.0449 7.08778 29.8349 7.19667C29.6249 7.29778 29.4538 7.44167 29.3216 7.62833C29.1894 7.80722 29.0921 8.02111 29.0299 8.27C28.9755 8.51111 28.9483 8.76778 28.9483 9.04V11H27.8866V5.94833ZM32.5788 11H31.4588V5.995H32.5788V6.56667C32.7499 6.32556 32.9444 6.15444 33.1622 6.05333C33.3877 5.95222 33.621 5.90167 33.8622 5.90167C34.3133 5.90167 34.6788 6.00667 34.9588 6.21667C35.2466 6.42667 35.4566 6.69111 35.5888 7.01C35.7522 6.60556 35.9699 6.32167 36.2422 6.15833C36.5222 5.98722 36.8138 5.90167 37.1172 5.90167C37.6072 5.90167 37.996 6.02611 38.2838 6.275C38.5794 6.51611 38.7855 6.81167 38.9022 7.16167C38.9877 7.45722 39.0383 7.76444 39.0538 8.08333C39.0694 8.40222 39.0772 8.74833 39.0772 9.12167V11H37.9805V9.23833C37.9805 9.04389 37.9766 8.83389 37.9688 8.60833C37.9688 8.375 37.961 8.16889 37.9455 7.99C37.9066 7.68667 37.8055 7.43 37.6422 7.22C37.4866 7.00222 37.2455 6.89333 36.9188 6.89333C36.5844 6.89333 36.3355 6.99833 36.1722 7.20833C36.0166 7.41833 35.9194 7.67111 35.8805 7.96667C35.8572 8.14556 35.8416 8.37889 35.8338 8.66667C35.826 8.95444 35.8222 9.25 35.8222 9.55333V11H34.7255V9.23833C34.7255 9.04389 34.7216 8.83389 34.7138 8.60833C34.7138 8.375 34.706 8.16889 34.6905 7.99C34.6516 7.68667 34.5505 7.43 34.3872 7.22C34.2316 7.00222 33.9905 6.89333 33.6638 6.89333C33.3994 6.89333 33.1933 6.95944 33.0455 7.09167C32.8977 7.21611 32.7888 7.37556 32.7188 7.57C32.6488 7.76444 32.606 7.97444 32.5905 8.2C32.5827 8.42556 32.5788 8.63556 32.5788 8.83V11ZM39.7674 8.46833C39.7674 8.07944 39.8296 7.72944 39.954 7.41833C40.0785 7.09944 40.2496 6.82722 40.4674 6.60167C40.6851 6.37611 40.9418 6.20111 41.2374 6.07667C41.5407 5.95222 41.8674 5.89 42.2174 5.89C42.544 5.89 42.8435 5.95611 43.1157 6.08833C43.3957 6.21278 43.6368 6.39944 43.839 6.64833V6.00667H44.9007V11.0117H43.839V10.3C43.6368 10.5489 43.3957 10.7394 43.1157 10.8717C42.8435 10.9961 42.544 11.0583 42.2174 11.0583C41.8674 11.0583 41.5407 10.9961 41.2374 10.8717C40.9418 10.7472 40.6851 10.5722 40.4674 10.3467C40.2496 10.1133 40.0785 9.83722 39.954 9.51833C39.8296 9.19944 39.7674 8.84944 39.7674 8.46833ZM40.8524 8.49167C40.8524 8.73278 40.8912 8.95056 40.969 9.145C41.0468 9.33944 41.1518 9.50278 41.284 9.635C41.424 9.75944 41.5835 9.85667 41.7624 9.92667C41.9412 9.99667 42.1318 10.0317 42.334 10.0317C42.7774 10.0317 43.1312 9.89556 43.3957 9.62333C43.6679 9.35111 43.8118 8.96611 43.8274 8.46833C43.8274 8.235 43.7924 8.025 43.7224 7.83833C43.6524 7.64389 43.5512 7.47667 43.419 7.33667C43.2868 7.19667 43.1274 7.09167 42.9407 7.02167C42.7618 6.94389 42.5596 6.905 42.334 6.905C42.1318 6.905 41.9412 6.94389 41.7624 7.02167C41.5835 7.09944 41.424 7.20833 41.284 7.34833C41.1518 7.48833 41.0468 7.65556 40.969 7.85C40.8912 8.04444 40.8524 8.25833 40.8524 8.49167ZM45.8924 5.94833H46.9541V6.82333C47.133 6.55111 47.3586 6.33722 47.6308 6.18167C47.903 6.01833 48.2297 5.93667 48.6108 5.93667V7.03333C48.3074 7.03333 48.0508 7.08778 47.8408 7.19667C47.6308 7.29778 47.4597 7.44167 47.3274 7.62833C47.1952 7.80722 47.098 8.02111 47.0358 8.27C46.9813 8.51111 46.9541 8.76778 46.9541 9.04V11H45.8924V5.94833ZM49.4997 3.53333H50.5963L50.5847 7.93167L53.3613 5.10833L54.0263 6.00667L52.1363 7.89667L54.3997 11H53.058L51.3547 8.67833L50.5847 9.44833V11H49.488L49.4997 3.53333ZM54.382 8.45667C54.382 8.09889 54.4403 7.76444 54.557 7.45333C54.6737 7.13444 54.8409 6.85833 55.0587 6.625C55.2764 6.38389 55.5409 6.19722 55.852 6.065C56.1709 5.925 56.5287 5.855 56.9253 5.855C57.2753 5.855 57.602 5.925 57.9053 6.065C58.2164 6.19722 58.4848 6.38778 58.7103 6.63667C58.9359 6.87778 59.1109 7.17333 59.2353 7.52333C59.3598 7.87333 59.4103 8.25833 59.387 8.67833L59.3753 8.97L55.5253 8.98167C55.5642 9.17611 55.6303 9.34333 55.7237 9.48333C55.817 9.61556 55.9259 9.72444 56.0503 9.81C56.1826 9.89556 56.3264 9.96167 56.482 10.0083C56.6376 10.0472 56.7892 10.0706 56.937 10.0783C57.3492 10.0861 57.7031 10.0239 57.9987 9.89167C58.2942 9.75944 58.5431 9.60778 58.7453 9.43667L59.2937 10.2067C59.1614 10.3233 59.0176 10.4361 58.862 10.545C58.7142 10.6461 58.547 10.7394 58.3603 10.825C58.1737 10.9106 57.9598 10.9767 57.7187 11.0233C57.4853 11.0778 57.2131 11.105 56.902 11.105C56.5598 11.105 56.237 11.0428 55.9337 10.9183C55.6303 10.7939 55.362 10.615 55.1287 10.3817C54.9031 10.1483 54.7203 9.86833 54.5803 9.54167C54.4481 9.215 54.382 8.85333 54.382 8.45667ZM58.2787 8.03667C58.2398 7.71778 58.0959 7.44944 57.847 7.23167C57.5981 7.00611 57.2753 6.88944 56.8787 6.88167C56.7076 6.88167 56.5403 6.91278 56.377 6.975C56.2214 7.02944 56.0814 7.11111 55.957 7.22C55.8326 7.32111 55.7276 7.44167 55.642 7.58167C55.5642 7.72167 55.5176 7.87722 55.502 8.04833L58.2787 8.03667ZM63.0603 7.02167H61.6019V8.67833C61.6019 9.02056 61.6136 9.28889 61.6369 9.48333C61.668 9.67778 61.7575 9.81778 61.9053 9.90333C62.0064 9.95778 62.1308 9.985 62.2786 9.985C62.3797 9.985 62.4808 9.97333 62.5819 9.95C62.6908 9.92667 62.7997 9.88389 62.9086 9.82167L63.1653 10.7667C62.9708 10.8833 62.7764 10.9611 62.5819 11C62.3875 11.0467 62.1814 11.07 61.9636 11.07C61.6525 11.07 61.388 10.9922 61.1703 10.8367C60.9525 10.6811 60.7969 10.4867 60.7036 10.2533C60.6336 10.0822 60.583 9.89944 60.5519 9.705C60.5286 9.50278 60.5169 9.215 60.5169 8.84167V7.02167H59.8869V5.94833H60.5169V4.32667H61.6019V5.94833H63.0603V7.02167Z",
                    fill: "white"
                }))
            }

            function G() {
                return r().createElement("svg", {
                    width: "58",
                    height: "16",
                    viewBox: "0 0 58 16",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg"
                }, r().createElement("rect", {
                    width: "58",
                    height: "16",
                    rx: "2",
                    fill: "#066BC8"
                }), r().createElement("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M42.8888 3.54146C42.4892 3.54146 42.1467 3.86497 42.1467 4.28363V4.43587H47.0564V5.787H43.9736C43.4027 5.787 42.9459 6.24373 42.9459 6.81463V10.4684C42.9459 10.9251 43.3075 11.2867 43.7642 11.2867V7.08105C43.7642 6.85269 43.9545 6.68142 44.1639 6.68142H47.0564V12.9994H47.8747V6.66239H51.0527C51.2811 6.66239 51.4524 6.85269 51.4524 7.06202V9.82137C51.4524 10.1259 51.205 10.3732 50.9005 10.3732H49.7777L49.987 11.1915H51.1669C51.7759 11.1915 52.2707 10.6968 52.2707 10.0878V6.81463C52.2707 6.24373 51.8139 5.787 51.243 5.787H47.8747V4.43587H52.8035V3.54146H42.8888ZM46.79 2.72317C46.79 2.72317 46.79 2.7422 46.809 2.7422L46.9422 3.1228H48.0079L47.5893 2.26645C47.5131 2.13324 47.3609 2.03809 47.1896 2.03809C46.9422 2.03809 46.7329 2.24742 46.7329 2.49481C46.7329 2.58996 46.7519 2.66608 46.79 2.72317Z",
                    fill: "white"
                }), r().createElement("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M36.7421 8.71762C36.7421 8.41314 36.8563 8.27993 37.1798 8.27993H37.313H39.806C40.1105 8.27993 40.2437 8.39411 40.2437 8.71762V10.5064H36.7421V8.71762ZM36.8944 7.48067C36.2854 7.48067 35.9048 7.91836 35.9048 8.52732V11.3247H41.0049V8.47023C41.0049 7.86127 40.6433 7.48067 40.0153 7.48067H36.8944ZM36.0951 2.72315V3.54145H37.256C37.2179 4.2075 37.1037 4.74034 36.8373 5.159C36.628 5.55863 36.3425 5.88214 35.9619 6.1105L36.3235 6.94782C36.9324 6.45304 37.3511 5.93923 37.5985 5.42542C37.8649 4.93064 37.941 4.37877 38.0362 3.54145H39.8631C40.1675 3.54145 40.3008 3.65563 40.3008 3.97914V5.57766C40.3008 5.88214 40.0534 6.12953 39.7489 6.12953H39.1019L38.7403 6.94782H40.0153C40.6243 6.94782 41.1191 6.45304 41.1191 5.84408V3.69369C41.1191 3.08473 40.7575 2.70412 40.1295 2.70412H36.0951V2.72315ZM32.5936 2.41867V3.76981H31.1473C30.7286 3.76981 30.3861 4.11235 30.3861 4.53101H32.5936V6.12953H31.2044C30.7477 6.12953 30.3861 6.4911 30.3861 6.94782H32.5936L32.5175 10.6397C31.9846 10.3161 31.6231 10.0117 31.4518 9.72621V8.10866C31.4518 7.8803 31.2615 7.70903 31.0522 7.70903C30.8238 7.70903 30.6525 7.89933 30.6525 8.10866V10.5635C30.6335 11.0012 30.4242 11.7053 30.0245 12.6949L30.8999 12.9803C31.1854 12.2762 31.4137 11.5531 31.4708 11.0203C31.8895 11.3628 33.6022 13.0374 36.5328 12.9994C38.4739 12.9803 40.1295 12.9803 41.5187 12.9994L41.69 12.105C38.9877 12.105 37.3321 12.105 36.7612 12.105C34.4585 12.105 33.507 11.2867 33.4499 11.2486V9.28852H35.1436V8.47023H33.4499V6.94782H35.2959V6.12953H33.4499V4.55004H35.1436V3.78884H33.4499V2.4377C33.4499 2.20934 33.2596 2.01904 33.0313 2.01904C32.7649 2.01904 32.5936 2.19031 32.5936 2.41867Z",
                    fill: "white"
                }), r().createElement("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M7.87354 11.515H8.71086C8.71086 11.2867 8.52056 11.0964 8.2922 11.0964C8.06384 11.0964 7.87354 11.2867 7.87354 11.515ZM13.3161 7.34744V8.18476H15.3714C15.5807 8.18476 15.771 8.37507 15.771 8.60343C15.771 8.75567 15.6378 9.49784 14.9147 10.3732C14.2676 9.44075 14.1535 8.60343 14.1535 8.60343H13.3352C13.3352 8.60343 13.4113 9.74523 14.3628 10.9632C13.868 11.4199 13.4684 11.8385 12.574 12.2762L12.9165 12.9994C13.868 12.5236 14.3438 12.0669 14.8956 11.5721C15.4475 12.124 15.9042 12.5997 16.9128 12.9994L17.2553 12.2762C16.3229 11.9337 15.9423 11.496 15.4475 11.0012C16.5893 9.68814 16.6274 8.47022 16.6274 8.18476C16.6274 7.72804 16.2658 7.34744 15.8091 7.34744H13.3161ZM13.2781 2.91344V3.75076H15.162C15.3904 3.75076 15.5807 3.94106 15.5807 4.16943V5.50153H13.2781V6.33885H16.418V3.75076C16.418 3.29404 16.0565 2.91344 15.5807 2.91344H13.2781ZM10.3855 3.7127H11.4322C11.6605 3.7127 11.8508 3.90301 11.8508 4.13137V5.44444H10.3855V3.7127ZM9.54818 12.9613H10.3855V10.2781H13.2019C13.2019 10.2781 12.9165 9.84038 12.8213 9.44075H10.3855V8.26089H12.6881V7.42356H10.3855V6.2437H12.6881V3.76979V3.69367C12.6881 3.23695 12.3266 2.85635 11.8508 2.85635H9.54818V12.9613ZM5.85635 8.86985H6.46531V4.32167H5.85635V8.86985ZM7.28361 4.32167H7.64518C7.77839 4.32167 7.89257 4.41682 7.89257 4.58809V8.88888H7.28361V4.32167ZM6.44628 2.41866V3.50337H5.41866C5.1903 3.50337 5.01903 3.69367 5.01903 3.92203V8.88888V9.7262H6.44628V12.143H5.41866C5.1903 12.143 5 12.3333 5 12.5617C5 12.79 5.1903 12.9803 5.41866 12.9803H8.71086V11.5341H7.87354V12.143H7.26457V9.70717H8.69183V4.32167C8.69183 3.86495 8.33026 3.50337 7.85451 3.50337H7.24554V2.41866C7.24554 2.1903 7.05524 2 6.82688 2C6.63658 2 6.44628 2.1903 6.44628 2.41866Z",
                    fill: "white"
                }), r().createElement("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M19.615 4.26458C19.615 4.03621 19.7863 3.84592 20.0337 3.84592H23.2878V5.90116H19.615V4.26458ZM23.2878 2.41866V3.02762H20.0337C19.3296 3.02762 18.7777 3.59852 18.7777 4.28361V5.61571V7.67095C18.7777 10.9251 17.5408 12.3333 17.5408 12.3333L18.1878 12.9042C19.7102 11.1725 19.596 8.27991 19.596 8.27991V6.73848H26.6562H27.0368C27.5506 6.73848 27.3603 7.15714 27.3603 7.15714C26.7133 8.50827 25.4953 9.45978 24.2584 10.24C22.9834 9.44075 21.8796 8.64148 21.0423 7.15714H20.1859C20.1859 7.15714 20.7759 8.94597 23.4781 10.6967C21.4419 11.7244 19.4628 12.1811 19.4628 12.1811L19.7673 12.9613C21.9177 12.4094 23.2117 11.8385 24.2393 11.2105C25.4763 11.9337 27.0177 12.5426 29.073 12.9613L29.3013 12.1811C29.3013 12.1811 27.208 11.8576 25.0196 10.6967C28.2737 8.64149 28.2547 6.73848 28.2547 6.73848C28.2547 6.30079 27.8931 5.92019 27.4364 5.92019H24.0681V3.84592H27.3793C27.4174 3.84592 27.5696 3.86494 27.5696 3.97912C27.5696 3.97912 27.5696 4.15039 27.2461 4.58809L27.8931 5.12093C27.8931 5.12093 28.3689 4.49294 28.464 4.03622C28.464 4.03622 28.5782 3.59852 28.426 3.35113C28.2166 3.00859 27.6838 3.00859 27.6838 3.00859H27.3603H24.049V2.41866C24.049 2.1903 23.8587 2 23.6304 2C23.4781 2.01903 23.2878 2.1903 23.2878 2.41866Z",
                    fill: "white"
                }))
            }

            function U(e) {
                var t = e.className;
                return r().createElement("div", {
                    className: t
                }, "TW" === (0, d.Kd)() ? r().createElement(G, null) : r().createElement(I, null))
            }

            function W() {
                return (W = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var a = arguments[t];
                        for (var n in a) Object.prototype.hasOwnProperty.call(a, n) && (e[n] = a[n])
                    }
                    return e
                }).apply(this, arguments)
            }

            function F(e) {
                var t = W({}, e);
                return r().createElement("svg", W({
                    width: "30",
                    height: "16",
                    viewBox: "0 0 30 16",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg"
                }, t), r().createElement("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M0 2C0 0.895431 0.895431 0 2 0H28C29.1046 0 30 0.895431 30 2V14C30 15.1046 29.1046 16 28 16H2C0.89543 16 0 15.1046 0 14V2Z",
                    fill: "#D0011B"
                }), r().createElement("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M8.29904 2.89008C8.27727 3.00567 8.27119 3.19843 8.37498 3.39072H9.60639L9.42345 2.93942L9.40395 2.90646C9.32545 2.77327 9.22162 2.59709 9.05284 2.5335C8.86162 2.46537 8.39152 2.46477 8.29904 2.89008ZM4.16813 3.66368H14.381V4.75602H3.50942C3.40738 3.73489 4.16813 3.66368 4.16813 3.66368ZM12.8604 11.7736C12.8575 12.1636 12.6711 12.3974 12.3354 12.3974V13.5C13.5725 13.5 13.9329 12.9237 13.9329 12.1231V6.90771C13.9328 6.49214 13.6101 6.19662 13.262 6.19531H4.32798C4.11149 6.19531 3.9287 6.31404 3.9287 6.55151V12.6382C3.9287 12.6382 3.9287 13.3698 5.02173 13.3698V7.28362H7.00082C6.95772 7.54307 6.75866 7.90552 6.0564 8.16417C5.68318 8.31657 5.83745 8.74874 5.83745 8.74874C5.91494 8.94904 6.0564 9.04672 6.31313 9.04672C6.44415 9.04672 6.74616 8.97178 6.80789 8.94904C6.82341 8.94338 6.84619 8.93738 6.87481 8.92985C7.1456 8.85858 7.93895 8.64978 8.04711 7.28362H9.69834V8.28746C9.69834 8.64015 10.0285 8.99985 10.3946 8.99985H11.762C11.9791 8.99985 12.1655 8.80184 12.1655 8.46532C12.1655 8.1288 11.9112 7.99506 11.7189 7.99506L11.1031 7.99394C10.8261 7.99394 10.7615 7.83857 10.7578 7.66642L10.7584 7.28362H12.5956C12.7697 7.28379 12.8604 7.36251 12.8604 7.55913V11.7736ZM10.7578 7.66642L10.7576 7.77292V7.65122L10.7578 7.66642ZM10.0639 11.2003L7.88441 11.204L7.88 10.3296H9.71077C10.0367 10.3296 10.0505 10.5084 10.0505 10.7776L10.0639 11.2003ZM6.81539 12.2922H11.1367L11.1356 9.95731C11.1356 9.56573 10.8465 9.24991 10.4404 9.24712L7.14618 9.24492C6.95389 9.24492 6.81539 9.40438 6.81539 9.60112V12.2922ZM6.21117 6.01364H7.44279L7.1579 5.36571C7.03228 5.04197 6.81944 4.9412 6.55256 4.9412C6.31711 4.9412 5.98772 5.06097 6.016 5.44339C6.02088 5.50936 6.03126 5.56954 6.05766 5.62635L6.21117 6.01364ZM10.4466 6.01405H11.6782L11.8317 5.62676C11.8581 5.56994 11.8685 5.50976 11.8734 5.44379C11.9016 5.06137 11.5723 4.9416 11.3368 4.9416C11.0699 4.9416 10.8571 5.04238 10.7315 5.36611L10.4466 6.01405ZM25.135 11.2401C25.3849 11.57 26.0565 11.8506 26.5 11.8506V12.9901C25.8174 12.9901 25.2156 12.9001 24.6254 12.376C24.4235 12.1742 24.2371 11.9446 24.065 11.6931C23.2294 12.7597 22.4717 13.0128 22.4717 13.0128L22.0536 12.1233C22.6255 11.7369 23.0913 11.2086 23.4695 10.6258C22.6639 8.87372 22.2988 6.62091 22.1304 5.0332L20.7724 5.03029H20.3987H19.9966H19.5904V6.56223H21.3173C21.7019 6.56223 22.1103 6.9189 22.1103 7.36549V8.35004V10.4265C22.1103 11.6685 21.3173 12.6062 20.146 12.4154C20.1494 12.4154 20.1404 12.4135 20.1214 12.4095C20.0016 12.3842 19.483 12.2749 19.1363 12.0218C19.4019 11.5685 19.5941 11.0822 19.5941 11.0822C19.8641 11.2683 20.1439 11.3024 20.146 11.3024C20.7482 11.3989 21.1092 10.8631 21.0962 10.2191C21.0841 9.61787 21.0963 8.35004 21.0963 8.35004V7.87511C21.0963 7.69702 20.9387 7.69702 20.7482 7.69702H19.5904V8.12642C19.5904 8.12642 19.8734 12.28 16.8113 13.0969V11.9595C16.8113 11.9595 18.5675 11.3596 18.5675 8.12642V3.95832H19.5007H22.0353C22.012 3.63072 21.9993 3.37914 21.9917 3.22931C21.9865 3.12772 21.9837 3.07291 21.9816 3.07291C21.9816 2.74693 22.1662 2.53677 22.4916 2.53341C22.8171 2.53005 23.0152 2.72859 23.0582 3.09885C23.072 3.39537 23.0889 3.68174 23.1087 3.95832H25.4296C26.3216 3.99638 26.2128 5.04194 26.2128 5.04194L23.2049 5.0355C23.4133 6.96359 23.769 8.34222 24.1462 9.33934C24.8235 7.75436 25.0062 6.21764 25.0062 6.21764H26.0441C25.7832 8.20368 25.2887 9.62409 24.7489 10.6341C24.8863 10.8746 25.0172 11.0736 25.135 11.2401ZM23.8682 3.65584C23.8398 3.54919 23.8126 3.44687 23.8316 3.34626C23.9241 2.92095 24.3993 2.85283 24.5905 2.92095C24.7806 2.97474 24.8753 3.1334 24.9292 3.24682L25.1727 3.72528L23.8807 3.70378L23.8682 3.65584ZM16.4437 3.94257V5.97704H15.4447V7.09332H16.4437V7.64648C16.4437 7.64648 16.5428 9.69121 15.6178 10.231L15.6142 10.2315V10.2331C15.6024 10.2399 15.5906 10.2464 15.5785 10.2527V11.4653C15.7119 11.4438 15.836 11.4088 15.9517 11.3622C17.1305 10.9656 17.7084 9.70432 18.0653 8.8822C17.8035 9.13627 17.5408 9.34349 17.2898 9.51225C17.5401 8.57039 17.5116 7.64648 17.5116 7.64648V7.09332H18.1675V5.97704H17.5116V3.94257H16.4437Z",
                    fill: "white"
                }))
            }

            function J() {
                return (J = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var a = arguments[t];
                        for (var n in a) Object.prototype.hasOwnProperty.call(a, n) && (e[n] = a[n])
                    }
                    return e
                }).apply(this, arguments)
            }

            function K(e) {
                var t = J({}, e);
                return r().createElement("svg", J({
                    xmlns: "http://www.w3.org/2000/svg",
                    width: "43",
                    height: "16",
                    fill: "none",
                    viewBox: "0 0 43 16"
                }, t), r().createElement("path", {
                    fill: "#D0011B",
                    fillRule: "evenodd",
                    d: "M0 2a2 2 0 012-2h39a2 2 0 012 2v12a2 2 0 01-2 2H2a2 2 0 01-2-2V2z",
                    clipRule: "evenodd"
                }), r().createElement("path", {
                    fill: "#fff",
                    d: "M8.64 12.107a4.12 4.12 0 01-1.68-.347A4.429 4.429 0 014.707 9.4a4.358 4.358 0 01-.334-1.693c0-.596.107-1.156.32-1.68.223-.534.525-1 .907-1.4.382-.4.831-.716 1.347-.947a4.12 4.12 0 011.68-.347 4.06 4.06 0 011.68.347 4.36 4.36 0 012.267 2.333c.222.525.333 1.09.333 1.694 0 .595-.111 1.16-.334 1.693-.213.533-.515 1-.906 1.4-.383.4-.831.72-1.347.96a4.06 4.06 0 01-1.68.347zm0-7.52c-.427 0-.827.084-1.2.253a3.194 3.194 0 00-.96.68 3.37 3.37 0 00-.64.987 2.98 2.98 0 00-.24 1.186c0 .427.076.831.227 1.214.16.373.377.706.653 1 .276.284.596.51.96.68.373.169.773.253 1.2.253.427 0 .822-.084 1.187-.253.364-.17.68-.396.946-.68.276-.294.49-.627.64-1 .16-.383.24-.787.24-1.214 0-.417-.08-.813-.24-1.186a3.164 3.164 0 00-.626-.987 2.988 2.988 0 00-.96-.68 2.788 2.788 0 00-1.187-.253zM15.736 12h-1.253V7.453h-.88V6.227h.88V6.08c0-.409.009-.76.026-1.053.027-.294.072-.53.134-.707.106-.32.28-.569.52-.747.249-.186.56-.28.933-.28.231 0 .453.031.667.094.213.053.382.129.506.226l-.4 1.04c-.195-.089-.36-.133-.493-.133-.32 0-.515.182-.587.547a4.616 4.616 0 00-.04.466 15.53 15.53 0 00-.013.694h1.52v1.226h-1.52V12zm4.014-7.28a.717.717 0 01-.227.547.753.753 0 01-.534.213.717.717 0 01-.546-.227.752.752 0 01-.213-.533c0-.204.075-.378.226-.52a.73.73 0 01.534-.227c.222 0 .404.076.546.227a.737.737 0 01.213.52zM19.63 12h-1.28V6.227h1.28V12zm4.068.107a2.923 2.923 0 01-2.693-1.787 3.068 3.068 0 01-.227-1.187c0-.453.08-.862.24-1.226.16-.365.373-.676.64-.934a2.97 2.97 0 01.96-.6 3.162 3.162 0 011.16-.213c.444 0 .849.093 1.213.28.374.178.703.422.987.733l-.693.907a2.89 2.89 0 00-.627-.453c-.231-.125-.529-.187-.893-.187-.507 0-.916.156-1.227.467-.311.302-.467.706-.467 1.213 0 .276.05.52.147.733.098.214.222.391.373.534.16.142.338.249.534.32.204.07.404.106.6.106.222 0 .417-.022.586-.066a3.73 3.73 0 00.454-.174 2.17 2.17 0 00.333-.213c.098-.071.182-.133.253-.187l.694.92a3.337 3.337 0 01-.853.653 3.46 3.46 0 01-.654.254 3.058 3.058 0 01-.84.107zm4.73-7.387a.718.718 0 01-.226.547.753.753 0 01-.533.213.717.717 0 01-.547-.227.753.753 0 01-.213-.533c0-.204.075-.378.227-.52a.73.73 0 01.533-.227c.222 0 .404.076.546.227a.737.737 0 01.214.52zm-.12 7.28h-1.28V6.227h1.28V12zm1.088-2.893c0-.445.072-.845.214-1.2.142-.365.338-.676.587-.934.248-.257.542-.457.88-.6.346-.142.72-.213 1.12-.213.373 0 .715.076 1.026.227.32.142.596.355.827.64v-.734h1.213v5.72H34.05V11.2a2.347 2.347 0 01-.827.653 2.44 2.44 0 01-1.026.214c-.4 0-.774-.071-1.12-.214a2.624 2.624 0 01-.88-.6 2.934 2.934 0 01-.587-.946 3.274 3.274 0 01-.213-1.2zm1.24.026c0 .276.045.525.134.747.089.222.209.409.36.56a1.807 1.807 0 001.2.453c.507 0 .911-.155 1.213-.466.311-.311.476-.751.493-1.32 0-.267-.04-.507-.12-.72a1.624 1.624 0 00-.346-.574 1.432 1.432 0 00-.547-.36 1.723 1.723 0 00-.693-.133 1.62 1.62 0 00-.653.133 1.76 1.76 0 00-.547.374c-.151.16-.271.35-.36.573a1.96 1.96 0 00-.133.733zM37.77 12h-1.267V3.467h1.267V12z"
                }))
            }

            function q() {
                return (q = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var a = arguments[t];
                        for (var n in a) Object.prototype.hasOwnProperty.call(a, n) && (e[n] = a[n])
                    }
                    return e
                }).apply(this, arguments)
            }

            function X(e) {
                var t = q({}, e);
                return r().createElement("svg", q({
                    width: "30",
                    height: "16",
                    viewBox: "0 0 30 16",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg"
                }, t), r().createElement("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M0 2C0 0.895431 0.895431 0 2 0L28 0C29.1046 0 30 0.895431 30 2V14C30 15.1046 29.1046 16 28 16H2C0.89543 16 0 15.1046 0 14L0 2Z",
                    fill: "#D0011B"
                }), r().createElement("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M11.8045 3.00128H10.8673C10.8403 3.00132 10.8137 3.00752 10.7895 3.01939C10.7652 3.03126 10.744 3.0485 10.7274 3.0698L10.151 3.70154C10.1108 3.74133 10.0736 3.78149 10.0397 3.82129L10.0109 3.85512L9.73645 4.1559C9.26611 4.63346 8.55272 5.15874 7.50601 5.1696H7.47399C6.35562 5.1696 5.61724 4.53545 5.18223 4.084L4.2545 3.06788C4.23787 3.04676 4.21666 3.02968 4.19249 3.01792C4.16831 3.00617 4.14178 3.00004 4.1149 3H3.17803C3.13084 3.00008 3.08561 3.01887 3.05224 3.05223C3.01887 3.0856 3.00008 3.13084 3 3.17803V12.8198C3.00008 12.867 3.01887 12.9123 3.05224 12.9456C3.08561 12.979 3.13084 12.9978 3.17803 12.9979H4.11458C4.16177 12.9978 4.207 12.979 4.24037 12.9456C4.27373 12.9123 4.29252 12.867 4.2926 12.8198V5.00726C4.51669 5.20068 4.74894 5.38439 4.9887 5.55788C5.57807 5.9956 6.40375 6.40585 7.47655 6.40585H7.51722C8.53818 6.3953 9.32642 6.03468 9.89137 5.64233L9.89877 5.64155L9.97012 5.58642C10.0506 5.52802 10.1262 5.46926 10.1969 5.41116L10.689 5.03095V12.8198C10.6892 12.867 10.708 12.9122 10.7413 12.9455C10.7747 12.9789 10.8199 12.9977 10.867 12.9979H11.8042C11.8514 12.9977 11.8966 12.9789 11.9299 12.9455C11.9633 12.9122 11.9821 12.867 11.9822 12.8198V3.17931C11.9821 3.1322 11.9633 3.08706 11.93 3.05372C11.8967 3.02038 11.8516 3.00153 11.8045 3.00128ZM19.3506 6.74843H18.4154C18.3682 6.74851 18.3229 6.76729 18.2896 6.80066C18.2562 6.83403 18.2374 6.87926 18.2373 6.92645V7.5172C17.6712 7.03692 16.8957 6.70776 16.087 6.70776C14.307 6.70776 12.8639 8.11659 12.8639 9.85105C12.8639 11.5855 14.307 12.9947 16.087 12.9947C16.8743 12.9882 17.6348 12.7074 18.2373 12.2006V12.8195C18.2372 12.843 18.2417 12.8663 18.2506 12.888C18.2595 12.9097 18.2726 12.9295 18.2891 12.9461C18.3057 12.9628 18.3253 12.976 18.347 12.9851C18.3686 12.9941 18.3919 12.9988 18.4154 12.9988H19.3522C19.3994 12.9987 19.4446 12.98 19.478 12.9466C19.5114 12.9132 19.5302 12.868 19.5303 12.8208V6.92933C19.5306 6.90559 19.5262 6.88202 19.5173 6.86C19.5084 6.83798 19.4952 6.81796 19.4785 6.80111C19.4618 6.78426 19.4418 6.77092 19.4199 6.76187C19.3979 6.75283 19.3744 6.74825 19.3506 6.74843ZM16.1455 11.8375C14.9929 11.8375 14.0586 10.9493 14.0586 9.85425C14.0586 8.75921 14.9929 7.87133 16.1455 7.87133C17.2982 7.87133 18.2329 8.75921 18.2329 9.85425C18.2329 10.9493 17.2982 11.8375 16.1455 11.8375ZM23.7506 12.02C23.7618 11.9746 23.7547 11.9266 23.7307 11.8865C23.7067 11.8464 23.6678 11.8174 23.6225 11.8058L23.2034 11.7005L23.1918 11.6976C22.5499 11.5653 22.3174 11.354 22.287 10.769V3.17897C22.2866 3.13204 22.2677 3.08715 22.2344 3.05414C22.201 3.02114 22.1559 3.0027 22.109 3.00287H21.2445C21.1975 3.0027 21.1524 3.02114 21.1191 3.05414C21.0857 3.08715 21.0668 3.13204 21.0664 3.17897V10.4472C21.0082 12.1513 21.9818 12.6863 22.8857 12.8864L23.3174 12.9947C23.363 13.0061 23.4113 12.999 23.4517 12.975C23.4922 12.951 23.5216 12.9121 23.5335 12.8666L23.6318 12.4888C23.6348 12.4786 23.6374 12.4681 23.6399 12.4576L23.6427 12.4465L23.7506 12.02ZM26.9708 11.8864C26.9948 11.9266 27.0019 11.9746 26.9905 12.02L26.8826 12.4465C26.8794 12.4606 26.8759 12.475 26.8718 12.4888L26.7738 12.8666C26.7618 12.9121 26.7324 12.9511 26.6918 12.975C26.6513 12.999 26.603 13.0061 26.5573 12.9947L26.1257 12.8864C25.2218 12.6863 24.2485 12.1513 24.3064 10.4472V3.17897C24.3067 3.13204 24.3257 3.08715 24.359 3.05414C24.3924 3.02114 24.4375 3.0027 24.4844 3.00287H25.3489C25.3959 3.0027 25.441 3.02114 25.4743 3.05414C25.5077 3.08715 25.5266 3.13204 25.527 3.17897V10.769C25.5574 11.354 25.7914 11.5653 26.4318 11.6976C26.436 11.6982 26.4395 11.7005 26.4437 11.7005L26.8625 11.8058C26.9078 11.8173 26.9468 11.8463 26.9708 11.8864Z",
                    fill: "white"
                }))
            }
            var Y = function() {
                switch ((0, d.Kd)()) {
                    case "TW":
                        return F;
                    case "BR":
                        return K;
                    default:
                        return X
                }
            }()
        },
        54166: function(e, t, a) {
            "use strict";
            a.d(t, {
                Z: function() {
                    return s
                }
            });
            var n = a(53713),
                r = a(27378),
                o = a.n(r);

            function l() {
                return (l = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var a = arguments[t];
                        for (var n in a) Object.prototype.hasOwnProperty.call(a, n) && (e[n] = a[n])
                    }
                    return e
                }).apply(this, arguments)
            }
            var i = function(e) {
                    return o().createElement("svg", l({
                        enableBackground: "new 0 0 13 20",
                        viewBox: "0 0 13 20",
                        x: "0",
                        y: "0"
                    }, e), o().createElement("polygon", {
                        points: "4.2 10 12.1 2.1 10 -.1 1 8.9 -.1 10 1 11 10 20 12.1 17.9"
                    }))
                },
                s = (0, n.Z)({
                    Icon: i,
                    iconClassNames: ["icon-arrow-left-bold"]
                })
        },
        67062: function(e, t, a) {
            "use strict";
            a.d(t, {
                Z: function() {
                    return s
                }
            });
            var n = a(53713),
                r = a(27378),
                o = a.n(r);

            function l() {
                return (l = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var a = arguments[t];
                        for (var n in a) Object.prototype.hasOwnProperty.call(a, n) && (e[n] = a[n])
                    }
                    return e
                }).apply(this, arguments)
            }
            var i = function(e) {
                    return o().createElement("svg", l({
                        enableBackground: "new 0 0 13 21",
                        viewBox: "0 0 13 21",
                        x: "0",
                        y: "0"
                    }, e), o().createElement("polygon", {
                        points: "11.1 9.9 2.1 .9 -.1 3.1 7.9 11 -.1 18.9 2.1 21 11.1 12 12.1 11"
                    }))
                },
                s = (0, n.Z)({
                    Icon: i,
                    iconClassNames: ["icon-arrow-right-bold"]
                })
        },
        7283: function(e, t, a) {
            "use strict";
            a.d(t, {
                HS: function() {
                    return S
                },
                ZP: function() {
                    return P
                }
            });
            var n = a(27378),
                r = a.n(n),
                o = a(94184),
                l = a.n(o),
                i = a(74301),
                s = a(97953),
                c = a(33379),
                m = a(13384),
                u = a(51720),
                d = a(98675),
                p = a(73777),
                C = a(6976),
                _ = (0, a(90759).S)((0, C.of)()),
                f = p.LU.bind(null, p.x5[_]),
                h = function(e, t) {
                    var a = new Date(1e3 * t),
                        n = new Date(1e3 * e),
                        r = (0, p.IS)("minute", a, n);
                    return f(a, n, {
                        totalUnits: 1,
                        endUnit: "minute",
                        roundLast: r > 60 ? "floor" : r < 1 ? "ceil" : "round",
                        unitLowerBounds: {
                            year: Number.MAX_VALUE,
                            month: Number.MAX_VALUE,
                            week: Number.MAX_VALUE,
                            day: Number.MAX_VALUE
                        }
                    })
                },
                v = a(58295),
                g = a(90858);

            function b() {
                return (b = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var a = arguments[t];
                        for (var n in a) Object.prototype.hasOwnProperty.call(a, n) && (e[n] = a[n])
                    }
                    return e
                }).apply(this, arguments)
            }

            function E(e, t) {
                if (null == e) return {};
                var a, n, r = {},
                    o = Object.keys(e);
                for (n = 0; n < o.length; n++) a = o[n], t.indexOf(a) >= 0 || (r[a] = e[a]);
                return r
            }

            function w(e, t, a, n) {
                return function(r) {
                    e(), r && r.stopPropagation(), r && r.preventDefault(), n ? window.location.href = t : a.push(t)
                }
            }

            function y(e) {
                var t = e.trackingClick,
                    a = e.to,
                    r = e.history,
                    o = E(e, ["trackingClick", "to", "history"]);
                return n.createElement("div", {
                    onClick: w(t, a, r, "string" == typeof a && /^http/.test(a))
                }, o.children)
            }

            function V(e) {
                var t = e.targetType,
                    a = E(e, ["targetType"]),
                    r = (0, g.Z)(t, a);
                return n.createElement(y, b({
                    trackingClick: r
                }, a))
            }
            var H = a(95802),
                L = a(99096),
                N = a(41636),
                O = a(98466),
                M = (0, a(68849).jK)(__LOCALE__),
                k = ["PL", "ES"].includes(__LOCALE__);
            var x = function(e) {
                var t = e.priceText;
                return n.createElement(n.Fragment, null, !k && n.createElement("span", {
                    className: "item-price-dollar-sign"
                }, M + " "), n.createElement("span", {
                    className: "item-price-number"
                }, t), k && n.createElement("span", {
                    className: "item-price-dollar-sign"
                }, " " + M))
            };

            function Z() {
                return (Z = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var a = arguments[t];
                        for (var n in a) Object.prototype.hasOwnProperty.call(a, n) && (e[n] = a[n])
                    }
                    return e
                }).apply(this, arguments)
            }

            function D(e, t) {
                return (D = Object.setPrototypeOf || function(e, t) {
                    return e.__proto__ = t, e
                })(e, t)
            }
            var T = s.oc.t,
                A = s.oc.withI18nCollections,
                z = u.Y.bind(null, (function(e) {
                    return r().createElement("span", {
                        className: "item-price-dollar-sign",
                        key: 0
                    }, e + " ")
                }), (function(e) {
                    return r().createElement("span", {
                        className: "item-price-number",
                        key: 1
                    }, e)
                }), __LOCALE__),
                S = {
                    HOME_PAGE: "home-page",
                    LANDING_PAGE: "landing-page",
                    MART_LANDING_PAGE: "mart-landing-page",
                    MART_HOME_PAGE: "mart-home-page"
                },
                j = function(e) {
                    var t, a;

                    function n(t) {
                        var a;
                        return (a = e.call(this, t) || this).now = +new Date, a
                    }
                    a = e, (t = n).prototype = Object.create(a.prototype), t.prototype.constructor = t, D(t, a);
                    var o = n.prototype;
                    return o.componentDidMount = function() {
                        var e = this.props,
                            t = e.item,
                            a = e.isOngoing,
                            n = t.flash_sale_stock,
                            r = t.stock,
                            o = n - r;
                        a && window.Sentry && t && o && o < 0 && window.Sentry.captureMessage("Flash Sale sold out count is negative\n        promotionid: " + t.promotionid + "\n        itemid: " + t.itemid + "\n        flash_sale_stock:" + r + "\n        stock:" + n + "\n        sold(flash_sale_stock-stock): " + o + ",", "error")
                    }, o.shouldComponentUpdate = function(e) {
                        return this.props.item.itemid !== e.item.itemid || this.props.item.promotionid !== e.item.promotionid
                    }, o.render = function() {
                        var e = this,
                            t = this.props,
                            a = t.item,
                            n = t.layout,
                            o = t.overwriteCardLink,
                            s = t.displayFlashSaleProgressBar,
                            c = t.setShowDiscountBadge,
                            u = t.isPlaceholder,
                            p = t.isOngoing,
                            C = t.toTrack,
                            _ = t.isDP,
                            f = t.position,
                            g = t.history,
                            b = t.recommendation_info;
                        if (u && "home-page" === n) return r().createElement("div", {
                            className: l()("flash-sale-item-card", "flash-sale-item-card--home-page")
                        }, r().createElement("div", {
                            className: l()("flash-sale-item-card__image", "flash-sale-item-card__image--home-page")
                        }, r().createElement(m.p, {
                            className: "flash-sale-item-card-placeholder__image"
                        })), r().createElement("div", {
                            className: l()("flash-sale-item-card__lower-wrapper", "flash-sale-item-card__lower-wrapper--home-page")
                        }, r().createElement("div", {
                            className: "skeleton-full"
                        }, r().createElement("div", {
                            className: "center skeleton-full",
                            style: {
                                height: 26
                            }
                        }, r().createElement("div", {
                            className: "skeleton skeleton-medium skeleton-line"
                        })), r().createElement("div", {
                            className: "center skeleton-full",
                            style: {
                                height: 16
                            }
                        }, r().createElement("div", {
                            className: "skeleton skeleton-full skeleton-line"
                        })))));
                        var E = p,
                            w = E && (0 === a.stock || 0 === a.flash_sale_stock || a.is_soldout),
                            y = a.raw_discount,
                            O = (0, i.Jn)(a.promo_images && a.promo_images.length > 0 ? a.promo_images[0] : a.image, !0),
                            M = function(e, t) {
                                if (e) {
                                    var a = "TW" === __LOCALE__ ? (100 - e.extra_discount) / 10 : e.extra_discount,
                                        n = "";
                                    if (e.end_time && e.start_time && (n = h(e.start_time, e.end_time)), e && "function" == typeof t) return n ? t("fs_extra_n_off_applied_for_first_m_in_x", {
                                        n: a,
                                        m: e.extra_discount_stock,
                                        x: n
                                    }) : t("fs_extra_n_off_applied_for_first_m", {
                                        n: a,
                                        m: e.extra_discount_stock
                                    })
                                }
                                return ""
                            }(a.extra_discount_info, T),
                            k = n === S.LANDING_PAGE || n === S.MART_LANDING_PAGE,
                            D = !!M && k,
                            A = z(a.price),
                            j = z(a.price_before_discount),
                            P = a.hidden_price_display,
                            R = !!a && !!a.shopid && !!a.itemid,
                            B = o || (R ? w ? (0, L.recommendProduct)(a.shopid, a.itemid, a.name, "flash_sale") : (0, L.product)(a.shopid, a.itemid, a.name) : ""),
                            I = {
                                isDP: _,
                                toTrack: C,
                                item: a,
                                position: f,
                                isOngoing: p,
                                recommendation_info: b
                            };
                        return R ? r().createElement("div", {
                            ref: function(t) {
                                e.rootElement = t, e.props.trackingRef && e.props.trackingRef(t)
                            },
                            onClick: function() {
                                e.props.trackingClick && e.props.trackingClick()
                            },
                            className: l()("flash-sale-item-card", "flash-sale-item-card--" + n.replace("_", "-").toLowerCase(), "flash-sale-item-card--" + __LOCALE__, {
                                "flash-sale-item-card--sold-out": w
                            })
                        }, r().createElement(H.Z, {
                            className: "flash-sale-item-card-link",
                            to: B
                        }, r().createElement("div", {
                            className: l()("flash-sale-item-card__image", "flash-sale-item-card__image--" + n)
                        }, w && r().createElement(v.VL, {
                            useLandingPageLayout: k
                        }), a.promo_overlay_image && r().createElement(m.p, {
                            src: (0, i.Jn)(a.promo_overlay_image, !0),
                            className: l()("flash-sale-item-card__image-overlay", "flash-sale-item-card__image-overlay--" + n),
                            position: this.props.position,
                            imageServerWidthOperator: 320
                        }), r().createElement(m.p, {
                            className: "flash-sale-item-card__animated-image",
                            src: O,
                            imageServerWidthOperator: 320
                        })), k && r().createElement("div", {
                            className: l()("flash-sale-item-card__item-name", !M && "flash-sale-item-card__item-name-extra-discount")
                        }, r().createElement("div", {
                            className: M ? "flash-sale-item-card__item-name-box-extra-discount" : "flash-sale-item-card__item-name-box",
                            title: a.promo_name || a.name
                        }, a.promo_name || a.name)), D && r().createElement("div", {
                            className: "flash-sale-item-card__extra-discount-label"
                        }, M), (k || !p && n === S.MART_HOME_PAGE) && a.price_before_discount !== a.price && r().createElement("div", {
                            className: l()("flash-sale-item-card__original-price", "flash-sale-item-card__original-price--" + n)
                        }, j), r().createElement("div", {
                            className: l()("flash-sale-item-card__lower-wrapper", "flash-sale-item-card__lower-wrapper--" + __LOCALE__, "flash-sale-item-card__lower-wrapper--" + n, !E && "flash-sale-item-card__lower-wrapper--" + n + "__coming-soon")
                        }, r().createElement("div", {
                            className: "flash-sale-item-card__lower-left"
                        }, r().createElement("div", {
                            className: l()("flash-sale-item-card__current-price", "flash-sale-item-card__current-price--" + n, !E && "flash-sale-item-card__current-price--" + n + "__coming-soon")
                        }, P ? r().createElement(x, {
                            priceText: P
                        }) : A), s && r().createElement(d.Z, {
                            sold: a.flash_sale_stock - a.stock,
                            total: a.flash_sale_stock,
                            soldOutTime: a.end_time,
                            startTime: a.start_time,
                            layout: n
                        })), r().createElement("div", {
                            className: "flash-sale-item-card__lower-right"
                        }, !w && k && E && r().createElement(V, Z({}, I, {
                            targetType: "BuyNowButton",
                            to: B,
                            history: g
                        }), r().createElement("div", {
                            className: l()("flash-sale-item-card__buy-now-button", "flash-sale-item-card__buy-now-button--" + n)
                        }, T("label_buy_now_flash_sale"))), (k || n === S.MART_HOME_PAGE) && !E && r().createElement(V, Z({}, I, {
                            targetType: "ViewDetailsButton",
                            to: B,
                            history: g
                        }), r().createElement("div", {
                            className: l()("flash-sale-item-card__view-details-button", "flash-sale-item-card__view-details-button--" + n)
                        }, T("label_btn_view_details")))), c && !!y && p && r().createElement("div", {
                            className: l()("shopee-item-card__badge-wrapper", "shopee-fs-item-card__badge-wrapper", "shopee-fs-item-card__badge-wrapper--" + n)
                        }, r().createElement(v.OO, {
                            rawDiscount: y,
                            language: N.UA,
                            key: "badge-promotion",
                            offText: T("pr_badge_label_off")
                        }))))) : null
                    }, n
                }(n.Component),
                P = A([c.x7, c.L])((0, O.Z)(j, "FlashSaleItemCard"))
        },
        98675: function(e, t, a) {
            "use strict";
            var n = a(27378),
                r = a(94184),
                o = a.n(r),
                l = a(26235),
                i = a(6965),
                s = a(33379);
            t.Z = (0, i.withI18nCollections)([s.L, s.GC])((function(e) {
                var t = e.sold,
                    a = e.total,
                    r = e.soldOutTime,
                    i = e.startTime,
                    s = e.layout,
                    c = 100 * (a - t) / a,
                    m = Math.ceil(Math.floor(2 * c) / 2),
                    u = 0 === a || t === a,
                    d = u ? Math.floor((r - i) / 3600) : null,
                    p = u && 0 === d ? r - i < 60 ? 1 : Math.floor((r - i) / 60) % 60 : null;
                return u ? n.createElement("div", {
                    className: o()("flash-sale-sold-out", "flash-sale-sold-out--" + s)
                }, p ? 1 === p ? (0, l.t)("label_amount_sold_out_in_1_min", {
                    amount: a
                }) : (0, l.t)("label_amount_sold_out_in_n_mins", {
                    minutes: p,
                    amount: a
                }) : d ? 1 === d ? (0, l.t)("label_amount_sold_out_in_1_hour", {
                    hours: 1,
                    amount: a
                }) : (0, l.t)("label_amount_sold_out_in_n_hours", {
                    hours: d,
                    amount: a
                }) : null) : n.createElement("div", {
                    className: "flash-sale-progress-bar__wrapper flash-sale-progress-bar__wrapper--" + s
                }, n.createElement("div", {
                    className: o()("flash-sale-progress-bar", "flash-sale-progress-bar--" + s)
                }, n.createElement("div", {
                    className: o()("flash-sale-progress-bar__text", {
                        "flash-sale-progress-bar__text--selling-fast": m <= 15
                    })
                }, m > 15 ? (0, l.t)("label_n_sold_flash_sale", {
                    count: t > 0 ? t : 0
                }) : (0, l.t)("label_selling_fast")), n.createElement("div", {
                    className: o()("flash-sale-progress-bar__complement-wrapper", "flash-sale-progress-bar__complement-wrapper--" + s)
                }, n.createElement("div", {
                    className: o()("flash-sale-progress-bar__complement-sizer", "flash-sale-progress-bar__complement-sizer--" + s),
                    style: {
                        width: m + "%"
                    }
                }, n.createElement("div", {
                    className: "flash-sale-progress-bar__complement-color"
                }))), c <= 50 && n.createElement("div", {
                    className: "flash-sale-progress-bar__fire"
                })))
            }))
        },
        58295: function(e, t, a) {
            "use strict";
            a.d(t, {
                OO: function() {
                    return n.OO
                },
                Cf: function() {
                    return n.Cf
                },
                VL: function() {
                    return n.VL
                },
                tI: function() {
                    return n.tI
                },
                l: function() {
                    return n.l
                },
                TE: function() {
                    return n.TE
                }
            });
            var n = a(51816)
        },
        51720: function(e, t, a) {
            "use strict";
            a.d(t, {
                Y: function() {
                    return n.ui
                },
                m: function() {
                    return n.mt
                }
            });
            var n = a(29659)
        }
    }
]);
//# sourceMappingURL=https://shopee.sg/assets/4309.9a25c11030068f42c5bd.js.map