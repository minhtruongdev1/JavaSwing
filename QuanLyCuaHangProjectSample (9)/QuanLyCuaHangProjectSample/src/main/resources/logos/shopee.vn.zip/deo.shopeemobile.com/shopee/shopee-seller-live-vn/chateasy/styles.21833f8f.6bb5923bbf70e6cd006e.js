(window.miniJsonp = window.miniJsonp || []).push([
    [6], {
        "+TCL": function(e, o, s) {
            e.exports = {
                "product-item-wrapper": "src-modules-conversationDetail-component-InputField-Toolbar-ProductPopover-index__product-item-wrapper--1Ah8u",
                productItemWrapper: "src-modules-conversationDetail-component-InputField-Toolbar-ProductPopover-index__product-item-wrapper--1Ah8u",
                "tab-nav": "src-modules-conversationDetail-component-InputField-Toolbar-ProductPopover-index__tab-nav--2eBWV",
                tabNav: "src-modules-conversationDetail-component-InputField-Toolbar-ProductPopover-index__tab-nav--2eBWV",
                "shop-icon": "src-modules-conversationDetail-component-InputField-Toolbar-ProductPopover-index__shop-icon--2Vxmd",
                shopIcon: "src-modules-conversationDetail-component-InputField-Toolbar-ProductPopover-index__shop-icon--2Vxmd",
                "shop-name": "src-modules-conversationDetail-component-InputField-Toolbar-ProductPopover-index__shop-name--PnMZe",
                shopName: "src-modules-conversationDetail-component-InputField-Toolbar-ProductPopover-index__shop-name--PnMZe",
                complete: "src-modules-conversationDetail-component-InputField-Toolbar-ProductPopover-index__complete--3dtzk"
            }
        },
        "/o74": function(e, o, s) {
            e.exports = {
                root: "src-components-Common-Modal-ModalFooter-index__root--3HHSm"
            }
        },
        "1iP0": function(e, o, s) {
            e.exports = {
                header: "src-modules-conversationDetail-component-index__header--1rfp7",
                zone: "src-modules-conversationDetail-component-index__zone--Xa4RW",
                "drag-over": "src-modules-conversationDetail-component-index__drag-over--2NXKn",
                dragOver: "src-modules-conversationDetail-component-index__drag-over--2NXKn",
                input: "src-modules-conversationDetail-component-index__input--1mVbC",
                message: "src-modules-conversationDetail-component-index__message--32BNf",
                mediaPreviewerWrap: "src-modules-conversationDetail-component-index__mediaPreviewerWrap--2LlmA"
            }
        },
        "2WOU": function(e, o, s) {
            e.exports = {
                btn: "src-components-UI-Button-index__btn--101Hy",
                "shopee-btn": "src-components-UI-Button-index__shopee-btn--3E5Lm src-components-UI-Button-index__btn--101Hy",
                shopeeBtn: "src-components-UI-Button-index__shopee-btn--3E5Lm src-components-UI-Button-index__btn--101Hy",
                disabled: "src-components-UI-Button-index__disabled--3mMOK",
                "size-tiny": "src-components-UI-Button-index__size-tiny--3kpmI",
                sizeTiny: "src-components-UI-Button-index__size-tiny--3kpmI",
                "size-small": "src-components-UI-Button-index__size-small--2l7S-",
                sizeSmall: "src-components-UI-Button-index__size-small--2l7S-",
                "size-large": "src-components-UI-Button-index__size-large--sgVAj",
                sizeLarge: "src-components-UI-Button-index__size-large--sgVAj",
                "size-custome": "src-components-UI-Button-index__size-custome--II73Z",
                sizeCustome: "src-components-UI-Button-index__size-custome--II73Z",
                "theme-primary": "src-components-UI-Button-index__theme-primary--2Ke0o",
                themePrimary: "src-components-UI-Button-index__theme-primary--2Ke0o",
                "shape-outline": "src-components-UI-Button-index__shape-outline--27InS",
                shapeOutline: "src-components-UI-Button-index__shape-outline--27InS",
                "shape-frameless": "src-components-UI-Button-index__shape-frameless--ERK16",
                shapeFrameless: "src-components-UI-Button-index__shape-frameless--ERK16",
                "button-rounded": "src-components-UI-Button-index__button-rounded--1MppU",
                buttonRounded: "src-components-UI-Button-index__button-rounded--1MppU",
                "theme-red": "src-components-UI-Button-index__theme-red--1IuOG",
                themeRed: "src-components-UI-Button-index__theme-red--1IuOG",
                "theme-blue": "src-components-UI-Button-index__theme-blue--2GXaH",
                themeBlue: "src-components-UI-Button-index__theme-blue--2GXaH"
            }
        },
        "6xV8": function(e, o, s) {
            e.exports = {
                error: "src-components-Common-ErrorBoundary-index__error--2p3ST",
                img: "src-components-Common-ErrorBoundary-index__img--3iR4d",
                loadMore: "src-components-Common-ErrorBoundary-index__loadMore--34RLf"
            }
        },
        "8Oat": function(e, o, s) {
            e.exports = {
                root: "src-components-Common-ToastBubble-index__root--1MX2V",
                show: "src-components-Common-ToastBubble-index__show--2dzv4",
                mall: "src-components-Common-ToastBubble-index__mall--1bcii src-components-Common-ToastBubble-index__root--1MX2V",
                icon: "src-components-Common-ToastBubble-index__icon--3y_PL",
                success: "src-components-Common-ToastBubble-index__success--1kOJT",
                fail: "src-components-Common-ToastBubble-index__fail--tuncr",
                error: "src-components-Common-ToastBubble-index__error--2d_f1",
                info: "src-components-Common-ToastBubble-index__info--3UVTg",
                warn: "src-components-Common-ToastBubble-index__warn--A7_f1",
                message: "src-components-Common-ToastBubble-index__message--27eK2"
            }
        },
        "9xvY": function(e, o, s) {
            e.exports = {
                "detail-block": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-Common-ProductItem-index__detail-block--22YpB",
                detailBlock: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-Common-ProductItem-index__detail-block--22YpB",
                image: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-Common-ProductItem-index__image--3VcrL",
                invalid: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-Common-ProductItem-index__invalid--3o1wj src-modules-conversationDetail-component-MessageSection-ConversationMessages-Common-ProductItem-index__image--3VcrL",
                "invalid-icon": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-Common-ProductItem-index__invalid-icon--3cDz2",
                invalidIcon: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-Common-ProductItem-index__invalid-icon--3cDz2",
                content: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-Common-ProductItem-index__content--17W-i",
                "no-model": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-Common-ProductItem-index__no-model--2_uEW",
                noModel: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-Common-ProductItem-index__no-model--2_uEW",
                priceDetail: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-Common-ProductItem-index__priceDetail--WqSlU",
                invalidBrand: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-Common-ProductItem-index__invalidBrand--2iM_0",
                divider: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-Common-ProductItem-index__divider--8vGzA",
                price: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-Common-ProductItem-index__price--rT8rZ",
                name: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-Common-ProductItem-index__name--3501h",
                dot: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-Common-ProductItem-index__dot--3o53k",
                "image-border": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-Common-ProductItem-index__image-border--1nDvQ",
                imageBorder: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-Common-ProductItem-index__image-border--1nDvQ"
            }
        },
        AWp0: function(e, o, s) {
            e.exports = {
                "new-message-tip": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-NewMessageTip-index__new-message-tip--VAZGT",
                newMessageTip: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-NewMessageTip-index__new-message-tip--VAZGT",
                "new-message-content": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-NewMessageTip-index__new-message-content--3cmnl",
                newMessageContent: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-NewMessageTip-index__new-message-content--3cmnl",
                "prev-line": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-NewMessageTip-index__prev-line--3_Cx2",
                prevLine: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-NewMessageTip-index__prev-line--3_Cx2",
                "post-line": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-NewMessageTip-index__post-line--XoKz9",
                postLine: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-NewMessageTip-index__post-line--XoKz9"
            }
        },
        AlKw: function(e, o, s) {
            e.exports = {
                root: "src-pages-ConversationLists-ConversationCells-index__root--2c-3H",
                empty: "src-pages-ConversationLists-ConversationCells-index__empty--2z4Bf",
                highlighted: "src-pages-ConversationLists-ConversationCells-index__highlighted--2ZVTo",
                avatar: "src-pages-ConversationLists-ConversationCells-index__avatar--2ysIp",
                container: "src-pages-ConversationLists-ConversationCells-index__container--aqDNm",
                pinned: "src-pages-ConversationLists-ConversationCells-index__pinned--2QKv0",
                upper: "src-pages-ConversationLists-ConversationCells-index__upper--1WFzs",
                lower: "src-pages-ConversationLists-ConversationCells-index__lower--2T1ND",
                username: "src-pages-ConversationLists-ConversationCells-index__username--2o8T7",
                "username-feed-container": "src-pages-ConversationLists-ConversationCells-index__username-feed-container--rCQUJ",
                usernameFeedContainer: "src-pages-ConversationLists-ConversationCells-index__username-feed-container--rCQUJ",
                feed: "src-pages-ConversationLists-ConversationCells-index__feed--hD3TN",
                wrapper: "src-pages-ConversationLists-ConversationCells-index__wrapper--2XPN4",
                keyword: "src-pages-ConversationLists-ConversationCells-index__keyword--3MrN6",
                text: "src-pages-ConversationLists-ConversationCells-index__text--3HOCt",
                closed: "src-pages-ConversationLists-ConversationCells-index__closed--31Tzx",
                banned: "src-pages-ConversationLists-ConversationCells-index__banned--3KBrS src-pages-ConversationLists-ConversationCells-index__closed--31Tzx",
                unread: "src-pages-ConversationLists-ConversationCells-index__unread--2ZBvy",
                "mall-unread": "src-pages-ConversationLists-ConversationCells-index__mall-unread--2b21B src-pages-ConversationLists-ConversationCells-index__unread--2ZBvy",
                mallUnread: "src-pages-ConversationLists-ConversationCells-index__mall-unread--2b21B src-pages-ConversationLists-ConversationCells-index__unread--2ZBvy",
                message: "src-pages-ConversationLists-ConversationCells-index__message--3hDTo",
                timestamp: "src-pages-ConversationLists-ConversationCells-index__timestamp--2V1YK",
                "three-dots": "src-pages-ConversationLists-ConversationCells-index__three-dots--1zgO8",
                threeDots: "src-pages-ConversationLists-ConversationCells-index__three-dots--1zgO8",
                "three-dots-icon": "src-pages-ConversationLists-ConversationCells-index__three-dots-icon--1psZR",
                threeDotsIcon: "src-pages-ConversationLists-ConversationCells-index__three-dots-icon--1psZR",
                active: "src-pages-ConversationLists-ConversationCells-index__active--1SO6N",
                draft: "src-pages-ConversationLists-ConversationCells-index__draft--30Oe8",
                status: "src-pages-ConversationLists-ConversationCells-index__status--1572s",
                sending: "src-pages-ConversationLists-ConversationCells-index__sending--3rSZR src-pages-ConversationLists-ConversationCells-index__status--1572s",
                rotate: "src-pages-ConversationLists-ConversationCells-index__rotate--1RzXh",
                failed: "src-pages-ConversationLists-ConversationCells-index__failed--HuvD9 src-pages-ConversationLists-ConversationCells-index__status--1572s",
                "options-icon": "src-pages-ConversationLists-ConversationCells-index__options-icon--3iPkZ",
                optionsIcon: "src-pages-ConversationLists-ConversationCells-index__options-icon--3iPkZ",
                "option-delete": "src-pages-ConversationLists-ConversationCells-index__option-delete--3OxjV",
                optionDelete: "src-pages-ConversationLists-ConversationCells-index__option-delete--3OxjV",
                forward: "src-pages-ConversationLists-ConversationCells-index__forward--WlX5o"
            }
        },
        Cj5w: function(e, o, s) {
            e.exports = {
                "resend-wrap": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-ErrorContent-index__resend-wrap--vNiJ4",
                resendWrap: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-ErrorContent-index__resend-wrap--vNiJ4",
                "icon-base": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-ErrorContent-index__icon-base--3XSxv",
                iconBase: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-ErrorContent-index__icon-base--3XSxv",
                icon: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-ErrorContent-index__icon--3zvzS src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-ErrorContent-index__icon-base--3XSxv"
            }
        },
        DcsN: function(e, o, s) {
            e.exports = {
                root: "src-modules-conversationDetail-component-InputField-ChatEditor-index__root--1fgd5",
                editor: "src-modules-conversationDetail-component-InputField-ChatEditor-index__editor--pmSS2",
                selected: "src-modules-conversationDetail-component-InputField-ChatEditor-index__selected--2RnZo",
                "send-button": "src-modules-conversationDetail-component-InputField-ChatEditor-index__send-button--2S3uj",
                sendButton: "src-modules-conversationDetail-component-InputField-ChatEditor-index__send-button--2S3uj",
                button: "src-modules-conversationDetail-component-InputField-ChatEditor-index__button--1B6_-",
                "button-active": "src-modules-conversationDetail-component-InputField-ChatEditor-index__button-active--1UCrc src-modules-conversationDetail-component-InputField-ChatEditor-index__button--1B6_-",
                buttonActive: "src-modules-conversationDetail-component-InputField-ChatEditor-index__button-active--1UCrc src-modules-conversationDetail-component-InputField-ChatEditor-index__button--1B6_-",
                wordlimit: "src-modules-conversationDetail-component-InputField-ChatEditor-index__wordlimit--1eg96",
                exceed: "src-modules-conversationDetail-component-InputField-ChatEditor-index__exceed--Md1je",
                "send-tooltip": "src-modules-conversationDetail-component-InputField-ChatEditor-index__send-tooltip--2vnkF",
                sendTooltip: "src-modules-conversationDetail-component-InputField-ChatEditor-index__send-tooltip--2vnkF"
            }
        },
        FGDU: function(e, o, s) {
            e.exports = {
                root: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BundelDealMessage-index__root--1J8N8",
                send: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BundelDealMessage-index__send--21dd8",
                receive: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BundelDealMessage-index__receive--QxVwf",
                header: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BundelDealMessage-index__header--2eWzt",
                active: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BundelDealMessage-index__active--1Kk11",
                inactive: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BundelDealMessage-index__inactive--32CQ3",
                detail: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BundelDealMessage-index__detail--5YR3Q",
                footer: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BundelDealMessage-index__footer--2ZyYx",
                "text-end": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BundelDealMessage-index__text-end--2kW-N",
                textEnd: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BundelDealMessage-index__text-end--2kW-N"
            }
        },
        FK2i: function(e, o, s) {
            e.exports = {
                container: "src-pages-ChatWindow-index__container--1qoj1",
                header: "src-pages-ChatWindow-index__header--USXSl",
                windows: "src-pages-ChatWindow-index__windows--3KL4n",
                "logo-wrapper": "src-pages-ChatWindow-index__logo-wrapper--1rM8W",
                logoWrapper: "src-pages-ChatWindow-index__logo-wrapper--1rM8W",
                logo: "src-pages-ChatWindow-index__logo--3ygfr",
                "operator-wrapper": "src-pages-ChatWindow-index__operator-wrapper--Wcn9j",
                operatorWrapper: "src-pages-ChatWindow-index__operator-wrapper--Wcn9j",
                "operator-item-wrapper": "src-pages-ChatWindow-index__operator-item-wrapper--2_9Si",
                operatorItemWrapper: "src-pages-ChatWindow-index__operator-item-wrapper--2_9Si",
                "operator-item": "src-pages-ChatWindow-index__operator-item--JM24S",
                operatorItem: "src-pages-ChatWindow-index__operator-item--JM24S",
                "show-dialog": "src-pages-ChatWindow-index__show-dialog--1vT1i src-pages-ChatWindow-index__operator-item--JM24S",
                showDialog: "src-pages-ChatWindow-index__show-dialog--1vT1i src-pages-ChatWindow-index__operator-item--JM24S",
                "hide-dialog": "src-pages-ChatWindow-index__hide-dialog--1STCP src-pages-ChatWindow-index__operator-item--JM24S",
                hideDialog: "src-pages-ChatWindow-index__hide-dialog--1STCP src-pages-ChatWindow-index__operator-item--JM24S",
                minimize: "src-pages-ChatWindow-index__minimize--3dPxE src-pages-ChatWindow-index__operator-item--JM24S",
                "see-all": "src-pages-ChatWindow-index__see-all--1XnL1 src-pages-ChatWindow-index__operator-item--JM24S",
                seeAll: "src-pages-ChatWindow-index__see-all--1XnL1 src-pages-ChatWindow-index__operator-item--JM24S",
                "custom-menu": "src-pages-ChatWindow-index__custom-menu--1leqN",
                customMenu: "src-pages-ChatWindow-index__custom-menu--1leqN",
                "status-option": "src-pages-ChatWindow-index__status-option--27OcN",
                statusOption: "src-pages-ChatWindow-index__status-option--27OcN",
                selected: "src-pages-ChatWindow-index__selected--1yWYV",
                active: "src-pages-ChatWindow-index__active--SL1Bb",
                "current-status": "src-pages-ChatWindow-index__current-status--3mXF5",
                currentStatus: "src-pages-ChatWindow-index__current-status--3mXF5",
                status: "src-pages-ChatWindow-index__status--3fvT2",
                "user-status": "src-pages-ChatWindow-index__user-status--OiJ9v",
                userStatus: "src-pages-ChatWindow-index__user-status--OiJ9v",
                "hover-style": "src-pages-ChatWindow-index__hover-style--nKsmu",
                hoverStyle: "src-pages-ChatWindow-index__hover-style--nKsmu",
                working: "src-pages-ChatWindow-index__working--7WJEL",
                hangup: "src-pages-ChatWindow-index__hangup--2x5_N",
                hang_up: "src-pages-ChatWindow-index__hang_up--2oK5J",
                hangUp: "src-pages-ChatWindow-index__hang_up--2oK5J",
                arrow: "src-pages-ChatWindow-index__arrow--3hZxi",
                "guide-content": "src-pages-ChatWindow-index__guide-content--1Q9v8",
                guideContent: "src-pages-ChatWindow-index__guide-content--1Q9v8",
                "guide-item": "src-pages-ChatWindow-index__guide-item--31OYs",
                guideItem: "src-pages-ChatWindow-index__guide-item--31OYs",
                "guide-icon": "src-pages-ChatWindow-index__guide-icon--1xFR6",
                guideIcon: "src-pages-ChatWindow-index__guide-icon--1xFR6",
                "guide-tip": "src-pages-ChatWindow-index__guide-tip--17cIL",
                guideTip: "src-pages-ChatWindow-index__guide-tip--17cIL",
                "guide-btn": "src-pages-ChatWindow-index__guide-btn--aEd5z",
                guideBtn: "src-pages-ChatWindow-index__guide-btn--aEd5z",
                portal: "src-pages-ChatWindow-index__portal--DV4Qq",
                unread: "src-pages-ChatWindow-index__unread--3ljEi",
                "unread-open": "src-pages-ChatWindow-index__unread-open--10xov",
                unreadOpen: "src-pages-ChatWindow-index__unread-open--10xov",
                "unread-close": "src-pages-ChatWindow-index__unread-close--2H65U",
                unreadClose: "src-pages-ChatWindow-index__unread-close--2H65U",
                details: "src-pages-ChatWindow-index__details--3uIPO",
                "half-container": "src-pages-ChatWindow-index__half-container--30UWO src-pages-ChatWindow-index__container--1qoj1",
                halfContainer: "src-pages-ChatWindow-index__half-container--30UWO src-pages-ChatWindow-index__container--1qoj1",
                conversations: "src-pages-ChatWindow-index__conversations--LJ1VZ",
                blank: "src-pages-ChatWindow-index__blank--2pLm1",
                maxBlank: "src-pages-ChatWindow-index__maxBlank--17RoZ",
                image: "src-pages-ChatWindow-index__image--3GQ-r",
                "error-image": "src-pages-ChatWindow-index__error-image--ApbYo",
                errorImage: "src-pages-ChatWindow-index__error-image--ApbYo",
                title: "src-pages-ChatWindow-index__title--200qt",
                subtitle: "src-pages-ChatWindow-index__subtitle--1y5vi",
                reload: "src-pages-ChatWindow-index__reload--f2Tg1"
            }
        },
        FL8G: function(e, o, s) {
            e.exports = {
                root: "src-modules-conversationDetail-component-MessageSection-TranslateTips-index__root--35j8r",
                left: "src-modules-conversationDetail-component-MessageSection-TranslateTips-index__left--3lb1l",
                icon: "src-modules-conversationDetail-component-MessageSection-TranslateTips-index__icon--372uF",
                tips: "src-modules-conversationDetail-component-MessageSection-TranslateTips-index__tips--30PbJ",
                close: "src-modules-conversationDetail-component-MessageSection-TranslateTips-index__close--3qwjq"
            }
        },
        HuPw: function(e, o, s) {
            e.exports = {
                "meta-info": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MetaInfo-index__meta-info--10N_d",
                metaInfo: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MetaInfo-index__meta-info--10N_d",
                "meta-content": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MetaInfo-index__meta-content--12QUV",
                metaContent: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MetaInfo-index__meta-content--12QUV"
            }
        },
        IsXm: function(e, o, s) {
            e.exports = {
                root: "src-components-Common-Modal-ModalHeader-index__root--2kngq",
                title: "src-components-Common-Modal-ModalHeader-index__title--g0rkq",
                "has-cancel": "src-components-Common-Modal-ModalHeader-index__has-cancel--3ifQa",
                hasCancel: "src-components-Common-Modal-ModalHeader-index__has-cancel--3ifQa",
                cancel: "src-components-Common-Modal-ModalHeader-index__cancel--1UUqn"
            }
        },
        LI8N: function(e, o, s) {
            e.exports = {
                root: "src-pages-ConversationLists-index__root--3_OYj",
                "conversation-lists": "src-pages-ConversationLists-index__conversation-lists--gMnh8",
                conversationLists: "src-pages-ConversationLists-index__conversation-lists--gMnh8",
                hangupTip: "src-pages-ConversationLists-index__hangupTip--1K77Q",
                left: "src-pages-ConversationLists-index__left--1OeMi",
                image: "src-pages-ConversationLists-index__image--1lH2f",
                feedback: "src-pages-ConversationLists-index__feedback--14hfY",
                icon: "src-pages-ConversationLists-index__icon--2NtVq",
                rotates: "src-pages-ConversationLists-index__rotates--3xhS1"
            }
        },
        PwHj: function(e, o, s) {
            e.exports = {
                overlay: "src-components-UI-Modal-index__overlay--15_uM",
                content: "src-components-UI-Modal-index__content--2PHIZ"
            }
        },
        RBR7: function(e, o, s) {
            e.exports = {
                root: "src-components-Common-Menus-index__root--2dnxA",
                button: "src-components-Common-Menus-index__button--2et6C",
                portal: "src-components-Common-Menus-index__portal--J9c_O",
                list: "src-components-Common-Menus-index__list--2tWe8",
                info: "src-components-Common-Menus-index__info--1mpiW",
                name: "src-components-Common-Menus-index__name--2I-HI",
                detail: "src-components-Common-Menus-index__detail--3AlUU",
                wrapper: "src-components-Common-Menus-index__wrapper--2T64C",
                divide: "src-components-Common-Menus-index__divide--3cgpp",
                option: "src-components-Common-Menus-index__option--2lyP0",
                node: "src-components-Common-Menus-index__node--sBdyU src-components-Common-Menus-index__option--2lyP0",
                "outer-link": "src-components-Common-Menus-index__outer-link--26mTw",
                outerLink: "src-components-Common-Menus-index__outer-link--26mTw",
                "outer-link-icon": "src-components-Common-Menus-index__outer-link-icon--2MGv0",
                outerLinkIcon: "src-components-Common-Menus-index__outer-link-icon--2MGv0",
                reddot: "src-components-Common-Menus-index__reddot--1-mWA",
                popover: "src-components-Common-Menus-index__popover--kPHFo"
            }
        },
        Smyv: function(e, o, s) {
            e.exports = {
                root: "src-components-Common-ScrollList-style__root--31xcV",
                empty: "src-components-Common-ScrollList-style__empty--jHfK1"
            }
        },
        "T/S7": function(e, o, s) {
            e.exports = {
                root: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-FAQHistoryMessage-index__root--3UBje",
                send: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-FAQHistoryMessage-index__send--33q5K",
                receive: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-FAQHistoryMessage-index__receive--6gxrN",
                container: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-FAQHistoryMessage-index__container--1c4fE",
                header: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-FAQHistoryMessage-index__header--27Kr1",
                footer: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-FAQHistoryMessage-index__footer--3AjSE",
                preview: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-FAQHistoryMessage-index__preview--3eaPC"
            }
        },
        TGg8: function(e, o, s) {
            e.exports = {
                root: "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__root--1-7KP",
                "no-edit": "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__no-edit--2dsUv",
                noEdit: "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__no-edit--2dsUv",
                label: "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__label--3PAoJ",
                "edit-entry": "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__edit-entry--3YUsh",
                editEntry: "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__edit-entry--3YUsh",
                "edit-text": "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__edit-text--qV0Iu",
                editText: "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__edit-text--qV0Iu",
                "message-list": "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__message-list--1KwOt",
                messageList: "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__message-list--1KwOt",
                content: "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__content--G9VTU",
                "active-content": "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__active-content--33c4h",
                activeContent: "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__active-content--33c4h",
                "message-text": "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__message-text--2pcfO",
                messageText: "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__message-text--2pcfO",
                "select-tips": "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__select-tips--3Gdaq",
                selectTips: "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__select-tips--3Gdaq",
                tips: "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__tips--2uk-h",
                "empty-list": "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__empty-list--2CA_P",
                emptyList: "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__empty-list--2CA_P",
                "empty-tips": "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__empty-tips--bQrQg",
                emptyTips: "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__empty-tips--bQrQg",
                "empty-image": "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__empty-image--2-1AV",
                emptyImage: "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__empty-image--2-1AV",
                "create-button": "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__create-button--1y8HW",
                createButton: "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__create-button--1y8HW",
                "button-no-access": "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__button-no-access--2kSNO",
                buttonNoAccess: "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__button-no-access--2kSNO",
                "sub-title": "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__sub-title--2gBi0",
                subTitle: "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__sub-title--2gBi0",
                "general-text": "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__general-text--2c6tw",
                generalText: "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__general-text--2c6tw",
                "group-header": "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__group-header--1gox6",
                groupHeader: "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__group-header--1gox6",
                "scroll-headr": "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__scroll-headr--34mP5",
                scrollHeadr: "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__scroll-headr--34mP5",
                "group-item": "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__group-item--3yvxI",
                groupItem: "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__group-item--3yvxI",
                active: "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__active--3r2Jd",
                arrow: "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__arrow--1O15j",
                "arrow-left": "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__arrow-left--1Z84B src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__arrow--1O15j",
                arrowLeft: "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__arrow-left--1Z84B src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__arrow--1O15j",
                "arrow-right": "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__arrow-right--lnJJr src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__arrow--1O15j",
                arrowRight: "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__arrow-right--lnJJr src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-MessageShortcutList-index__arrow--1O15j"
            }
        },
        UtK8: function(e, o, s) {
            e.exports = {
                "detail-block": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-common__detail-block--3pQnq",
                detailBlock: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-common__detail-block--3pQnq",
                image: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-common__image--3lORG",
                "image-border": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-common__image-border--2c25A",
                imageBorder: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-common__image-border--2c25A",
                invalid: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-common__invalid--3Wk1q src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-common__image--3lORG",
                "invalid-icon": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-common__invalid-icon--r9h2a",
                invalidIcon: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-common__invalid-icon--r9h2a",
                content: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-common__content--1Pe7s",
                "no-model": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-common__no-model--oxjjO",
                noModel: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-common__no-model--oxjjO",
                name: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-common__name--3TkUA",
                "product-name": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-common__product-name--3oVis src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-common__name--3TkUA",
                productName: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-common__product-name--3oVis src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-common__name--3TkUA",
                "order-name": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-common__order-name--1mzC1 src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-common__name--3TkUA",
                orderName: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-common__order-name--1mzC1 src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-common__name--3TkUA",
                "offer-name": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-common__offer-name--tRQSv src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-common__name--3TkUA",
                offerName: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-common__offer-name--tRQSv src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-common__name--3TkUA",
                "order-detail": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-common__order-detail--3Pn_4",
                orderDetail: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-common__order-detail--3Pn_4",
                divider: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-common__divider--18Z60",
                "product-detail": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-common__product-detail--2uWKb",
                productDetail: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-common__product-detail--2uWKb"
            }
        },
        V5eP: function(e, o, s) {
            e.exports = {
                overlay: "src-components-Common-Modal-style__overlay--38xwc",
                content: "src-components-Common-Modal-style__content--2Dew0"
            }
        },
        VFQk: function(e, o, s) {
            e.exports = {
                root: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-FlashSaleMessage-index__root--1IpNU",
                send: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-FlashSaleMessage-index__send--FdIvF",
                receive: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-FlashSaleMessage-index__receive--3sODH",
                header: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-FlashSaleMessage-index__header--2YXr1",
                "product-header": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-FlashSaleMessage-index__product-header--2COqV",
                productHeader: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-FlashSaleMessage-index__product-header--2COqV",
                "product-header-inactive": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-FlashSaleMessage-index__product-header-inactive--1dvxF",
                productHeaderInactive: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-FlashSaleMessage-index__product-header-inactive--1dvxF",
                "header-right": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-FlashSaleMessage-index__header-right--2ySbH",
                headerRight: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-FlashSaleMessage-index__header-right--2ySbH",
                headerText: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-FlashSaleMessage-index__headerText--3bjMR",
                price: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-FlashSaleMessage-index__price--ebVwo",
                discount: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-FlashSaleMessage-index__discount--2mNyD",
                soldout: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-FlashSaleMessage-index__soldout--2VwC2",
                textEnd: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-FlashSaleMessage-index__textEnd--G_rxr",
                footer: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-FlashSaleMessage-index__footer--2J9eb"
            }
        },
        "Vx+b": function(e, o, s) {
            e.exports = {
                root: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-index__root--Lum6r",
                source: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-index__source--206aW",
                product: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-index__product--3pvGV",
                order: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-index__order--2jBbF",
                offer: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-index__offer--2wN4S",
                header: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-index__header--10t5H",
                body: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-index__body--3C3Ft",
                image: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-index__image--2ZYdh",
                content: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-index__content--2CGwl",
                "order-info": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-index__order-info--3JRFQ",
                orderInfo: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-index__order-info--3JRFQ",
                prices: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-index__prices--315Ql",
                "first-block": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-index__first-block--3VKdH",
                firstBlock: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-index__first-block--3VKdH",
                block: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-index__block--1SH58 src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-index__first-block--3VKdH",
                label: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-index__label--3DFT8",
                income: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-index__income--1rvql",
                serial: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-index__serial--FDrIK",
                number: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-index__number--3Ke0E",
                create: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-index__create--23Bnb",
                "original-price": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-index__original-price--NBHKJ",
                originalPrice: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-index__original-price--NBHKJ",
                "offer-price": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-index__offer-price--1DB8F",
                offerPrice: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-index__offer-price--1DB8F",
                price: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-index__price--1f7uz",
                accept: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-index__accept--1M7Cb",
                count: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-index__count--2uKBp"
            }
        },
        W9K7: function(e, o, s) {
            e.exports = {
                policy: "src-components-Common-CancelOrderHint-index__policy--5wLVI"
            }
        },
        WIfX: function(e, o, s) {
            e.exports = {
                root: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-Footer-index__root--4_lV-",
                source: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-Footer-index__source--3vSl2",
                label: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-Footer-index__label--3cyK4",
                "accept-btn": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-Footer-index__accept-btn--3Cbk-",
                acceptBtn: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-Footer-index__accept-btn--3Cbk-",
                "reject-btn": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-Footer-index__reject-btn--2sDHk",
                rejectBtn: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-Footer-index__reject-btn--2sDHk",
                "status-text": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-Footer-index__status-text--3wA7Z",
                statusText: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-Footer-index__status-text--3wA7Z",
                link: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-Footer-index__link--2u1Nl",
                actions: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-Footer-index__actions--2VkGI",
                disabled: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-Footer-index__disabled--2rSCx",
                "accept-icon": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-Footer-index__accept-icon--3hvlS",
                acceptIcon: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-Footer-index__accept-icon--3hvlS",
                "reject-icon": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-Footer-index__reject-icon--3G-Fm",
                rejectIcon: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-Footer-index__reject-icon--3G-Fm",
                "no-access": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-Footer-index__no-access--3jRDs",
                noAccess: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-Footer-index__no-access--3jRDs",
                "send-status": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-Footer-index__send-status--1e9rJ",
                sendStatus: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-Footer-index__send-status--1e9rJ",
                "link-arrow": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-Footer-index__link-arrow--3YCY2",
                linkArrow: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-Footer-index__link-arrow--3YCY2"
            }
        },
        WuDf: function(e, o, s) {
            e.exports = {
                root: "src-components-UI-Star-index__root--3cE1D",
                editable: "src-components-UI-Star-index__editable--2vNlW",
                empty: "src-components-UI-Star-index__empty--2FxbX",
                full: "src-components-UI-Star-index__full--3YKAT",
                layout: "src-components-UI-Star-index__layout--xVzwv",
                small: "src-components-UI-Star-index__small--z9xOD",
                normal: "src-components-UI-Star-index__normal--2HT2I",
                large: "src-components-UI-Star-index__large--2lfLs"
            }
        },
        "X+/D": function(e, o, s) {
            e.exports = {
                root: "src-components-Common-Modal-ConfirmModal-style__root--1G08P",
                title: "src-components-Common-Modal-ConfirmModal-style__title--GMRGR",
                content: "src-components-Common-Modal-ConfirmModal-style__content--1eg4Y",
                "no-title": "src-components-Common-Modal-ConfirmModal-style__no-title--3Wzxh",
                noTitle: "src-components-Common-Modal-ConfirmModal-style__no-title--3Wzxh",
                actions: "src-components-Common-Modal-ConfirmModal-style__actions--2O8Nq",
                action: "src-components-Common-Modal-ConfirmModal-style__action--1TXMo",
                cancel: "src-components-Common-Modal-ConfirmModal-style__cancel--A3VCw src-components-Common-Modal-ConfirmModal-style__action--1TXMo",
                confirm: "src-components-Common-Modal-ConfirmModal-style__confirm--1NYTx src-components-Common-Modal-ConfirmModal-style__action--1TXMo"
            }
        },
        Xu7G: function(e, o, s) {
            e.exports = {
                root: "src-modules-conversationDetail-component-InputField-ChatEditor-Hints-style__root--3bXGa"
            }
        },
        Y4DK: function(e, o, s) {
            e.exports = {
                root: "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-index__root--1_q9P",
                header: "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-index__header--xzyD_",
                "header-item": "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-index__header-item--2gtsU",
                headerItem: "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-index__header-item--2gtsU",
                "header-item-active": "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-index__header-item-active--22g3E",
                headerItemActive: "src-modules-conversationDetail-component-InputField-Toolbar-MessageShortcutPopover-index__header-item-active--22g3E"
            }
        },
        Zvlp: function(e, o, s) {
            e.exports = {
                "original-price": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-ProductBody-index__original-price--gR64v",
                originalPrice: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-ProductBody-index__original-price--gR64v",
                price: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-ProductBody-index__price--3cgDr",
                status: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-ProductBody-index__status--2RQdr",
                normal: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-ProductBody-index__normal--32q3l",
                invalid: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-ProductBody-index__invalid--1wkO8",
                deleted: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-ProductBody-index__deleted--16VGL",
                origin: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-ProductBody-index__origin--ME7Ss",
                "inline-block": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-ProductBody-index__inline-block--33evz",
                inlineBlock: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-ProductBody-index__inline-block--33evz",
                "range-price": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-ProductBody-index__range-price--UC8sj",
                rangePrice: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-ProductBody-index__range-price--UC8sj",
                "price-text-small": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-ProductBody-index__price-text-small--eSeDI",
                priceTextSmall: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-ProductBody-index__price-text-small--eSeDI",
                "price-text-mini": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-ProductBody-index__price-text-mini--1eVAK",
                priceTextMini: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-ProductBody-index__price-text-mini--1eVAK"
            }
        },
        aUon: function(e, o, s) {
            e.exports = {
                root: "src-modules-conversationDetail-component-InputField-Toolbar-index__root--3i22j",
                left: "src-modules-conversationDetail-component-InputField-Toolbar-index__left--2TWyG",
                drawer: "src-modules-conversationDetail-component-InputField-Toolbar-index__drawer--4tv5l",
                "label-wrap": "src-modules-conversationDetail-component-InputField-Toolbar-index__label-wrap--3u3lT",
                labelWrap: "src-modules-conversationDetail-component-InputField-Toolbar-index__label-wrap--3u3lT",
                label: "src-modules-conversationDetail-component-InputField-Toolbar-index__label--4e1TY",
                "inactive-label": "src-modules-conversationDetail-component-InputField-Toolbar-index__inactive-label--16IFU",
                inactiveLabel: "src-modules-conversationDetail-component-InputField-Toolbar-index__inactive-label--16IFU",
                "active-label": "src-modules-conversationDetail-component-InputField-Toolbar-index__active-label--2TPXv",
                activeLabel: "src-modules-conversationDetail-component-InputField-Toolbar-index__active-label--2TPXv",
                stickers: "src-modules-conversationDetail-component-InputField-Toolbar-index__stickers--2zQ8S src-modules-conversationDetail-component-InputField-Toolbar-index__label--4e1TY",
                image: "src-modules-conversationDetail-component-InputField-Toolbar-index__image--3Di2y src-modules-conversationDetail-component-InputField-Toolbar-index__label--4e1TY",
                video: "src-modules-conversationDetail-component-InputField-Toolbar-index__video--2R2Kb src-modules-conversationDetail-component-InputField-Toolbar-index__label--4e1TY",
                products: "src-modules-conversationDetail-component-InputField-Toolbar-index__products--3wGJ5 src-modules-conversationDetail-component-InputField-Toolbar-index__label--4e1TY",
                orders: "src-modules-conversationDetail-component-InputField-Toolbar-index__orders--1ZsoJ src-modules-conversationDetail-component-InputField-Toolbar-index__label--4e1TY",
                message_shortcuts: "src-modules-conversationDetail-component-InputField-Toolbar-index__message_shortcuts--7nRj0 src-modules-conversationDetail-component-InputField-Toolbar-index__label--4e1TY",
                messageShortcuts: "src-modules-conversationDetail-component-InputField-Toolbar-index__message_shortcuts--7nRj0 src-modules-conversationDetail-component-InputField-Toolbar-index__label--4e1TY",
                "popper-content": "src-modules-conversationDetail-component-InputField-Toolbar-index__popper-content--1mfan",
                popperContent: "src-modules-conversationDetail-component-InputField-Toolbar-index__popper-content--1mfan",
                disabled: "src-modules-conversationDetail-component-InputField-Toolbar-index__disabled--2rZpT"
            }
        },
        bByp: function(e, o, s) {
            e.exports = {
                root: "src-pages-ConversationLists-Headerbar-index__root--1dKOe",
                search: "src-pages-ConversationLists-Headerbar-index__search--3qaBZ",
                input: "src-pages-ConversationLists-Headerbar-index__input--1vfwR",
                wrapper: "src-pages-ConversationLists-Headerbar-index__wrapper--2E1h9",
                focus: "src-pages-ConversationLists-Headerbar-index__focus--2rA_f",
                icon: "src-pages-ConversationLists-Headerbar-index__icon--2Eyzi",
                cancel: "src-pages-ConversationLists-Headerbar-index__cancel--2lKVx",
                filter: "src-pages-ConversationLists-Headerbar-index__filter--2-eFW",
                selected: "src-pages-ConversationLists-Headerbar-index__selected--2-Frn",
                "arrow-down": "src-pages-ConversationLists-Headerbar-index__arrow-down--32-9v",
                arrowDown: "src-pages-ConversationLists-Headerbar-index__arrow-down--32-9v",
                "reddot-filter": "src-pages-ConversationLists-Headerbar-index__reddot-filter--1McFP",
                reddotFilter: "src-pages-ConversationLists-Headerbar-index__reddot-filter--1McFP",
                reddot: "src-pages-ConversationLists-Headerbar-index__reddot--1GVwX"
            }
        },
        cIpp: function(e, o, s) {
            e.exports = {
                root: "src-modules-conversationDetail-component-InputField-ChatEditor-Hints-Hint-style__root--37jHG",
                selected: "src-modules-conversationDetail-component-InputField-ChatEditor-Hints-Hint-style__selected--1tJS5 src-modules-conversationDetail-component-InputField-ChatEditor-Hints-Hint-style__root--37jHG",
                highlighter: "src-modules-conversationDetail-component-InputField-ChatEditor-Hints-Hint-style__highlighter--3CWOJ",
                "reverse-highlighter": "src-modules-conversationDetail-component-InputField-ChatEditor-Hints-Hint-style__reverse-highlighter--B5jN4 src-modules-conversationDetail-component-InputField-ChatEditor-Hints-Hint-style__highlighter--3CWOJ",
                reverseHighlighter: "src-modules-conversationDetail-component-InputField-ChatEditor-Hints-Hint-style__reverse-highlighter--B5jN4 src-modules-conversationDetail-component-InputField-ChatEditor-Hints-Hint-style__highlighter--3CWOJ",
                tail: "src-modules-conversationDetail-component-InputField-ChatEditor-Hints-Hint-style__tail--2iDfW",
                highlighted: "src-modules-conversationDetail-component-InputField-ChatEditor-Hints-Hint-style__highlighted--1J0ZH"
            }
        },
        d4jj: function(e, o, s) {
            e.exports = {
                root: "src-modules-conversationDetail-component-BuyerProfile-index__root--2wNEP",
                name: "src-modules-conversationDetail-component-BuyerProfile-index__name--1qplR",
                arrow: "src-modules-conversationDetail-component-BuyerProfile-index__arrow--1oXQJ",
                wrapper: "src-modules-conversationDetail-component-BuyerProfile-index__wrapper--30qlh",
                header: "src-modules-conversationDetail-component-BuyerProfile-index__header--JtXaj",
                "mall-header": "src-modules-conversationDetail-component-BuyerProfile-index__mall-header--3Bqjx",
                mallHeader: "src-modules-conversationDetail-component-BuyerProfile-index__mall-header--3Bqjx",
                avatar: "src-modules-conversationDetail-component-BuyerProfile-index__avatar--2goVh",
                basic: "src-modules-conversationDetail-component-BuyerProfile-index__basic--2YjaY",
                "pop-name": "src-modules-conversationDetail-component-BuyerProfile-index__pop-name--3rrmw",
                popName: "src-modules-conversationDetail-component-BuyerProfile-index__pop-name--3rrmw",
                "pop-mall-name": "src-modules-conversationDetail-component-BuyerProfile-index__pop-mall-name--2a0Wq",
                popMallName: "src-modules-conversationDetail-component-BuyerProfile-index__pop-mall-name--2a0Wq",
                rate: "src-modules-conversationDetail-component-BuyerProfile-index__rate--2nnVZ",
                score: "src-modules-conversationDetail-component-BuyerProfile-index__score--2vBd8",
                informations: "src-modules-conversationDetail-component-BuyerProfile-index__informations--2xIZ6",
                "information-item": "src-modules-conversationDetail-component-BuyerProfile-index__information-item--2zotr",
                informationItem: "src-modules-conversationDetail-component-BuyerProfile-index__information-item--2zotr",
                "information-content": "src-modules-conversationDetail-component-BuyerProfile-index__information-content--1PuKM",
                informationContent: "src-modules-conversationDetail-component-BuyerProfile-index__information-content--1PuKM",
                "information-content-order": "src-modules-conversationDetail-component-BuyerProfile-index__information-content-order--1sTST",
                informationContentOrder: "src-modules-conversationDetail-component-BuyerProfile-index__information-content-order--1sTST",
                base: "src-modules-conversationDetail-component-BuyerProfile-index__base--1AgMZ",
                shop: "src-modules-conversationDetail-component-BuyerProfile-index__shop--BS7gA src-modules-conversationDetail-component-BuyerProfile-index__base--1AgMZ",
                location: "src-modules-conversationDetail-component-BuyerProfile-index__location--1DDlH src-modules-conversationDetail-component-BuyerProfile-index__base--1AgMZ",
                successful: "src-modules-conversationDetail-component-BuyerProfile-index__successful--3wFt6 src-modules-conversationDetail-component-BuyerProfile-index__base--1AgMZ",
                unsuccessful: "src-modules-conversationDetail-component-BuyerProfile-index__unsuccessful--1YedE src-modules-conversationDetail-component-BuyerProfile-index__base--1AgMZ",
                operations: "src-modules-conversationDetail-component-BuyerProfile-index__operations--1xz4R"
            }
        },
        dGdO: function(e, o, s) {
            e.exports = {
                root: "src-components-Common-InfiniteList-index__root--3StQn",
                list: "src-components-Common-InfiniteList-index__list--3kTYP",
                shadow: "src-components-Common-InfiniteList-index__shadow--UwK2G",
                grid: "src-components-Common-InfiniteList-index__grid--1sIg_",
                space: "src-components-Common-InfiniteList-index__space--3SJLb"
            }
        },
        dNqK: function(e, o, s) {
            e.exports = {
                root: "src-modules-conversationDetail-component-MessageSection-UnreadBriefMessages-index__root--XamDR",
                "new-message-username": "src-modules-conversationDetail-component-MessageSection-UnreadBriefMessages-index__new-message-username--1tXBc",
                newMessageUsername: "src-modules-conversationDetail-component-MessageSection-UnreadBriefMessages-index__new-message-username--1tXBc",
                "new-message-content": "src-modules-conversationDetail-component-MessageSection-UnreadBriefMessages-index__new-message-content--lJ-Lz",
                newMessageContent: "src-modules-conversationDetail-component-MessageSection-UnreadBriefMessages-index__new-message-content--lJ-Lz",
                "new-message-arrow": "src-modules-conversationDetail-component-MessageSection-UnreadBriefMessages-index__new-message-arrow--3ycKH",
                newMessageArrow: "src-modules-conversationDetail-component-MessageSection-UnreadBriefMessages-index__new-message-arrow--3ycKH"
            }
        },
        dW70: function(e, o, s) {
            e.exports = {
                root: "src-modules-conversationDetail-component-InputField-index__root--1Qf1b",
                toolbar: "src-modules-conversationDetail-component-InputField-index__toolbar--1Pyx0"
            }
        },
        "dh/+": function(e, o, s) {
            e.exports = {
                list: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-FAQHistoryMessage-HistoryList-index__list--4Smuh",
                header: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-FAQHistoryMessage-HistoryList-index__header--2_PwF",
                message: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-FAQHistoryMessage-HistoryList-index__message--1yuJj",
                right: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-FAQHistoryMessage-HistoryList-index__right--8XoKn",
                username: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-FAQHistoryMessage-HistoryList-index__username--1xiCI",
                stamp: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-FAQHistoryMessage-HistoryList-index__stamp--3ykHZ",
                split: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-FAQHistoryMessage-HistoryList-index__split--pW6iS"
            }
        },
        f48l: function(e, o, s) {
            e.exports = {
                "logo-wrapper": "src-pages-Entry-index__logo-wrapper--IqLfz",
                logoWrapper: "src-pages-Entry-index__logo-wrapper--IqLfz",
                logo: "src-pages-Entry-index__logo--2m8Mr",
                "status-dot": "src-pages-Entry-index__status-dot--3neFZ",
                statusDot: "src-pages-Entry-index__status-dot--3neFZ",
                working: "src-pages-Entry-index__working--2qNBQ",
                hangup: "src-pages-Entry-index__hangup--3CSRI",
                hang_up: "src-pages-Entry-index__hang_up--1wgoX",
                hangUp: "src-pages-Entry-index__hang_up--1wgoX",
                jumpbar: "src-pages-Entry-index__jumpbar--xaues",
                jump: "src-pages-Entry-index__jump--2tTE-",
                portal: "src-pages-Entry-index__portal--1EY7W",
                "guide-content": "src-pages-Entry-index__guide-content--2E3Yt",
                guideContent: "src-pages-Entry-index__guide-content--2E3Yt",
                "guide-item": "src-pages-Entry-index__guide-item--lNG6y",
                guideItem: "src-pages-Entry-index__guide-item--lNG6y",
                "guide-icon": "src-pages-Entry-index__guide-icon--3N8KO",
                guideIcon: "src-pages-Entry-index__guide-icon--3N8KO",
                "chat-logo": "src-pages-Entry-index__chat-logo--2hzBa",
                chatLogo: "src-pages-Entry-index__chat-logo--2hzBa",
                "guide-tip": "src-pages-Entry-index__guide-tip--3q96W",
                guideTip: "src-pages-Entry-index__guide-tip--3q96W",
                "guide-btn": "src-pages-Entry-index__guide-btn--1D1qZ",
                guideBtn: "src-pages-Entry-index__guide-btn--1D1qZ",
                chat: "src-pages-Entry-index__chat--3rr3d",
                counts: "src-pages-Entry-index__counts--1f4Va",
                root: "src-pages-Entry-index__root--1G_Ox",
                "sc-entry": "src-pages-Entry-index__sc-entry--ILLvS",
                scEntry: "src-pages-Entry-index__sc-entry--ILLvS",
                "has-unread": "src-pages-Entry-index__has-unread--110fk",
                hasUnread: "src-pages-Entry-index__has-unread--110fk",
                "window-enter": "src-pages-Entry-index__window-enter--WFXa3",
                windowEnter: "src-pages-Entry-index__window-enter--WFXa3",
                "half-window-enter": "src-pages-Entry-index__half-window-enter--2iQ0J",
                halfWindowEnter: "src-pages-Entry-index__half-window-enter--2iQ0J",
                "window-enter-active": "src-pages-Entry-index__window-enter-active--1_4fB",
                windowEnterActive: "src-pages-Entry-index__window-enter-active--1_4fB",
                "half-window-enter-active": "src-pages-Entry-index__half-window-enter-active--Gk43Q",
                halfWindowEnterActive: "src-pages-Entry-index__half-window-enter-active--Gk43Q",
                "window-exit": "src-pages-Entry-index__window-exit--3O-f_",
                windowExit: "src-pages-Entry-index__window-exit--3O-f_",
                "window-exit-active": "src-pages-Entry-index__window-exit-active--8yUZT",
                windowExitActive: "src-pages-Entry-index__window-exit-active--8yUZT",
                "half-window-exit-active": "src-pages-Entry-index__half-window-exit-active--3JbJA src-pages-Entry-index__window-exit-active--8yUZT",
                halfWindowExitActive: "src-pages-Entry-index__half-window-exit-active--3JbJA src-pages-Entry-index__window-exit-active--8yUZT",
                "mall-window-exit-active": "src-pages-Entry-index__mall-window-exit-active--7Sa1M src-pages-Entry-index__window-exit-active--8yUZT",
                mallWindowExitActive: "src-pages-Entry-index__mall-window-exit-active--7Sa1M src-pages-Entry-index__window-exit-active--8yUZT",
                "half-mall-window-exit-active": "src-pages-Entry-index__half-mall-window-exit-active--1VGAe src-pages-Entry-index__window-exit-active--8yUZT",
                halfMallWindowExitActive: "src-pages-Entry-index__half-mall-window-exit-active--1VGAe src-pages-Entry-index__window-exit-active--8yUZT"
            }
        },
        fqMH: function(e, o, s) {
            e.exports = {
                "sending-wrap": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-SendingStatus-index__sending-wrap--3b8Vi",
                sendingWrap: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-SendingStatus-index__sending-wrap--3b8Vi",
                "icon-base": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-SendingStatus-index__icon-base--UCO48",
                iconBase: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-SendingStatus-index__icon-base--UCO48",
                icon: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-SendingStatus-index__icon--2TONy src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-SendingStatus-index__icon-base--UCO48"
            }
        },
        gdj5: function(e, o, s) {
            e.exports = {
                product: "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-Card-index__product--KTy0W",
                left: "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-Card-index__left--1P7zN",
                center: "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-Card-index__center--3wE9z",
                picture: "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-Card-index__picture--2xI6-",
                right: "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-Card-index__right--1ZZpT",
                money: "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-Card-index__money--fhUD7",
                count: "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-Card-index__count--27aZv",
                name: "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-Card-index__name--hZc60",
                details: "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-Card-index__details--3V7Qm",
                model: "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-Card-index__model--hW-_h",
                id: "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-Card-index__id--3mKb6",
                copy: "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-Card-index__copy--3dGDJ",
                tag: "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-Card-index__tag--3OfwA",
                tag_preorder: "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-Card-index__tag_preorder--11sCR",
                tagPreorder: "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-Card-index__tag_preorder--11sCR",
                tag_stars: "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-Card-index__tag_stars--36jFq",
                tagStars: "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-Card-index__tag_stars--36jFq",
                refunded: "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-Card-index__refunded--1F7KF"
            }
        },
        gzZ0: function(e, o, s) {
            e.exports = {
                root: "src-components-Common-ListContainer-index__root--3vLtz",
                tabs: "src-components-Common-ListContainer-index__tabs--Y19NK",
                header: "src-components-Common-ListContainer-index__header--2FJYt",
                tab: "src-components-Common-ListContainer-index__tab--dWatp src-components-Common-ListContainer-index__header--2FJYt",
                active: "src-components-Common-ListContainer-index__active--2KOj5 src-components-Common-ListContainer-index__header--2FJYt",
                main: "src-components-Common-ListContainer-index__main--RhtCG",
                hidden: "src-components-Common-ListContainer-index__hidden--2khwr"
            }
        },
        ilZm: function(e, o, s) {
            e.exports = {
                root: "src-components-Common-SearchBar-index__root--Cgb3Z",
                input: "src-components-Common-SearchBar-index__input--3oQvj",
                wrapper: "src-components-Common-SearchBar-index__wrapper--eFqTf",
                focus: "src-components-Common-SearchBar-index__focus--1DNCo",
                "icon-wrapper": "src-components-Common-SearchBar-index__icon-wrapper--3d4w9",
                iconWrapper: "src-components-Common-SearchBar-index__icon-wrapper--3d4w9",
                icon: "src-components-Common-SearchBar-index__icon--2w7NP",
                cancel: "src-components-Common-SearchBar-index__cancel--35r5V"
            }
        },
        jZ4q: function(e, o, s) {
            e.exports = {
                root: "src-components-Common-Copy-index__root--MbKnn"
            }
        },
        kIFs: function(e, o, s) {
            e.exports = {
                root: "src-components-UI-Stars-index__root--3eQwF",
                stars: "src-components-UI-Stars-index__stars--2H8wc"
            }
        },
        kuoV: function(e, o, s) {
            e.exports = {
                root: "src-components-Common-Avatar-index__root--2xGjv",
                circle: "src-components-Common-Avatar-index__circle--12X2I",
                "avatar-wrapper": "src-components-Common-Avatar-index__avatar-wrapper--29uog",
                avatarWrapper: "src-components-Common-Avatar-index__avatar-wrapper--29uog",
                "avatar-border": "src-components-Common-Avatar-index__avatar-border--2Wkz3",
                avatarBorder: "src-components-Common-Avatar-index__avatar-border--2Wkz3",
                default: "src-components-Common-Avatar-index__default--1e_Nv",
                blue: "src-components-Common-Avatar-index__blue--2n5pG src-components-Common-Avatar-index__default--1e_Nv",
                "blue-gray": "src-components-Common-Avatar-index__blue-gray--1uApj src-components-Common-Avatar-index__default--1e_Nv",
                blueGray: "src-components-Common-Avatar-index__blue-gray--1uApj src-components-Common-Avatar-index__default--1e_Nv",
                green: "src-components-Common-Avatar-index__green--2_qZn src-components-Common-Avatar-index__default--1e_Nv",
                "green-gray": "src-components-Common-Avatar-index__green-gray--2jygG src-components-Common-Avatar-index__default--1e_Nv",
                greenGray: "src-components-Common-Avatar-index__green-gray--2jygG src-components-Common-Avatar-index__default--1e_Nv",
                orange: "src-components-Common-Avatar-index__orange--11MH3 src-components-Common-Avatar-index__default--1e_Nv",
                "orange-gray": "src-components-Common-Avatar-index__orange-gray--247yR src-components-Common-Avatar-index__default--1e_Nv",
                orangeGray: "src-components-Common-Avatar-index__orange-gray--247yR src-components-Common-Avatar-index__default--1e_Nv",
                purple: "src-components-Common-Avatar-index__purple--F1GYX src-components-Common-Avatar-index__default--1e_Nv",
                "purple-gray": "src-components-Common-Avatar-index__purple-gray--25TG9 src-components-Common-Avatar-index__default--1e_Nv",
                purpleGray: "src-components-Common-Avatar-index__purple-gray--25TG9 src-components-Common-Avatar-index__default--1e_Nv",
                red: "src-components-Common-Avatar-index__red--2qmi_ src-components-Common-Avatar-index__default--1e_Nv",
                "red-gray": "src-components-Common-Avatar-index__red-gray--2glFV src-components-Common-Avatar-index__default--1e_Nv",
                redGray: "src-components-Common-Avatar-index__red-gray--2glFV src-components-Common-Avatar-index__default--1e_Nv",
                yellow: "src-components-Common-Avatar-index__yellow--1j7AK src-components-Common-Avatar-index__default--1e_Nv",
                "yellow-gray": "src-components-Common-Avatar-index__yellow-gray--3muye src-components-Common-Avatar-index__default--1e_Nv",
                yellowGray: "src-components-Common-Avatar-index__yellow-gray--3muye src-components-Common-Avatar-index__default--1e_Nv",
                font10: "src-components-Common-Avatar-index__font10--1hcge",
                font12: "src-components-Common-Avatar-index__font12--1Gb-x",
                font14: "src-components-Common-Avatar-index__font14--39Oxl",
                font16: "src-components-Common-Avatar-index__font16--3cwZz",
                font20: "src-components-Common-Avatar-index__font20--34wAb",
                font24: "src-components-Common-Avatar-index__font24--2qVwb",
                font32: "src-components-Common-Avatar-index__font32--3WjlW",
                font36: "src-components-Common-Avatar-index__font36--2EsOy",
                font40: "src-components-Common-Avatar-index__font40--2iFeY",
                group: "src-components-Common-Avatar-index__group--qRUrL src-components-Common-Avatar-index__default--1e_Nv",
                "group-gray": "src-components-Common-Avatar-index__group-gray--262sR src-components-Common-Avatar-index__default--1e_Nv",
                groupGray: "src-components-Common-Avatar-index__group-gray--262sR src-components-Common-Avatar-index__default--1e_Nv",
                shop: "src-components-Common-Avatar-index__shop--1erCv",
                user: "src-components-Common-Avatar-index__user--1dDg3"
            }
        },
        lMzC: function(e, o, s) {
            e.exports = {
                root: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__root--2NtGm",
                "last-message": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__last-message--xpkYa",
                lastMessage: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__last-message--xpkYa",
                message: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__message--1qecj",
                "message-send": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__message-send--2UHvy src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__message--1qecj",
                messageSend: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__message-send--2UHvy src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__message--1qecj",
                "message-receive": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__message-receive--1AXRv src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__message--1qecj",
                messageReceive: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__message-receive--1AXRv src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__message--1qecj",
                "message-time": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__message-time--3OdBK",
                messageTime: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__message-time--3OdBK",
                "product-origin": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__product-origin--3pnWj",
                productOrigin: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__product-origin--3pnWj",
                "product-origin-info": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__product-origin-info--28YRT",
                productOriginInfo: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__product-origin-info--28YRT",
                "image-wrapper": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__image-wrapper--1l7kG",
                imageWrapper: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__image-wrapper--1l7kG",
                "product-image": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__product-image--2raLp",
                productImage: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__product-image--2raLp",
                "sold-out": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__sold-out--OkRob",
                soldOut: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__sold-out--OkRob",
                "background-settings": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__background-settings--3Q8so",
                backgroundSettings: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__background-settings--3Q8so",
                "view-link": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__view-link--rC0FD",
                viewLink: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__view-link--rC0FD",
                "view-mall-link": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__view-mall-link--2atot",
                viewMallLink: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__view-mall-link--2atot",
                banned: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__banned--3zjYK",
                "product-name": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__product-name--2L5c-",
                productName: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__product-name--2L5c-",
                "origin-price": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__origin-price--9r2UX",
                originPrice: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__origin-price--9r2UX",
                "product-price": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__product-price--1ADr8",
                productPrice: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__product-price--1ADr8",
                "product-stock": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__product-stock--3wUCa",
                productStock: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__product-stock--3wUCa",
                "deleted-product": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__deleted-product--iDMZq",
                deletedProduct: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__deleted-product--iDMZq",
                "banned-product": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__banned-product--3puA- src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__product-price--1ADr8",
                bannedProduct: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__banned-product--3puA- src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__product-price--1ADr8",
                "view-product-block": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__view-product-block--2j_jv",
                viewProductBlock: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__view-product-block--2j_jv",
                "avatar-wrap": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__avatar-wrap--1xgJO",
                avatarWrap: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__avatar-wrap--1xgJO",
                avatar: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__avatar--1wVnQ",
                "avatar-placeholder": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__avatar-placeholder--13TIY",
                avatarPlaceholder: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__avatar-placeholder--13TIY",
                "order-origin": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__order-origin--2m271",
                orderOrigin: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__order-origin--2m271",
                "order-origin-info": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__order-origin-info--2zREJ",
                orderOriginInfo: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__order-origin-info--2zREJ",
                "order-info": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__order-info--DhoAD",
                orderInfo: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__order-info--DhoAD",
                "order-product-image": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__order-product-image--udglz",
                orderProductImage: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__order-product-image--udglz",
                "status-wrap": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__status-wrap--1Z08t",
                statusWrap: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__status-wrap--1Z08t",
                "order-status": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__order-status--2h1gU",
                orderStatus: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__order-status--2h1gU",
                pipe: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__pipe--ChItL",
                "order-product-name": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__order-product-name--FACdn",
                orderProductName: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__order-product-name--FACdn",
                "order-detail": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__order-detail--1TWrf",
                orderDetail: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__order-detail--1TWrf",
                "order-sn": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__order-sn--37aDh",
                orderSn: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__order-sn--37aDh",
                "shop-information": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__shop-information--2zjzY",
                shopInformation: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__shop-information--2zjzY",
                "shop-avatar": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__shop-avatar--40ecj",
                shopAvatar: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__shop-avatar--40ecj",
                "shop-name": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__shop-name--2756A",
                shopName: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__shop-name--2756A",
                "shop-origin": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__shop-origin--2jyrL",
                shopOrigin: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__shop-origin--2jyrL",
                "shop-origin-info": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__shop-origin-info--geDPz",
                shopOriginInfo: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__shop-origin-info--geDPz",
                "shop-origin-avatar": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__shop-origin-avatar--1sykE",
                shopOriginAvatar: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__shop-origin-avatar--1sykE",
                "shop-origin-name": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__shop-origin-name--2JeLC",
                shopOriginName: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__shop-origin-name--2JeLC",
                "view-shop-block": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__view-shop-block--1ZaLT",
                viewShopBlock: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__view-shop-block--1ZaLT",
                bubble: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__bubble--2xM_F",
                "offer-tips": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__offer-tips--1R7Ej",
                offerTips: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__offer-tips--1R7Ej",
                rotate: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-index__rotate--3sF-m"
            }
        },
        m4YU: function(e, o, s) {
            e.exports = {
                "order-status": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-OrderBody-index__order-status--5IV2v",
                orderStatus: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-OrderBody-index__order-status--5IV2v",
                "status-icon": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-OrderBody-index__status-icon--2GkfL",
                statusIcon: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-OrderBody-index__status-icon--2GkfL",
                unpaid: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-OrderBody-index__unpaid--203Bn",
                to_ship: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-OrderBody-index__to_ship--1tgh5",
                toShip: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-OrderBody-index__to_ship--1tgh5",
                shipping: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-OrderBody-index__shipping--2DMFX",
                completed: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-OrderBody-index__completed--3X7PX",
                cancelled: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-OrderBody-index__cancelled--2lXyr",
                refund: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-OrderBody-index__refund--1qU8c",
                "status-text": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-OrderBody-index__status-text--29gSc",
                statusText: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-OrderBody-index__status-text--29gSc",
                payment: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-OrderBody-index__payment--20SfX",
                count: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-OrderBody-index__count--1N4ek",
                detail: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-OrderBody-index__detail--CzjRe",
                "source-count": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-OrderBody-index__source-count--VlCnu",
                sourceCount: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-OrderBody-index__source-count--VlCnu",
                "order-info": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-OrderBody-index__order-info--2OSc2",
                orderInfo: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-OrderBody-index__order-info--2OSc2",
                "first-block": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-OrderBody-index__first-block--25a-M",
                firstBlock: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-OrderBody-index__first-block--25a-M",
                block: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-OrderBody-index__block--3_BGk src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-OrderBody-index__first-block--25a-M",
                income: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-OrderBody-index__income--1rqp9",
                number: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-OrderBody-index__number--3pB4y",
                date: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-OrderBody-index__date--J25jm",
                serial: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-BaseMessage-MessageSource-SpecialMessageCard-OrderBody-index__serial--3pTqU"
            }
        },
        mZsR: function(e, o, s) {
            e.exports = {
                root: "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-index__root--yf6BH",
                header: "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-index__header--MQYX3",
                number: "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-index__number--QV8u6",
                text: "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-index__text--3FPEF",
                shop: "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-index__shop--3s53F",
                avatar: "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-index__avatar--3WmjS",
                name: "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-index__name--MHX5O",
                status: "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-index__status--1opb5",
                "status-icon": "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-index__status-icon--BSEvA",
                statusIcon: "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-index__status-icon--BSEvA",
                unpaid: "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-index__unpaid--35Azo",
                to_ship: "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-index__to_ship--C-xMQ",
                toShip: "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-index__to_ship--C-xMQ",
                shipping: "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-index__shipping--1pTc_",
                completed: "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-index__completed--yk7cQ",
                cancelled: "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-index__cancelled--tsiXe",
                refund: "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-index__refund--wtEh4",
                products: "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-index__products--3f0tb",
                toolbar: "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-index__toolbar--11syY",
                button: "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-index__button--2IX82",
                disabled: "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-index__disabled--2wasS",
                base: "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-index__base--e-JyF",
                over: "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-index__over--Vo_QD",
                all: "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-index__all--vF7-x",
                content: "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-index__content--JZYlh",
                details: "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-index__details--1RkzD src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-index__content--JZYlh",
                counts: "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-index__counts--274SY",
                payment: "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-index__payment--69nYO",
                cancel: "src-modules-conversationDetail-component-InputField-Toolbar-OrderPopover-OrderCell-index__cancel--O-khp"
            }
        },
        n2EK: function(e, o, s) {
            e.exports = {
                root: "src-modules-conversationDetail-component-InputField-BlockedInput-index__root--w20KS"
            }
        },
        "ok/c": function(e, o, s) {
            e.exports = {
                root: "src-components-Common-BlacklistHint-index__root--2PCJS",
                "learn-more": "src-components-Common-BlacklistHint-index__learn-more--13rJH",
                learnMore: "src-components-Common-BlacklistHint-index__learn-more--13rJH"
            }
        },
        p2bk: function(e, o, s) {},
        "q/Zp": function(e, o, s) {
            e.exports = {
                root: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-PondMessage-index__root--3VfLN",
                option: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-PondMessage-index__option--1Z5Vz",
                title: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-PondMessage-index__title--1S9vp",
                primary: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-PondMessage-index__primary--2_7Fx",
                invalid: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-PondMessage-index__invalid--1YokO"
            }
        },
        "r3/W": function(e, o, s) {
            e.exports = {
                "count-time": "src-modules-conversationDetail-component-MessageSection-ConversationMessages-FlashSaleMessage-Count-index__count-time--2F1y3",
                countTime: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-FlashSaleMessage-Count-index__count-time--2F1y3",
                time: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-FlashSaleMessage-Count-index__time--6Nwrw",
                split: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-FlashSaleMessage-Count-index__split--1W2-p",
                count: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-FlashSaleMessage-Count-index__count--3Txum"
            }
        },
        sF2i: function(e, o, s) {
            e.exports = {
                base: "src-components-Common-Menus-WithIcon-index__base--d0XfI",
                icon: "src-components-Common-Menus-WithIcon-index__icon--yMyhb",
                "reddot-icon": "src-components-Common-Menus-WithIcon-index__reddot-icon--3n35P src-components-Common-Menus-WithIcon-index__icon--yMyhb",
                reddotIcon: "src-components-Common-Menus-WithIcon-index__reddot-icon--3n35P src-components-Common-Menus-WithIcon-index__icon--yMyhb"
            }
        },
        sOyU: function(e, o, s) {
            e.exports = {
                "message-section": "src-modules-conversationDetail-component-MessageSection-index__message-section--3P722",
                messageSection: "src-modules-conversationDetail-component-MessageSection-index__message-section--3P722",
                grid: "src-modules-conversationDetail-component-MessageSection-index__grid--SiKzk"
            }
        },
        "t+QN": function(e, o, s) {
            e.exports = {
                root: "src-components-Common-Modal-CancelOrderWarningModal-index__root--sBwji",
                content: "src-components-Common-Modal-CancelOrderWarningModal-index__content--tRS5z",
                policy: "src-components-Common-Modal-CancelOrderWarningModal-index__policy--1AArC"
            }
        },
        "tE+g": function(e, o, s) {
            e.exports = {
                root: "src-modules-conversationDetail-component-InputField-ClosedInput-index__root--3K2Gp",
                "restart-button": "src-modules-conversationDetail-component-InputField-ClosedInput-index__restart-button--3SRbv",
                restartButton: "src-modules-conversationDetail-component-InputField-ClosedInput-index__restart-button--3SRbv"
            }
        },
        "ue+V": function(e, o, s) {
            e.exports = {
                root: "src-components-Common-Alert-index__root--1H8f-",
                resolved: "src-components-Common-Alert-index__resolved--2sPO6",
                success: "src-components-Common-Alert-index__success--1IOu1",
                error: "src-components-Common-Alert-index__error--YqzRm",
                pending: "src-components-Common-Alert-index__pending--1tkv1",
                warn: "src-components-Common-Alert-index__warn--3recN",
                info: "src-components-Common-Alert-index__info--3Y3zF",
                icon: "src-components-Common-Alert-index__icon--11s76",
                "alert-icon": "src-components-Common-Alert-index__alert-icon--1UoUi src-components-Common-Alert-index__icon--11s76",
                alertIcon: "src-components-Common-Alert-index__alert-icon--1UoUi src-components-Common-Alert-index__icon--11s76",
                "alert-icon-resolved": "src-components-Common-Alert-index__alert-icon-resolved--2vQEs",
                alertIconResolved: "src-components-Common-Alert-index__alert-icon-resolved--2vQEs",
                "alert-icon-success": "src-components-Common-Alert-index__alert-icon-success--WEl9t",
                alertIconSuccess: "src-components-Common-Alert-index__alert-icon-success--WEl9t",
                "alert-icon-error": "src-components-Common-Alert-index__alert-icon-error--3z87Q",
                alertIconError: "src-components-Common-Alert-index__alert-icon-error--3z87Q",
                "alert-icon-warn": "src-components-Common-Alert-index__alert-icon-warn--1gRT8",
                alertIconWarn: "src-components-Common-Alert-index__alert-icon-warn--1gRT8",
                "alert-icon-info": "src-components-Common-Alert-index__alert-icon-info--2IMcE",
                alertIconInfo: "src-components-Common-Alert-index__alert-icon-info--2IMcE",
                "alert-icon-pending": "src-components-Common-Alert-index__alert-icon-pending--3iX5i",
                alertIconPending: "src-components-Common-Alert-index__alert-icon-pending--3iX5i",
                loading: "src-components-Common-Alert-index__loading--1VXNy",
                "alert-icon-size": "src-components-Common-Alert-index__alert-icon-size--UYA15",
                alertIconSize: "src-components-Common-Alert-index__alert-icon-size--UYA15",
                "alert-close": "src-components-Common-Alert-index__alert-close--3h-MI",
                alertClose: "src-components-Common-Alert-index__alert-close--3h-MI",
                "close-icon": "src-components-Common-Alert-index__close-icon--3vCZ- src-components-Common-Alert-index__icon--11s76",
                closeIcon: "src-components-Common-Alert-index__close-icon--3vCZ- src-components-Common-Alert-index__icon--11s76",
                content: "src-components-Common-Alert-index__content--3IWXi",
                title: "src-components-Common-Alert-index__title--19fut",
                message: "src-components-Common-Alert-index__message--1i4vs"
            }
        },
        wStF: function(e, o, s) {
            e.exports = {
                container: "src-modules-conversationDetail-component-InputField-Toolbar-ProductPopover-ProductList-index__container--2BjL8",
                "search-bar": "src-modules-conversationDetail-component-InputField-Toolbar-ProductPopover-ProductList-index__search-bar--Qg28R",
                searchBar: "src-modules-conversationDetail-component-InputField-Toolbar-ProductPopover-ProductList-index__search-bar--Qg28R",
                "scroll-container": "src-modules-conversationDetail-component-InputField-Toolbar-ProductPopover-ProductList-index__scroll-container--1nAlr",
                scrollContainer: "src-modules-conversationDetail-component-InputField-Toolbar-ProductPopover-ProductList-index__scroll-container--1nAlr",
                "product-item-wrapper": "src-modules-conversationDetail-component-InputField-Toolbar-ProductPopover-ProductList-index__product-item-wrapper--3-OJA",
                productItemWrapper: "src-modules-conversationDetail-component-InputField-Toolbar-ProductPopover-ProductList-index__product-item-wrapper--3-OJA",
                "product-body": "src-modules-conversationDetail-component-InputField-Toolbar-ProductPopover-ProductList-index__product-body--1UERO",
                productBody: "src-modules-conversationDetail-component-InputField-Toolbar-ProductPopover-ProductList-index__product-body--1UERO",
                "product-body-other": "src-modules-conversationDetail-component-InputField-Toolbar-ProductPopover-ProductList-index__product-body-other--1QP8x",
                productBodyOther: "src-modules-conversationDetail-component-InputField-Toolbar-ProductPopover-ProductList-index__product-body-other--1QP8x",
                "product-pic": "src-modules-conversationDetail-component-InputField-Toolbar-ProductPopover-ProductList-index__product-pic--249Pa",
                productPic: "src-modules-conversationDetail-component-InputField-Toolbar-ProductPopover-ProductList-index__product-pic--249Pa",
                "product-info": "src-modules-conversationDetail-component-InputField-Toolbar-ProductPopover-ProductList-index__product-info--3kIT7",
                productInfo: "src-modules-conversationDetail-component-InputField-Toolbar-ProductPopover-ProductList-index__product-info--3kIT7",
                "product-name": "src-modules-conversationDetail-component-InputField-Toolbar-ProductPopover-ProductList-index__product-name--1rUla",
                productName: "src-modules-conversationDetail-component-InputField-Toolbar-ProductPopover-ProductList-index__product-name--1rUla",
                "old-price": "src-modules-conversationDetail-component-InputField-Toolbar-ProductPopover-ProductList-index__old-price--3_sVR",
                oldPrice: "src-modules-conversationDetail-component-InputField-Toolbar-ProductPopover-ProductList-index__old-price--3_sVR",
                "new-price": "src-modules-conversationDetail-component-InputField-Toolbar-ProductPopover-ProductList-index__new-price--2hl2K",
                newPrice: "src-modules-conversationDetail-component-InputField-Toolbar-ProductPopover-ProductList-index__new-price--2hl2K",
                "product-footer": "src-modules-conversationDetail-component-InputField-Toolbar-ProductPopover-ProductList-index__product-footer--1mBzI",
                productFooter: "src-modules-conversationDetail-component-InputField-Toolbar-ProductPopover-ProductList-index__product-footer--1mBzI",
                "other-shop-footer": "src-modules-conversationDetail-component-InputField-Toolbar-ProductPopover-ProductList-index__other-shop-footer--3hT4o",
                otherShopFooter: "src-modules-conversationDetail-component-InputField-Toolbar-ProductPopover-ProductList-index__other-shop-footer--3hT4o",
                "sale-info": "src-modules-conversationDetail-component-InputField-Toolbar-ProductPopover-ProductList-index__sale-info--2zzaj",
                saleInfo: "src-modules-conversationDetail-component-InputField-Toolbar-ProductPopover-ProductList-index__sale-info--2zzaj",
                "send-btn": "src-modules-conversationDetail-component-InputField-Toolbar-ProductPopover-ProductList-index__send-btn--3ICmf",
                sendBtn: "src-modules-conversationDetail-component-InputField-Toolbar-ProductPopover-ProductList-index__send-btn--3ICmf",
                highlighted: "src-modules-conversationDetail-component-InputField-Toolbar-ProductPopover-ProductList-index__highlighted--32B66",
                "vertical-line": "src-modules-conversationDetail-component-InputField-Toolbar-ProductPopover-ProductList-index__vertical-line--on9T6",
                verticalLine: "src-modules-conversationDetail-component-InputField-Toolbar-ProductPopover-ProductList-index__vertical-line--on9T6"
            }
        },
        x4xU: function(e, o, s) {
            e.exports = {
                root: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-CustomMessage-index__root--boFWd",
                send: "src-modules-conversationDetail-component-MessageSection-ConversationMessages-CustomMessage-index__send--3GKdU"
            }
        }
    }
]);
//# sourceMappingURL=styles.21833f8f.6bb5923bbf70e6cd006e.js.map