(("undefined" != typeof self ? self : this).webpackChunkshopee_pc = ("undefined" != typeof self ? self : this).webpackChunkshopee_pc || []).push([
    [7464], {
        30057: function(e, t, r) {
            "use strict";
            r.r(t), r.d(t, {
                default: function() {
                    return K
                }
            });
            var a = r(27378),
                n = r(79308),
                o = r(43058),
                s = r(23615),
                i = r.n(s),
                c = r(73727),
                u = r(83367),
                p = r(98466),
                l = r(108),
                f = r(29735),
                h = r(1297),
                d = "_2o2XQg";

            function v(e, t) {
                return (v = Object.setPrototypeOf || function(e, t) {
                    return e.__proto__ = t, e
                })(e, t)
            }
            var y = h.o.searchWithQuery,
                _ = function(e) {
                    var t, r;

                    function n(t) {
                        var r;
                        return (r = e.call(this, t) || this).onClick = r.onClick.bind(function(e) {
                            if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                            return e
                        }(r)), r
                    }
                    r = e, (t = n).prototype = Object.create(r.prototype), t.prototype.constructor = t, v(t, r);
                    var o = n.prototype;
                    return o.onClick = function() {
                        var e = this.props,
                            t = e.keyword,
                            r = e.trackingClick,
                            a = e.searchParams,
                            n = e.targetSearchParams,
                            o = e.recordSearchHistory,
                            s = e.index;
                        (0, u.Z)({
                            action: "submitKeyboardSearch",
                            data: {
                                keyword: t,
                                inputType: "popular_search",
                                targetSearchParams: n,
                                searchParams: a,
                                isMallSearch: !!this.context.isOfficialShopPath,
                                absoluteLocation: s,
                                relativeLocation: s
                            },
                            track: this.props.contextOnTrack
                        }), o("product", t), (0, f.b)(t), r && r()
                    }, o.render = function() {
                        var e = this.props,
                            t = e.trackingRef,
                            r = e.keyword,
                            n = e.targetSearchParams;
                        return a.createElement(c.Link, {
                            onClick: this.onClick,
                            to: y(n),
                            className: d,
                            innerRef: t
                        }, r)
                    }, n
                }(a.Component);
            _.contextTypes = {
                isOfficialShopPath: i().bool
            };
            var m, k, S = (0, o.qC)((0, p.n)("HotwordItem"), (0, l.ou)())(_),
                g = r(14081),
                E = r(67986),
                C = r(18363),
                b = (0, r(69068).n)("FETCH_POP_SEARCH");

            function R() {
                return (R = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = arguments[t];
                        for (var a in r) Object.prototype.hasOwnProperty.call(r, a) && (e[a] = r[a])
                    }
                    return e
                }).apply(this, arguments)
            }
            var O = {
                    progress: C.Z.INIT,
                    state_update_time: 0
                },
                w = {
                    update_time: 0,
                    version: "",
                    sections: (m = {}, m.popsearch_sec = {
                        total: 0,
                        data: []
                    }, m)
                },
                P = (0, g.Z)(((k = {})[b.REQUESTED] = function(e) {
                    return R({}, e, {
                        progress: C.Z.REQ,
                        error: 0,
                        state_update_time: 0
                    })
                }, k[b.SUCCESS] = function(e, t) {
                    var r, a = t.payload,
                        n = a.offset,
                        o = a.data,
                        s = a.shouldReset,
                        i = e && e.data || w;
                    return R({}, e, {
                        data: R({}, i, {
                            update_time: o.update_time,
                            version: o.version,
                            sections: R({}, i.sections, (r = {}, r.popsearch_sec = {
                                total: o.sections.popsearch_sec.total,
                                data: (0, E.Z)(s ? [] : i.sections.popsearch_sec.data, o.sections.popsearch_sec.data, n)
                            }, r))
                        }),
                        progress: C.Z.OK,
                        state_update_time: Date.now()
                    })
                }, k[b.FAILED] = function(e, t) {
                    var r = t.payload.error;
                    return R({}, e, {
                        progress: C.Z.ERR,
                        error: r
                    })
                }, k), O),
                I = r(15263),
                T = r(92027),
                Z = r(72609);

            function x(e) {
                var t, r = {
                        sections: (t = {}, t.popsearch_sec = {
                            total: 0,
                            data: []
                        }, t)
                    },
                    a = e.data.querys;
                return a && a.length < 1 || (r.sections.popsearch_sec.total = a.length || 0, a.forEach((function(e) {
                    r.sections.popsearch_sec.data.push({
                        key: e.tracking,
                        data_type: "keyword",
                        keyword: e.text,
                        label: e.text,
                        count: e.count,
                        images: e.pic,
                        info: e.tracking
                    })
                }))), r
            }

            function D(e) {
                var t = e.limit,
                    r = void 0 === t ? 8 : t,
                    a = e.offset,
                    n = void 0 === a ? 0 : a,
                    o = e.getStore,
                    s = e.onFinish,
                    i = e.shouldSkipCall,
                    c = e.shouldReset,
                    u = e.version,
                    p = (0, T.Wc)({
                        bundle: "popsearch",
                        limit: r,
                        offset: n,
                        version: n > 0 && u || void 0
                    });
                return (0, I.Z)({
                    apiCall: function() {
                        return function(e) {
                            return (0, Z.fetchInfo)("/api/v4/search/trending_search" + e)
                        }(p)
                    },
                    actions: [function() {
                        return {
                            type: b.REQUESTED
                        }
                    }, function(e, t) {
                        return {
                            type: b.SUCCESS,
                            payload: {
                                offset: n,
                                data: x(t),
                                shouldReset: c
                            }
                        }
                    }, function(e, t) {
                        return {
                            type: b.FAILED,
                            payload: {
                                error: t.error
                            }
                        }
                    }],
                    shouldSkipCall: o && !i ? j(o) : i,
                    onFinish: s
                })
            }

            function j(e) {
                return function(t) {
                    var r = e(t);
                    return !!(r && r && r.state_update_time) && r.state_update_time > Date.now() - 6e4
                }
            }
            var H = [];

            function N() {
                return (N = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = arguments[t];
                        for (var a in r) Object.prototype.hasOwnProperty.call(r, a) && (e[a] = r[a])
                    }
                    return e
                }).apply(this, arguments)
            }
            var Q = r(30085),
                A = r(98953),
                F = "_1aYDEh",
                L = "_2MXg3O",
                U = [C.Z.INIT, C.Z.REQ];

            function q(e) {
                return e.popSearch
            }
            var K = function(e) {
                var t = e.searchParams,
                    r = a.useContext(Q.InjectReducerContext).injectAsyncReducer;
                a.useEffect((function() {
                    var e;
                    r(((e = {}).popSearch = P, e))
                }), [r]);
                var o = (0, n.useDispatch)();
                a.useEffect((function() {
                    o(D({
                        offset: 0,
                        limit: 8,
                        getStore: q
                    }))
                }), [o]);
                var s, i = a.useCallback((function(e, t) {
                        o(function(e, t, r) {
                            return void 0 === r && (r = {}), N({
                                type: "RECORD_SEARCH_HISTORY",
                                searchType: e,
                                data: t
                            }, r, {
                                isOfficialShop: !1
                            })
                        }(e, t))
                    }), [o]),
                    c = (0, n.useSelector)(q);
                if (U.includes((s = c) ? s.progress : C.Z.INIT)) return null;
                var u = function(e) {
                    return e && e.data ? e.data.sections.popsearch_sec.data : H
                }(c);
                return !u || u.length < 2 ? null : a.createElement("div", {
                    className: F
                }, a.createElement("div", {
                    className: L
                }, u.map((function(e, r) {
                    var n = e.keyword,
                        o = e.info,
                        s = e.label;
                    if (!n) return null;
                    var c = (0, A.C)(n, t);
                    return a.createElement(S, {
                        key: n,
                        keyword: n,
                        recordSearchHistory: i,
                        index: r,
                        searchParams: t,
                        targetSearchParams: c,
                        info: o,
                        intentionid: s
                    })
                }))))
            }
        }
    }
]);
//# sourceMappingURL=https://shopee.sg/assets/HotWordList.3c0fdbdfad87a433085a.js.map