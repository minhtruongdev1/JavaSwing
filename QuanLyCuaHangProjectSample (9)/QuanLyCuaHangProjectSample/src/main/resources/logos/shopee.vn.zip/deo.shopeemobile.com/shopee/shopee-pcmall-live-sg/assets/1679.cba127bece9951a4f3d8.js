(("undefined" != typeof self ? self : this).webpackChunkshopee_pc = ("undefined" != typeof self ? self : this).webpackChunkshopee_pc || []).push([
    [1679], {
        73777: function(e, n, r) {
            "use strict";
            var t;

            function a() {
                return (a = Object.assign || function(e) {
                    for (var n = 1; n < arguments.length; n++) {
                        var r = arguments[n];
                        for (var t in r) Object.prototype.hasOwnProperty.call(r, t) && (e[t] = r[t])
                    }
                    return e
                }).apply(this, arguments)
            }
            r.d(n, {
                x5: function() {
                    return v
                },
                LU: function() {
                    return g
                },
                IS: function() {
                    return d
                }
            });
            (t = {}).y = "year", t.M = "month", t.w = "week", t.d = "day", t.h = "hour", t.m = "minute", t.s = "second", t.S = "millisecond";
            var i = ["year", "month", "week", "day", "hour", "minute", "second", "millisecond"],
                o = [365, 30, 7, 24, 60, 60, 1e3, 1];

            function s(e) {
                return !isNaN(parseInt(e, 10))
            }

            function u(e) {
                return i.includes(e)
            }

            function l(e) {
                return e instanceof Date && !isNaN(e.valueOf())
            }

            function m(e, n) {
                return void 0 === n && (n = 2), ("0".repeat(n) + String(e)).slice(-n)
            }

            function d(e, n, r, t) {
                if (void 0 === r && (r = Date.now()), void 0 === t && (t = !1), n = new Date(n), r = new Date(r), !l(n) || !l(r) || !u(e)) throw new TypeError("Invalid unit or dates");
                var a = function(e, n, r) {
                    if (void 0 === r && (r = "millisecond"), !s(e) || !u(n) || !u(r)) throw new TypeError("Invalid unit or value");
                    if (n === r) return e;
                    var t = i.indexOf(n),
                        a = i.indexOf(r),
                        l = a - t > 0 ? 1 : -1;
                    if (t + a === 1) return e * Math.pow(12, l);
                    e *= (t < 3 ? o[t] : 1) / (a < 3 ? o[a] : 1);
                    var m = Math.max(Math.min(t, a), 3),
                        d = Math.max(t, a, 3);
                    return o.slice(m, d).reduce((function(e, n) {
                        return e * Math.pow(n, l)
                    }), e)
                }(+n - +r, "millisecond", e);
                return t ? a > 0 ? Math.ceil(a) : Math.floor(a) : a
            }
            var c = {
                    separator: " ",
                    suffix: ["# ago", "in #"],
                    year: ["a year", "# year", "# years"],
                    month: ["a month", "# month", "# months"],
                    week: ["a week", "# week", "# weeks"],
                    day: ["a day", "# day", "# days"],
                    hour: ["an hour", "# hour", "# hours"],
                    minute: ["a minute", "# minute", "# minutes"],
                    second: ["a few seconds", "# second", "# seconds"],
                    millisecond: ["", ""]
                },
                f = {
                    separator: " ",
                    suffix: ["hace #", "en #"],
                    year: ["un año", "# año", "# años"],
                    month: ["un mes", "# mes", "# meses"],
                    week: ["una semana", "# semana", "# semanas"],
                    day: ["un día", "# día", "# días"],
                    hour: ["una hora", "# hora", "# horas"],
                    minute: ["un minuto", "# minuto", "# minutos"],
                    second: ["unos pocos segundos", "# segundo", "# segundos"],
                    millisecond: ["", ""]
                },
                p = a({}, f, {
                    second: ["hace unos segundos", "# segundo", "# segundos"]
                }),
                h = Object.freeze({
                    __proto__: null,
                    default: c,
                    CN: {
                        separator: "",
                        suffix: ["#前", "#内"],
                        year: ["一年", "#年"],
                        month: ["一个月", "#个月"],
                        week: ["一周", "#周"],
                        day: ["一天", "#天"],
                        hour: ["一小时", "#小时"],
                        minute: ["一分钟", "#分钟"],
                        second: ["几秒", "#秒"],
                        millisecond: ["", ""]
                    },
                    ID: {
                        separator: " ",
                        suffix: ["# yang lalu", "dalam #"],
                        year: ["setahun", "# tahun"],
                        month: ["sebulan", "# bulan"],
                        week: ["seminggu", "# minggu"],
                        day: ["sehari", "# hari"],
                        hour: ["sejam", "# jam"],
                        minute: ["semenit", "# menit"],
                        second: ["beberapa detik", "# detik"],
                        millisecond: ["", ""]
                    },
                    MY: {
                        separator: " ",
                        suffix: ["# yang lepas", "dalam #"],
                        year: ["setahun", "# tahun"],
                        month: ["sebulan", "# bulan"],
                        week: ["seminggu", "# minggu"],
                        day: ["sehari", "# hari"],
                        hour: ["sejam", "# jam"],
                        minute: ["seminit", "# minit"],
                        second: ["beberapa saat", "# saat"],
                        millisecond: ["", ""]
                    },
                    PH: c,
                    SG: c,
                    TH: {
                        separator: " ",
                        suffix: ["#ที่แล้ว", "อีก #"],
                        year: ["1 ปี", "# ปี"],
                        month: ["1 เดือน", "# เดือน"],
                        week: ["1 สัปดาห์", "# สัปดาห์"],
                        day: ["1 วัน", "# วัน"],
                        hour: ["1 ชั่วโมง", "# ชั่วโมง"],
                        minute: ["1 นาที", "# นาที"],
                        second: ["ไม่กี่วินาที", "# วินาที"],
                        millisecond: ["", ""]
                    },
                    TW: {
                        separator: "",
                        suffix: ["#前", "#內"],
                        year: ["一年", "#年"],
                        month: ["一個月", "#個月"],
                        week: ["一週", "#週"],
                        day: ["一天", "#天"],
                        hour: ["一小時", "#小時"],
                        minute: ["一分鐘", "#分鐘"],
                        second: ["幾秒", "#秒"],
                        millisecond: ["", ""]
                    },
                    VN: {
                        separator: " ",
                        suffix: ["# trước", "# tới"],
                        year: ["một năm", "# năm"],
                        month: ["một tháng", "# tháng"],
                        week: ["một tuần", "# tuần"],
                        day: ["một ngày", "# ngày"],
                        hour: ["một giờ", "# giờ"],
                        minute: ["một phút", "# phút"],
                        second: ["vài giây", "# giây"],
                        millisecond: ["", ""]
                    },
                    BR: {
                        separator: " ",
                        suffix: ["há #", "em #"],
                        year: ["um ano", "# ano", "# anos"],
                        month: ["um mês", "# mês", "# meses"],
                        week: ["uma semana", "# semana", "# semanas"],
                        day: ["um dia", "# dia", "# dias"],
                        hour: ["uma hora", "# hora", "# horas"],
                        minute: ["um minuto", "# minuto", "# minutos"],
                        second: ["poucos segundos", "# segundo", "# segundos"],
                        millisecond: ["", ""]
                    },
                    MX: f,
                    CO: f,
                    CL: f,
                    AR: p,
                    PL: {
                        separator: " ",
                        suffix: ["# temu", "w #"],
                        year: ["rok", "# lat(a)", "# rok"],
                        month: ["miesiąc", "# miesięcy/e", "# miesiąc"],
                        week: ["tydzień", "# tydzień", "# tygodnie"],
                        day: ["dzień", "# dni", "# dzień"],
                        hour: ["godzina", "# godzin(y)", "# godzina"],
                        minute: ["minuta", "# minuta", "# minut(y)"],
                        second: ["kilka sekund", "# sekunda", "# sekund"],
                        millisecond: ["", ""]
                    },
                    ES: f,
                    FR: {
                        separator: " ",
                        suffix: ["il y a #", "dans #"],
                        year: ["un an", "# ans", "# an"],
                        month: ["un mois", "# mois", "# mois"],
                        week: ["une semaine", "# semaine", "# semaines"],
                        day: ["un jour", "# jours", "# jour"],
                        hour: ["une heure", "# heures", "# heure"],
                        minute: ["une minute", "# minutes", "# minute"],
                        second: ["quelques secondes", "# seconde", "# secondes"],
                        millisecond: ["", ""]
                    },
                    IN: {
                        separator: " ",
                        suffix: ["# पहले", "# में"],
                        year: ["एक साल", "# साल", "# साल"],
                        month: ["# महीना", "# महीना", "# महीने"],
                        week: ["सप्ताह", "# हफ्ता", "# हफ्तों"],
                        day: ["एक दिन", "# दिन", "# दिन"],
                        hour: ["एक घंटा", "# घंटा", "# घंटे"],
                        minute: ["एक मिनट", "# मिनट", "# मिनट"],
                        second: ["कुछ क्षणों", "# क्षण", "# क्षण"],
                        millisecond: ["", ""]
                    }
                }),
                y = {
                    year: 3,
                    month: 2,
                    week: 2,
                    day: 2,
                    hour: 1,
                    minute: 1,
                    second: 1,
                    millisecond: 1
                },
                b = o.reduceRight((function(e, n, r) {
                    return [n * e[Math.max(2 - r, 0)]].concat(e)
                }), [1]);

            function g(e, n, r, t) {
                void 0 === r && (r = Date.now()), void 0 === t && (t = {});
                try {
                    if (n = new Date(n), r = new Date(r), !e || !l(r) || !l(n)) throw new TypeError("Invalid locale or from/to dates");
                    var o = t,
                        s = o.unitLowerBounds,
                        u = void 0 === s ? {} : s,
                        d = o.startUnit,
                        c = void 0 === d ? null : d,
                        f = o.endUnit,
                        p = void 0 === f ? null : f,
                        h = o.totalUnits,
                        g = void 0 === h ? 0 : h,
                        v = o.useWords,
                        w = void 0 !== v && v,
                        j = o.includeWeek,
                        k = void 0 !== j && j,
                        S = o.addSuffix,
                        M = void 0 !== S && S,
                        x = o.numberFormat,
                        O = void 0 === x ? "numeric" : x,
                        z = o.roundLast,
                        A = void 0 === z ? "round" : z,
                        T = a({}, y, u);
                    if (c && !i.includes(c) || p && !i.includes(p)) throw new RangeError("Invalid start or end units");
                    var D = n >= r;
                    if (!D) {
                        var J = [r, n];
                        n = J[0], r = J[1]
                    }
                    var L = +n - +r,
                        N = c ? Math.min(i.indexOf(c), 6) : i.findIndex((function(e, n) {
                            return "second" === e || L >= b[n] * T[e]
                        })),
                        P = Math.min(i.indexOf(p || "second"), 6) + 1;
                    N = Math.min(N, P - 1);
                    var E = g > 0 ? g : p ? P - N : 2,
                        F = [],
                        I = n.getFullYear() - r.getFullYear(),
                        C = n.getMonth() - r.getMonth(),
                        R = n.getDate() - r.getDate();
                    if (R < 0) {
                        var V = new Date(n.getFullYear(), n.getMonth(), 0).getDate();
                        R += V + Math.max(0, r.getDate() - V), C--
                    }
                    C < 0 && (C += 12, I--);
                    for (var _ = N;; _++) {
                        2 === _ && _++;
                        var W = i[_],
                            q = L / b[_],
                            Y = 0 === F.length;
                        if ("day" === W ? (Y || (q = R + q % 1), k && (!Y || q >= 7 * T.week || "week" === c) && (F.push(["week", q / 7]), q %= 7)) : "month" === W ? q = C + R / 31 + Number(Y && 12 * I) : "year" === W && (q = I + C / 12), _ >= P || F.length >= E) break;
                        F.push([W, q]), L %= b[_]
                    }
                    var B = e.separator,
                        H = e.suffix,
                        U = "function" == typeof A ? A.apply(void 0, F[F.length - 1]) : A,
                        K = F.map((function(n, r, t) {
                            var a = n[0],
                                i = n[1];
                            i = r === t.length - 1 ? Math[U](i) : Math.floor(i);
                            var o = w && (1 === i || i < 10 && "second" === a) ? 0 : 1 === i ? 1 : 2,
                                s = e[a] ? e[a][o] || e[a][o - 1] : "#",
                                u = "2-digit" === O ? m(i) : String(i);
                            return s.replace("#", u)
                        })).filter(Boolean).join(B);
                    return M ? H[Number(D)].replace("#", K) : K
                } catch (e) {
                    return ""
                }
            }
            var v = h,
                w = {
                    useLocale: "en-US",
                    order: "wdMyhmsS",
                    dateLiteral: " ",
                    monthShortValues: "Jan,Feb,Mar,Apr,May,Jun,Jul,Aug,Sept,Oct,Nov,Dec".split(","),
                    monthValues: "January,February,March,April,May,June,July,August,September,October,November,December".split(","),
                    weekShortValues: "Sun,Mon,Tue,Wed,Thu,Fri,Sat".split(","),
                    weekValues: "Sunday,Monday,Tuesday,Wednesday,Thursday,Friday,Saturday".split(",")
                },
                j = "日一二三四五六",
                k = {
                    useLocale: "zh-CN",
                    order: "yMdhmsSw",
                    dateLiteral: "-",
                    dateLiteralWord: "",
                    weekShortValues: j.split("").map((function(e) {
                        return "周" + e
                    })),
                    weekValues: j.split("").map((function(e) {
                        return "星期" + e
                    })),
                    transform: function(e, n, r) {
                        ["year", "month", "day"].forEach((function(e, t) {
                            return ("long" === r[e] || "short" === r[e]) && (n[e] = String(Number(n[e])) + "年月日" [t])
                        }))
                    }
                },
                S = ("Jan,Feb,Mar,Apr,Mei,Jun,Jul,Ags,Sep,Okt,Nov,Des".split(","), "Januari,Februari,Maret,April,Mei,Juni,Juli,Agustus,September,Oktober,November,Desember".split(","), "Min,Sen,Sel,Rab,Kam,Jum,Sab".split(","), "Minggu,Senin,Selasa,Rabu,Kamis,Jumat,Sabtu".split(","), "Jan,Feb,Mac,Apr,Mei,Jun,Julai,Og,Sept,Okt,Nov,Dis".split(","), "Januari,Februari,Mac,April,Mei,Jun,Julai,Ogos,September,Oktober,November,Disember".split(","), "Ahd,Isn,Sel,Rab,Kha,Jum,Sab".split(","), "Ahad,Isnin,Selasa,Rabu,Khamis,Jumaat,Sabtu".split(","), a({}, w, {
                    useLocale: "en-PH"
                }), a({}, w, {
                    useLocale: "en-SG"
                }), "ม.ค.,ก.พ.,มี.ค.,เม.ย.,พ.ค.,มิ.ย.,ก.ค.,ส.ค.,ก.ย.,ต.ค.,พ.ย.,ธ.ค.".split(","), "มกราคม,กุมภาพันธ์,มีนาคม,เมษายน,พฤษภาคม,มิถุนายน,กรกฎาคม,สิงหาคม,กันยายน,ตุลาคม,พฤศจิกายน,ธันวาคม".split(","), "อา.,จ.,อ.,พ.,พฤ.,ศ.,ส.".split(","), "วันอาทิตย์,วันจันทร์,วันอังคาร,วันพุธ,วันพฤหัสบดี,วันศุกร์,วันเสาร์".split(","), a({}, k, {
                    useLocale: "zh-TW",
                    weekShortValues: j.split("").map((function(e) {
                        return "週" + e
                    }))
                }), Array.from({
                    length: 12
                }).map((function(e, n) {
                    return "Th" + String(101 + n).slice(-2)
                })), Array.from({
                    length: 12
                }).map((function(e, n) {
                    return "Tháng " + String(n + 1)
                })), "CN,T2,T3,T4,T5,T6,T7".split(","), "chủ nhật,thứ hai,thứ ba,thứ tư,thứ năm,thứ sáu,thứ bảy".split(","), "jan,fev,mar,abr,mai,jun,jul,ago,set,out,nov,dez".split(","), "janeiro,fevereiro,março,abril,maio,junho,julho,agosto,setembro,outubro,novembro,dezembro".split(","), "dom,seg,ter,qua,qui,sex,sáb".split(","), "domingo,segunda-feira,terça-feira,quarta-feira,quinta-feira,sexta-feira,sábado".split(","), {
                    useLocale: "es-MX",
                    order: "wdMyhmsS",
                    dateLiteral: "/",
                    dateLiteralWord: " \\de ",
                    monthShortValues: "ene.,feb.,mar.,abr.,may.,jun.,jul.,ago.,sep.,oct.,nov.,dic.".split(","),
                    monthValues: "enero,febrero,marzo,abril,mayo,junio,julio,agosto,septiembre,octubre,noviembre,diciembre".split(","),
                    weekShortValues: "dom.,lun.,mar.,mié.,jue.,vie.,sáb.".split(","),
                    weekValues: "domingo,lunes,martes,miércoles,jueves,viernes,sábado".split(",")
                });
            a({}, S), a({}, S), a({}, S), "ene.,feb.,mar.,abr.,may.,jun.,jul.,ago.,sep.,oct.,nov.,dic.".split(","), "enero,febrero,marzo,abril,mayo,junio,julio,agosto,septiembre,octubre,noviembre,diciembre".split(","), "dom.,lun.,mar.,mié.,jue.,vie.,sáb.".split(","), "domingo,lunes,martes,miércoles,jueves,viernes,sábado".split(","), "stycz.,luty,mar.,kwiec.,maj,czerw.,lip.,sierp.,wrzes.,pazdz.,listop.,grudz.".split(","), "Styczeń,Luty,Marzec,Kwiecień,Maj,Czerwiec,Lipiec,Sierpień,Wrzesień,Październik,Listopad,Grudzień".split(","), "nie.,pon.,wt.,śr.,czw.,pią.,sob.".split(","), "Niedziela,Poniedziałek,Wtorek,Środa,Czwartek,Piątek,Sobota".split(","), "ene.,feb.,mar.,abr.,may.,jun.,jul.,ago.,sep.,oct.,nov.,dic.".split(","), "enero,febrero,marzo,abril,mayo,junio,julio,agosto,septiembre,octubre,noviembre,diciembre".split(","), "dom.,lun.,mar.,mié.,jue.,vie.,sáb.".split(","), "domingo,lunes,martes,miércoles,jueves,viernes,sábado".split(","), "janv.,févr.,mars,avril,mai,juin,juil.,août,sept.,oct.,nov.,déc.".split(","), "janvier,février,mars,avril,mai,juin,juillet,aout,septembre,octobre,novembre,décembre".split(","), "dim.,lun.,mar.,mer.,jeu.,ven.,sam.".split(","), "dimanche,lundi,mardi,mercredi,jeudi,vendredi,samedi".split(","), "जनवरी,फरवरी,मार्च,अप्रैल,मई,जून,जुलाई,अगस्त,सितंबर,अक्टूबर,नवंबर,दिसंबर".split(","), "जनवरी,फरवरी,मार्च,अप्रैल,मई,जून,जुलाई,अगस्त,सितंबर,अक्टूबर,नवंबर,दिसंबर".split(","), "रविवार,सोमवार,मंगलवार,बुधवार,गुरुवार,शुक्रवार,शनिवार".split(","), "रविवार,सोमवार,मंगलवार,बुधवार,गुरुवार,शुक्रवार,शनिवार".split(","), new Map, new Map
        },
        37472: function(e, n, r) {
            "use strict";

            function t(e, n, r) {
                return n in e ? Object.defineProperty(e, n, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[n] = r, e
            }

            function a(e, n) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var t = Object.getOwnPropertySymbols(e);
                    n && (t = t.filter((function(n) {
                        return Object.getOwnPropertyDescriptor(e, n).enumerable
                    }))), r.push.apply(r, t)
                }
                return r
            }

            function i(e) {
                for (var n = 1; n < arguments.length; n++) {
                    var r = null != arguments[n] ? arguments[n] : {};
                    n % 2 ? a(Object(r), !0).forEach((function(n) {
                        t(e, n, r[n])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : a(Object(r)).forEach((function(n) {
                        Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n))
                    }))
                }
                return e
            }
            r.d(n, {
                Z: function() {
                    return v
                }
            });
            var o = r(27378);

            function s(e, n) {
                (null == n || n > e.length) && (n = e.length);
                for (var r = 0, t = new Array(n); r < n; r++) t[r] = e[r];
                return t
            }

            function u(e, n) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, n) {
                    if ("undefined" != typeof Symbol && Symbol.iterator in Object(e)) {
                        var r = [],
                            t = !0,
                            a = !1,
                            i = void 0;
                        try {
                            for (var o, s = e[Symbol.iterator](); !(t = (o = s.next()).done) && (r.push(o.value), !n || r.length !== n); t = !0);
                        } catch (e) {
                            a = !0, i = e
                        } finally {
                            try {
                                t || null == s.return || s.return()
                            } finally {
                                if (a) throw i
                            }
                        }
                        return r
                    }
                }(e, n) || function(e, n) {
                    if (e) {
                        if ("string" == typeof e) return s(e, n);
                        var r = Object.prototype.toString.call(e).slice(8, -1);
                        return "Object" === r && e.constructor && (r = e.constructor.name), "Map" === r || "Set" === r ? Array.from(e) : "Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r) ? s(e, n) : void 0
                    }
                }(e, n) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }
            var l = function(e) {
                    var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                    return n.alignSelf = e.alignSelf, n
                },
                m = function(e) {
                    var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                    return n.flex = e.flex, n
                },
                d = function(e) {
                    var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                    return n.margin = e.m || e.margin, n.marginTop = e.mt || e.marginTop || e.my || e.marginY, n.marginRight = e.mr || e.marginRight || e.mx || e.marginX, n.marginBottom = e.mb || e.marginBottom || e.my || e.marginY, n.marginLeft = e.ml || e.marginLeft || e.mx || e.marginX, n
                },
                c = function(e) {
                    var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                    return n.order = e.order, n
                },
                f = function(e) {
                    var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                    return n.textTransform = e.textTransform, n
                },
                p = function(e) {
                    var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                    return n.width = e.width, n
                },
                h = r(60042),
                y = r.n(h),
                b = {
                    button: "_3sjFp",
                    "size-dynamic": "lJMau",
                    "size-default": "_3zn07",
                    "size-medium": "_18F8b",
                    "size-small": "uxSdp",
                    "variant-wireframe": "xCn81",
                    "color-primary": "TOjHY",
                    "variant-solid": "AHhqR",
                    "color-secondary": "_1-4Xn",
                    "color-white": "_1qQAl",
                    text: "_2HCeY",
                    icon: "_19rDu"
                },
                g = function(e, n) {
                    var r = e.text,
                        a = e.icon,
                        s = e.color,
                        h = void 0 === s ? "primary" : s,
                        g = e.size,
                        v = void 0 === g ? "default" : g,
                        w = e.variant,
                        j = void 0 === w ? "solid" : w,
                        k = e.disabled,
                        S = e.onClick,
                        M = "secondary" === h || "white" === h ? "wireframe" : j,
                        x = a ? o.cloneElement(a, i(i({}, a.props), {}, {
                            style: i(i({}, a.props.style), {}, {
                                flex: "0 0 auto"
                            })
                        })) : null,
                        O = y()(b.button, b["size-" + v], b["variant-" + M], b["color-" + h], "nt-regular", "small" === v ? "nt-small" : "dynamic" === v ? "nt-large" : "nt-normal"),
                        z = function(e, n) {
                            var r = {};
                            return e && Array.isArray(n) ? (n.forEach((function(n) {
                                n && n(e, r)
                            })), Object.entries(r).forEach((function(e) {
                                var n = u(e, 2),
                                    t = n[0],
                                    a = n[1];
                                a || 0 === a || delete r[t]
                            })), r) : r
                        }(e, [l, "dynamic" === v && m, d, c, f, "dynamic" === v && p]),
                        A = y()(b.text, t({}, b.icon, Boolean(a)));
                    return o.createElement("button", {
                        ref: n,
                        className: O,
                        style: z,
                        disabled: k,
                        onClick: S
                    }, x, o.createElement("span", {
                        className: A
                    }, r))
                },
                v = o.forwardRef(g)
        },
        78068: function(e) {
            "use strict";
            e.exports = function(e, n, r, t, a, i, o, s) {
                if (!e) {
                    var u;
                    if (void 0 === n) u = new Error("Minified exception occurred; use the non-minified dev environment for the full error message and additional helpful warnings.");
                    else {
                        var l = [r, t, a, i, o, s],
                            m = 0;
                        (u = new Error(n.replace(/%s/g, (function() {
                            return l[m++]
                        })))).name = "Invariant Violation"
                    }
                    throw u.framesToPop = 1, u
                }
            }
        }
    }
]);
//# sourceMappingURL=https://shopee.sg/assets/1679.cba127bece9951a4f3d8.js.map