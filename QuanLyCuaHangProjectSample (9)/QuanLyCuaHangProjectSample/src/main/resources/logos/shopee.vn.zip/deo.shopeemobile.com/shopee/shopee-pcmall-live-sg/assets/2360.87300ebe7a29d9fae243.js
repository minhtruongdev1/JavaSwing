(("undefined" != typeof self ? self : this).webpackChunkshopee_pc = ("undefined" != typeof self ? self : this).webpackChunkshopee_pc || []).push([
    [2360], {
        61569: function(t, e, n) {
            "use strict";

            function r(t, e, n, r, o, i, a) {
                try {
                    var s = t[i](a),
                        l = s.value
                } catch (t) {
                    return void n(t)
                }
                s.done ? e(l) : Promise.resolve(l).then(r, o)
            }

            function o(t) {
                return function() {
                    var e = this,
                        n = arguments;
                    return new Promise((function(o, i) {
                        var a = t.apply(e, n);

                        function s(t) {
                            r(a, o, i, s, l, "next", t)
                        }

                        function l(t) {
                            r(a, o, i, s, l, "throw", t)
                        }
                        s(void 0)
                    }))
                }
            }
            n.d(e, {
                Z: function() {
                    return o
                }
            })
        },
        28856: function(t, e, n) {
            "use strict";

            function r(t, e, n) {
                return e in t ? Object.defineProperty(t, e, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = n, t
            }
            n.d(e, {
                Z: function() {
                    return r
                }
            })
        },
        56433: function(t, e, n) {
            "use strict";
            n.d(e, {
                Z: function() {
                    return i
                }
            });
            var r = n(28856);

            function o(t, e) {
                var n = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(t);
                    e && (r = r.filter((function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable
                    }))), n.push.apply(n, r)
                }
                return n
            }

            function i(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? o(Object(n), !0).forEach((function(e) {
                        (0, r.Z)(t, e, n[e])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : o(Object(n)).forEach((function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
                    }))
                }
                return t
            }
        },
        41693: function(t, e, n) {
            "use strict";

            function r(t) {
                return (r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                    return typeof t
                } : function(t) {
                    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
                })(t)
            }
            n.d(e, {
                Z: function() {
                    return r
                }
            })
        },
        6164: function(t, e, n) {
            t.exports = n(19271)
        },
        80155: function(t) {
            window,
            t.exports = function(t) {
                var e = {};

                function n(r) {
                    if (e[r]) return e[r].exports;
                    var o = e[r] = {
                        i: r,
                        l: !1,
                        exports: {}
                    };
                    return t[r].call(o.exports, o, o.exports, n), o.l = !0, o.exports
                }
                return n.m = t, n.c = e, n.d = function(t, e, r) {
                    n.o(t, e) || Object.defineProperty(t, e, {
                        enumerable: !0,
                        get: r
                    })
                }, n.r = function(t) {
                    "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
                        value: "Module"
                    }), Object.defineProperty(t, "__esModule", {
                        value: !0
                    })
                }, n.t = function(t, e) {
                    if (1 & e && (t = n(t)), 8 & e) return t;
                    if (4 & e && "object" == typeof t && t && t.__esModule) return t;
                    var r = Object.create(null);
                    if (n.r(r), Object.defineProperty(r, "default", {
                            enumerable: !0,
                            value: t
                        }), 2 & e && "string" != typeof t)
                        for (var o in t) n.d(r, o, function(e) {
                            return t[e]
                        }.bind(null, o));
                    return r
                }, n.n = function(t) {
                    var e = t && t.__esModule ? function() {
                        return t.default
                    } : function() {
                        return t
                    };
                    return n.d(e, "a", e), e
                }, n.o = function(t, e) {
                    return Object.prototype.hasOwnProperty.call(t, e)
                }, n.p = "", n(n.s = 3)
            }([function(t, e, n) {
                t.exports = n(2)
            }, function(t, e) {
                function n(e) {
                    return "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? (t.exports = n = function(t) {
                        return typeof t
                    }, t.exports.default = t.exports, t.exports.__esModule = !0) : (t.exports = n = function(t) {
                        return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
                    }, t.exports.default = t.exports, t.exports.__esModule = !0), n(e)
                }
                t.exports = n, t.exports.default = t.exports, t.exports.__esModule = !0
            }, function(t, e, n) {
                var r = function(t) {
                    "use strict";
                    var e, n = Object.prototype,
                        r = n.hasOwnProperty,
                        o = "function" == typeof Symbol ? Symbol : {},
                        i = o.iterator || "@@iterator",
                        a = o.asyncIterator || "@@asyncIterator",
                        s = o.toStringTag || "@@toStringTag";

                    function l(t, e, n) {
                        return Object.defineProperty(t, e, {
                            value: n,
                            enumerable: !0,
                            configurable: !0,
                            writable: !0
                        }), t[e]
                    }
                    try {
                        l({}, "")
                    } catch (t) {
                        l = function(t, e, n) {
                            return t[e] = n
                        }
                    }

                    function u(t, e, n, r) {
                        var o = e && e.prototype instanceof m ? e : m,
                            i = Object.create(o.prototype),
                            a = new O(r || []);
                        return i._invoke = function(t, e, n) {
                            var r = d;
                            return function(o, i) {
                                if (r === f) throw new Error("Generator is already running");
                                if (r === p) {
                                    if ("throw" === o) throw i;
                                    return P()
                                }
                                for (n.method = o, n.arg = i;;) {
                                    var a = n.delegate;
                                    if (a) {
                                        var s = N(a, n);
                                        if (s) {
                                            if (s === v) continue;
                                            return s
                                        }
                                    }
                                    if ("next" === n.method) n.sent = n._sent = n.arg;
                                    else if ("throw" === n.method) {
                                        if (r === d) throw r = p, n.arg;
                                        n.dispatchException(n.arg)
                                    } else "return" === n.method && n.abrupt("return", n.arg);
                                    r = f;
                                    var l = c(t, e, n);
                                    if ("normal" === l.type) {
                                        if (r = n.done ? p : h, l.arg === v) continue;
                                        return {
                                            value: l.arg,
                                            done: n.done
                                        }
                                    }
                                    "throw" === l.type && (r = p, n.method = "throw", n.arg = l.arg)
                                }
                            }
                        }(t, n, a), i
                    }

                    function c(t, e, n) {
                        try {
                            return {
                                type: "normal",
                                arg: t.call(e, n)
                            }
                        } catch (t) {
                            return {
                                type: "throw",
                                arg: t
                            }
                        }
                    }
                    t.wrap = u;
                    var d = "suspendedStart",
                        h = "suspendedYield",
                        f = "executing",
                        p = "completed",
                        v = {};

                    function m() {}

                    function y() {}

                    function _() {}
                    var g = {};
                    l(g, i, (function() {
                        return this
                    }));
                    var b = Object.getPrototypeOf,
                        w = b && b(b(k([])));
                    w && w !== n && r.call(w, i) && (g = w);
                    var E = _.prototype = m.prototype = Object.create(g);

                    function S(t) {
                        ["next", "throw", "return"].forEach((function(e) {
                            l(t, e, (function(t) {
                                return this._invoke(e, t)
                            }))
                        }))
                    }

                    function C(t, e) {
                        function n(o, i, a, s) {
                            var l = c(t[o], t, i);
                            if ("throw" !== l.type) {
                                var u = l.arg,
                                    d = u.value;
                                return d && "object" == typeof d && r.call(d, "__await") ? e.resolve(d.__await).then((function(t) {
                                    n("next", t, a, s)
                                }), (function(t) {
                                    n("throw", t, a, s)
                                })) : e.resolve(d).then((function(t) {
                                    u.value = t, a(u)
                                }), (function(t) {
                                    return n("throw", t, a, s)
                                }))
                            }
                            s(l.arg)
                        }
                        var o;
                        this._invoke = function(t, r) {
                            function i() {
                                return new e((function(e, o) {
                                    n(t, r, e, o)
                                }))
                            }
                            return o = o ? o.then(i, i) : i()
                        }
                    }

                    function N(t, n) {
                        var r = t.iterator[n.method];
                        if (r === e) {
                            if (n.delegate = null, "throw" === n.method) {
                                if (t.iterator.return && (n.method = "return", n.arg = e, N(t, n), "throw" === n.method)) return v;
                                n.method = "throw", n.arg = new TypeError("The iterator does not provide a 'throw' method")
                            }
                            return v
                        }
                        var o = c(r, t.iterator, n.arg);
                        if ("throw" === o.type) return n.method = "throw", n.arg = o.arg, n.delegate = null, v;
                        var i = o.arg;
                        return i ? i.done ? (n[t.resultName] = i.value, n.next = t.nextLoc, "return" !== n.method && (n.method = "next", n.arg = e), n.delegate = null, v) : i : (n.method = "throw", n.arg = new TypeError("iterator result is not an object"), n.delegate = null, v)
                    }

                    function x(t) {
                        var e = {
                            tryLoc: t[0]
                        };
                        1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e)
                    }

                    function T(t) {
                        var e = t.completion || {};
                        e.type = "normal", delete e.arg, t.completion = e
                    }

                    function O(t) {
                        this.tryEntries = [{
                            tryLoc: "root"
                        }], t.forEach(x, this), this.reset(!0)
                    }

                    function k(t) {
                        if (t) {
                            var n = t[i];
                            if (n) return n.call(t);
                            if ("function" == typeof t.next) return t;
                            if (!isNaN(t.length)) {
                                var o = -1,
                                    a = function n() {
                                        for (; ++o < t.length;)
                                            if (r.call(t, o)) return n.value = t[o], n.done = !1, n;
                                        return n.value = e, n.done = !0, n
                                    };
                                return a.next = a
                            }
                        }
                        return {
                            next: P
                        }
                    }

                    function P() {
                        return {
                            value: e,
                            done: !0
                        }
                    }
                    return y.prototype = _, l(E, "constructor", _), l(_, "constructor", y), y.displayName = l(_, s, "GeneratorFunction"), t.isGeneratorFunction = function(t) {
                        var e = "function" == typeof t && t.constructor;
                        return !!e && (e === y || "GeneratorFunction" === (e.displayName || e.name))
                    }, t.mark = function(t) {
                        return Object.setPrototypeOf ? Object.setPrototypeOf(t, _) : (t.__proto__ = _, l(t, s, "GeneratorFunction")), t.prototype = Object.create(E), t
                    }, t.awrap = function(t) {
                        return {
                            __await: t
                        }
                    }, S(C.prototype), l(C.prototype, a, (function() {
                        return this
                    })), t.AsyncIterator = C, t.async = function(e, n, r, o, i) {
                        void 0 === i && (i = Promise);
                        var a = new C(u(e, n, r, o), i);
                        return t.isGeneratorFunction(n) ? a : a.next().then((function(t) {
                            return t.done ? t.value : a.next()
                        }))
                    }, S(E), l(E, s, "Generator"), l(E, i, (function() {
                        return this
                    })), l(E, "toString", (function() {
                        return "[object Generator]"
                    })), t.keys = function(t) {
                        var e = [];
                        for (var n in t) e.push(n);
                        return e.reverse(),
                            function n() {
                                for (; e.length;) {
                                    var r = e.pop();
                                    if (r in t) return n.value = r, n.done = !1, n
                                }
                                return n.done = !0, n
                            }
                    }, t.values = k, O.prototype = {
                        constructor: O,
                        reset: function(t) {
                            if (this.prev = 0, this.next = 0, this.sent = this._sent = e, this.done = !1, this.delegate = null, this.method = "next", this.arg = e, this.tryEntries.forEach(T), !t)
                                for (var n in this) "t" === n.charAt(0) && r.call(this, n) && !isNaN(+n.slice(1)) && (this[n] = e)
                        },
                        stop: function() {
                            this.done = !0;
                            var t = this.tryEntries[0].completion;
                            if ("throw" === t.type) throw t.arg;
                            return this.rval
                        },
                        dispatchException: function(t) {
                            if (this.done) throw t;
                            var n = this;

                            function o(r, o) {
                                return s.type = "throw", s.arg = t, n.next = r, o && (n.method = "next", n.arg = e), !!o
                            }
                            for (var i = this.tryEntries.length - 1; i >= 0; --i) {
                                var a = this.tryEntries[i],
                                    s = a.completion;
                                if ("root" === a.tryLoc) return o("end");
                                if (a.tryLoc <= this.prev) {
                                    var l = r.call(a, "catchLoc"),
                                        u = r.call(a, "finallyLoc");
                                    if (l && u) {
                                        if (this.prev < a.catchLoc) return o(a.catchLoc, !0);
                                        if (this.prev < a.finallyLoc) return o(a.finallyLoc)
                                    } else if (l) {
                                        if (this.prev < a.catchLoc) return o(a.catchLoc, !0)
                                    } else {
                                        if (!u) throw new Error("try statement without catch or finally");
                                        if (this.prev < a.finallyLoc) return o(a.finallyLoc)
                                    }
                                }
                            }
                        },
                        abrupt: function(t, e) {
                            for (var n = this.tryEntries.length - 1; n >= 0; --n) {
                                var o = this.tryEntries[n];
                                if (o.tryLoc <= this.prev && r.call(o, "finallyLoc") && this.prev < o.finallyLoc) {
                                    var i = o;
                                    break
                                }
                            }
                            i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null);
                            var a = i ? i.completion : {};
                            return a.type = t, a.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, v) : this.complete(a)
                        },
                        complete: function(t, e) {
                            if ("throw" === t.type) throw t.arg;
                            return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), v
                        },
                        finish: function(t) {
                            for (var e = this.tryEntries.length - 1; e >= 0; --e) {
                                var n = this.tryEntries[e];
                                if (n.finallyLoc === t) return this.complete(n.completion, n.afterLoc), T(n), v
                            }
                        },
                        catch: function(t) {
                            for (var e = this.tryEntries.length - 1; e >= 0; --e) {
                                var n = this.tryEntries[e];
                                if (n.tryLoc === t) {
                                    var r = n.completion;
                                    if ("throw" === r.type) {
                                        var o = r.arg;
                                        T(n)
                                    }
                                    return o
                                }
                            }
                            throw new Error("illegal catch attempt")
                        },
                        delegateYield: function(t, n, r) {
                            return this.delegate = {
                                iterator: k(t),
                                resultName: n,
                                nextLoc: r
                            }, "next" === this.method && (this.arg = e), v
                        }
                    }, t
                }(t.exports);
                try {
                    regeneratorRuntime = r
                } catch (t) {
                    "object" == typeof globalThis ? globalThis.regeneratorRuntime = r : Function("r", "regeneratorRuntime = r")(r)
                }
            }, function(t, e, n) {
                "use strict";

                function r(t, e) {
                    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                }

                function o(t, e) {
                    for (var n = 0; n < e.length; n++) {
                        var r = e[n];
                        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                    }
                }

                function i(t, e, n) {
                    return e && o(t.prototype, e), n && o(t, n), t
                }

                function a(t) {
                    return (a = Object.setPrototypeOf ? Object.getPrototypeOf : function(t) {
                        return t.__proto__ || Object.getPrototypeOf(t)
                    })(t)
                }

                function s(t, e, n) {
                    return (s = "undefined" != typeof Reflect && Reflect.get ? Reflect.get : function(t, e, n) {
                        var r = function(t, e) {
                            for (; !Object.prototype.hasOwnProperty.call(t, e) && null !== (t = a(t)););
                            return t
                        }(t, e);
                        if (r) {
                            var o = Object.getOwnPropertyDescriptor(r, e);
                            return o.get ? o.get.call(n) : o.value
                        }
                    })(t, e, n || t)
                }

                function l(t, e) {
                    return (l = Object.setPrototypeOf || function(t, e) {
                        return t.__proto__ = e, t
                    })(t, e)
                }

                function u(t, e) {
                    if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function");
                    t.prototype = Object.create(e && e.prototype, {
                        constructor: {
                            value: t,
                            writable: !0,
                            configurable: !0
                        }
                    }), e && l(t, e)
                }

                function c() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (t) {
                        return !1
                    }
                }
                n.r(e), n.d(e, "defaultConverter", (function() {
                    return bt
                })), n.d(e, "notEqual", (function() {
                    return wt
                })), n.d(e, "UpdatingElement", (function() {
                    return Ct
                })), n.d(e, "ReactiveElement", (function() {
                    return Ct
                })), n.d(e, "customElement", (function() {
                    return Nt
                })), n.d(e, "property", (function() {
                    return xt
                })), n.d(e, "internalProperty", (function() {
                    return Tt
                })), n.d(e, "state", (function() {
                    return Ot
                })), n.d(e, "query", (function() {
                    return kt
                })), n.d(e, "queryAsync", (function() {
                    return Pt
                })), n.d(e, "queryAll", (function() {
                    return Dt
                })), n.d(e, "eventOptions", (function() {
                    return jt
                })), n.d(e, "queryAssignedNodes", (function() {
                    return Rt
                })), n.d(e, "svg", (function() {
                    return st
                })), n.d(e, "SVGTemplateResult", (function() {
                    return W
                })), n.d(e, "supportsAdoptingStyleSheets", (function() {
                    return Ft
                })), n.d(e, "CSSResult", (function() {
                    return Bt
                })), n.d(e, "unsafeCSS", (function() {
                    return Ht
                })), n.d(e, "css", (function() {
                    return Vt
                })), n.d(e, "LitElement", (function() {
                    return qt
                })), n.d(e, "html", (function() {
                    return at
                })), n.d(e, "TemplateResult", (function() {
                    return V
                })), n.d(e, "styleMap", (function() {
                    return Gt
                })), n.d(e, "unsafeHTML", (function() {
                    return Kt
                }));
                var d = n(1),
                    h = n.n(d);

                function f(t, e) {
                    if (e && ("object" === h()(e) || "function" == typeof e)) return e;
                    if (void 0 !== e) throw new TypeError("Derived constructors may only return object or undefined");
                    return function(t) {
                        if (void 0 === t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                        return t
                    }(t)
                }

                function p(t) {
                    var e = c();
                    return function() {
                        var n, r = a(t);
                        if (e) {
                            var o = a(this).constructor;
                            n = Reflect.construct(r, arguments, o)
                        } else n = r.apply(this, arguments);
                        return f(this, n)
                    }
                }

                function v(t) {
                    return (v = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                        return typeof t
                    } : function(t) {
                        return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
                    })(t)
                }
                var m = "undefined" != typeof window && null != window.customElements && void 0 !== window.customElements.polyfillWrapFlushCallback,
                    y = function(t, e) {
                        for (var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null; e !== n;) {
                            var r = e.nextSibling;
                            t.removeChild(e), e = r
                        }
                    },
                    _ = "{{lit-".concat(String(Math.random()).slice(2), "}}"),
                    g = "\x3c!--".concat(_, "--\x3e"),
                    b = new RegExp("".concat(_, "|").concat(g)),
                    w = "$lit$",
                    E = function t(e, n) {
                        r(this, t), this.parts = [], this.element = n;
                        for (var o = [], i = [], a = document.createTreeWalker(n.content, 133, null, !1), s = 0, l = -1, u = 0, c = e.strings, d = e.values.length; u < d;) {
                            var h = a.nextNode();
                            if (null !== h) {
                                if (l++, 1 === h.nodeType) {
                                    if (h.hasAttributes()) {
                                        for (var f = h.attributes, p = f.length, v = 0, m = 0; m < p; m++) S(f[m].name, w) && v++;
                                        for (; v-- > 0;) {
                                            var y = c[u],
                                                g = x.exec(y)[2],
                                                E = g.toLowerCase() + w,
                                                C = h.getAttribute(E);
                                            h.removeAttribute(E);
                                            var T = C.split(b);
                                            this.parts.push({
                                                type: "attribute",
                                                index: l,
                                                name: g,
                                                strings: T
                                            }), u += T.length - 1
                                        }
                                    }
                                    "TEMPLATE" === h.tagName && (i.push(h), a.currentNode = h.content)
                                } else if (3 === h.nodeType) {
                                    var O = h.data;
                                    if (O.indexOf(_) >= 0) {
                                        for (var k = h.parentNode, P = O.split(b), D = P.length - 1, A = 0; A < D; A++) {
                                            var M = void 0,
                                                j = P[A];
                                            if ("" === j) M = N();
                                            else {
                                                var L = x.exec(j);
                                                null !== L && S(L[2], w) && (j = j.slice(0, L.index) + L[1] + L[2].slice(0, -w.length) + L[3]), M = document.createTextNode(j)
                                            }
                                            k.insertBefore(M, h), this.parts.push({
                                                type: "node",
                                                index: ++l
                                            })
                                        }
                                        "" === P[D] ? (k.insertBefore(N(), h), o.push(h)) : h.data = P[D], u += D
                                    }
                                } else if (8 === h.nodeType)
                                    if (h.data === _) {
                                        var I = h.parentNode;
                                        null !== h.previousSibling && l !== s || (l++, I.insertBefore(N(), h)), s = l, this.parts.push({
                                            type: "node",
                                            index: l
                                        }), null === h.nextSibling ? h.data = "" : (o.push(h), l--), u++
                                    } else
                                        for (var R = -1; - 1 !== (R = h.data.indexOf(_, R + 1));) this.parts.push({
                                            type: "node",
                                            index: -1
                                        }), u++
                            } else a.currentNode = i.pop()
                        }
                        for (var F = 0, U = o; F < U.length; F++) {
                            var B = U[F];
                            B.parentNode.removeChild(B)
                        }
                    },
                    S = function(t, e) {
                        var n = t.length - e.length;
                        return n >= 0 && t.slice(n) === e
                    },
                    C = function(t) {
                        return -1 !== t.index
                    },
                    N = function() {
                        return document.createComment("")
                    },
                    x = /([ \x09\x0a\x0c\x0d])([^\0-\x1F\x7F-\x9F "'>=/]+)([ \x09\x0a\x0c\x0d]*=[ \x09\x0a\x0c\x0d]*(?:[^ \x09\x0a\x0c\x0d"'`<>=]*|"[^"]*|'[^']*))$/,
                    T = 133;

                function O(t, e) {
                    for (var n = t.element.content, r = t.parts, o = document.createTreeWalker(n, T, null, !1), i = P(r), a = r[i], s = -1, l = 0, u = [], c = null; o.nextNode();) {
                        s++;
                        var d = o.currentNode;
                        for (d.previousSibling === c && (c = null), e.has(d) && (u.push(d), null === c && (c = d)), null !== c && l++; void 0 !== a && a.index === s;) a.index = null !== c ? -1 : a.index - l, a = r[i = P(r, i)]
                    }
                    u.forEach((function(t) {
                        return t.parentNode.removeChild(t)
                    }))
                }
                var k = function(t) {
                        for (var e = 11 === t.nodeType ? 0 : 1, n = document.createTreeWalker(t, T, null, !1); n.nextNode();) e++;
                        return e
                    },
                    P = function(t) {
                        for (var e = (arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : -1) + 1; e < t.length; e++) {
                            var n = t[e];
                            if (C(n)) return e
                        }
                        return -1
                    };

                function D(t, e) {
                    (null == e || e > t.length) && (e = t.length);
                    for (var n = 0, r = new Array(e); n < e; n++) r[n] = t[n];
                    return r
                }

                function A(t, e) {
                    if (t) {
                        if ("string" == typeof t) return D(t, e);
                        var n = Object.prototype.toString.call(t).slice(8, -1);
                        return "Object" === n && t.constructor && (n = t.constructor.name), "Map" === n || "Set" === n ? Array.from(t) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? D(t, e) : void 0
                    }
                }

                function M(t, e) {
                    var n = "undefined" != typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
                    if (!n) {
                        if (Array.isArray(t) || (n = A(t)) || e && t && "number" == typeof t.length) {
                            n && (t = n);
                            var r = 0,
                                o = function() {};
                            return {
                                s: o,
                                n: function() {
                                    return r >= t.length ? {
                                        done: !0
                                    } : {
                                        done: !1,
                                        value: t[r++]
                                    }
                                },
                                e: function(t) {
                                    throw t
                                },
                                f: o
                            }
                        }
                        throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                    }
                    var i, a = !0,
                        s = !1;
                    return {
                        s: function() {
                            n = n.call(t)
                        },
                        n: function() {
                            var t = n.next();
                            return a = t.done, t
                        },
                        e: function(t) {
                            s = !0, i = t
                        },
                        f: function() {
                            try {
                                a || null == n.return || n.return()
                            } finally {
                                if (s) throw i
                            }
                        }
                    }
                }
                var j = new WeakMap,
                    L = function(t) {
                        return function() {
                            var e = t.apply(void 0, arguments);
                            return j.set(e, !0), e
                        }
                    },
                    I = function(t) {
                        return "function" == typeof t && j.has(t)
                    },
                    R = {},
                    F = {};

                function U(t) {
                    return function(t) {
                        if (Array.isArray(t)) return D(t)
                    }(t) || function(t) {
                        if ("undefined" != typeof Symbol && null != t[Symbol.iterator] || null != t["@@iterator"]) return Array.from(t)
                    }(t) || A(t) || function() {
                        throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                    }()
                }
                var B = function() {
                        function t(e, n, o) {
                            r(this, t), this.__parts = [], this.template = e, this.processor = n, this.options = o
                        }
                        return i(t, [{
                            key: "update",
                            value: function(t) {
                                var e, n = 0,
                                    r = M(this.__parts);
                                try {
                                    for (r.s(); !(e = r.n()).done;) {
                                        var o = e.value;
                                        void 0 !== o && o.setValue(t[n]), n++
                                    }
                                } catch (t) {
                                    r.e(t)
                                } finally {
                                    r.f()
                                }
                                var i, a = M(this.__parts);
                                try {
                                    for (a.s(); !(i = a.n()).done;) {
                                        var s = i.value;
                                        void 0 !== s && s.commit()
                                    }
                                } catch (t) {
                                    a.e(t)
                                } finally {
                                    a.f()
                                }
                            }
                        }, {
                            key: "_clone",
                            value: function() {
                                for (var t, e = m ? this.template.element.content.cloneNode(!0) : document.importNode(this.template.element.content, !0), n = [], r = this.template.parts, o = document.createTreeWalker(e, 133, null, !1), i = 0, a = 0, s = o.nextNode(); i < r.length;)
                                    if (t = r[i], C(t)) {
                                        for (; a < t.index;) a++, "TEMPLATE" === s.nodeName && (n.push(s), o.currentNode = s.content), null === (s = o.nextNode()) && (o.currentNode = n.pop(), s = o.nextNode());
                                        if ("node" === t.type) {
                                            var l = this.processor.handleTextExpression(this.options);
                                            l.insertAfterNode(s.previousSibling), this.__parts.push(l)
                                        } else {
                                            var u;
                                            (u = this.__parts).push.apply(u, U(this.processor.handleAttributeExpressions(s, t.name, t.strings, this.options)))
                                        }
                                        i++
                                    } else this.__parts.push(void 0), i++;
                                return m && (document.adoptNode(e), customElements.upgrade(e)), e
                            }
                        }]), t
                    }(),
                    H = window.trustedTypes && trustedTypes.createPolicy("lit-html", {
                        createHTML: function(t) {
                            return t
                        }
                    }),
                    Z = " ".concat(_, " "),
                    V = function() {
                        function t(e, n, o, i) {
                            r(this, t), this.strings = e, this.values = n, this.type = o, this.processor = i
                        }
                        return i(t, [{
                            key: "getHTML",
                            value: function() {
                                for (var t = this.strings.length - 1, e = "", n = !1, r = 0; r < t; r++) {
                                    var o = this.strings[r],
                                        i = o.lastIndexOf("\x3c!--");
                                    n = (i > -1 || n) && -1 === o.indexOf("--\x3e", i + 1);
                                    var a = x.exec(o);
                                    e += null === a ? o + (n ? Z : g) : o.substr(0, a.index) + a[1] + a[2] + w + a[3] + _
                                }
                                return e + this.strings[t]
                            }
                        }, {
                            key: "getTemplateElement",
                            value: function() {
                                var t = document.createElement("template"),
                                    e = this.getHTML();
                                return void 0 !== H && (e = H.createHTML(e)), t.innerHTML = e, t
                            }
                        }]), t
                    }(),
                    W = function(t) {
                        u(n, t);
                        var e = p(n);

                        function n() {
                            return r(this, n), e.apply(this, arguments)
                        }
                        return i(n, [{
                            key: "getHTML",
                            value: function() {
                                return "<svg>".concat(s(a(n.prototype), "getHTML", this).call(this), "</svg>")
                            }
                        }, {
                            key: "getTemplateElement",
                            value: function() {
                                var t = s(a(n.prototype), "getTemplateElement", this).call(this),
                                    e = t.content,
                                    r = e.firstChild;
                                return e.removeChild(r),
                                    function(t, e) {
                                        for (var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null, r = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null; e !== n;) {
                                            var o = e.nextSibling;
                                            t.insertBefore(e, r), e = o
                                        }
                                    }(e, r.firstChild), t
                            }
                        }]), n
                    }(V),
                    q = function(t) {
                        return null === t || !("object" === v(t) || "function" == typeof t)
                    },
                    z = function(t) {
                        return Array.isArray(t) || !(!t || !t[Symbol.iterator])
                    },
                    G = function() {
                        function t(e, n, o) {
                            r(this, t), this.dirty = !0, this.element = e, this.name = n, this.strings = o, this.parts = [];
                            for (var i = 0; i < o.length - 1; i++) this.parts[i] = this._createPart()
                        }
                        return i(t, [{
                            key: "_createPart",
                            value: function() {
                                return new X(this)
                            }
                        }, {
                            key: "_getValue",
                            value: function() {
                                var t = this.strings,
                                    e = t.length - 1,
                                    n = this.parts;
                                if (1 === e && "" === t[0] && "" === t[1]) {
                                    var r = n[0].value;
                                    if ("symbol" === v(r)) return String(r);
                                    if ("string" == typeof r || !z(r)) return r
                                }
                                for (var o = "", i = 0; i < e; i++) {
                                    o += t[i];
                                    var a = n[i];
                                    if (void 0 !== a) {
                                        var s = a.value;
                                        if (q(s) || !z(s)) o += "string" == typeof s ? s : String(s);
                                        else {
                                            var l, u = M(s);
                                            try {
                                                for (u.s(); !(l = u.n()).done;) {
                                                    var c = l.value;
                                                    o += "string" == typeof c ? c : String(c)
                                                }
                                            } catch (t) {
                                                u.e(t)
                                            } finally {
                                                u.f()
                                            }
                                        }
                                    }
                                }
                                return o + t[e]
                            }
                        }, {
                            key: "commit",
                            value: function() {
                                this.dirty && (this.dirty = !1, this.element.setAttribute(this.name, this._getValue()))
                            }
                        }]), t
                    }(),
                    X = function() {
                        function t(e) {
                            r(this, t), this.value = void 0, this.committer = e
                        }
                        return i(t, [{
                            key: "setValue",
                            value: function(t) {
                                t === R || q(t) && t === this.value || (this.value = t, I(t) || (this.committer.dirty = !0))
                            }
                        }, {
                            key: "commit",
                            value: function() {
                                for (; I(this.value);) {
                                    var t = this.value;
                                    this.value = R, t(this)
                                }
                                this.value !== R && this.committer.commit()
                            }
                        }]), t
                    }(),
                    K = function() {
                        function t(e) {
                            r(this, t), this.value = void 0, this.__pendingValue = void 0, this.options = e
                        }
                        return i(t, [{
                            key: "appendInto",
                            value: function(t) {
                                this.startNode = t.appendChild(N()), this.endNode = t.appendChild(N())
                            }
                        }, {
                            key: "insertAfterNode",
                            value: function(t) {
                                this.startNode = t, this.endNode = t.nextSibling
                            }
                        }, {
                            key: "appendIntoPart",
                            value: function(t) {
                                t.__insert(this.startNode = N()), t.__insert(this.endNode = N())
                            }
                        }, {
                            key: "insertAfterPart",
                            value: function(t) {
                                t.__insert(this.startNode = N()), this.endNode = t.endNode, t.endNode = this.startNode
                            }
                        }, {
                            key: "setValue",
                            value: function(t) {
                                this.__pendingValue = t
                            }
                        }, {
                            key: "commit",
                            value: function() {
                                if (null !== this.startNode.parentNode) {
                                    for (; I(this.__pendingValue);) {
                                        var t = this.__pendingValue;
                                        this.__pendingValue = R, t(this)
                                    }
                                    var e = this.__pendingValue;
                                    e !== R && (q(e) ? e !== this.value && this.__commitText(e) : e instanceof V ? this.__commitTemplateResult(e) : e instanceof Node ? this.__commitNode(e) : z(e) ? this.__commitIterable(e) : e === F ? (this.value = F, this.clear()) : this.__commitText(e))
                                }
                            }
                        }, {
                            key: "__insert",
                            value: function(t) {
                                this.endNode.parentNode.insertBefore(t, this.endNode)
                            }
                        }, {
                            key: "__commitNode",
                            value: function(t) {
                                this.value !== t && (this.clear(), this.__insert(t), this.value = t)
                            }
                        }, {
                            key: "__commitText",
                            value: function(t) {
                                var e = this.startNode.nextSibling,
                                    n = "string" == typeof(t = null == t ? "" : t) ? t : String(t);
                                e === this.endNode.previousSibling && 3 === e.nodeType ? e.data = n : this.__commitNode(document.createTextNode(n)), this.value = t
                            }
                        }, {
                            key: "__commitTemplateResult",
                            value: function(t) {
                                var e = this.options.templateFactory(t);
                                if (this.value instanceof B && this.value.template === e) this.value.update(t.values);
                                else {
                                    var n = new B(e, t.processor, this.options),
                                        r = n._clone();
                                    n.update(t.values), this.__commitNode(r), this.value = n
                                }
                            }
                        }, {
                            key: "__commitIterable",
                            value: function(e) {
                                Array.isArray(this.value) || (this.value = [], this.clear());
                                var n, r, o = this.value,
                                    i = 0,
                                    a = M(e);
                                try {
                                    for (a.s(); !(r = a.n()).done;) {
                                        var s = r.value;
                                        void 0 === (n = o[i]) && (n = new t(this.options), o.push(n), 0 === i ? n.appendIntoPart(this) : n.insertAfterPart(o[i - 1])), n.setValue(s), n.commit(), i++
                                    }
                                } catch (t) {
                                    a.e(t)
                                } finally {
                                    a.f()
                                }
                                i < o.length && (o.length = i, this.clear(n && n.endNode))
                            }
                        }, {
                            key: "clear",
                            value: function() {
                                var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this.startNode;
                                y(this.startNode.parentNode, t.nextSibling, this.endNode)
                            }
                        }]), t
                    }(),
                    Y = function() {
                        function t(e, n, o) {
                            if (r(this, t), this.value = void 0, this.__pendingValue = void 0, 2 !== o.length || "" !== o[0] || "" !== o[1]) throw new Error("Boolean attributes can only contain a single expression");
                            this.element = e, this.name = n, this.strings = o
                        }
                        return i(t, [{
                            key: "setValue",
                            value: function(t) {
                                this.__pendingValue = t
                            }
                        }, {
                            key: "commit",
                            value: function() {
                                for (; I(this.__pendingValue);) {
                                    var t = this.__pendingValue;
                                    this.__pendingValue = R, t(this)
                                }
                                if (this.__pendingValue !== R) {
                                    var e = !!this.__pendingValue;
                                    this.value !== e && (e ? this.element.setAttribute(this.name, "") : this.element.removeAttribute(this.name), this.value = e), this.__pendingValue = R
                                }
                            }
                        }]), t
                    }(),
                    J = function(t) {
                        u(n, t);
                        var e = p(n);

                        function n(t, o, i) {
                            var a;
                            return r(this, n), (a = e.call(this, t, o, i)).single = 2 === i.length && "" === i[0] && "" === i[1], a
                        }
                        return i(n, [{
                            key: "_createPart",
                            value: function() {
                                return new $(this)
                            }
                        }, {
                            key: "_getValue",
                            value: function() {
                                return this.single ? this.parts[0].value : s(a(n.prototype), "_getValue", this).call(this)
                            }
                        }, {
                            key: "commit",
                            value: function() {
                                this.dirty && (this.dirty = !1, this.element[this.name] = this._getValue())
                            }
                        }]), n
                    }(G),
                    $ = function(t) {
                        u(n, t);
                        var e = p(n);

                        function n() {
                            return r(this, n), e.apply(this, arguments)
                        }
                        return n
                    }(X),
                    Q = !1;
                ! function() {
                    try {
                        var t = {
                            get capture() {
                                return Q = !0, !1
                            }
                        };
                        window.addEventListener("test", t, t), window.removeEventListener("test", t, t)
                    } catch (t) {}
                }();
                var tt = function() {
                        function t(e, n, o) {
                            var i = this;
                            r(this, t), this.value = void 0, this.__pendingValue = void 0, this.element = e, this.eventName = n, this.eventContext = o, this.__boundHandleEvent = function(t) {
                                return i.handleEvent(t)
                            }
                        }
                        return i(t, [{
                            key: "setValue",
                            value: function(t) {
                                this.__pendingValue = t
                            }
                        }, {
                            key: "commit",
                            value: function() {
                                for (; I(this.__pendingValue);) {
                                    var t = this.__pendingValue;
                                    this.__pendingValue = R, t(this)
                                }
                                if (this.__pendingValue !== R) {
                                    var e = this.__pendingValue,
                                        n = this.value,
                                        r = null == e || null != n && (e.capture !== n.capture || e.once !== n.once || e.passive !== n.passive);
                                    r && this.element.removeEventListener(this.eventName, this.__boundHandleEvent, this.__options), null == e || null != n && !r || (this.__options = et(e), this.element.addEventListener(this.eventName, this.__boundHandleEvent, this.__options)), this.value = e, this.__pendingValue = R
                                }
                            }
                        }, {
                            key: "handleEvent",
                            value: function(t) {
                                "function" == typeof this.value ? this.value.call(this.eventContext || this.element, t) : this.value.handleEvent(t)
                            }
                        }]), t
                    }(),
                    et = function(t) {
                        return t && (Q ? {
                            capture: t.capture,
                            passive: t.passive,
                            once: t.once
                        } : t.capture)
                    };

                function nt(t) {
                    var e = rt.get(t.type);
                    void 0 === e && (e = {
                        stringsArray: new WeakMap,
                        keyString: new Map
                    }, rt.set(t.type, e));
                    var n = e.stringsArray.get(t.strings);
                    if (void 0 !== n) return n;
                    var r = t.strings.join(_);
                    return void 0 === (n = e.keyString.get(r)) && (n = new E(t, t.getTemplateElement()), e.keyString.set(r, n)), e.stringsArray.set(t.strings, n), n
                }
                var rt = new Map,
                    ot = new WeakMap,
                    it = new(function() {
                        function t() {
                            r(this, t)
                        }
                        return i(t, [{
                            key: "handleAttributeExpressions",
                            value: function(t, e, n, r) {
                                var o = e[0];
                                return "." === o ? new J(t, e.slice(1), n).parts : "@" === o ? [new tt(t, e.slice(1), r.eventContext)] : "?" === o ? [new Y(t, e.slice(1), n)] : new G(t, e, n).parts
                            }
                        }, {
                            key: "handleTextExpression",
                            value: function(t) {
                                return new K(t)
                            }
                        }]), t
                    }());
                "undefined" != typeof window && (window.litHtmlVersions || (window.litHtmlVersions = [])).push("1.4.1");
                var at = function(t) {
                        for (var e = arguments.length, n = new Array(e > 1 ? e - 1 : 0), r = 1; r < e; r++) n[r - 1] = arguments[r];
                        return new V(t, n, "html", it)
                    },
                    st = function(t) {
                        for (var e = arguments.length, n = new Array(e > 1 ? e - 1 : 0), r = 1; r < e; r++) n[r - 1] = arguments[r];
                        return new W(t, n, "svg", it)
                    },
                    lt = function(t, e) {
                        return "".concat(t, "--").concat(e)
                    },
                    ut = !0;
                (void 0 === window.ShadyCSS || void 0 === window.ShadyCSS.prepareTemplateDom) && (ut = !1);
                var ct = function(t) {
                        return function(e) {
                            var n = lt(e.type, t),
                                r = rt.get(n);
                            void 0 === r && (r = {
                                stringsArray: new WeakMap,
                                keyString: new Map
                            }, rt.set(n, r));
                            var o = r.stringsArray.get(e.strings);
                            if (void 0 !== o) return o;
                            var i = e.strings.join(_);
                            if (void 0 === (o = r.keyString.get(i))) {
                                var a = e.getTemplateElement();
                                ut && window.ShadyCSS.prepareTemplateDom(a, t), o = new E(e, a), r.keyString.set(i, o)
                            }
                            return r.stringsArray.set(e.strings, o), o
                        }
                    },
                    dt = ["html", "svg"],
                    ht = new Set,
                    ft = function(t, e, n) {
                        ht.add(t);
                        var r = n ? n.element : document.createElement("template"),
                            o = e.querySelectorAll("style"),
                            i = o.length;
                        if (0 !== i) {
                            for (var a = document.createElement("style"), s = 0; s < i; s++) {
                                var l = o[s];
                                l.parentNode.removeChild(l), a.textContent += l.textContent
                            }! function(t) {
                                dt.forEach((function(e) {
                                    var n = rt.get(lt(e, t));
                                    void 0 !== n && n.keyString.forEach((function(t) {
                                        var e = t.element.content,
                                            n = new Set;
                                        Array.from(e.querySelectorAll("style")).forEach((function(t) {
                                            n.add(t)
                                        })), O(t, n)
                                    }))
                                }))
                            }(t);
                            var u = r.content;
                            n ? function(t, e) {
                                var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
                                    r = t.element.content,
                                    o = t.parts;
                                if (null != n)
                                    for (var i = document.createTreeWalker(r, T, null, !1), a = P(o), s = 0, l = -1; i.nextNode();)
                                        for (l++, i.currentNode === n && (s = k(e), n.parentNode.insertBefore(e, n)); - 1 !== a && o[a].index === l;) {
                                            if (s > 0) {
                                                for (; - 1 !== a;) o[a].index += s, a = P(o, a);
                                                return
                                            }
                                            a = P(o, a)
                                        } else r.appendChild(e)
                            }(n, a, u.firstChild) : u.insertBefore(a, u.firstChild), window.ShadyCSS.prepareTemplateStyles(r, t);
                            var c = u.querySelector("style");
                            if (window.ShadyCSS.nativeShadow && null !== c) e.insertBefore(c.cloneNode(!0), e.firstChild);
                            else if (n) {
                                u.insertBefore(a, u.firstChild);
                                var d = new Set;
                                d.add(a), O(n, d)
                            }
                        } else window.ShadyCSS.prepareTemplateStyles(r, t)
                    };

                function pt(t, e, n, r, o, i, a) {
                    try {
                        var s = t[i](a),
                            l = s.value
                    } catch (t) {
                        return void n(t)
                    }
                    s.done ? e(l) : Promise.resolve(l).then(r, o)
                }

                function vt(t) {
                    return function() {
                        var e = this,
                            n = arguments;
                        return new Promise((function(r, o) {
                            var i = t.apply(e, n);

                            function a(t) {
                                pt(i, r, o, a, s, "next", t)
                            }

                            function s(t) {
                                pt(i, r, o, a, s, "throw", t)
                            }
                            a(void 0)
                        }))
                    }
                }

                function mt(t, e, n) {
                    return (mt = c() ? Reflect.construct : function(t, e, n) {
                        var r = [null];
                        r.push.apply(r, e);
                        var o = new(Function.bind.apply(t, r));
                        return n && l(o, n.prototype), o
                    }).apply(null, arguments)
                }

                function yt(t) {
                    var e = "function" == typeof Map ? new Map : void 0;
                    return (yt = function(t) {
                        if (null === t || (n = t, -1 === Function.toString.call(n).indexOf("[native code]"))) return t;
                        var n;
                        if ("function" != typeof t) throw new TypeError("Super expression must either be null or a function");
                        if (void 0 !== e) {
                            if (e.has(t)) return e.get(t);
                            e.set(t, r)
                        }

                        function r() {
                            return mt(t, arguments, a(this).constructor)
                        }
                        return r.prototype = Object.create(t.prototype, {
                            constructor: {
                                value: r,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), l(r, t)
                    })(t)
                }
                var _t = n(0),
                    gt = n.n(_t);
                window.JSCompiler_renameProperty = function(t) {
                    return t
                };
                var bt = {
                        toAttribute: function(t, e) {
                            switch (e) {
                                case Boolean:
                                    return t ? "" : null;
                                case Object:
                                case Array:
                                    return null == t ? t : JSON.stringify(t)
                            }
                            return t
                        },
                        fromAttribute: function(t, e) {
                            switch (e) {
                                case Boolean:
                                    return null !== t;
                                case Number:
                                    return null === t ? null : Number(t);
                                case Object:
                                case Array:
                                    return JSON.parse(t)
                            }
                            return t
                        }
                    },
                    wt = function(t, e) {
                        return e !== t && (e == e || t == t)
                    },
                    Et = {
                        attribute: !0,
                        type: String,
                        converter: bt,
                        reflect: !1,
                        hasChanged: wt
                    },
                    St = "finalized",
                    Ct = function(t) {
                        u(o, t);
                        var e, n = p(o);

                        function o() {
                            var t;
                            return r(this, o), (t = n.call(this)).initialize(), t
                        }
                        return i(o, [{
                            key: "initialize",
                            value: function() {
                                var t = this;
                                this._updateState = 0, this._updatePromise = new Promise((function(e) {
                                    return t._enableUpdatingResolver = e
                                })), this._changedProperties = new Map, this._saveInstanceProperties(), this.requestUpdateInternal()
                            }
                        }, {
                            key: "_saveInstanceProperties",
                            value: function() {
                                var t = this;
                                this.constructor._classProperties.forEach((function(e, n) {
                                    if (t.hasOwnProperty(n)) {
                                        var r = t[n];
                                        delete t[n], t._instanceProperties || (t._instanceProperties = new Map), t._instanceProperties.set(n, r)
                                    }
                                }))
                            }
                        }, {
                            key: "_applyInstanceProperties",
                            value: function() {
                                var t = this;
                                this._instanceProperties.forEach((function(e, n) {
                                    return t[n] = e
                                })), this._instanceProperties = void 0
                            }
                        }, {
                            key: "connectedCallback",
                            value: function() {
                                this.enableUpdating()
                            }
                        }, {
                            key: "enableUpdating",
                            value: function() {
                                void 0 !== this._enableUpdatingResolver && (this._enableUpdatingResolver(), this._enableUpdatingResolver = void 0)
                            }
                        }, {
                            key: "disconnectedCallback",
                            value: function() {}
                        }, {
                            key: "attributeChangedCallback",
                            value: function(t, e, n) {
                                e !== n && this._attributeToProperty(t, n)
                            }
                        }, {
                            key: "_propertyToAttribute",
                            value: function(t, e) {
                                var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : Et,
                                    r = this.constructor,
                                    o = r._attributeNameForProperty(t, n);
                                if (void 0 !== o) {
                                    var i = r._propertyValueToAttribute(e, n);
                                    if (void 0 === i) return;
                                    this._updateState = 8 | this._updateState, null == i ? this.removeAttribute(o) : this.setAttribute(o, i), this._updateState = -9 & this._updateState
                                }
                            }
                        }, {
                            key: "_attributeToProperty",
                            value: function(t, e) {
                                if (!(8 & this._updateState)) {
                                    var n = this.constructor,
                                        r = n._attributeToPropertyMap.get(t);
                                    if (void 0 !== r) {
                                        var o = n.getPropertyOptions(r);
                                        this._updateState = 16 | this._updateState, this[r] = n._propertyValueFromAttribute(e, o), this._updateState = -17 & this._updateState
                                    }
                                }
                            }
                        }, {
                            key: "requestUpdateInternal",
                            value: function(t, e, n) {
                                var r = !0;
                                if (void 0 !== t) {
                                    var o = this.constructor;
                                    n = n || o.getPropertyOptions(t), o._valueHasChanged(this[t], e, n.hasChanged) ? (this._changedProperties.has(t) || this._changedProperties.set(t, e), !0 !== n.reflect || 16 & this._updateState || (void 0 === this._reflectingProperties && (this._reflectingProperties = new Map), this._reflectingProperties.set(t, n))) : r = !1
                                }!this._hasRequestedUpdate && r && (this._updatePromise = this._enqueueUpdate())
                            }
                        }, {
                            key: "requestUpdate",
                            value: function(t, e) {
                                return this.requestUpdateInternal(t, e), this.updateComplete
                            }
                        }, {
                            key: "_enqueueUpdate",
                            value: (e = vt(gt.a.mark((function t() {
                                var e;
                                return gt.a.wrap((function(t) {
                                    for (;;) switch (t.prev = t.next) {
                                        case 0:
                                            return this._updateState = 4 | this._updateState, t.prev = 1, t.next = 4, this._updatePromise;
                                        case 4:
                                            t.next = 8;
                                            break;
                                        case 6:
                                            t.prev = 6, t.t0 = t.catch(1);
                                        case 8:
                                            if (null == (e = this.performUpdate())) {
                                                t.next = 12;
                                                break
                                            }
                                            return t.next = 12, e;
                                        case 12:
                                            return t.abrupt("return", !this._hasRequestedUpdate);
                                        case 13:
                                        case "end":
                                            return t.stop()
                                    }
                                }), t, this, [
                                    [1, 6]
                                ])
                            }))), function() {
                                return e.apply(this, arguments)
                            })
                        }, {
                            key: "_hasRequestedUpdate",
                            get: function() {
                                return 4 & this._updateState
                            }
                        }, {
                            key: "hasUpdated",
                            get: function() {
                                return 1 & this._updateState
                            }
                        }, {
                            key: "performUpdate",
                            value: function() {
                                if (this._hasRequestedUpdate) {
                                    this._instanceProperties && this._applyInstanceProperties();
                                    var t = !1,
                                        e = this._changedProperties;
                                    try {
                                        (t = this.shouldUpdate(e)) ? this.update(e): this._markUpdated()
                                    } catch (e) {
                                        throw t = !1, this._markUpdated(), e
                                    }
                                    t && (1 & this._updateState || (this._updateState = 1 | this._updateState, this.firstUpdated(e)), this.updated(e))
                                }
                            }
                        }, {
                            key: "_markUpdated",
                            value: function() {
                                this._changedProperties = new Map, this._updateState = -5 & this._updateState
                            }
                        }, {
                            key: "updateComplete",
                            get: function() {
                                return this._getUpdateComplete()
                            }
                        }, {
                            key: "_getUpdateComplete",
                            value: function() {
                                return this.getUpdateComplete()
                            }
                        }, {
                            key: "getUpdateComplete",
                            value: function() {
                                return this._updatePromise
                            }
                        }, {
                            key: "shouldUpdate",
                            value: function() {
                                return !0
                            }
                        }, {
                            key: "update",
                            value: function() {
                                var t = this;
                                void 0 !== this._reflectingProperties && this._reflectingProperties.size > 0 && (this._reflectingProperties.forEach((function(e, n) {
                                    return t._propertyToAttribute(n, t[n], e)
                                })), this._reflectingProperties = void 0), this._markUpdated()
                            }
                        }, {
                            key: "updated",
                            value: function() {}
                        }, {
                            key: "firstUpdated",
                            value: function() {}
                        }], [{
                            key: "observedAttributes",
                            get: function() {
                                var t = this;
                                this.finalize();
                                var e = [];
                                return this._classProperties.forEach((function(n, r) {
                                    var o = t._attributeNameForProperty(r, n);
                                    void 0 !== o && (t._attributeToPropertyMap.set(o, r), e.push(o))
                                })), e
                            }
                        }, {
                            key: "_ensureClassProperties",
                            value: function() {
                                var t = this;
                                if (!this.hasOwnProperty(JSCompiler_renameProperty("_classProperties", this))) {
                                    this._classProperties = new Map;
                                    var e = Object.getPrototypeOf(this)._classProperties;
                                    void 0 !== e && e.forEach((function(e, n) {
                                        return t._classProperties.set(n, e)
                                    }))
                                }
                            }
                        }, {
                            key: "createProperty",
                            value: function(t) {
                                var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : Et;
                                if (this._ensureClassProperties(), this._classProperties.set(t, e), !e.noAccessor && !this.prototype.hasOwnProperty(t)) {
                                    var n = "symbol" === v(t) ? Symbol() : "__".concat(t),
                                        r = this.getPropertyDescriptor(t, n, e);
                                    void 0 !== r && Object.defineProperty(this.prototype, t, r)
                                }
                            }
                        }, {
                            key: "getPropertyDescriptor",
                            value: function(t, e, n) {
                                return {
                                    get: function() {
                                        return this[e]
                                    },
                                    set: function(r) {
                                        var o = this[t];
                                        this[e] = r, this.requestUpdateInternal(t, o, n)
                                    },
                                    configurable: !0,
                                    enumerable: !0
                                }
                            }
                        }, {
                            key: "getPropertyOptions",
                            value: function(t) {
                                return this._classProperties && this._classProperties.get(t) || Et
                            }
                        }, {
                            key: "finalize",
                            value: function() {
                                var t = Object.getPrototypeOf(this);
                                if (t.hasOwnProperty(St) || t.finalize(), this.finalized = !0, this._ensureClassProperties(), this._attributeToPropertyMap = new Map, this.hasOwnProperty(JSCompiler_renameProperty("properties", this))) {
                                    var e, n = this.properties,
                                        r = M([].concat(U(Object.getOwnPropertyNames(n)), U("function" == typeof Object.getOwnPropertySymbols ? Object.getOwnPropertySymbols(n) : [])));
                                    try {
                                        for (r.s(); !(e = r.n()).done;) {
                                            var o = e.value;
                                            this.createProperty(o, n[o])
                                        }
                                    } catch (t) {
                                        r.e(t)
                                    } finally {
                                        r.f()
                                    }
                                }
                            }
                        }, {
                            key: "_attributeNameForProperty",
                            value: function(t, e) {
                                var n = e.attribute;
                                return !1 === n ? void 0 : "string" == typeof n ? n : "string" == typeof t ? t.toLowerCase() : void 0
                            }
                        }, {
                            key: "_valueHasChanged",
                            value: function(t, e) {
                                return (arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : wt)(t, e)
                            }
                        }, {
                            key: "_propertyValueFromAttribute",
                            value: function(t, e) {
                                var n = e.type,
                                    r = e.converter || bt,
                                    o = "function" == typeof r ? r : r.fromAttribute;
                                return o ? o(t, n) : t
                            }
                        }, {
                            key: "_propertyValueToAttribute",
                            value: function(t, e) {
                                if (void 0 !== e.reflect) {
                                    var n = e.type,
                                        r = e.converter;
                                    return (r && r.toAttribute || bt.toAttribute)(t, n)
                                }
                            }
                        }]), o
                    }(yt(HTMLElement));
                Ct.finalized = !0;
                var Nt = function(t) {
                    return function(e) {
                        return "function" == typeof e ? function(t, e) {
                            return window.customElements.define(t, e), e
                        }(t, e) : function(t, e) {
                            return {
                                kind: e.kind,
                                elements: e.elements,
                                finisher: function(e) {
                                    window.customElements.define(t, e)
                                }
                            }
                        }(t, e)
                    }
                };

                function xt(t) {
                    return function(e, n) {
                        return void 0 !== n ? function(t, e, n) {
                            e.constructor.createProperty(n, t)
                        }(t, e, n) : function(t, e) {
                            return "method" === e.kind && e.descriptor && !("value" in e.descriptor) ? Object.assign(Object.assign({}, e), {
                                finisher: function(n) {
                                    n.createProperty(e.key, t)
                                }
                            }) : {
                                kind: "field",
                                key: Symbol(),
                                placement: "own",
                                descriptor: {},
                                initializer: function() {
                                    "function" == typeof e.initializer && (this[e.key] = e.initializer.call(this))
                                },
                                finisher: function(n) {
                                    n.createProperty(e.key, t)
                                }
                            }
                        }(t, e)
                    }
                }

                function Tt(t) {
                    return xt({
                        attribute: !1,
                        hasChanged: null == t ? void 0 : t.hasChanged
                    })
                }
                var Ot = function(t) {
                    return Tt(t)
                };

                function kt(t, e) {
                    return function(n, r) {
                        var o = {
                            get: function() {
                                return this.renderRoot.querySelector(t)
                            },
                            enumerable: !0,
                            configurable: !0
                        };
                        if (e) {
                            var i = void 0 !== r ? r : n.key,
                                a = "symbol" === v(i) ? Symbol() : "__".concat(i);
                            o.get = function() {
                                return void 0 === this[a] && (this[a] = this.renderRoot.querySelector(t)), this[a]
                            }
                        }
                        return void 0 !== r ? At(o, n, r) : Mt(o, n)
                    }
                }

                function Pt(t) {
                    return function(e, n) {
                        var r = {
                            get: function() {
                                var e = this;
                                return vt(gt.a.mark((function n() {
                                    return gt.a.wrap((function(n) {
                                        for (;;) switch (n.prev = n.next) {
                                            case 0:
                                                return n.next = 2, e.updateComplete;
                                            case 2:
                                                return n.abrupt("return", e.renderRoot.querySelector(t));
                                            case 3:
                                            case "end":
                                                return n.stop()
                                        }
                                    }), n)
                                })))()
                            },
                            enumerable: !0,
                            configurable: !0
                        };
                        return void 0 !== n ? At(r, e, n) : Mt(r, e)
                    }
                }

                function Dt(t) {
                    return function(e, n) {
                        var r = {
                            get: function() {
                                return this.renderRoot.querySelectorAll(t)
                            },
                            enumerable: !0,
                            configurable: !0
                        };
                        return void 0 !== n ? At(r, e, n) : Mt(r, e)
                    }
                }
                var At = function(t, e, n) {
                        Object.defineProperty(e, n, t)
                    },
                    Mt = function(t, e) {
                        return {
                            kind: "method",
                            placement: "prototype",
                            key: e.key,
                            descriptor: t
                        }
                    };

                function jt(t) {
                    return function(e, n) {
                        return void 0 !== n ? function(t, e, n) {
                            Object.assign(e[n], t)
                        }(t, e, n) : function(t, e) {
                            return Object.assign(Object.assign({}, e), {
                                finisher: function(n) {
                                    Object.assign(n.prototype[e.key], t)
                                }
                            })
                        }(t, e)
                    }
                }
                var Lt = Element.prototype,
                    It = Lt.msMatchesSelector || Lt.webkitMatchesSelector;

                function Rt() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "",
                        e = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
                        n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "";
                    return function(r, o) {
                        var i = {
                            get: function() {
                                var r = "slot".concat(t ? "[name=".concat(t, "]") : ":not([name])"),
                                    o = this.renderRoot.querySelector(r),
                                    i = o && o.assignedNodes({
                                        flatten: e
                                    });
                                return i && n && (i = i.filter((function(t) {
                                    return t.nodeType === Node.ELEMENT_NODE && (t.matches ? t.matches(n) : It.call(t, n))
                                }))), i
                            },
                            enumerable: !0,
                            configurable: !0
                        };
                        return void 0 !== o ? At(i, r, o) : Mt(i, r)
                    }
                }
                var Ft = window.ShadowRoot && (void 0 === window.ShadyCSS || window.ShadyCSS.nativeShadow) && "adoptedStyleSheets" in Document.prototype && "replace" in CSSStyleSheet.prototype,
                    Ut = Symbol(),
                    Bt = function() {
                        function t(e, n) {
                            if (r(this, t), n !== Ut) throw new Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");
                            this.cssText = e
                        }
                        return i(t, [{
                            key: "styleSheet",
                            get: function() {
                                return void 0 === this._styleSheet && (Ft ? (this._styleSheet = new CSSStyleSheet, this._styleSheet.replaceSync(this.cssText)) : this._styleSheet = null), this._styleSheet
                            }
                        }, {
                            key: "toString",
                            value: function() {
                                return this.cssText
                            }
                        }]), t
                    }(),
                    Ht = function(t) {
                        return new Bt(String(t), Ut)
                    },
                    Zt = function(t) {
                        if (t instanceof Bt) return t.cssText;
                        if ("number" == typeof t) return t;
                        throw new Error("Value passed to 'css' function must be a 'css' function result: ".concat(t, ". Use 'unsafeCSS' to pass non-literal values, but\n            take care to ensure page security."))
                    },
                    Vt = function(t) {
                        for (var e = arguments.length, n = new Array(e > 1 ? e - 1 : 0), r = 1; r < e; r++) n[r - 1] = arguments[r];
                        var o = n.reduce((function(e, n, r) {
                            return e + Zt(n) + t[r + 1]
                        }), t[0]);
                        return new Bt(o, Ut)
                    };
                (window.litElementVersions || (window.litElementVersions = [])).push("2.5.1");
                var Wt = {},
                    qt = function(t) {
                        u(n, t);
                        var e = p(n);

                        function n() {
                            return r(this, n), e.apply(this, arguments)
                        }
                        return i(n, [{
                            key: "initialize",
                            value: function() {
                                s(a(n.prototype), "initialize", this).call(this), this.constructor._getUniqueStyles(), this.renderRoot = this.createRenderRoot(), window.ShadowRoot && this.renderRoot instanceof window.ShadowRoot && this.adoptStyles()
                            }
                        }, {
                            key: "createRenderRoot",
                            value: function() {
                                return this.attachShadow(this.constructor.shadowRootOptions)
                            }
                        }, {
                            key: "adoptStyles",
                            value: function() {
                                var t = this.constructor._styles;
                                0 !== t.length && (void 0 === window.ShadyCSS || window.ShadyCSS.nativeShadow ? Ft ? this.renderRoot.adoptedStyleSheets = t.map((function(t) {
                                    return t instanceof CSSStyleSheet ? t : t.styleSheet
                                })) : this._needsShimAdoptedStyleSheets = !0 : window.ShadyCSS.ScopingShim.prepareAdoptedCssText(t.map((function(t) {
                                    return t.cssText
                                })), this.localName))
                            }
                        }, {
                            key: "connectedCallback",
                            value: function() {
                                s(a(n.prototype), "connectedCallback", this).call(this), this.hasUpdated && void 0 !== window.ShadyCSS && window.ShadyCSS.styleElement(this)
                            }
                        }, {
                            key: "update",
                            value: function(t) {
                                var e = this,
                                    r = this.render();
                                s(a(n.prototype), "update", this).call(this, t), r !== Wt && this.constructor.render(r, this.renderRoot, {
                                    scopeName: this.localName,
                                    eventContext: this
                                }), this._needsShimAdoptedStyleSheets && (this._needsShimAdoptedStyleSheets = !1, this.constructor._styles.forEach((function(t) {
                                    var n = document.createElement("style");
                                    n.textContent = t.cssText, e.renderRoot.appendChild(n)
                                })))
                            }
                        }, {
                            key: "render",
                            value: function() {
                                return Wt
                            }
                        }], [{
                            key: "getStyles",
                            value: function() {
                                return this.styles
                            }
                        }, {
                            key: "_getUniqueStyles",
                            value: function() {
                                if (!this.hasOwnProperty(JSCompiler_renameProperty("_styles", this))) {
                                    var t = this.getStyles();
                                    if (Array.isArray(t)) {
                                        var e = function t(e, n) {
                                                return e.reduceRight((function(e, n) {
                                                    return Array.isArray(n) ? t(n, e) : (e.add(n), e)
                                                }), n)
                                            }(t, new Set),
                                            n = [];
                                        e.forEach((function(t) {
                                            return n.unshift(t)
                                        })), this._styles = n
                                    } else this._styles = void 0 === t ? [] : [t];
                                    this._styles = this._styles.map((function(t) {
                                        if (t instanceof CSSStyleSheet && !Ft) {
                                            var e = Array.prototype.slice.call(t.cssRules).reduce((function(t, e) {
                                                return t + e.cssText
                                            }), "");
                                            return Ht(e)
                                        }
                                        return t
                                    }))
                                }
                            }
                        }]), n
                    }(Ct);
                qt.finalized = !0, qt.render = function(t, e, n) {
                    if (!n || "object" !== v(n) || !n.scopeName) throw new Error("The `scopeName` option is required.");
                    var r = n.scopeName,
                        o = ot.has(e),
                        i = ut && 11 === e.nodeType && !!e.host,
                        a = i && !ht.has(r),
                        s = a ? document.createDocumentFragment() : e;
                    if (function(t, e, n) {
                            var r = ot.get(e);
                            void 0 === r && (y(e, e.firstChild), ot.set(e, r = new K(Object.assign({
                                templateFactory: nt
                            }, n))), r.appendInto(e)), r.setValue(t), r.commit()
                        }(t, s, Object.assign({
                            templateFactory: ct(r)
                        }, n)), a) {
                        var l = ot.get(s);
                        ot.delete(s);
                        var u = l.value instanceof B ? l.value.template : void 0;
                        ft(r, s, u), y(e, e.firstChild), e.appendChild(s), ot.set(e, l)
                    }!o && i && window.ShadyCSS.styleElement(e.host)
                }, qt.shadowRootOptions = {
                    mode: "open"
                };
                var zt = new WeakMap,
                    Gt = L((function(t) {
                        return function(e) {
                            if (!(e instanceof X) || e instanceof $ || "style" !== e.committer.name || e.committer.parts.length > 1) throw new Error("The `styleMap` directive must be used in the style attribute and must be the only part in the attribute.");
                            var n = e.committer,
                                r = n.element.style,
                                o = zt.get(e);
                            for (var i in void 0 === o && (r.cssText = n.strings.join(" "), zt.set(e, o = new Set)), o.forEach((function(e) {
                                    e in t || (o.delete(e), -1 === e.indexOf("-") ? r[e] = null : r.removeProperty(e))
                                })), t) o.add(i), -1 === i.indexOf("-") ? r[i] = t[i] : r.setProperty(i, t[i])
                        }
                    })),
                    Xt = new WeakMap,
                    Kt = L((function(t) {
                        return function(e) {
                            if (!(e instanceof K)) throw new Error("unsafeHTML can only be used in text bindings");
                            var n = Xt.get(e);
                            if (void 0 === n || !q(t) || t !== n.value || e.value !== n.fragment) {
                                var r = document.createElement("template");
                                r.innerHTML = t;
                                var o = document.importNode(r.content, !0);
                                e.setValue(o), Xt.set(e, {
                                    value: t,
                                    fragment: o
                                })
                            }
                        }
                    }))
            }])
        },
        12463: function(t, e, n) {
            "use strict";
            n(6164), n(64065), n(95082)
        },
        95082: function(t, e, n) {
            "use strict";
            n.d(e, {
                r: function() {
                    return f
                }
            });
            var r = n(61569),
                o = n(6164),
                i = n.n(o),
                a = n(64065);

            function s() {
                return !!self.document && "string" == typeof self.document.cookie
            }

            function l(t, e) {
                var n = t + "csrftoken",
                    r = function(t) {
                        if (s()) {
                            var e = new RegExp("(?:^|;\\s?)".concat(t, "=([^;$]+)")).exec(self.document.cookie || "");
                            return e ? e[1] : void 0
                        }
                    }(n);
                return r || function(t, e, n, r) {
                    if (s()) {
                        var o = "".concat(t, "=").concat(e, ";");
                        if (n) {
                            var i = new Date;
                            i.setTime(i.getTime() + 24 * n * 60 * 60 * 1e3), o += "expires=".concat(i.toUTCString(), ";")
                        }
                        o += "path=/;", r && (o += "domain=".concat(r, ";")), self.document.cookie = o
                    }
                }(n, r = function(t) {
                    for (var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789", n = "", r = 0; r < t; r++) {
                        var o = Math.floor(Math.random() * e.length);
                        n += e.substring(o, o + 1)
                    }
                    return n
                }(32), 0, e), r
            }
            var u = {
                    data: {
                        space_banners: [{
                            space_key: "1-SG-Home Carousel-1",
                            ratio: 1.875,
                            banners: [{
                                banner_metadata: {
                                    banner_id: 100,
                                    campaign_unit_id: 1,
                                    slot_id: 1
                                },
                                image_url: "https://cf.shopee.sg/file/3c6f8ff3d865b5c71b1090385e7b5f4d",
                                image_hash: "3c6f8ff3d865b5c71b1090385e7b5f4d",
                                target_url: "https://shopee.sg/m/tech-showdown"
                            }, {
                                banner_metadata: {
                                    banner_id: 101,
                                    campaign_unit_id: 2,
                                    slot_id: 2
                                },
                                image_url: "https://cf.shopee.sg/file/ca9152d3335b2a1e627d2ca0dbdabd70",
                                image_hash: "ca9152d3335b2a1e627d2ca0dbdabd70",
                                target_url: "https://shopee.sg/m/tech-showdown"
                            }, {
                                banner_metadata: {
                                    banner_id: 100,
                                    campaign_unit_id: 1,
                                    slot_id: 1
                                },
                                image_url: "https://cf.shopee.sg/file/3c6f8ff3d865b5c71b1090385e7b5f4d",
                                image_hash: "3c6f8ff3d865b5c71b1090385e7b5f4d",
                                target_url: "https://shopee.sg/m/tech-showdown"
                            }]
                        }]
                    }
                },
                c = !!window.__STORYBOOK_ADDONS,
                d = function() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 200;
                    return new Promise((function(e) {
                        setTimeout((function() {
                            e({
                                ok: !0,
                                json: function() {
                                    return Promise.resolve(u)
                                }
                            })
                        }), t)
                    }))
                },
                h = function(t) {
                    return t.map((function(t) {
                        var e = {
                            space_key: t.space_key
                        };
                        return t.space_filter && (e.space_filter = Object.keys(t.space_filter).map((function(e) {
                            return {
                                key: e,
                                value: t.space_filter[e]
                            }
                        }))), e
                    }))
                };

            function f() {
                return p.apply(this, arguments)
            }

            function p() {
                return (p = (0, r.Z)(i().mark((function t(e, n) {
                    var o, s, u, f, p;
                    return i().wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                if (!c) {
                                    t.next = 8;
                                    break
                                }
                                return t.next = 3, d();
                            case 3:
                                return o = t.sent, t.next = 6, o.json();
                            case 6:
                                return t.t0 = t.sent, t.abrupt("return", {
                                    response: t.t0
                                });
                            case 8:
                                return s = h(e), u = {
                                    spaces: s
                                }, f = JSON.stringify(u), p = l(""), t.abrupt("return", fetch((n || "") + a.bj.URL_GET_BANNER_BY_SPACE, {
                                    method: "post",
                                    credentials: "include",
                                    headers: {
                                        "Content-Type": "application/json",
                                        Accept: "application/json",
                                        "X-CSRFToken": p
                                    },
                                    body: f
                                }).then(function() {
                                    var t = (0, r.Z)(i().mark((function t(e) {
                                        var n;
                                        return i().wrap((function(t) {
                                            for (;;) switch (t.prev = t.next) {
                                                case 0:
                                                    return t.next = 2, e.json();
                                                case 2:
                                                    return n = t.sent, t.abrupt("return", new Promise((function(t) {
                                                        t({
                                                            response: n
                                                        })
                                                    })));
                                                case 4:
                                                case "end":
                                                    return t.stop()
                                            }
                                        }), t)
                                    })));
                                    return function() {
                                        return t.apply(this, arguments)
                                    }
                                }()).catch((function(t) {
                                    return new Promise((function(e) {
                                        e({
                                            error: t
                                        })
                                    }))
                                })));
                            case 13:
                            case "end":
                                return t.stop()
                        }
                    }), t)
                })))).apply(this, arguments)
            }
        },
        64065: function(t, e, n) {
            "use strict";
            n.d(e, {
                KW: function() {
                    return r
                },
                bj: function() {
                    return o
                }
            });
            var r = {
                    UPDATE_DATA: "UPDATE_DATA",
                    UPDATE_BANNER_FETCHING_STATUS: "UPDATE_BANNER_FETCHING_STATUS"
                },
                o = {
                    URL_GET_BANNER_BY_SPACE: "/api/v4/banner/batch_list_by_spaces"
                }
        },
        15874: function(t, e, n) {
            "use strict";
            n.d(e, {
                fetchBannerDataApi: function() {
                    return o.r
                }
            });
            n(12463), n(15077);
            var r = n(75933);
            n.o(r, "fetchBannerDataApi") && n.d(e, {
                fetchBannerDataApi: function() {
                    return r.fetchBannerDataApi
                }
            });
            var o = n(95082);
            n(21057), n(64065)
        },
        21057: function(t, e, n) {
            "use strict";
            n.d(e, {
                S: function() {
                    return a
                }
            });
            var r = n(56433),
                o = n(64065),
                i = {
                    bannersData: {}
                };

            function a() {
                var t, e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : i,
                    n = arguments.length > 1 ? arguments[1] : void 0;
                switch (n.type) {
                    case o.KW.UPDATE_DATA:
                        var a = {};
                        return null == n || null === (t = n.payload) || void 0 === t || t.filter(Boolean).forEach((function(t) {
                            a[t.space_key] = t
                        })), (0, r.Z)((0, r.Z)({}, e), {}, {
                            bannersData: (0, r.Z)((0, r.Z)({}, e.bannersData), a)
                        });
                    case o.KW.UPDATE_BANNER_FETCHING_STATUS:
                        for (var s = n.payload, l = s.space_keys, u = (0, r.Z)({}, e.bannersData), c = 0; c < l.length; c++) {
                            var d = l[c] || "";
                            u[d] || (u[d] = {
                                space_key: d,
                                banners: []
                            }), u[d].status = s.status
                        }
                        return (0, r.Z)((0, r.Z)({}, e), {}, {
                            bannersData: u
                        });
                    default:
                        return e
                }
            }
        },
        15077: function(t, e, n) {
            "use strict";
            var r = n(41693),
                o = n(29591),
                i = n(77822),
                a = n(21057),
                s = ("object" === ("undefined" == typeof window ? "undefined" : (0, r.Z)(window)) && window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ ? window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__({}) : o.qC)((0, o.md)(i.Z)),
                l = (0, o.UY)({
                    banner: a.S
                });
            (0, o.MT)(l, s)
        },
        75933: function() {},
        67205: function(t, e, n) {
            "use strict";
            n.d(e, {
                ZJ: function() {
                    return qe
                }
            });
            n(19271);
            var r = n(41693),
                o = n(56433),
                i = n(28856);

            function a(t, e) {
                (null == e || e > t.length) && (e = t.length);
                for (var n = 0, r = new Array(e); n < e; n++) r[n] = t[n];
                return r
            }

            function s(t, e) {
                if (t) {
                    if ("string" == typeof t) return a(t, e);
                    var n = Object.prototype.toString.call(t).slice(8, -1);
                    return "Object" === n && t.constructor && (n = t.constructor.name), "Map" === n || "Set" === n ? Array.from(t) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? a(t, e) : void 0
                }
            }

            function l(t, e) {
                return function(t) {
                    if (Array.isArray(t)) return t
                }(t) || function(t, e) {
                    if ("undefined" != typeof Symbol && Symbol.iterator in Object(t)) {
                        var n = [],
                            r = !0,
                            o = !1,
                            i = void 0;
                        try {
                            for (var a, s = t[Symbol.iterator](); !(r = (a = s.next()).done) && (n.push(a.value), !e || n.length !== e); r = !0);
                        } catch (t) {
                            o = !0, i = t
                        } finally {
                            try {
                                r || null == s.return || s.return()
                            } finally {
                                if (o) throw i
                            }
                        }
                        return n
                    }
                }(t, e) || s(t, e) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function u(t, e) {
                for (var n = 0; n < e.length; n++) {
                    var r = e[n];
                    r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                }
            }

            function c(t, e, n) {
                return e && u(t.prototype, e), n && u(t, n), t
            }

            function d(t, e) {
                return (d = Object.setPrototypeOf || function(t, e) {
                    return t.__proto__ = e, t
                })(t, e)
            }

            function h(t, e) {
                if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function");
                t.prototype = Object.create(e && e.prototype, {
                    constructor: {
                        value: t,
                        writable: !0,
                        configurable: !0
                    }
                }), e && d(t, e)
            }

            function f(t) {
                return (f = Object.setPrototypeOf ? Object.getPrototypeOf : function(t) {
                    return t.__proto__ || Object.getPrototypeOf(t)
                })(t)
            }

            function p(t) {
                if (void 0 === t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                return t
            }

            function v(t, e) {
                return !e || "object" !== (0, r.Z)(e) && "function" != typeof e ? p(t) : e
            }

            function m(t) {
                var e = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Date.prototype.toString.call(Reflect.construct(Date, [], (function() {}))), !0
                    } catch (t) {
                        return !1
                    }
                }();
                return function() {
                    var n, r = f(t);
                    if (e) {
                        var o = f(this).constructor;
                        n = Reflect.construct(r, arguments, o)
                    } else n = r.apply(this, arguments);
                    return v(this, n)
                }
            }

            function y(t, e) {
                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
            }
            var _ = function(t) {
                var e = t.includeJSBuiltIns,
                    n = void 0 !== e && e,
                    r = t.props,
                    a = void 0 === r ? {} : r,
                    s = new WeakMap,
                    u = function(t) {
                        var e = s.get(t);
                        return e || s.set(t, e = new Map), e
                    },
                    d = function t() {
                        y(this, t)
                    },
                    f = function(t) {
                        h(n, t);
                        var e = m(n);

                        function n() {
                            return y(this, n), e.apply(this, arguments)
                        }
                        return c(n, [{
                            key: "attributes",
                            get: function() {
                                return Array.from(u(this)).map((function(t) {
                                    var e = l(t, 2);
                                    return {
                                        name: e[0],
                                        value: e[1]
                                    }
                                }))
                            }
                        }, {
                            key: "setAttribute",
                            value: function(t, e) {
                                u(this).set(t, e)
                            }
                        }, {
                            key: "removeAttribute",
                            value: function(t) {
                                u(this).delete(t)
                            }
                        }, {
                            key: "hasAttribute",
                            value: function(t) {
                                return u(this).has(t)
                            }
                        }, {
                            key: "attachShadow",
                            value: function() {
                                return {
                                    host: this
                                }
                            }
                        }, {
                            key: "getAttribute",
                            value: function(t) {
                                var e = u(this).get(t);
                                return void 0 === e ? null : e
                            }
                        }]), n
                    }(d),
                    p = function() {
                        function t() {
                            y(this, t)
                        }
                        return c(t, [{
                            key: "adoptedStyleSheets",
                            get: function() {
                                return []
                            }
                        }, {
                            key: "createTreeWalker",
                            value: function() {
                                return {}
                            }
                        }, {
                            key: "createTextNode",
                            value: function() {
                                return {}
                            }
                        }, {
                            key: "createElement",
                            value: function() {
                                return {}
                            }
                        }]), t
                    }(),
                    v = function() {
                        function t() {
                            y(this, t)
                        }
                        return c(t, [{
                            key: "replace",
                            value: function() {}
                        }]), t
                    }(),
                    _ = function() {
                        function t() {
                            y(this, t), (0, i.Z)(this, "__definitions", new Map)
                        }
                        return c(t, [{
                            key: "define",
                            value: function(t, e) {
                                var n;
                                this.__definitions.set(t, {
                                    ctor: e,
                                    observedAttributes: null !== (n = e.observedAttributes) && void 0 !== n ? n : []
                                })
                            }
                        }, {
                            key: "get",
                            value: function(t) {
                                var e = this.__definitions.get(t);
                                return e && e.ctor
                            }
                        }]), t
                    }(),
                    g = (0, o.Z)({
                        Element: d,
                        HTMLElement: f,
                        Document: p,
                        document: new p,
                        CSSStyleSheet: v,
                        ShadowRoot: function t() {
                            y(this, t)
                        },
                        CustomElementRegistry: _,
                        customElements: new _,
                        JSCompiler_renameProperty: function(t) {
                            return t
                        },
                        btoa: function(t) {
                            return Buffer.from(t, "binary").toString("base64")
                        },
                        location: new URL("http://localhost"),
                        MutationObserver: function() {
                            function t() {
                                y(this, t)
                            }
                            return c(t, [{
                                key: "observe",
                                value: function() {}
                            }]), t
                        }(),
                        requestAnimationFrame: function() {},
                        window: void 0,
                        global: void 0
                    }, a);
                return g.window = g, g.global = g, n && Object.assign(g, {
                    setTimeout: function() {},
                    clearTimeout: function() {},
                    Buffer: Buffer,
                    console: {
                        log: function() {
                            var t;
                            (t = console).log.apply(t, arguments)
                        },
                        info: function() {
                            var t;
                            (t = console).info.apply(t, arguments)
                        },
                        warn: function() {
                            var t;
                            (t = console).warn.apply(t, arguments)
                        },
                        debug: function() {
                            var t;
                            (t = console).debug.apply(t, arguments)
                        },
                        error: function() {
                            var t;
                            (t = console).error.apply(t, arguments)
                        },
                        assert: function(t, e) {
                            if (!t) throw new Error(e)
                        }
                    }
                }), g
            };
            "object" === ("undefined" == typeof process ? "undefined" : (0, r.Z)(process)) && "object" === (0, r.Z)(process.versions) && void 0 !== process.versions.node && function() {
                var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                if (void 0 === globalThis.window) {
                    var e = _({
                        props: t
                    });
                    e.window = new Proxy(e, {
                        set: function(t, n, r) {
                            return e[n] = globalThis[n] = r, !0
                        }
                    }), Object.assign(globalThis, e)
                }
            }();
            n(75963);

            function g(t, e, n) {
                return (g = "undefined" != typeof Reflect && Reflect.get ? Reflect.get : function(t, e, n) {
                    var r = function(t, e) {
                        for (; !Object.prototype.hasOwnProperty.call(t, e) && null !== (t = f(t)););
                        return t
                    }(t, e);
                    if (r) {
                        var o = Object.getOwnPropertyDescriptor(r, e);
                        return o.get ? o.get.call(n) : o.value
                    }
                })(t, e, n || t)
            }
            var b = {
                    connectedCallback: function() {
                        this.mixinExistingConnectedCallback && this.mixinExistingConnectedCallback(), this.mixinConnectState()
                    }
                },
                w = {
                    disconnectedCallback: function() {
                        this.mixinExistingDisconnectedCallback && this.mixinExistingDisconnectedCallback(), this.mixinDisconnectState()
                    }
                },
                E = {
                    mixinStore: null,
                    mixinState: void 0,
                    mixinUnsubscribeStore: null,
                    mixinExistingConnectedCallback: null,
                    mixinExistingDisconnectedCallback: null,
                    mixinConnectState: function() {
                        if (this.mapDispatchToProps) {
                            var t = this.mapDispatchToProps(this.mixinStore.dispatch);
                            if (t)
                                for (var e in t) this[e] = t[e]
                        }
                        var n = this.mixinStore.getState();
                        this.mapStateToProps && this.mapStateToProps(this.mixinState, n), this.mixinState = n, this.mixinOnStateChange = this.mixinOnStateChange.bind(this), this.mixinUnsubscribeStore = this.mixinStore.subscribe(this.mixinOnStateChange)
                    },
                    mixinDisconnectState: function() {
                        this.mixinUnsubscribeStore && (this.mixinUnsubscribeStore(), this.mixinUnsubscribeStore = null)
                    },
                    mixinOnStateChange: function() {
                        var t = this.mixinStore.getState();
                        t !== this.mixinState && (this.mapStateToProps && this.mapStateToProps(this.mixinState, t), this.mixinState = t)
                    }
                };
            var S = "";
            var C = n(29591),
                N = n(61569),
                x = n(6164),
                T = n.n(x),
                O = "UPDATE_DATA",
                k = "UPDATE_BANNER_FETCHING_STATUS",
                P = "/api/v4/banner/batch_list_by_spaces",
                D = "REQUESTED",
                A = "FAILED",
                M = "SUCCESS";

            function j() {
                return !!self.document && "string" == typeof self.document.cookie
            }

            function L(t, e) {
                var n = t + "csrftoken",
                    r = function(t) {
                        if (j()) {
                            var e = new RegExp("(?:^|;\\s?)".concat(t, "=([^;$]+)")).exec(self.document.cookie || "");
                            return e ? e[1] : void 0
                        }
                    }(n);
                return r || function(t, e, n, r) {
                    if (j()) {
                        var o = "".concat(t, "=").concat(e, ";");
                        if (n) {
                            var i = new Date;
                            i.setTime(i.getTime() + 24 * n * 60 * 60 * 1e3), o += "expires=".concat(i.toUTCString(), ";")
                        }
                        o += "path=/;", r && (o += "domain=".concat(r, ";")), self.document.cookie = o
                    }
                }(n, r = function(t) {
                    for (var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789", n = "", r = 0; r < t; r++) {
                        var o = Math.floor(Math.random() * e.length);
                        n += e.substring(o, o + 1)
                    }
                    return n
                }(32), 0, e), r
            }
            var I = {
                    data: {
                        space_banners: [{
                            space_key: "1-SG-Home Carousel-1",
                            ratio: 1.875,
                            banners: [{
                                banner_metadata: {
                                    banner_id: 100,
                                    campaign_unit_id: 1,
                                    slot_id: 1
                                },
                                image_url: "https://cf.shopee.sg/file/3c6f8ff3d865b5c71b1090385e7b5f4d",
                                image_hash: "3c6f8ff3d865b5c71b1090385e7b5f4d",
                                target_url: "https://shopee.sg/m/tech-showdown"
                            }, {
                                banner_metadata: {
                                    banner_id: 101,
                                    campaign_unit_id: 2,
                                    slot_id: 2
                                },
                                image_url: "https://cf.shopee.sg/file/ca9152d3335b2a1e627d2ca0dbdabd70",
                                image_hash: "ca9152d3335b2a1e627d2ca0dbdabd70",
                                target_url: "https://shopee.sg/m/tech-showdown"
                            }, {
                                banner_metadata: {
                                    banner_id: 100,
                                    campaign_unit_id: 1,
                                    slot_id: 1
                                },
                                image_url: "https://cf.shopee.sg/file/3c6f8ff3d865b5c71b1090385e7b5f4d",
                                image_hash: "3c6f8ff3d865b5c71b1090385e7b5f4d",
                                target_url: "https://shopee.sg/m/tech-showdown"
                            }]
                        }]
                    }
                },
                R = !!window.__STORYBOOK_ADDONS,
                F = function() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 200;
                    return new Promise((function(e) {
                        setTimeout((function() {
                            e({
                                ok: !0,
                                json: function() {
                                    return Promise.resolve(I)
                                }
                            })
                        }), t)
                    }))
                },
                U = function(t) {
                    return t.map((function(t) {
                        var e = {
                            space_key: t.space_key
                        };
                        return t.space_filter && (e.space_filter = Object.keys(t.space_filter).map((function(e) {
                            return {
                                key: e,
                                value: t.space_filter[e]
                            }
                        }))), e
                    }))
                };

            function B() {
                return H.apply(this, arguments)
            }

            function H() {
                return (H = (0, N.Z)(T().mark((function t(e, n) {
                    var r, o, i, a, s;
                    return T().wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                if (!R) {
                                    t.next = 9;
                                    break
                                }
                                return t.next = 3, F();
                            case 3:
                                return r = t.sent, t.next = 6, r.json();
                            case 6:
                                return t.t0 = t.sent, t.t1 = r.json, t.abrupt("return", {
                                    response: t.t0,
                                    json: t.t1
                                });
                            case 9:
                                return o = U(e), i = {
                                    spaces: o
                                }, a = JSON.stringify(i), s = L(""), t.abrupt("return", fetch((n || "") + P, {
                                    method: "post",
                                    credentials: "include",
                                    headers: {
                                        "Content-Type": "application/json",
                                        Accept: "application/json",
                                        "X-CSRFToken": s
                                    },
                                    body: a
                                }).then(function() {
                                    var t = (0, N.Z)(T().mark((function t(e) {
                                        var n;
                                        return T().wrap((function(t) {
                                            for (;;) switch (t.prev = t.next) {
                                                case 0:
                                                    return t.next = 2, e.json();
                                                case 2:
                                                    return n = t.sent, t.abrupt("return", new Promise((function(t) {
                                                        t({
                                                            response: n
                                                        })
                                                    })));
                                                case 4:
                                                case "end":
                                                    return t.stop()
                                            }
                                        }), t)
                                    })));
                                    return function() {
                                        return t.apply(this, arguments)
                                    }
                                }()).catch((function(t) {
                                    return new Promise((function(e) {
                                        e({
                                            error: t
                                        })
                                    }))
                                })));
                            case 14:
                            case "end":
                                return t.stop()
                        }
                    }), t)
                })))).apply(this, arguments)
            }

            function Z(t, e, n, r) {
                var o = t ? t.map((function(t) {
                    return t.space_key
                })) : [];
                return function() {
                    var i = (0, N.Z)(T().mark((function i(a) {
                        var s, l, u, c, d;
                        return T().wrap((function(i) {
                            for (;;) switch (i.prev = i.next) {
                                case 0:
                                    return s = r || B, a(V(o, D)), i.next = 4, s(t, n);
                                case 4:
                                    l = i.sent, u = l.response, (c = l.error) ? (a(V(o, A)), null == e || e("ERROR", c)) : (a((h = null == u || null === (d = u.data) || void 0 === d ? void 0 : d.space_banners, {
                                        type: O,
                                        payload: h
                                    })), a(V(o, M)), null == e || e("LOAD", u));
                                case 8:
                                case "end":
                                    return i.stop()
                            }
                            var h
                        }), i)
                    })));
                    return function() {
                        return i.apply(this, arguments)
                    }
                }()
            }

            function V(t, e) {
                return {
                    type: k,
                    payload: {
                        space_keys: t,
                        status: e
                    }
                }
            }
            var W = n(77822),
                q = {
                    bannersData: {}
                };
            var z = ("object" === ("undefined" == typeof window ? "undefined" : (0, r.Z)(window)) && window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ ? window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__({}) : C.qC)((0, C.md)(W.Z)),
                G = (0, C.UY)({
                    banner: function() {
                        var t, e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : q,
                            n = arguments.length > 1 ? arguments[1] : void 0;
                        switch (n.type) {
                            case O:
                                var r = {};
                                return null == n || null === (t = n.payload) || void 0 === t || t.filter(Boolean).forEach((function(t) {
                                    r[t.space_key] = t
                                })), (0, o.Z)((0, o.Z)({}, e), {}, {
                                    bannersData: (0, o.Z)((0, o.Z)({}, e.bannersData), r)
                                });
                            case k:
                                for (var i = n.payload, a = i.space_keys, s = (0, o.Z)({}, e.bannersData), l = 0; l < a.length; l++) {
                                    var u = a[l] || "";
                                    s[u] || (s[u] = {
                                        space_key: u,
                                        banners: []
                                    }), s[u].status = i.status
                                }
                                return (0, o.Z)((0, o.Z)({}, e), {}, {
                                    bannersData: s
                                });
                            default:
                                return e
                        }
                    }
                }),
                X = (0, C.MT)(G, z);

            function K(t, e) {
                return (null == t ? void 0 : t.bannersData[e]) || {}
            }

            function Y(t) {
                return function(t) {
                    if (Array.isArray(t)) return a(t)
                }(t) || function(t) {
                    if ("undefined" != typeof Symbol && Symbol.iterator in Object(t)) return Array.from(t)
                }(t) || s(t) || function() {
                    throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }
            var J, $, Q, tt, et, nt, rt, ot = n(80155),
                it = function(t) {
                    h(n, t);
                    var e = m(n);

                    function n() {
                        var t;
                        return y(this, n), t = e.call(this), (0, i.Z)(p(t), "baseUrl", void 0), (0, i.Z)(p(t), "status", void 0), (0, i.Z)(p(t), "spaceKey", void 0), (0, i.Z)(p(t), "spaceFilter", void 0), (0, i.Z)(p(t), "max", void 0), (0, i.Z)(p(t), "ratio", void 0), (0, i.Z)(p(t), "min", void 0), (0, i.Z)(p(t), "infinite", void 0), (0, i.Z)(p(t), "autoPlay", void 0), (0, i.Z)(p(t), "transitionTime", void 0), (0, i.Z)(p(t), "onChangeIndex", void 0), (0, i.Z)(p(t), "carouselPositionListener", void 0), (0, i.Z)(p(t), "autoScrollDuration", void 0), (0, i.Z)(p(t), "dots", void 0), (0, i.Z)(p(t), "useFallback", void 0), (0, i.Z)(p(t), "arrows", void 0), (0, i.Z)(p(t), "shouldOpenInNewWindow", void 0), (0, i.Z)(p(t), "onEventCallback", void 0), (0, i.Z)(p(t), "trackingConf", void 0), (0, i.Z)(p(t), "onClick", void 0), t.max = 100, t.spaceKey = "", t.min = 1, t.infinite = !0, t.transitionTime = 500, t.autoScrollDuration = 5e3, t.dots = !0, t.autoPlay = !0, t.arrows = !0, t.useFallback = !0, t.shouldOpenInNewWindow = !1, t.spaceFilter = {}, t.status = "", t.baseUrl = "", t
                    }
                    return c(n, null, [{
                        key: "properties",
                        get: function() {
                            return {
                                bannerData: {
                                    hasChanged: function() {
                                        return !0
                                    }
                                },
                                max: {
                                    converter: function(t) {
                                        return Number(t)
                                    }
                                },
                                spaceKey: {},
                                ratio: {},
                                min: {},
                                infinite: {
                                    hasChanged: function() {
                                        return !0
                                    }
                                },
                                autoPlay: {
                                    hasChanged: function() {
                                        return !0
                                    }
                                },
                                dots: {},
                                arrows: {},
                                autoScrollDuration: {},
                                shouldOpenInNewWindow: {},
                                trackingConf: {},
                                spaceFilter: {},
                                status: {},
                                useFallback: {},
                                baseUrl: {}
                            }
                        }
                    }]), n
                }(ot.LitElement);

            function at(t, e) {
                return e || (e = t.slice(0)), Object.freeze(Object.defineProperties(t, {
                    raw: {
                        value: Object.freeze(e)
                    }
                }))
            }

            function st(t) {
                var e = t.looping,
                    n = t.targetIndex,
                    r = t.bannerCount;
                return !e && (n < 0 || n >= r)
            }

            function lt(t) {
                var e, n = t.banners,
                    r = t.finalBanners,
                    i = t.onTrack,
                    a = t.ratio,
                    s = t.looping,
                    l = t.shouldOpenInNewWindow,
                    u = t.onClick,
                    c = t.trackingConf,
                    d = t.isSsr,
                    h = t.min;
                return "REQUESTED" === t.status ? (0, ot.html)(et || (et = at([' <div\n      style="padding-top: ', '%"\n    ></div>'])), t.ratio ? 100 / t.ratio : 0) : !n || n.length < h ? "" : d ? n && n.length ? '<div ><img style="width:100%" class="banner-image" src="'.concat(null === (e = n[0]) || void 0 === e ? void 0 : e.image_url, '"\n    /></a></div>') : "" : (0, ot.html)(nt || (nt = at(['\n    <div class="shopee-banner-carousel">\n      <div\n        class="stardust-carousel__item-list-wrapper"\n        style=', '\n      >\n        <ul\n          class="stardust-carousel__item-list"\n          style=', "\n        >\n          ", "\n        </ul>\n        ", " ", "\n      </div>\n    </div>\n  "])), (0, ot.styleMap)({
                    paddingTop: "".concat(100 / a, "%")
                }), (0, ot.styleMap)(function(t) {
                    var e = t.length,
                        n = t.looping,
                        r = t.ratio;
                    return {
                        width: "".concat(100 * (n ? e + 2 : e), "%"),
                        position: r ? "absolute" : "static"
                    }
                }({
                    length: n.length,
                    looping: s,
                    ratio: a
                })), r.map((function(t, e) {
                    return (0, ot.html)(rt || (rt = at(['<li\n              class="stardust-carousel__item"\n              style=', '\n            >\n              <div class="stardust-carousel__item-inner-wrapper">\n                <shopee-banner-simple\n                  .onTrack=', "\n                  .onClick=", "\n                  .bannerData=", "\n                  .trackingConf=", "\n                  .shouldOpenInNewWindow=", "\n                >\n                  <img src=", " />\n                </shopee-banner-simple>\n              </div>\n            </li>"])), (0, ot.styleMap)({
                        width: "".concat((r = {
                            length: n.length,
                            looping: s
                        }, a = r.length, 100 / (r.looping ? a + 2 : a)), "%"),
                        height: "100%"
                    }), i, u, (0, o.Z)((0, o.Z)({}, t), {}, {
                        index: e
                    }), c, l, t.image_url);
                    var r, a
                })), function(t) {
                    var e = t.banners,
                        n = t.looping,
                        r = t.activeIndex,
                        o = void 0 === r ? 0 : r,
                        i = t.dots,
                        a = t.onDotClick,
                        s = void 0 === a ? function() {} : a;
                    return i + "" != "true" || !e || e.length <= 1 ? "" : (0, ot.html)(J || (J = at(['<div class="stardust-carousel__dots">\n    ', "\n  </div>"])), i ? e.map((function(t, e) {
                        var r = n ? o === e + 1 : o === e;
                        return (0, ot.html)($ || ($ = at(["<div\n            .onclick=", '\n            class="stardust-carousel__dot ', '"\n          />'])), (function() {
                            s(e + 1)
                        }), r ? "stardust-carousel__dot--active" : "")
                    })) : "")
                }(t), function(t) {
                    var e = t.finalBanners,
                        n = t.banners,
                        r = t.looping,
                        o = t.activeIndex,
                        i = void 0 === o ? 0 : o,
                        a = t.dots,
                        s = t.arrows,
                        l = t.onArrowClick,
                        u = void 0 === l ? function() {} : l;
                    return a + "" != "true" || !n || n.length <= 1 ? "" : (0, ot.html)(Q || (Q = at(["", ""])), s ? (0, ot.html)(tt || (tt = at(["<div\n          .onclick=", '\n          class="stardust-carousel__arrow stardust-carousel__arrow--prev ', '"\n        >\n          <svg\n            enable-background="new 0 0 13 20"\n            viewBox="0 0 13 20"\n            class="stardust-icon stardust-icon-arrow-left-bold"\n          >\n            <path\n              stroke="none"\n              d="m4.2 10l7.9-7.9-2.1-2.2-9 9-1.1 1.1 1.1 1 9 9 2.1-2.1z"\n            ></path>\n          </svg>\n        </div>\n        <div\n          .onclick=', '\n          class="stardust-carousel__arrow stardust-carousel__arrow--next  ', '"\n        >\n          <svg\n            enable-background="new 0 0 13 21"\n            viewBox="0 0 13 21"\n            class="stardust-icon stardust-icon-arrow-right-bold"\n          >\n            <path\n              stroke="none"\n              d="m11.1 9.9l-9-9-2.2 2.2 8 7.9-8 7.9 2.2 2.1 9-9 1-1z"\n            ></path>\n          </svg>\n        </div>'])), (function() {
                        st({
                            looping: r,
                            targetIndex: i - 1,
                            bannerCount: e.length
                        }) || u(i - 1)
                    }), st({
                        looping: r,
                        targetIndex: i - 1,
                        bannerCount: e.length
                    }) ? "stardust-carousel__arrow--disabled" : "", (function() {
                        st({
                            looping: r,
                            targetIndex: i + 1,
                            bannerCount: e.length
                        }) || u(i + 1)
                    }), st({
                        looping: r,
                        targetIndex: i + 1,
                        bannerCount: e.length
                    }) ? "stardust-carousel__arrow--disabled" : "") : "")
                }(t))
            }
            var ut, ct = "requestIdleCallback" in window;

            function dt(t, e) {
                return ct ? window.requestIdleCallback(t, e) : setTimeout(t, 1)
            }

            function ht(t) {
                return ct ? window.cancelIdleCallback(t) : clearTimeout(t)
            }! function(t) {
                t.PC = "pc", t.RW = "rw"
            }(ut || (ut = {}));
            var ft, pt = ["Googlebot", "Baiduspider", "bingbot", "Yahoo", "coccocbot"],
                vt = ["Mobile"],
                mt = ["Windows NT", "Macintosh", "X11"];

            function yt(t, e) {
                return t.some((function(t) {
                    return e.includes(t)
                }))
            }

            function _t() {
                return (0, ot.css)(ft || (ft = at(["\n    .stardust-carousel {\n      width: 100%;\n      position: relative;\n      display: block;\n    }\n    .stardust-carousel__item-list-wrapper {\n      box-sizing: border-box;\n      overflow-x: hidden;\n      position: relative;\n      width: 100%;\n    }\n    .stardust-carousel__item-list {\n      top: 0;\n      left: 0;\n      bottom: 0;\n      right: 0;\n      display: flex;\n      padding: 0;\n      margin: 0;\n      overflow: hidden;\n      /* prevent vertical scroll when user is scrolling horizontally */\n      touch-action: pan-y;\n    }\n    .stardust-carousel__item {\n      flex-shrink: 0;\n      align-self: center;\n      list-style: none;\n      overflow: hidden;\n      display: flex;\n      justify-content: center;\n      align-items: center;\n    }\n    .stardust-carousel__item-inner-wrapper {\n      width: 100%;\n      height: 100%;\n    }\n    .shopee-sdk-banner-img {\n      width: 100%;\n    }\n    .stardust-carousel__item-inner-wrapper--hide {\n      display: none;\n    }\n    .shopee-banner-carousel:hover .stardust-carousel__arrow {\n      opacity: 1;\n    }\n\n    .stardust-carousel__dots {\n      position: absolute;\n      bottom: ", "px;\n      left: 50%;\n      transform: translate(-50%, 0%);\n      transition: opacity ease 0.5s;\n      width: 100%;\n      text-align: center;\n      font-size: 16px;\n    }\n    .stardust-carousel__dot {\n      width: 8px;\n      height: 8px;\n      border-radius: 50%;\n      display: inline-block;\n      cursor: pointer;\n      opacity: 1;\n      border: 1px solid rgba(137, 137, 137, 0.4);\n      background-color: rgba(255, 255, 255, 0.4);\n    }\n    .stardust-carousel__dot:not(:first-child) {\n      margin-left: 8px;\n    }\n    .stardust-carousel__dot--active {\n      opacity: 1;\n      background-color: #ee4d2d;\n      border-color: #ee4d2d;\n    }\n    .shopee-banner-carousel {\n      position: relative;\n    }\n    .stardust-carousel__arrow {\n      cursor: pointer;\n      user-select: none;\n      display: inline-flex;\n      position: absolute;\n      justify-content: center;\n      align-items: center;\n      top: 50%;\n      transform: translate(0, -50%);\n      width: 20px;\n      height: 20px;\n      font-size: 20px;\n      line-height: 20px;\n      text-align: center;\n      box-shadow: 0 1px 8px 0 rgba(0, 0, 0, 0.09);\n      border-radius: 50%;\n      opacity: 1;\n      color: rgba(0, 0, 0, 0.87);\n      fill: rgba(0, 0, 0, 0.87);\n      background-color: white;\n      transition: opacity 0.3s ease;\n      width: 35px;\n      height: 60px;\n      background-color: rgba(0, 0, 0, 0.18);\n      border-radius: 0;\n      border-radius: initial;\n      opacity: 0;\n    }\n\n    .stardust-carousel__arrow > svg {\n      flex: 0 1 auto;\n      width: 75%;\n      height: 75%;\n      color: #ee4d2d;\n      width: 1em;\n      height: 1em;\n      color: #fff;\n    }\n    .stardust-icon {\n      stroke: currentColor;\n      fill: currentColor;\n      width: 1em;\n      height: 1em;\n    }\n    .stardust-carousel__arrow:hover {\n      box-shadow: 0 1px 12px 0 rgba(0, 0, 0, 0.09);\n      background-color: rgba(0, 0, 0, 0.32);\n      border-radius: 0;\n    }\n\n    .stardust-carousel__arrow:active {\n      box-shadow: 0 1px 5px 0 rgba(0, 0, 0, 0.09);\n    }\n\n    .stardust-carousel__arrow--prev {\n      left: 0px;\n    }\n\n    .stardust-carousel__arrow--next {\n      right: 0px;\n    }\n\n    .stardust-carousel__arrow--disabled > svg {\n      fill: rgba(0, 0, 0, 0.12);\n    }\n  "])), function() {
                    var t, e, n, r, o = null === (t = window) || void 0 === t || null === (e = t.navigator) || void 0 === e ? void 0 : e.userAgent,
                        i = (null === (n = window) || void 0 === n || null === (r = n.location) || void 0 === r ? void 0 : r.search) || "";
                    if (i) {
                        if (/__mobile__/.test(i)) return ut.RW;
                        if (/__hybrid_pc__/.test(i)) return ut.PC
                    }
                    return o ? yt(pt, o) && !yt(vt, o) || yt(mt, o) ? ut.PC : ut.RW : ut.PC
                }() !== ut.PC ? 8 : 16)
            }
            var gt, bt, wt = 1,
                Et = -1,
                St = function(t) {
                    h(n, t);
                    var e = m(n);

                    function n() {
                        var t;
                        return y(this, n), t = e.call(this), (0, i.Z)(p(t), "bannerData", void 0), (0, i.Z)(p(t), "_isChildDisplayed", void 0), (0, i.Z)(p(t), "_carouselItemListWidth", null), (0, i.Z)(p(t), "_transitionTimeoutId", null), (0, i.Z)(p(t), "_autoPlayId", null), (0, i.Z)(p(t), "_slideId", null), (0, i.Z)(p(t), "_calculateItemListWidthIdleCallbackId", null), (0, i.Z)(p(t), "_finalBanners", []), (0, i.Z)(p(t), "_swipeStartX", 0), (0, i.Z)(p(t), "_swipeStartY", 0), (0, i.Z)(p(t), "_swipeVx", 0), (0, i.Z)(p(t), "_swipeLastX", 0), (0, i.Z)(p(t), "_swipeStarted", !1), (0, i.Z)(p(t), "_swipeMoved", !1), (0, i.Z)(p(t), "__reflowCount", 0), (0, i.Z)(p(t), "isSwiping", !1), (0, i.Z)(p(t), "state", {
                            activeIndex: 0,
                            isSliding: !1
                        }), (0, i.Z)(p(t), "handleSwipeMove", (function(e) {
                            if (t._swipeStarted) {
                                var n = e.changedTouches[0].pageX,
                                    r = e.changedTouches[0].pageY,
                                    o = n - t._swipeStartX;
                                if (e.stopPropagation(), !t._swipeMoved) {
                                    var i = r - t._swipeStartY;
                                    t.isSwiping = Math.abs(o) > Math.abs(i) && Math.abs(o) > 3, (t.isSwiping || Math.abs(i) > 3) && (t._swipeMoved = !0, t._swipeStartX = n, o = n - t._swipeStartX)
                                }
                                t.isSwiping && (t.animateCarousel(t.state.activeIndex, o), t._swipeVx = .5 * t._swipeVx + .5 * (n - t._swipeLastX), t._swipeLastX = n)
                            }
                        })), (0, i.Z)(p(t), "handleSwipeStart", (function(e) {
                            t.filteredBannerData.length <= 1 || (e.stopPropagation(), t._swipeStartX = e.changedTouches[0].pageX, t._swipeStartY = e.changedTouches[0].pageY, t._swipeVx = 0, t._swipeLastX = t._swipeStartX, t._swipeStarted = !0, t._swipeMoved = !1)
                        })), (0, i.Z)(p(t), "handleSwipeEnd", (function(e) {
                            var n = p(t),
                                r = n.onChangeIndex,
                                o = n.infinite;
                            if (t._swipeStarted && t.isSwiping) {
                                t._swipeStarted = !1, t._swipeMoved = !1, t.isSwiping = !1, e.stopPropagation();
                                var i = e.changedTouches[0].pageX - t._swipeStartX,
                                    a = t.state.activeIndex;
                                Math.abs(t._swipeVx) > 5 ? t._swipeVx > 0 ? a -= 1 : a += 1 : i > .5 * t.getCarouselItemListWidth() ? a -= 1 : i < .5 * -t.getCarouselItemListWidth() && (a += 1), o || (a < 0 || a >= t.filteredBannerData.length) && (a = t.state.activeIndex), t.animateCarousel(a, 0, 100), a !== t.state.activeIndex && ("function" == typeof r && r(t.getItemIndex(a)), t._transitionTimeoutId = setTimeout((function() {
                                    t.handleSlideEnd(a)
                                }), 100))
                            }
                        })), (0, i.Z)(p(t), "onDotClick", (function() {})), (0, i.Z)(p(t), "direction", wt), (0, i.Z)(p(t), "getItemWidthPercentage", (function() {
                            return 100 / (p(t).infinite ? t.filteredBannerData.length + 2 : t.filteredBannerData.length)
                        })), (0, i.Z)(p(t), "getCurrentCarouselTransform", (function(e) {
                            var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
                                r = t.getCarouselItemList();
                            return r ? "translateX(".concat(-e * t.getItemWidthPercentage(), "%) translateX(").concat(n, "px)") : ""
                        })), (0, i.Z)(p(t), "getCarouselItemListWidth", (function() {
                            t.__reflowCount;
                            var e = t.getCarouselItemList();
                            return null == t._carouselItemListWidth && e && e.firstElementChild && e.firstElementChild instanceof HTMLElement && (t._carouselItemListWidth = e.firstElementChild.getBoundingClientRect().width, t.__reflowCount += 1), t._carouselItemListWidth || 0
                        })), (0, i.Z)(p(t), "reportCarouselPosition", (function(e, n, r) {
                            if (n) {
                                var o = t.getCarouselItemListWidth();
                                "function" == typeof t.carouselPositionListener && t.carouselPositionListener(e - n / o, r)
                            } else "function" == typeof t.carouselPositionListener && t.carouselPositionListener(e, r)
                        })), (0, i.Z)(p(t), "getCarouselItemList", (function() {
                            var e;
                            return null === (e = t.shadowRoot) || void 0 === e ? void 0 : e.querySelector(".stardust-carousel__item-list")
                        })), (0, i.Z)(p(t), "animateCarousel", (function(e) {
                            var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
                                r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
                                o = t.getCarouselItemList();
                            if (o) {
                                o.style.transition = "".concat(r, "ms");
                                var i = t.getCurrentCarouselTransform(e, n);
                                o.style.webkitTransform = i, o.style.transform = i, t.reportCarouselPosition(e, n, r)
                            }
                        })), (0, i.Z)(p(t), "requestIdleCallbackSlide", (function() {
                            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : t.state.activeIndex + 1;
                            t._slideId && ht(t._slideId), t._slideId = dt((function() {
                                return t.slide(e, {
                                    fromautoPlay: !0
                                })
                            }), {
                                timeout: 2e3
                            })
                        })), (0, i.Z)(p(t), "renewautoPlay", (function() {
                            t.stopautoPlay(), t._autoPlayId = setTimeout(t.requestIdleCallbackSlide, t.autoScrollDuration)
                        })), (0, i.Z)(p(t), "stopautoPlay", (function() {
                            t._autoPlayId && clearTimeout(t._autoPlayId)
                        })), (0, i.Z)(p(t), "handleSlideEnd", (function(e) {
                            var n = e;
                            t._transitionTimeoutId = null, t.infinite && (0 === n ? (n = t.filteredBannerData.length, t.animateCarousel(n)) : n === t.filteredBannerData.length + 1 && (n = 1, t.animateCarousel(n))), t.autoPlay && t.renewautoPlay(), t.state.isSliding = !1, t.state.activeIndex = n, t.requestUpdate()
                        })), (0, i.Z)(p(t), "slide", (function(e) {
                            var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {
                                    skipAnimation: !1,
                                    fromautoPlay: !1
                                },
                                r = n.skipAnimation,
                                i = n.fromautoPlay,
                                a = t.state.activeIndex,
                                s = p(t),
                                l = s.autoPlay,
                                u = s.infinite,
                                c = s.onChangeIndex,
                                d = void 0 === c ? function(e) {
                                    t.onEventCallback && t.onEventCallback("CHANGE", (0, o.Z)((0, o.Z)({}, t.filteredBannerData[e]), {}, {
                                        index: e
                                    }))
                                } : c,
                                h = s.transitionTime,
                                f = e;
                            l && !u && i && (t.direction === wt && a >= t.filteredBannerData.length - 1 ? t.direction = Et : t.direction === Et && a <= 0 && (t.direction = wt), f = a + t.direction), t.filteredBannerData.length <= 1 || f !== a && (t.state.isSliding || (t._isChildDisplayed[f] || (t._isChildDisplayed[f] = !0), "function" == typeof d && d(t.getItemIndex(f)), t.state.isSliding = !0, t.animateCarousel(f, 0, r ? 0 : h), t._transitionTimeoutId = setTimeout((function() {
                                t.handleSlideEnd(f)
                            }), r ? 0 : h)))
                        })), t._isChildDisplayed = (0, i.Z)({}, t.state.activeIndex, !0), t.bannerData = [], t.state = {
                            activeIndex: t.bannerData.length ? t.bannerData.length - 1 : 0 + (t.infinite ? 1 : 0),
                            isSliding: !1
                        }, t
                    }
                    return c(n, [{
                        key: "filteredBannerData",
                        get: function() {
                            var t = this.bannerData,
                                e = this.max,
                                n = this.min;
                            return t.length < n ? [] : t.slice(0, e)
                        }
                    }, {
                        key: "connectedCallback",
                        value: function() {
                            g(f(n.prototype), "connectedCallback", this).call(this)
                        }
                    }, {
                        key: "disconnectedCallback",
                        value: function() {
                            var t;
                            g(f(n.prototype), "disconnectedCallback", this).call(this);
                            var e = null === (t = this.shadowRoot) || void 0 === t ? void 0 : t.querySelector(".shopee-banner-carousel");
                            null == e || e.removeEventListener("touchstart", this.handleSwipeStart), null == e || e.removeEventListener("touchend", this.handleSwipeEnd), null == e || e.removeEventListener("touchmove", this.handleSwipeMove, {
                                passive: !1
                            })
                        }
                    }, {
                        key: "updated",
                        value: function(t) {
                            var e;
                            g(f(n.prototype), "updated", this).call(this, t);
                            var r = null === (e = this.shadowRoot) || void 0 === e ? void 0 : e.querySelector(".shopee-banner-carousel");
                            null == r || r.addEventListener("touchstart", this.handleSwipeStart), null == r || r.addEventListener("touchend", this.handleSwipeEnd), null == r || r.addEventListener("touchmove", this.handleSwipeMove, {
                                passive: !1
                            });
                            var o = this.state.activeIndex;
                            this.animateCarousel(o), this.autoPlay ? this.renewautoPlay() : this.stopautoPlay()
                        }
                    }, {
                        key: "onTrack",
                        value: function(t, e) {
                            this.onEventCallback && this.onEventCallback(t.toUpperCase(), e)
                        }
                    }, {
                        key: "attributeChangedCallback",
                        value: function(t, e, r) {
                            "bannerData" === t && (this.bannerData = r.banners || [], this.useFallback || (this.bannerData = this.bannerData.filter((function(t) {
                                return !t.is_placeholder
                            }))), r.ratio && (this.ratio = r.ratio), this.status = r.status, r && this.requestUpdate()), g(f(n.prototype), "attributeChangedCallback", this).call(this, t, e, r)
                        }
                    }, {
                        key: "getItemIndex",
                        value: function(t) {
                            return this.infinite ? (t - 1 + this.filteredBannerData.length) % this.filteredBannerData.length : t
                        }
                    }, {
                        key: "finalBanners",
                        get: function() {
                            var t = this.filteredBannerData,
                                e = this.infinite,
                                n = Y(t);
                            return e && n.length > 0 && (n.unshift(n[n.length - 1]), n.push(n[1])), n
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var t = this.filteredBannerData,
                                e = void 0 === t ? [] : t,
                                n = this.onTrack,
                                r = this.ratio,
                                o = this.min,
                                i = this.infinite,
                                a = this.finalBanners,
                                s = this.dots,
                                l = this.useFallback,
                                u = this.shouldOpenInNewWindow,
                                c = (this.onEventCallback, this.arrows),
                                d = this.onClick,
                                h = this.trackingConf,
                                f = this.status;
                            return lt({
                                banners: e,
                                onTrack: n,
                                ratio: r,
                                looping: i,
                                activeIndex: this.state.activeIndex,
                                finalBanners: a,
                                onDotClick: this.slide,
                                useFallback: l,
                                dots: s,
                                arrows: c,
                                shouldOpenInNewWindow: u,
                                onArrowClick: this.slide,
                                onClick: d,
                                trackingConf: h,
                                min: o,
                                status: f
                            })
                        }
                    }], [{
                        key: "styles",
                        get: function() {
                            return [_t()]
                        }
                    }, {
                        key: "properties",
                        get: function() {
                            return (0, o.Z)((0, o.Z)({}, g(f(n), "properties", this)), {}, {
                                bannerData: {
                                    hasChanged: function() {
                                        return !0
                                    }
                                }
                            })
                        }
                    }]), n
                }(it),
                Ct = function(t) {
                    h(n, t);
                    var e = m(n);

                    function n() {
                        var t, r;
                        return y(this, n), r = e.call(this), (0, i.Z)(p(r), "onTrack", (function(e, o) {
                            var i = new CustomEvent("SHOPEE_BANNER_".concat(e.toUpperCase()), {
                                detail: {
                                    data: o
                                }
                            });
                            r.dispatchEvent(i), g((t = p(r), f(n.prototype)), "onTrack", t).call(t, e, o)
                        })), r
                    }
                    return c(n, [{
                        key: "firstUpdated",
                        value: function() {
                            var t = this;
                            this.loadData && this.loadData([{
                                space_key: this.spaceKey || this.getAttribute("spaceKey"),
                                space_filter: this.spaceFilter
                            }], (function(e, n) {
                                t.onTrack(e, n)
                            }), this.baseUrl)
                        }
                    }, {
                        key: "mapStateToProps",
                        value: function() {
                            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                                e = arguments.length > 1 ? arguments[1] : void 0;
                            this.attributeChangedCallback("bannerData", K(t.banner, this.spaceKey || this.getAttribute("spaceKey")), K(e.banner, this.spaceKey || this.getAttribute("spaceKey")))
                        }
                    }, {
                        key: "mapDispatchToProps",
                        value: function(t) {
                            return (0, o.Z)({
                                dispatch: t
                            }, (0, C.DE)({
                                loadData: Z
                            }, t))
                        }
                    }]), n
                }(St);

            function Nt(t, e, n, r) {
                n && Object.defineProperty(t, e, {
                    enumerable: n.enumerable,
                    configurable: n.configurable,
                    writable: n.writable,
                    value: n.initializer ? n.initializer.call(r) : void 0
                })
            }

            function xt(t, e, n, r, o) {
                var i = {};
                return Object.keys(r).forEach((function(t) {
                    i[t] = r[t]
                })), i.enumerable = !!i.enumerable, i.configurable = !!i.configurable, ("value" in i || i.initializer) && (i.writable = !0), i = n.slice().reverse().reduce((function(n, r) {
                    return r(t, e, n) || n
                }), i), o && void 0 !== i.initializer && (i.value = i.initializer ? i.initializer.call(o) : void 0, i.initializer = void 0), void 0 === i.initializer && (Object.defineProperty(t, e, i), i = null), i
            }
            bt = X, (gt = Ct) && "function" == typeof gt && bt && "object" === (0, r.Z)(bt) && (gt.prototype.hasOwnProperty("mapStateToProps") || "webcomponents-redux: ".concat(gt.name, " is missing method mapStateToProps"), gt.prototype.hasOwnProperty("mapDispatchToProps") || "webcomponents-redux: ".concat(gt.name, " is missing method mapDispatchToProps"), Object.assign(gt.prototype, E), gt.prototype.mixinExistingConnectedCallback = gt.prototype.connectedCallback, Object.assign(gt.prototype, b), gt.prototype.mixinExistingDisconnectedCallback = gt.prototype.disconnectedCallback, Object.assign(gt.prototype, w), gt.prototype.mixinStore = bt);
            var Tt = 1,
                Ot = 3,
                kt = 128,
                Pt = 1,
                Dt = 2,
                At = 6;

            function Mt(t) {
                var e = [];
                if (e[0] = null, void 0 !== t.match_type ? e[1] = t.match_type : e[1] = null, void 0 !== t.match_id) {
                    e[2] = [];
                    for (var n = 0; n < t.match_id.length; n++) e[2][n] = t.match_id[n]
                } else e[2] = null;
                if (void 0 !== t.hashtag) {
                    e[3] = [];
                    for (var r = 0; r < t.hashtag.length; r++) e[3][r] = t.hashtag[r]
                } else e[3] = null;
                return e
            }

            function jt(t) {
                var e = [];
                if (e[0] = null, void 0 !== t.keyword ? e[1] = t.keyword : e[1] = null, void 0 !== t.sorttype ? e[2] = t.sorttype : e[2] = 9, void 0 !== t.colorful_blocks) {
                    e[3] = [];
                    for (var n = 0; n < t.colorful_blocks.length; n++) e[3][n] = t.colorful_blocks[n]
                } else e[3] = null;
                if (void 0 !== t.filter_price_min ? e[4] = t.filter_price_min : e[4] = null, void 0 !== t.filter_price_max ? e[5] = t.filter_price_max : e[5] = null, void 0 !== t.filter_include_sf ? e[6] = t.filter_include_sf : e[6] = null, void 0 !== t.filter_with_discount ? e[7] = t.filter_with_discount : e[7] = null, void 0 !== t.filter_attribute ? e[8] = t.filter_attribute : e[8] = null, void 0 !== t.filter_item_condition ? e[9] = t.filter_item_condition : e[9] = null, void 0 !== t.filter_user_verified ? e[10] = t.filter_user_verified : e[10] = null, void 0 !== t.filters) {
                    e[11] = [];
                    for (var r = 0; r < t.filters.length; r++) e[11][r] = Mt(t.filters[r])
                } else e[11] = null;
                return void 0 !== t.itemid ? e[12] = t.itemid : e[12] = null, void 0 !== t.shopid ? e[13] = t.shopid : e[13] = null, e
            }

            function Lt(t) {
                var e = [];
                if (e[0] = null, void 0 !== t.itemid ? e[1] = t.itemid : e[1] = null, void 0 !== t.shopid ? e[2] = t.shopid : e[2] = null, void 0 !== t.discount ? e[3] = t.discount : e[3] = null, void 0 !== t.free_shipping ? e[4] = t.free_shipping : e[4] = null, void 0 !== t.is_prefered ? e[5] = t.is_prefered : e[5] = null, void 0 !== t.algorithm ? e[6] = t.algorithm : e[6] = null, void 0 !== t.compaignid ? e[7] = t.compaignid : e[7] = null, void 0 !== t.location ? e[8] = t.location : e[8] = null, void 0 !== t.query ? e[9] = jt(t.query) : e[9] = null, void 0 !== t.refer_urls) {
                    e[10] = [];
                    for (var n = 0; n < t.refer_urls.length; n++) e[10][n] = t.refer_urls[n]
                } else e[10] = null;
                return void 0 !== t.item_modelid ? e[11] = t.item_modelid : e[11] = null, void 0 !== t.list_type ? e[12] = t.list_type : e[12] = null, void 0 !== t.adsid ? e[13] = t.adsid : e[13] = null, void 0 !== t.location_in_ads ? e[14] = t.location_in_ads : e[14] = null, void 0 !== t.campaignid ? e[15] = t.campaignid : e[15] = null, void 0 !== t.ads_keyword ? e[16] = t.ads_keyword : e[16] = null, void 0 !== t.match_type ? e[17] = t.match_type : e[17] = null, void 0 !== t.deduction_info ? e[18] = t.deduction_info : e[18] = null, void 0 !== t.abtest_sign ? e[19] = t.abtest_sign : e[19] = null, void 0 !== t.add_cart_amount ? e[20] = t.add_cart_amount : e[20] = null, void 0 !== t.add_cart_price ? e[21] = t.add_cart_price : e[21] = null, void 0 !== t.modelid ? e[22] = t.modelid : e[22] = null, void 0 !== t.json_data ? e[23] = t.json_data : e[23] = null, void 0 !== t.product_card ? e[24] = function(t) {
                    return [null, "campaign_label_ids", "has_video", "item_discount", "shop_type", "service_by_shopee", "image_flag_ids", "price_before_discount", "price_max_before_discount", "price_min_before_discount", "price", "price_max", "price_min", "bundle_deal_label", "wholesale", "addon_deal_label", "cashback", "is_groupbuy", "other_promotion_label_id", "rating_star", "rating_star_rounded", "sold_count", "free_shipping", "other_icon_in_price_id", "sold_out"].map((function(e, n) {
                        return 0 === n || null === e || void 0 === t[e] ? null : t[e]
                    }))
                }(t.product_card) : e[24] = null, e
            }

            function It(t) {
                var e = [];
                if (e[0] = null, void 0 !== t.shopid ? e[1] = t.shopid : e[1] = null, void 0 !== t.query ? e[2] = jt(t.query) : e[2] = 9, void 0 !== t.algorithm ? e[3] = t.algorithm : e[3] = null, void 0 !== t.location ? e[4] = t.location : e[4] = null, void 0 !== t.refer_urls) {
                    e[5] = [];
                    for (var n = 0; n < t.refer_urls.length; n++) e[5][n] = t.refer_urls[n]
                } else e[5] = null;
                return void 0 !== t.list_type ? e[6] = t.list_type : e[6] = null, void 0 !== t.json_data ? e[7] = t.json_data : e[7] = null, e
            }
            n(39609);

            function Rt(t) {
                var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
                return "".concat(t, "_").concat(e.toString())
            }
            var Ft = self && self.innerWidth <= 640 ? 80 : 300;
            self.__INTERSECTION_OBSERVER || (self.__INTERSECTION_OBSERVER = {
                OBSERVER_MAP: new Map,
                CALLBACK_MULTIMAP: new Map
            });
            var Ut = self.__INTERSECTION_OBSERVER.OBSERVER_MAP,
                Bt = self.__INTERSECTION_OBSERVER.CALLBACK_MULTIMAP,
                Ht = "0px 0px ".concat(Ft, "px 0px"),
                Zt = Rt(Ht, 0);
            Bt.set(Zt, new WeakMap);
            var Vt = new self.IntersectionObserver(Wt(Zt), {
                rootMargin: Ht,
                threshold: 0
            });

            function Wt(t) {
                var e = Bt.get(t);
                return function(t) {
                    var n, r = function(t, e) {
                        var n;
                        if ("undefined" == typeof Symbol || null == t[Symbol.iterator]) {
                            if (Array.isArray(t) || (n = s(t)) || e && t && "number" == typeof t.length) {
                                n && (t = n);
                                var r = 0,
                                    o = function() {};
                                return {
                                    s: o,
                                    n: function() {
                                        return r >= t.length ? {
                                            done: !0
                                        } : {
                                            done: !1,
                                            value: t[r++]
                                        }
                                    },
                                    e: function(t) {
                                        throw t
                                    },
                                    f: o
                                }
                            }
                            throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                        }
                        var i, a = !0,
                            l = !1;
                        return {
                            s: function() {
                                n = t[Symbol.iterator]()
                            },
                            n: function() {
                                var t = n.next();
                                return a = t.done, t
                            },
                            e: function(t) {
                                l = !0, i = t
                            },
                            f: function() {
                                try {
                                    a || null == n.return || n.return()
                                } finally {
                                    if (l) throw i
                                }
                            }
                        }
                    }(t);
                    try {
                        for (r.s(); !(n = r.n()).done;) {
                            var o = n.value,
                                i = o.target;
                            if (e && e.has(i)) {
                                var a = e.get(i) || {},
                                    l = a.enterViewCallback,
                                    u = a.leaveViewCallback,
                                    c = a.intersectionChangeCallback;
                                o.isIntersecting ? l && l(o) : u && u(o), c && c(o)
                            }
                        }
                    } catch (t) {
                        r.e(t)
                    } finally {
                        r.f()
                    }
                }
            }

            function qt(t, e) {
                var n = null != t ? t : Ht,
                    r = null != e ? e : 0,
                    o = Rt(n, r),
                    i = o ? Ut.get(o) : Vt;
                return i || (Bt.set(o, new WeakMap), i = new self.IntersectionObserver(Wt(o), {
                    rootMargin: n,
                    threshold: r
                }), Ut.set(o, i)), {
                    observer: i,
                    callbackMap: Bt.get(o)
                }
            }
            Ut.set(Zt, Vt);
            var zt = .5,
                Gt = new WeakMap,
                Xt = new WeakMap;

            function Kt(t) {
                var e = t.target;
                if (t.intersectionRatio < zt) {
                    if (Xt.has(e)) {
                        var n = Xt.get(e);
                        n && clearTimeout(n), Xt.delete(e)
                    }
                } else Gt.has(e) ? Xt.set(e, setTimeout((function() {
                    Xt.delete(e);
                    var t, n, r, o, i, a = Gt.get(e);
                    "function" == typeof a && (t = e, r = qt((n = {
                        threshold: zt,
                        rootMargin: "0px 0px 0px 0px"
                    } || {}).rootMargin, n.threshold), o = r.observer, i = r.callbackMap, t && o && i && i.has(t) && (i.delete(t), o.unobserve(t)), a())
                }), 1e3)) : console.error
            }
            var Yt, Jt, $t, Qt, te, ee, ne, re = function(t, e) {
                t && !Gt.has(t) && (Gt.set(t, e), function(t, e) {
                    var n = e || {},
                        r = n.rootMargin,
                        o = n.threshold,
                        i = n.enterViewCallback,
                        a = n.leaveViewCallback,
                        s = n.intersectionChangeCallback,
                        l = qt(r, o),
                        u = l.observer,
                        c = l.callbackMap;
                    t && c && (c.set(t, {
                        enterViewCallback: i,
                        leaveViewCallback: a,
                        intersectionChangeCallback: s
                    }), u.observe(t))
                }(t, {
                    threshold: zt,
                    rootMargin: "0px 0px 0px 0px",
                    intersectionChangeCallback: Kt
                }))
            };

            function oe() {
                return {
                    userid: parseInt(ie("SPC_U") || "", 10) || void 0,
                    sessionid: ie("SPC_T_ID") || void 0,
                    token: ie("SPC_T_IV") || void 0,
                    deviceid: ie("SPC_F") || void 0
                }
            }

            function ie(t) {
                if (self.document && "string" == typeof self.document.cookie) {
                    var e = new RegExp("(?:^|;\\s?)".concat(t, "=([^;$]+)")).exec(self.document.cookie || "");
                    return e ? e[1] : void 0
                }
            }

            function ae(t, e) {
                var n, r = function(t) {
                    var e = [];
                    if (e[0] = null, void 0 !== t.userid ? e[1] = t.userid : e[1] = null, void 0 !== t.sessionid ? e[2] = t.sessionid : e[2] = null, void 0 !== t.deviceid ? e[3] = t.deviceid : e[3] = null, void 0 !== t.client_ip ? e[4] = t.client_ip : e[4] = null, void 0 !== t.platform ? e[5] = t.platform : e[5] = null, void 0 !== t.operation ? e[6] = t.operation : e[6] = null, void 0 !== t.items) {
                        e[7] = [];
                        for (var n = 0; n < t.items.length; n++) e[7][n] = Lt(t.items[n])
                    } else e[7] = null;
                    if (void 0 !== t.timestamp ? e[8] = t.timestamp : e[8] = null, void 0 !== t.country ? e[9] = t.country : e[9] = null, void 0 !== t.token ? e[10] = t.token : e[10] = null, void 0 !== t.from ? e[11] = t.from : e[11] = null, void 0 !== t.shops) {
                        e[12] = [];
                        for (var r = 0; r < t.shops.length; r++) e[12][r] = It(t.shops[r])
                    } else e[12] = null;
                    return void 0 !== t.placement ? e[13] = t.placement : e[13] = null, void 0 !== t.json_data ? e[14] = t.json_data : e[14] = null, void 0 !== t.fe_ab_test ? e[15] = t.fe_ab_test : e[15] = null, void 0 !== t.banner ? e[17] = function(t) {
                        var e = [];
                        return e[0] = null, void 0 !== t.banner_id ? e[1] = t.banner_id : e[1] = null, void 0 !== t.source ? e[2] = t.source : e[2] = null, void 0 !== t.campaign_unit_id ? e[3] = t.campaign_unit_id : e[3] = null, void 0 !== t.slot_id ? e[4] = t.slot_id : e[4] = null, void 0 !== t.json_data ? e[5] = t.json_data : e[5] = null, void 0 !== t.image_hash ? e[6] = t.image_hash : e[6] = null, void 0 !== t.target_url ? e[7] = t.target_url : e[7] = null, e
                    }(t.banner) : e[17] = null, e
                }((0, o.Z)((0, o.Z)({
                    from: "webbannersdk",
                    platform: (n = navigator ? navigator.userAgent || navigator.vendor || window.opera : "", /windows phone/i.test(n) ? kt : /android/i.test(n) ? Ot : /iPad|iPhone|iPod/.test(n) && !window.MSStream ? Tt : kt),
                    country: window.__LOCALE__,
                    placement: 9,
                    timestamp: (new Date).getTime()
                }, oe()), t));
                fetch("/__t__", {
                    method: "post",
                    credentials: "include",
                    body: JSON.stringify(r)
                }).then((function() {
                    e && e("success", r)
                }), (function(t) {
                    e && e("failed", t)
                }))
            }

            function se() {}
            var le, ue, ce = (Yt = (0, ot.property)(), Jt = (0, ot.property)(), $t = (0, ot.property)(), Qt = function(t) {
                h(n, t);
                var e = m(n);

                function n() {
                    var t;
                    return y(this, n), Nt(p(t = e.call(this)), "bannerData", te, p(t)), Nt(p(t), "onTrack", ee, p(t)), Nt(p(t), "trackingConf", ne, p(t)), t.addEventListener("click", (function() {
                        var e, n, r;
                        t.onTrack("click", t.bannerData), ae((0, o.Z)((0, o.Z)({
                            banner: (0, o.Z)((0, o.Z)({}, null === (e = t.bannerData) || void 0 === e ? void 0 : e.banner_metadata), {}, {
                                image_hash: null === (n = t.bannerData) || void 0 === n ? void 0 : n.image_hash,
                                target_url: null === (r = t.bannerData) || void 0 === r ? void 0 : r.target_url
                            }),
                            operation: Dt
                        }, t.trackingConf), oe()), se)
                    })), re(p(t), (function() {
                        var e, n, r;
                        t.onTrack("impression", t.bannerData), ae((0, o.Z)((0, o.Z)({
                            banner: (0, o.Z)((0, o.Z)({}, null === (e = t.bannerData) || void 0 === e ? void 0 : e.banner_metadata), {}, {
                                image_hash: null === (n = t.bannerData) || void 0 === n ? void 0 : n.image_hash,
                                target_url: null === (r = t.bannerData) || void 0 === r ? void 0 : r.target_url
                            }),
                            operation: Pt
                        }, t.trackingConf), oe()), se)
                    })), t
                }
                return n
            }(ot.LitElement), te = xt(Qt.prototype, "bannerData", [Yt], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return {}
                }
            }), ee = xt(Qt.prototype, "onTrack", [Jt], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return function() {}
                }
            }), ne = xt(Qt.prototype, "trackingConf", [$t], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return {}
                }
            }), Qt);
            var de, he, fe, pe, ve = function(t) {
                    h(n, t);
                    var e = m(n);

                    function n() {
                        return y(this, n), e.call(this)
                    }
                    return c(n, null, [{
                        key: "properties",
                        get: function() {
                            return (0, o.Z)((0, o.Z)({}, g(f(n), "properties", this)), {}, {
                                bannerData: {
                                    hasChanged: function() {
                                        return !0
                                    }
                                }
                            })
                        }
                    }]), n
                }(function(t) {
                    h(n, t);
                    var e = m(n);

                    function n() {
                        var t;
                        return y(this, n), t = e.call(this), (0, i.Z)(p(t), "bannerData", void 0), (0, i.Z)(p(t), "ratio", void 0), (0, i.Z)(p(t), "shouldOpenInNewWindow", void 0), (0, i.Z)(p(t), "onClick", void 0), (0, i.Z)(p(t), "withPlaceHolder", void 0), (0, i.Z)(p(t), "onItemClick", (function(e) {
                            var n, r = function(t) {
                                    if (self && self.URL) try {
                                        var e = new URL(t),
                                            n = e.host,
                                            r = void 0 === n ? S : n,
                                            o = e.pathname,
                                            i = void 0 === o ? S : o,
                                            a = e.hostname,
                                            s = void 0 === a ? S : a,
                                            l = e.hash,
                                            u = void 0 === l ? S : l,
                                            c = e.search,
                                            d = void 0 === c ? S : c,
                                            h = e.href,
                                            f = void 0 === h ? S : h,
                                            p = e.protocol,
                                            v = void 0 === p ? S : p,
                                            m = e.origin,
                                            y = void 0 === m ? S : m;
                                        if (!r || !s || !i) throw new Error("Instance of URL returns wrong values, trying fallback method");
                                        return {
                                            host: r,
                                            hostname: s,
                                            pathname: i,
                                            hash: u,
                                            search: d,
                                            href: f,
                                            protocol: v,
                                            origin: y
                                        }
                                    } catch (t) {}
                                    var _ = document.createElement("a");
                                    _.href = t;
                                    var g = _.host,
                                        b = _.hostname,
                                        w = _.pathname,
                                        E = _.hash,
                                        C = _.search,
                                        N = _.origin,
                                        x = _.href,
                                        T = _.protocol;
                                    return {
                                        host: g,
                                        pathname: "" !== w && "/" !== w[0] ? "/" + w : w,
                                        hostname: b,
                                        hash: E,
                                        search: C,
                                        href: x,
                                        protocol: T,
                                        origin: N || T + "://" + g
                                    }
                                }(null === (n = t.bannerData) || void 0 === n ? void 0 : n.target_url),
                                o = r.hostname === window.location.hostname,
                                i = p(t).onClick;
                            i ? (i(t.bannerData), e.preventDefault()) : o && !t.shouldOpenInNewWindow && window.__BANNER_SDK_HISTORY__ && (e.preventDefault(), window.__BANNER_SDK_HISTORY__.push(r))
                        })), t.bannerData = {}, t.ratio = 1, t.shouldOpenInNewWindow = !1, t.withPlaceHolder = !0, t
                    }
                    return c(n, [{
                        key: "render",
                        value: function() {
                            return function(t) {
                                var e = t.bannerData,
                                    n = t.shouldOpenInNewWindow,
                                    r = t.onItemClick,
                                    o = t.trackingConf,
                                    i = t.ratio,
                                    a = t.withPlaceHolder;
                                return (0, ot.html)(le || (le = at(['<div\n    class="simple-banner ', '"\n    style=', "\n  >\n    <a\n      .onclick=", "\n      .trackingConf=", '\n      target="', '"\n      href=', '\n      ><img class="banner-image" src=', "\n    /></a>\n  </div>"])), a ? "withPlaceHolder" : "", (0, ot.styleMap)({
                                    paddingTop: "".concat(100 / i, "%")
                                }), r, o, n ? "_blank" : "_self", e.target_url, e.image_url)
                            }({
                                bannerData: this.bannerData,
                                shouldOpenInNewWindow: this.shouldOpenInNewWindow,
                                onItemClick: this.onItemClick,
                                trackingConf: this.trackingConf,
                                withPlaceHolder: this.withPlaceHolder
                            })
                        }
                    }], [{
                        key: "styles",
                        get: function() {
                            return [(0, ot.css)(ue || (ue = at(["\n    .simple-banner {\n      width: 100%;\n      height: 100%;\n      overflow: hidden;\n    }\n    .banner-image {\n      display: block;\n      width: 100%;\n      overflow: hidden;\n    }\n    .withPlaceHolder{\n      background-position: center;\n      background-size: 60px 60px;\n      background-repeat: no-repeat;\n      background-image: url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 54 61' x='0' y='0' stroke='' fill='%23e5e4e4'%0A%3E%3Cpath d='M 99.2 59.9 H 86.7 c 0 -5.3 -2.7 -16.3 -11.7 -16.4 c -9.6 -.1 -11.8 11.9 -11.8 16.4 H 50.8 c -3.4 0 -2.7 3.4 -2.7 3.4 l 2.4 33 c 0 0 -.1 7.3 6.3 7.5 c .4 0 35.7 0 36.5 0 c 6.2 -.4 6.3 -7.5 6.3 -7.5 l 2.4 -33 C 102 63.2 102.5 59.8 99.2 59.9 z M 75.1 47.2 c 7.1 .2 7.9 11.7 7.7 12.6 H 67.1 C 67 58.9 67.5 47.4 75.1 47.2 z M 84.2 91.8 c -1 1.7 -2.7 3 -5 3.7 C 78 95.9 76.8 96 75.6 96 c -3.2 0 -6.5 -1.1 -9.3 -3.3 c -.8 -.6 -1 -1.5 -.5 -2.3 c .2 -.4 .7 -.7 1.2 -.8 c .4 -.1 .9 0 1.2 .3 c 3.2 2.4 8.3 4 11.9 1.6 c 1.4 -.9 2.1 -2.7 1.6 -4.3 c -.5 -1.6 -2.2 -2.7 -3.5 -3.4 c -1 -.6 -2.1 -1 -3.3 -1.4 c -.9 -.3 -1.9 -.7 -2.9 -1.2 c -2.4 -1.2 -4 -2.6 -4.8 -4.2 c -1.2 -2.3 -.6 -5.4 1.4 -7.5 c 3.6 -3.8 10 -3.2 14 -.4 c .9 .6 .9 1.7 .4 2.5 c -.5 .8 -1.4 .9 -2.2 .4 c -2 -1.4 -4.4 -2 -6.4 -1.7 c -2 .3 -4.7 2 -4.4 4.6 c .2 1.5 2 2.6 3.3 3.3 c .8 .4 1.5 .7 2.3 .9 c 4.3 1.3 7.2 3.3 8.6 5.7 C 85.4 86.9 85.4 89.7 84.2 91.8 z' transform='translate(-48 -43)' stroke='none' /%3E%3C/svg%3E\");\n    }\n  "])))]
                        }
                    }]), n
                }(ce)),
                me = function(t) {
                    h(n, t);
                    var e = m(n);

                    function n() {
                        return y(this, n), e.apply(this, arguments)
                    }
                    return c(n, [{
                        key: "render",
                        value: function() {
                            return (0, ot.html)(de || (de = at(["\n      <h2>Current version is : ", "</h2>\n    "])), window.__SHOPEE_BANNER_SDK_VERSION_)
                        }
                    }]), n
                }(ot.LitElement);
            var ye, _e, ge = function(t) {
                h(n, t);
                var e = m(n);

                function n() {
                    var t;
                    return y(this, n), t = e.call(this), (0, i.Z)(p(t), "bannerData", void 0), (0, i.Z)(p(t), "show", void 0), (0, i.Z)(p(t), "onClose", (function() {
                        t.onEventCallback && t.onEventCallback("CLOSE", t.bannerData)
                    })), (0, i.Z)(p(t), "onBackgroundClick", (function(e) {
                        var n;
                        "home-popup__background" === (null == e || null === (n = e.target) || void 0 === n ? void 0 : n.className) && t.onClose()
                    })), t.bannerData = [], t.useFallback = !1, t.show = !1, t
                }
                return c(n, [{
                    key: "render",
                    value: function() {
                        return e = (t = this).onClose, n = t.show, r = t.bannerData, o = t.onBackgroundClick, n ? (0, ot.html)(fe || (fe = at([' <div class="home-popup">\n    <div class="home-popup__background" .onclick=', '>\n      <div class="home-popup__content">\n        <shopee-carousel-ui\n          .bannerData=', "\n          .ratio=", "\n          min=", '\n          max="1"\n          .autoPlay=', "\n          .dots=", "\n          .useFallback=", "\n          .arrows=", "\n          .infinite=", "\n          autoScrollDuration=", "\n          .onClick=", "\n          .shouldOpenInNewWindow=", "\n          .onEventCallback=", "\n          .trackingConf=", '\n        ></shopee-carousel-ui>\n        <div class="home-popup__close-area">\n          <div class="shopee-popup__close-btn" .onclick=', '>\n            <svg\n              viewBox="0 0 16 16"\n              stroke="#EE4D2D"\n              class="home-popup__close-button"\n            >\n              <path stroke-linecap="round" d="M1.1,1.1L15.2,15.2"></path>\n              <path stroke-linecap="round" d="M15,1L0.9,15.1"></path>\n            </svg>\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>'])), o, r, t.ratio, t.min, t.autoPlay, t.dots, t.useFallback, t.arrows, t.infinite, t.autoScrollDuration, t.onClick, t.shouldOpenInNewWindow, t.onEventCallback, t.trackingConf, e) : (0, ot.html)(he || (he = at([""])));
                        var t, e, n, r, o
                    }
                }], [{
                    key: "styles",
                    get: function() {
                        return [(0, ot.css)(pe || (pe = at(["\n    .home-popup__background {\n      width: 100%;\n      height: 100%;\n      top: 0;\n      left: 0;\n      position: fixed;\n      background-color: rgba(0, 0, 0, 0.4);\n      display: -webkit-box;\n      display: -webkit-flex;\n      display: -moz-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-align: center;\n      -webkit-align-items: center;\n      -moz-box-align: center;\n      -ms-flex-align: center;\n      align-items: center;\n      -webkit-align-content: center;\n      -ms-flex-line-pack: center;\n      align-content: center;\n      -webkit-box-pack: center;\n      -webkit-justify-content: center;\n      -moz-box-pack: center;\n      -ms-flex-pack: center;\n      justify-content: center;\n      z-index: 9000;\n    }\n    .home-popup__content {\n      -webkit-box-flex: 0;\n      -webkit-flex: 0 1 auto;\n      -moz-box-flex: 0;\n      -ms-flex: 0 1 auto;\n      flex: 0 1 auto;\n      position: relative;\n      width: 80%;\n      max-width: 460px;\n      max-height: 100%;\n    }\n    .home-popup__close-area {\n      position: absolute;\n      display: block;\n      top: 0;\n      right: 0;\n      width: 15%;\n      height: 19%;\n      cursor: pointer;\n    }\n    .shopee-popup__close-btn {\n      cursor: pointer;\n      -webkit-user-select: none;\n      -moz-user-select: none;\n      -ms-user-select: none;\n      user-select: none;\n      line-height: 40px;\n      height: 30px;\n      width: 30px;\n      display: -webkit-box;\n      display: -webkit-flex;\n      display: -moz-box;\n      display: -ms-flexbox;\n      display: flex;\n      -webkit-box-align: center;\n      -webkit-align-items: center;\n      -moz-box-align: center;\n      -ms-flex-align: center;\n      align-items: center;\n      -webkit-box-pack: center;\n      -webkit-justify-content: center;\n      -moz-box-pack: center;\n      -ms-flex-pack: center;\n      justify-content: center;\n      position: absolute;\n      -moz-box-sizing: border-box;\n      box-sizing: border-box;\n      background: #efefef;\n      top: -10px;\n      right: -10px;\n      border-radius: 20px;\n      border: 3px solid #efefef;\n    }\n    .home-popup__close-button {\n      height: 16px;\n      width: 16px;\n      stroke: rgba(0, 0, 0, 0.5);\n      stroke-width: 2px;\n    }\n  "])))]
                    }
                }, {
                    key: "properties",
                    get: function() {
                        return (0, o.Z)((0, o.Z)({}, g(f(n), "properties", this)), {}, {
                            show: {},
                            bannerData: {
                                hasChanged: function() {
                                    return !0
                                }
                            }
                        })
                    }
                }]), n
            }(it);
            var be = function(t) {
                h(n, t);
                var e = m(n);

                function n() {
                    var t;
                    y(this, n);
                    for (var r = arguments.length, a = new Array(r), s = 0; s < r; s++) a[s] = arguments[s];
                    return t = e.call.apply(e, [this].concat(a)), (0, i.Z)(p(t), "onClose", (function() {
                        var e, n, r, i = (null === (e = t.data) || void 0 === e || null === (n = e[0]) || void 0 === n || null === (r = n.banners) || void 0 === r ? void 0 : r[0]) || {};
                        ae((0, o.Z)((0, o.Z)({
                            banner: (0, o.Z)((0, o.Z)({}, i.banner_metadata), {}, {
                                image_hash: null == i ? void 0 : i.image_hash,
                                target_url: null == i ? void 0 : i.target_url
                            }),
                            operation: At
                        }, t.trackingConf), oe()), (function() {})), t.onEventCallback && t.onEventCallback("CLOSE", t.data)
                    })), (0, i.Z)(p(t), "onEvent", (function(e, n) {
                        var r, o, i;
                        "LOAD" === e ? (t.data = t.useFallback ? null == n || null === (r = n.data) || void 0 === r ? void 0 : r.space_banners : null == n || null === (o = n.data) || void 0 === o || null === (i = o.space_banners) || void 0 === i ? void 0 : i.filter((function(t) {
                            return !t.is_placeholder
                        })), t.onEventCallback && t.onEventCallback(e, t.data)) : t.onEventCallback && t.onEventCallback(e, n)
                    })), (0, i.Z)(p(t), "data", void 0), t
                }
                return c(n, [{
                    key: "render",
                    value: function() {
                        return t = this, e = this.onEvent, n = t.onClose, r = t.show, o = t.bannerData, i = t.onBackgroundClick, r ? (0, ot.html)(_e || (_e = at([' <div class="home-popup">\n    <div class="home-popup__background" .onclick=', '>\n      <div class="home-popup__content">\n        <shopee-carousel-stateful\n          spaceKey=', "\n          .bannerData=", "\n          .ratio=", "\n          min=", '\n          max="1"\n          .autoPlay=', "\n          .dots=", "\n          .useFallback=", "\n          .arrows=", "\n          .infinite=", "\n          autoScrollDuration=", "\n          .onClick=", "\n          .shouldOpenInNewWindow=", "\n          .onEventCallback=", "\n          .trackingConf=", '\n        ></shopee-carousel-stateful>\n        <div class="home-popup__close-area">\n          <div class="shopee-popup__close-btn" .onclick=', '>\n            <svg\n              viewBox="0 0 16 16"\n              stroke="#EE4D2D"\n              class="home-popup__close-button"\n            >\n              <path stroke-linecap="round" d="M1.1,1.1L15.2,15.2"></path>\n              <path stroke-linecap="round" d="M15,1L0.9,15.1"></path>\n            </svg>\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>'])), i, t.spaceKey, o, t.ratio, t.min, t.autoPlay, t.dots, t.dots, t.arrows, t.infinite, t.autoScrollDuration, t.onClick, t.shouldOpenInNewWindow, e, t.trackingConf, n) : (0, ot.html)(ye || (ye = at([""])));
                        var t, e, n, r, o, i
                    }
                }]), n
            }(ge);

            function we(t) {
                if (document && document.createElement && ((e = document.createElement) && "[object Function]" === {}.toString.call(e))) switch (document.createElement(t).constructor) {
                    case HTMLElement:
                        return !1;
                    case HTMLUnknownElement:
                        return
                }
                var e;
                return !0
            }
            customElements && (!we("tracking-wrapper") && customElements.define("tracking-wrapper", ce), !we("shopee-carousel-ui") && customElements.define("shopee-carousel-ui", St), !we("shopee-banner-simple") && customElements.define("shopee-banner-simple", ve), !we("shopee-banner-version") && customElements.define("shopee-banner-version", me), !we("shopee-carousel-stateful") && customElements.define("shopee-carousel-stateful", Ct), !we("shopee-banner-popup-ui") && customElements.define("shopee-banner-popup-ui", ge), !we("shopee-banner-popup-stateful") && customElements.define("shopee-banner-popup-stateful", be));
            var Ee = n(27378),
                Se = n.n(Ee),
                Ce = {
                    _effects: [],
                    reset: function() {
                        this._effects = []
                    },
                    hasPendingEffects: function() {
                        return this._effects.length > 0
                    },
                    getEffects: function() {
                        return this._effects.slice()
                    }
                },
                Ne = null,
                xe = null;

            function Te(t, e) {
                Ne = function() {
                    if (null === Ne) {
                        if (null === xe) {
                            var t = {
                                memorizedState: null,
                                next: null
                            };
                            return Ne = t, (xe = t).suspensedTimes = 0, Ne
                        }
                        return Ne = xe
                    }
                    return Ne = null === Ne.next ? Ne.next = {
                        memorizedState: null,
                        next: null
                    } : Ne.next
                }();
                var n = xe;
                if (!(n.suspensedTimes >= 25)) {
                    var r, o = void 0 === e ? [] : e,
                        i = Ne.memorizedState;
                    if (null !== i && null !== o)
                        if (function(t, e) {
                                if (null === e) return !1;
                                for (var n = 0; n < e.length && n < t.length; n++)
                                    if (!Oe(t[n], e[n])) return !1;
                                return !0
                            }(o, i[1])) return;
                    try {
                        r = t()
                    } catch (t) {
                        throw t
                    }
                    Array.isArray(r) || (r = [r, function() {}]);
                    var a = Promise.resolve(r[0]);
                    Ne.memorizedState = [a, o], Ce._effects.push(a), n.suspensedTimes++
                }
            }
            var Oe = "function" == typeof Object.is ? Object.is : function(t, e) {
                return t === e && (0 !== t || 1 / t == 1 / e) || t != t && e != e
            };

            function ke() {
                return (ke = Object.assign || function(t) {
                    for (var e = 1; e < arguments.length; e++) {
                        var n = arguments[e];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (t[r] = n[r])
                    }
                    return t
                }).apply(this, arguments)
            }
            var Pe = n(41153),
                De = "UPDATE_DATA",
                Ae = "UPDATE_BANNER_FETCHING_STATUS",
                Me = "/api/v4/banner/batch_list_by_spaces";

            function je() {
                return !!self.document && "string" == typeof self.document.cookie
            }

            function Le(t, e) {
                var n = t + "csrftoken",
                    r = function(t) {
                        if (je()) {
                            var e = new RegExp("(?:^|;\\s?)".concat(t, "=([^;$]+)")).exec(self.document.cookie || "");
                            return e ? e[1] : void 0
                        }
                    }(n);
                return r || function(t, e, n, r) {
                    if (je()) {
                        var o = "".concat(t, "=").concat(e, ";");
                        if (n) {
                            var i = new Date;
                            i.setTime(i.getTime() + 24 * n * 60 * 60 * 1e3), o += "expires=".concat(i.toUTCString(), ";")
                        }
                        o += "path=/;", r && (o += "domain=".concat(r, ";")), self.document.cookie = o
                    }
                }(n, r = function(t) {
                    for (var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789", n = "", r = 0; r < t; r++) {
                        var o = Math.floor(Math.random() * e.length);
                        n += e.substring(o, o + 1)
                    }
                    return n
                }(32), 0, e), r
            }
            var Ie = {
                    data: {
                        space_banners: [{
                            space_key: "1-SG-Home Carousel-1",
                            ratio: 1.875,
                            banners: [{
                                banner_metadata: {
                                    banner_id: 100,
                                    campaign_unit_id: 1,
                                    slot_id: 1
                                },
                                image_url: "https://cf.shopee.sg/file/3c6f8ff3d865b5c71b1090385e7b5f4d",
                                image_hash: "3c6f8ff3d865b5c71b1090385e7b5f4d",
                                target_url: "https://shopee.sg/m/tech-showdown"
                            }, {
                                banner_metadata: {
                                    banner_id: 101,
                                    campaign_unit_id: 2,
                                    slot_id: 2
                                },
                                image_url: "https://cf.shopee.sg/file/ca9152d3335b2a1e627d2ca0dbdabd70",
                                image_hash: "ca9152d3335b2a1e627d2ca0dbdabd70",
                                target_url: "https://shopee.sg/m/tech-showdown"
                            }, {
                                banner_metadata: {
                                    banner_id: 100,
                                    campaign_unit_id: 1,
                                    slot_id: 1
                                },
                                image_url: "https://cf.shopee.sg/file/3c6f8ff3d865b5c71b1090385e7b5f4d",
                                image_hash: "3c6f8ff3d865b5c71b1090385e7b5f4d",
                                target_url: "https://shopee.sg/m/tech-showdown"
                            }]
                        }]
                    }
                },
                Re = !!window.__STORYBOOK_ADDONS,
                Fe = function() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 200;
                    return new Promise((function(e) {
                        setTimeout((function() {
                            e({
                                ok: !0,
                                json: function() {
                                    return Promise.resolve(Ie)
                                }
                            })
                        }), t)
                    }))
                },
                Ue = function(t) {
                    return t.map((function(t) {
                        var e = {
                            space_key: t.space_key
                        };
                        return t.space_filter && (e.space_filter = Object.keys(t.space_filter).map((function(e) {
                            return {
                                key: e,
                                value: t.space_filter[e]
                            }
                        }))), e
                    }))
                };

            function Be() {
                return He.apply(this, arguments)
            }

            function He() {
                return (He = (0, N.Z)(T().mark((function t(e, n) {
                    var r, o, i, a, s;
                    return T().wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                if (!Re) {
                                    t.next = 9;
                                    break
                                }
                                return t.next = 3, Fe();
                            case 3:
                                return r = t.sent, t.next = 6, r.json();
                            case 6:
                                return t.t0 = t.sent, t.t1 = r.json, t.abrupt("return", {
                                    response: t.t0,
                                    json: t.t1
                                });
                            case 9:
                                return o = Ue(e), i = {
                                    spaces: o
                                }, a = JSON.stringify(i), s = Le(""), t.abrupt("return", fetch((n || "") + Me, {
                                    method: "post",
                                    credentials: "include",
                                    headers: {
                                        "Content-Type": "application/json",
                                        Accept: "application/json",
                                        "X-CSRFToken": s
                                    },
                                    body: a
                                }).then(function() {
                                    var t = (0, N.Z)(T().mark((function t(e) {
                                        var n;
                                        return T().wrap((function(t) {
                                            for (;;) switch (t.prev = t.next) {
                                                case 0:
                                                    return t.next = 2, e.json();
                                                case 2:
                                                    return n = t.sent, t.abrupt("return", new Promise((function(t) {
                                                        t({
                                                            response: n
                                                        })
                                                    })));
                                                case 4:
                                                case "end":
                                                    return t.stop()
                                            }
                                        }), t)
                                    })));
                                    return function() {
                                        return t.apply(this, arguments)
                                    }
                                }()).catch((function(t) {
                                    return new Promise((function(e) {
                                        e({
                                            error: t
                                        })
                                    }))
                                })));
                            case 14:
                            case "end":
                                return t.stop()
                        }
                    }), t)
                })))).apply(this, arguments)
            }
            var Ze = {
                bannersData: {}
            };
            var Ve = ("object" === ("undefined" == typeof window ? "undefined" : (0, r.Z)(window)) && window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ ? window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__({}) : C.qC)((0, C.md)(W.Z)),
                We = (0, C.UY)({
                    banner: function() {
                        var t, e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : Ze,
                            n = arguments.length > 1 ? arguments[1] : void 0;
                        switch (n.type) {
                            case De:
                                var r = {};
                                return null == n || null === (t = n.payload) || void 0 === t || t.filter(Boolean).forEach((function(t) {
                                    r[t.space_key] = t
                                })), (0, o.Z)((0, o.Z)({}, e), {}, {
                                    bannersData: (0, o.Z)((0, o.Z)({}, e.bannersData), r)
                                });
                            case Ae:
                                for (var i = n.payload, a = i.space_keys, s = (0, o.Z)({}, e.bannersData), l = 0; l < a.length; l++) {
                                    var u = a[l] || "";
                                    s[u] || (s[u] = {
                                        space_key: u,
                                        banners: []
                                    }), s[u].status = i.status
                                }
                                return (0, o.Z)((0, o.Z)({}, e), {}, {
                                    bannersData: s
                                });
                            default:
                                return e
                        }
                    }
                }),
                qe = ((0, C.MT)(We, Ve), function(t) {
                    var e = ke({}, t),
                        n = l(function(t) {
                            var e = Se().createRef();
                            return Se().useLayoutEffect((function() {
                                var n = e.current;
                                n && Object.keys(t).filter((function(e) {
                                    return !("number" == typeof t[e] || "string" == typeof t[e])
                                })).forEach((function(e) {
                                    n[e] = t[e]
                                }))
                            }), [t, e]), [Object.keys(t).filter((function(e) {
                                return "number" == typeof t[e] || "string" == typeof t[e]
                            })).reduce((function(e, n) {
                                return (0, o.Z)((0, o.Z)({}, e), {}, (0, i.Z)({}, n, t[n]))
                            }), {}), e]
                        }(e), 2),
                        a = n[0],
                        s = n[1],
                        u = l((0, Ee.useState)([]), 2),
                        c = u[0],
                        d = u[1],
                        h = (0, Pe.k6)();
                    return h && (window.__BANNER_SDK_HISTORY__ = h),
                        function(t, e) {
                            var n;
                            if (n = Se().__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED) {
                                var r = null;
                                (r = n.ReactCurrentDispatcher.current) && r.useServerEffect && r.useServerEffect(t, e)
                            } else Te(t, e)
                        }((0, N.Z)(T().mark((function t() {
                            var n, r, o, i, a;
                            return T().wrap((function(t) {
                                for (;;) switch (t.prev = t.next) {
                                    case 0:
                                        return t.next = 2, Be([{
                                            space_key: e.spaceKey,
                                            space_filter: e.spaceFilter
                                        }], e.baseUrl);
                                    case 2:
                                        r = t.sent, o = r.response, i = (null == o || null === (n = o.data) || void 0 === n ? void 0 : n.space_banners) || [], a = i.find((function(t) {
                                            return t.space_key === e.spaceKey
                                        })), d((null == a ? void 0 : a.banners) || []);
                                    case 7:
                                    case "end":
                                        return t.stop()
                                }
                            }), t)
                        })))), "object" === ("undefined" == typeof process ? "undefined" : (0, r.Z)(process)) && "object" === (0, r.Z)(process.versions) && void 0 !== process.versions.node ? Se().createElement("div", {
                            dangerouslySetInnerHTML: {
                                __html: lt({
                                    ratio: e.ratio,
                                    banners: c,
                                    isSsr: !0
                                }) + ""
                            }
                        }) : Se().createElement("div", {
                            style: {
                                width: "100%"
                            }
                        }, Se().createElement("shopee-carousel-stateful", ke({
                            ref: s
                        }, a), Se().createElement("div", {
                            style: {
                                paddingTop: "".concat(e.ratio ? 100 / e.ratio : 0, "%")
                            }
                        })))
                })
        },
        75963: function(t, e, n) {
            (function() {
                "use strict";
                var t;

                function e(t) {
                    var e = 0;
                    return function() {
                        return e < t.length ? {
                            done: !1,
                            value: t[e++]
                        } : {
                            done: !0
                        }
                    }
                }
                var r = "function" == typeof Object.defineProperties ? Object.defineProperty : function(t, e, n) {
                    return t == Array.prototype || t == Object.prototype || (t[e] = n.value), t
                };
                var o, i = function(t) {
                    t = ["object" == typeof globalThis && globalThis, t, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof n.g && n.g];
                    for (var e = 0; e < t.length; ++e) {
                        var r = t[e];
                        if (r && r.Math == Math) return r
                    }
                    throw Error("Cannot find global object")
                }(this);

                function a(t, e) {
                    if (e) t: {
                        var n = i;t = t.split(".");
                        for (var o = 0; o < t.length - 1; o++) {
                            var a = t[o];
                            if (!(a in n)) break t;
                            n = n[a]
                        }(e = e(o = n[t = t[t.length - 1]])) != o && null != e && r(n, t, {
                            configurable: !0,
                            writable: !0,
                            value: e
                        })
                    }
                }

                function s(t) {
                    return (t = {
                        next: t
                    })[Symbol.iterator] = function() {
                        return this
                    }, t
                }

                function l(t) {
                    var n = "undefined" != typeof Symbol && Symbol.iterator && t[Symbol.iterator];
                    return n ? n.call(t) : {
                        next: e(t)
                    }
                }

                function u(t) {
                    if (!(t instanceof Array)) {
                        t = l(t);
                        for (var e, n = []; !(e = t.next()).done;) n.push(e.value);
                        t = n
                    }
                    return t
                }
                if (a("Symbol", (function(t) {
                        function e(t, e) {
                            this.g = t, r(this, "description", {
                                configurable: !0,
                                writable: !0,
                                value: e
                            })
                        }
                        if (t) return t;
                        e.prototype.toString = function() {
                            return this.g
                        };
                        var n = 0;
                        return function t(r) {
                            if (this instanceof t) throw new TypeError("Symbol is not a constructor");
                            return new e("jscomp_symbol_" + (r || "") + "_" + n++, r)
                        }
                    })), a("Symbol.iterator", (function(t) {
                        if (t) return t;
                        t = Symbol("Symbol.iterator");
                        for (var n = "Array Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array".split(" "), o = 0; o < n.length; o++) {
                            var a = i[n[o]];
                            "function" == typeof a && "function" != typeof a.prototype[t] && r(a.prototype, t, {
                                configurable: !0,
                                writable: !0,
                                value: function() {
                                    return s(e(this))
                                }
                            })
                        }
                        return t
                    })), "function" == typeof Object.setPrototypeOf) o = Object.setPrototypeOf;
                else {
                    var c;
                    t: {
                        var d = {};
                        try {
                            d.__proto__ = {
                                a: !0
                            }, c = d.a;
                            break t
                        } catch (A) {}
                        c = !1
                    }
                    o = c ? function(t, e) {
                        if (t.__proto__ = e, t.__proto__ !== e) throw new TypeError(t + " is not extensible");
                        return t
                    } : null
                }
                var h = o;

                function f() {
                    this.u = !1, this.h = null, this.Ka = void 0, this.g = 1, this.da = 0, this.i = null
                }

                function p(t) {
                    if (t.u) throw new TypeError("Generator is already running");
                    t.u = !0
                }

                function v(t, e) {
                    t.i = {
                        Wa: e,
                        $a: !0
                    }, t.g = t.da
                }

                function m(t, e) {
                    return t.g = 3, {
                        value: e
                    }
                }

                function y(t) {
                    this.g = new f, this.h = t
                }

                function _(t, e, n, r) {
                    try {
                        var o = e.call(t.g.h, n);
                        if (!(o instanceof Object)) throw new TypeError("Iterator result " + o + " is not an object");
                        if (!o.done) return t.g.u = !1, o;
                        var i = o.value
                    } catch (e) {
                        return t.g.h = null, v(t.g, e), g(t)
                    }
                    return t.g.h = null, r.call(t.g, i), g(t)
                }

                function g(t) {
                    for (; t.g.g;) try {
                        var e = t.h(t.g);
                        if (e) return t.g.u = !1, {
                            value: e.value,
                            done: !1
                        }
                    } catch (e) {
                        t.g.Ka = void 0, v(t.g, e)
                    }
                    if (t.g.u = !1, t.g.i) {
                        if (e = t.g.i, t.g.i = null, e.$a) throw e.Wa;
                        return {
                            value: e.return,
                            done: !0
                        }
                    }
                    return {
                        value: void 0,
                        done: !0
                    }
                }

                function b(t) {
                    this.next = function(e) {
                        return p(t.g), t.g.h ? e = _(t, t.g.h.next, e, t.g.O) : (t.g.O(e), e = g(t)), e
                    }, this.throw = function(e) {
                        return p(t.g), t.g.h ? e = _(t, t.g.h.throw, e, t.g.O) : (v(t.g, e), e = g(t)), e
                    }, this.return = function(e) {
                        return function(t, e) {
                            p(t.g);
                            var n = t.g.h;
                            return n ? _(t, "return" in n ? n.return : function(t) {
                                return {
                                    value: t,
                                    done: !0
                                }
                            }, e, t.g.return) : (t.g.return(e), g(t))
                        }(t, e)
                    }, this[Symbol.iterator] = function() {
                        return this
                    }
                }

                function w(t, e) {
                    return e = new b(new y(e)), h && t.prototype && h(e, t.prototype), e
                }
                f.prototype.O = function(t) {
                    this.Ka = t
                }, f.prototype.return = function(t) {
                    this.i = {
                        return: t
                    }, this.g = this.da
                }, Array.from || (Array.from = function(t) {
                    return [].slice.call(t)
                }), Object.assign || (Object.assign = function(t) {
                    for (var e, n = [].slice.call(arguments, 1), r = 0; r < n.length; r++)
                        if (e = n[r])
                            for (var o = t, i = Object.keys(e), a = 0; a < i.length; a++) {
                                var s = i[a];
                                o[s] = e[s]
                            }
                    return t
                });
                var E = setTimeout;

                function S() {}

                function C(t) {
                    if (!(this instanceof C)) throw new TypeError("Promises must be constructed via new");
                    if ("function" != typeof t) throw new TypeError("not a function");
                    this.N = 0, this.Ea = !1, this.I = void 0, this.ba = [], P(t, this)
                }

                function N(t, e) {
                    for (; 3 === t.N;) t = t.I;
                    0 === t.N ? t.ba.push(e) : (t.Ea = !0, F((function() {
                        var n = 1 === t.N ? e.bb : e.cb;
                        if (null === n)(1 === t.N ? x : T)(e.promise, t.I);
                        else {
                            try {
                                var r = n(t.I)
                            } catch (t) {
                                return void T(e.promise, t)
                            }
                            x(e.promise, r)
                        }
                    })))
                }

                function x(t, e) {
                    try {
                        if (e === t) throw new TypeError("A promise cannot be resolved with itself.");
                        if (e && ("object" == typeof e || "function" == typeof e)) {
                            var n = e.then;
                            if (e instanceof C) return t.N = 3, t.I = e, void O(t);
                            if ("function" == typeof n) return void P(function(t, e) {
                                return function() {
                                    t.apply(e, arguments)
                                }
                            }(n, e), t)
                        }
                        t.N = 1, t.I = e, O(t)
                    } catch (e) {
                        T(t, e)
                    }
                }

                function T(t, e) {
                    t.N = 2, t.I = e, O(t)
                }

                function O(t) {
                    2 === t.N && 0 === t.ba.length && F((function() {
                        t.Ea || "undefined" != typeof console && console
                    }));
                    for (var e = 0, n = t.ba.length; e < n; e++) N(t, t.ba[e]);
                    t.ba = null
                }

                function k(t, e, n) {
                    this.bb = "function" == typeof t ? t : null, this.cb = "function" == typeof e ? e : null, this.promise = n
                }

                function P(t, e) {
                    var n = !1;
                    try {
                        t((function(t) {
                            n || (n = !0, x(e, t))
                        }), (function(t) {
                            n || (n = !0, T(e, t))
                        }))
                    } catch (t) {
                        n || (n = !0, T(e, t))
                    }
                }

                function D(t) {
                    return t && "object" == typeof t && t.constructor === C ? t : new C((function(e) {
                        e(t)
                    }))
                }
                C.prototype.catch = function(t) {
                    return this.then(null, t)
                }, C.prototype.then = function(t, e) {
                    var n = new this.constructor(S);
                    return N(this, new k(t, e, n)), n
                }, C.prototype.finally = function(t) {
                    var e = this.constructor;
                    return this.then((function(n) {
                        return e.resolve(t()).then((function() {
                            return n
                        }))
                    }), (function(n) {
                        return e.resolve(t()).then((function() {
                            return e.reject(n)
                        }))
                    }))
                };
                var A, M, j, L, I, R, F = "function" == typeof setImmediate && function(t) {
                    setImmediate(t)
                } || function(t) {
                    E(t, 0)
                };
                if (!window.Promise) {
                    window.Promise = C, C.prototype.then = C.prototype.then, C.all = function(t) {
                        return new C((function(e, n) {
                            function r(t, a) {
                                try {
                                    if (a && ("object" == typeof a || "function" == typeof a)) {
                                        var s = a.then;
                                        if ("function" == typeof s) return void s.call(a, (function(e) {
                                            r(t, e)
                                        }), n)
                                    }
                                    o[t] = a, 0 == --i && e(o)
                                } catch (t) {
                                    n(t)
                                }
                            }
                            if (!t || void 0 === t.length) return n(new TypeError("Promise.all accepts an array"));
                            var o = Array.prototype.slice.call(t);
                            if (0 === o.length) return e([]);
                            for (var i = o.length, a = 0; a < o.length; a++) r(a, o[a])
                        }))
                    }, C.race = function(t) {
                        return new C((function(e, n) {
                            if (!t || void 0 === t.length) return n(new TypeError("Promise.race accepts an array"));
                            for (var r = 0, o = t.length; r < o; r++) D(t[r]).then(e, n)
                        }))
                    }, C.resolve = D, C.reject = function(t) {
                        return new C((function(e, n) {
                            n(t)
                        }))
                    };
                    var U = document.createTextNode(""),
                        B = [];
                    new MutationObserver((function() {
                        for (var t = B.length, e = 0; e < t; e++) B[e]();
                        B.splice(0, t)
                    })).observe(U, {
                        characterData: !0
                    }), F = function(t) {
                        B.push(t), U.textContent = 0 < U.textContent.length ? "" : "a"
                    }
                }! function(t, e) {
                    if (!(e in t)) {
                        var r = typeof n.g == typeof r ? window : n.g,
                            o = 0,
                            i = String(Math.random()),
                            a = "__symbol@@" + i,
                            s = t.getOwnPropertyNames,
                            l = t.getOwnPropertyDescriptor,
                            u = t.create,
                            c = t.keys,
                            d = t.freeze || t,
                            h = t.defineProperty,
                            f = t.defineProperties,
                            p = l(t, "getOwnPropertyNames"),
                            v = t.prototype,
                            m = v.hasOwnProperty,
                            y = v.propertyIsEnumerable,
                            _ = v.toString,
                            g = function(t, e, n) {
                                m.call(t, a) || h(t, a, {
                                    enumerable: !1,
                                    configurable: !1,
                                    writable: !1,
                                    value: {}
                                }), t[a]["@@" + e] = n
                            },
                            b = function(t, e) {
                                var n = u(t);
                                return s(e).forEach((function(t) {
                                    C.call(e, t) && P(n, t, e[t])
                                })), n
                            },
                            w = function() {},
                            E = function(t) {
                                return t != a && !m.call(T, t)
                            },
                            S = function(t) {
                                return t != a && m.call(T, t)
                            },
                            C = function(t) {
                                var e = String(t);
                                return S(e) ? m.call(this, e) && !!this[a] && this[a]["@@" + e] : y.call(this, t)
                            },
                            N = function(e) {
                                return h(v, e, {
                                    enumerable: !1,
                                    configurable: !0,
                                    get: w,
                                    set: function(t) {
                                        A(this, e, {
                                            enumerable: !1,
                                            configurable: !0,
                                            writable: !0,
                                            value: t
                                        }), g(this, e, !0)
                                    }
                                }), T[e] = h(t(e), "constructor", O), d(T[e])
                            },
                            x = function t(e) {
                                if (this instanceof t) throw new TypeError("Symbol is not a constructor");
                                return N("__symbol:".concat(e || "", i, ++o))
                            },
                            T = u(null),
                            O = {
                                value: x
                            },
                            k = function(t) {
                                return T[t]
                            },
                            P = function(t, e, n) {
                                var r = String(e);
                                if (S(r)) {
                                    if (e = A, n.enumerable) {
                                        var o = u(n);
                                        o.enumerable = !1
                                    } else o = n;
                                    e(t, r, o), g(t, r, !!n.enumerable)
                                } else h(t, e, n);
                                return t
                            },
                            D = function(t) {
                                return s(t).filter(S).map(k)
                            };
                        p.value = P, h(t, "defineProperty", p), p.value = D, h(t, e, p), p.value = function(t) {
                            return s(t).filter(E)
                        }, h(t, "getOwnPropertyNames", p), p.value = function(t, e) {
                            var n = D(e);
                            return n.length ? c(e).concat(n).forEach((function(n) {
                                C.call(e, n) && P(t, n, e[n])
                            })) : f(t, e), t
                        }, h(t, "defineProperties", p), p.value = C, h(v, "propertyIsEnumerable", p), p.value = x, h(r, "Symbol", p), p.value = function(t) {
                            return (t = "__symbol:".concat("__symbol:", t, i)) in v ? T[t] : N(t)
                        }, h(x, "for", p), p.value = function(t) {
                            if (E(t)) throw new TypeError(t + " is not a symbol");
                            if (m.call(T, t) && ("__symbol:" === (t = t.slice(10)).slice(0, 10) && (t = t.slice(10)) !== i)) return 0 < (t = t.slice(0, t.length - i.length)).length ? t : void 0
                        }, h(x, "keyFor", p), p.value = function(t, e) {
                            var n = l(t, e);
                            return n && S(e) && (n.enumerable = C.call(t, e)), n
                        }, h(t, "getOwnPropertyDescriptor", p), p.value = function(t, e) {
                            return 1 === arguments.length || void 0 === e ? u(t) : b(t, e)
                        }, h(t, "create", p), p.value = function() {
                            var t = _.call(this);
                            return "[object String]" === t && S(this) ? "[object Symbol]" : t
                        }, h(v, "toString", p);
                        try {
                            if (!0 !== u(h({}, "__symbol:", {
                                    get: function() {
                                        return h(this, "__symbol:", {
                                            value: !0
                                        })["__symbol:"]
                                    }
                                }))["__symbol:"]) throw "IE11";
                            var A = h
                        } catch (t) {
                            A = function(t, e, n) {
                                var r = l(v, e);
                                delete v[e], h(t, e, n), h(v, e, r)
                            }
                        }
                    }
                }(Object, "getOwnPropertySymbols"), A = Object, M = Symbol, L = A.defineProperty, I = A.prototype, R = I.toString, "iterator match replace search split hasInstance isConcatSpreadable unscopables species toPrimitive toStringTag".split(" ").forEach((function(t) {
                        t in M || (L(M, t, {
                            value: M(t)
                        }), "toStringTag" === t && ((j = A.getOwnPropertyDescriptor(I, "toString")).value = function() {
                            var t = R.call(this),
                                e = null == this ? this : this[M.toStringTag];
                            return null == e ? t : "[object " + e + "]"
                        }, L(I, "toString", j)))
                    })),
                    function(t, e, n) {
                        function r() {
                            return this
                        }
                        e[t] || (e[t] = function() {
                            var e = 0,
                                n = this,
                                o = {
                                    next: function() {
                                        var t = n.length <= e;
                                        return t ? {
                                            done: t
                                        } : {
                                            done: t,
                                            value: n[e++]
                                        }
                                    }
                                };
                            return o[t] = r, o
                        }), n[t] || (n[t] = function() {
                            var e = String.fromCodePoint,
                                n = this,
                                o = 0,
                                i = n.length,
                                a = {
                                    next: function() {
                                        var t = i <= o,
                                            r = t ? "" : e(n.codePointAt(o));
                                        return o += r.length, t ? {
                                            done: t
                                        } : {
                                            done: t,
                                            value: r
                                        }
                                    }
                                };
                            return a[t] = r, a
                        })
                    }(Symbol.iterator, Array.prototype, String.prototype);
                var H = Object.prototype.toString;
                Object.prototype.toString = function() {
                    return void 0 === this ? "[object Undefined]" : null === this ? "[object Null]" : H.call(this)
                }, Object.keys = function(t) {
                    return Object.getOwnPropertyNames(t).filter((function(e) {
                        return (e = Object.getOwnPropertyDescriptor(t, e)) && e.enumerable
                    }))
                }, String.prototype[Symbol.iterator] && String.prototype.codePointAt || (String.prototype[Symbol.iterator] = function t() {
                    var e, n = this;
                    return w(t, (function(t) {
                        if (1 == t.g && (e = 0), 3 != t.g) return e < n.length ? t = m(t, n[e]) : (t.g = 0, t = void 0), t;
                        e++, t.g = 2
                    }))
                }), Set.prototype[Symbol.iterator] || (Set.prototype[Symbol.iterator] = function t() {
                    var e, n, r = this;
                    return w(t, (function(t) {
                        if (1 == t.g && (e = [], r.forEach((function(t) {
                                e.push(t)
                            })), n = 0), 3 != t.g) return n < e.length ? t = m(t, e[n]) : (t.g = 0, t = void 0), t;
                        n++, t.g = 2
                    }))
                }), Map.prototype[Symbol.iterator] || (Map.prototype[Symbol.iterator] = function t() {
                    var e, n, r = this;
                    return w(t, (function(t) {
                        if (1 == t.g && (e = [], r.forEach((function(t, n) {
                                e.push([n, t])
                            })), n = 0), 3 != t.g) return n < e.length ? t = m(t, e[n]) : (t.g = 0, t = void 0), t;
                        n++, t.g = 2
                    }))
                });
                var Z = document.createEvent("Event");
                if (Z.initEvent("foo", !0, !0), Z.preventDefault(), !Z.defaultPrevented) {
                    var V = Event.prototype.preventDefault;
                    Event.prototype.preventDefault = function() {
                        this.cancelable && (V.call(this), Object.defineProperty(this, "defaultPrevented", {
                            get: function() {
                                return !0
                            },
                            configurable: !0
                        }))
                    }
                }
                var W = /Trident/.test(navigator.userAgent);
                if (!window.Event || W && "function" != typeof window.Event) {
                    var q = window.Event;
                    if (window.Event = function(t, e) {
                            e = e || {};
                            var n = document.createEvent("Event");
                            return n.initEvent(t, !!e.bubbles, !!e.cancelable), n
                        }, q) {
                        for (var z in q) window.Event[z] = q[z];
                        window.Event.prototype = q.prototype
                    }
                }
                if ((!window.CustomEvent || W && "function" != typeof window.CustomEvent) && (window.CustomEvent = function(t, e) {
                        e = e || {};
                        var n = document.createEvent("CustomEvent");
                        return n.initCustomEvent(t, !!e.bubbles, !!e.cancelable, e.detail), n
                    }, window.CustomEvent.prototype = window.Event.prototype), !window.MouseEvent || W && "function" != typeof window.MouseEvent) {
                    var G = window.MouseEvent;
                    if (window.MouseEvent = function(t, e) {
                            e = e || {};
                            var n = document.createEvent("MouseEvent");
                            return n.initMouseEvent(t, !!e.bubbles, !!e.cancelable, e.view || window, e.detail, e.screenX, e.screenY, e.clientX, e.clientY, e.ctrlKey, e.altKey, e.shiftKey, e.metaKey, e.button, e.relatedTarget), n
                        }, G)
                        for (var X in G) window.MouseEvent[X] = G[X];
                    window.MouseEvent.prototype = G.prototype
                }
                Object.getOwnPropertyDescriptor(Node.prototype, "baseURI") || Object.defineProperty(Node.prototype, "baseURI", {
                    get: function() {
                        var t = (this.ownerDocument || this).querySelector("base[href]");
                        return t && t.href || window.location.href
                    },
                    configurable: !0,
                    enumerable: !0
                });
                var K, Y, J = Element.prototype,
                    $ = null !== (K = Object.getOwnPropertyDescriptor(J, "attributes")) && void 0 !== K ? K : Object.getOwnPropertyDescriptor(Node.prototype, "attributes"),
                    Q = null !== (Y = null == $ ? void 0 : $.get) && void 0 !== Y ? Y : function() {
                        return this.attributes
                    },
                    tt = Array.prototype.map;
                J.hasOwnProperty("getAttributeNames") || (J.getAttributeNames = function() {
                    return tt.call(Q.call(this), (function(t) {
                        return t.name
                    }))
                });
                var et, nt = Element.prototype;
                nt.hasOwnProperty("matches") || (nt.matches = null !== (et = nt.webkitMatchesSelector) && void 0 !== et ? et : nt.msMatchesSelector);
                var rt = Node.prototype.appendChild;

                function ot(t) {
                    (t = t.prototype).hasOwnProperty("append") || Object.defineProperty(t, "append", {
                        configurable: !0,
                        enumerable: !0,
                        writable: !0,
                        value: function(t) {
                            for (var e = [], n = 0; n < arguments.length; ++n) e[n] = arguments[n];
                            for (n = (e = l(e)).next(); !n.done; n = e.next()) n = n.value, rt.call(this, "string" == typeof n ? document.createTextNode(n) : n)
                        }
                    })
                }
                ot(Document), ot(DocumentFragment), ot(Element);
                var it, at, st = Node.prototype.insertBefore,
                    lt = null !== (at = null === (it = Object.getOwnPropertyDescriptor(Node.prototype, "firstChild")) || void 0 === it ? void 0 : it.get) && void 0 !== at ? at : function() {
                        return this.firstChild
                    };

                function ut(t) {
                    (t = t.prototype).hasOwnProperty("prepend") || Object.defineProperty(t, "prepend", {
                        configurable: !0,
                        enumerable: !0,
                        writable: !0,
                        value: function(t) {
                            for (var e = [], n = 0; n < arguments.length; ++n) e[n] = arguments[n];
                            n = lt.call(this);
                            for (var r = (e = l(e)).next(); !r.done; r = e.next()) r = r.value, st.call(this, "string" == typeof r ? document.createTextNode(r) : r, n)
                        }
                    })
                }
                ut(Document), ut(DocumentFragment), ut(Element);
                var ct, dt, ht = Node.prototype.appendChild,
                    ft = Node.prototype.removeChild,
                    pt = null !== (dt = null === (ct = Object.getOwnPropertyDescriptor(Node.prototype, "firstChild")) || void 0 === ct ? void 0 : ct.get) && void 0 !== dt ? dt : function() {
                        return this.firstChild
                    };

                function vt(t) {
                    (t = t.prototype).hasOwnProperty("replaceChildren") || Object.defineProperty(t, "replaceChildren", {
                        configurable: !0,
                        enumerable: !0,
                        writable: !0,
                        value: function(t) {
                            for (var e = [], n = 0; n < arguments.length; ++n) e[n] = arguments[n];
                            for (; null !== (n = pt.call(this));) ft.call(this, n);
                            for (n = (e = l(e)).next(); !n.done; n = e.next()) n = n.value, ht.call(this, "string" == typeof n ? document.createTextNode(n) : n)
                        }
                    })
                }
                vt(Document), vt(DocumentFragment), vt(Element);
                var mt, yt, _t, gt, bt = Node.prototype.insertBefore,
                    wt = null !== (yt = null === (mt = Object.getOwnPropertyDescriptor(Node.prototype, "parentNode")) || void 0 === mt ? void 0 : mt.get) && void 0 !== yt ? yt : function() {
                        return this.parentNode
                    },
                    Et = null !== (gt = null === (_t = Object.getOwnPropertyDescriptor(Node.prototype, "nextSibling")) || void 0 === _t ? void 0 : _t.get) && void 0 !== gt ? gt : function() {
                        return this.nextSibling
                    };

                function St(t) {
                    (t = t.prototype).hasOwnProperty("after") || Object.defineProperty(t, "after", {
                        configurable: !0,
                        enumerable: !0,
                        writable: !0,
                        value: function(t) {
                            for (var e = [], n = 0; n < arguments.length; ++n) e[n] = arguments[n];
                            if (null !== (n = wt.call(this)))
                                for (var r = Et.call(this), o = (e = l(e)).next(); !o.done; o = e.next()) o = o.value, bt.call(n, "string" == typeof o ? document.createTextNode(o) : o, r)
                        }
                    })
                }
                St(CharacterData), St(Element);
                var Ct, Nt, xt = Node.prototype.insertBefore,
                    Tt = null !== (Nt = null === (Ct = Object.getOwnPropertyDescriptor(Node.prototype, "parentNode")) || void 0 === Ct ? void 0 : Ct.get) && void 0 !== Nt ? Nt : function() {
                        return this.parentNode
                    };

                function Ot(t) {
                    (t = t.prototype).hasOwnProperty("before") || Object.defineProperty(t, "before", {
                        configurable: !0,
                        enumerable: !0,
                        writable: !0,
                        value: function(t) {
                            for (var e = [], n = 0; n < arguments.length; ++n) e[n] = arguments[n];
                            if (null !== (n = Tt.call(this)))
                                for (var r = (e = l(e)).next(); !r.done; r = e.next()) r = r.value, xt.call(n, "string" == typeof r ? document.createTextNode(r) : r, this)
                        }
                    })
                }
                Ot(CharacterData), Ot(Element);
                var kt, Pt, Dt = Node.prototype.removeChild,
                    At = null !== (Pt = null === (kt = Object.getOwnPropertyDescriptor(Node.prototype, "parentNode")) || void 0 === kt ? void 0 : kt.get) && void 0 !== Pt ? Pt : function() {
                        return this.parentNode
                    };

                function Mt(t) {
                    (t = t.prototype).hasOwnProperty("remove") || Object.defineProperty(t, "remove", {
                        configurable: !0,
                        enumerable: !0,
                        writable: !0,
                        value: function() {
                            var t = At.call(this);
                            t && Dt.call(t, this)
                        }
                    })
                }
                Mt(CharacterData), Mt(Element);
                var jt, Lt, It = Node.prototype.insertBefore,
                    Rt = Node.prototype.removeChild,
                    Ft = null !== (Lt = null === (jt = Object.getOwnPropertyDescriptor(Node.prototype, "parentNode")) || void 0 === jt ? void 0 : jt.get) && void 0 !== Lt ? Lt : function() {
                        return this.parentNode
                    };

                function Ut(t) {
                    (t = t.prototype).hasOwnProperty("replaceWith") || Object.defineProperty(t, "replaceWith", {
                        configurable: !0,
                        enumerable: !0,
                        writable: !0,
                        value: function(t) {
                            for (var e = [], n = 0; n < arguments.length; ++n) e[n] = arguments[n];
                            if (null !== (n = Ft.call(this))) {
                                for (var r = (e = l(e)).next(); !r.done; r = e.next()) r = r.value, It.call(n, "string" == typeof r ? document.createTextNode(r) : r, this);
                                Rt.call(n, this)
                            }
                        }
                    })
                }
                Ut(CharacterData), Ut(Element);
                var Bt = window.Element.prototype,
                    Ht = window.HTMLElement.prototype,
                    Zt = window.SVGElement.prototype;
                !Ht.hasOwnProperty("classList") || Bt.hasOwnProperty("classList") || Zt.hasOwnProperty("classList") || Object.defineProperty(Bt, "classList", Object.getOwnPropertyDescriptor(Ht, "classList"));
                var Vt = document.createElement("style");
                Vt.textContent = "body {transition: opacity ease-in 0.2s; } \nbody[unresolved] {opacity: 0; display: block; overflow: hidden; position: relative; } \n";
                var Wt = document.querySelector("head");
                Wt.insertBefore(Vt, Wt.firstChild);
                var qt = window;
                qt.WebComponents = qt.WebComponents || {
                    flags: {}
                };
                var zt = document.querySelector('script[src*="webcomponents-bundle"]'),
                    Gt = /wc-(.+)/,
                    Xt = {};
                if (!Xt.noOpts) {
                    if (location.search.slice(1).split("&").forEach((function(t) {
                            var e;
                            (t = t.split("="))[0] && (e = t[0].match(Gt)) && (Xt[e[1]] = t[1] || !0)
                        })), zt)
                        for (var Kt = 0, Yt = void 0; Yt = zt.attributes[Kt]; Kt++) "src" !== Yt.name && (Xt[Yt.name] = Yt.value || !0);
                    var Jt = {};
                    Xt.log && Xt.log.split && Xt.log.split(",").forEach((function(t) {
                        Jt[t] = !0
                    })), Xt.log = Jt
                }
                qt.WebComponents.flags = Xt;
                var $t = Xt.shadydom;
                if ($t) {
                    qt.ShadyDOM = qt.ShadyDOM || {}, qt.ShadyDOM.force = $t;
                    var Qt = Xt.noPatch;
                    qt.ShadyDOM.noPatch = "true" === Qt || Qt
                }
                var te = Xt.register || Xt.ce;

                function ee() {}

                function ne(t) {
                    return t.__shady || (t.__shady = new ee), t.__shady
                }

                function re(t) {
                    return t && t.__shady
                }
                te && window.customElements && (qt.customElements.forcePolyfill = te),
                    function() {
                        function t() {}

                        function e(t, e) {
                            if (!t.childNodes.length) return [];
                            switch (t.nodeType) {
                                case Node.DOCUMENT_NODE:
                                    return v.call(t, e);
                                case Node.DOCUMENT_FRAGMENT_NODE:
                                    return m.call(t, e);
                                default:
                                    return p.call(t, e)
                            }
                        }
                        var n = "undefined" == typeof HTMLTemplateElement,
                            r = !(document.createDocumentFragment().cloneNode() instanceof DocumentFragment),
                            o = !1;
                        /Trident/.test(navigator.userAgent) && function() {
                            function t(t, e) {
                                if (t instanceof DocumentFragment)
                                    for (var r; r = t.firstChild;) n.call(this, r, e);
                                else n.call(this, t, e);
                                return t
                            }
                            o = !0;
                            var e = Node.prototype.cloneNode;
                            Node.prototype.cloneNode = function(t) {
                                return t = e.call(this, t), this instanceof DocumentFragment && (t.__proto__ = DocumentFragment.prototype), t
                            }, DocumentFragment.prototype.querySelectorAll = HTMLElement.prototype.querySelectorAll, DocumentFragment.prototype.querySelector = HTMLElement.prototype.querySelector, Object.defineProperties(DocumentFragment.prototype, {
                                nodeType: {
                                    get: function() {
                                        return Node.DOCUMENT_FRAGMENT_NODE
                                    },
                                    configurable: !0
                                },
                                localName: {
                                    get: function() {},
                                    configurable: !0
                                },
                                nodeName: {
                                    get: function() {
                                        return "#document-fragment"
                                    },
                                    configurable: !0
                                }
                            });
                            var n = Node.prototype.insertBefore;
                            Node.prototype.insertBefore = t;
                            var r = Node.prototype.appendChild;
                            Node.prototype.appendChild = function(e) {
                                return e instanceof DocumentFragment ? t.call(this, e, null) : r.call(this, e), e
                            };
                            var i = Node.prototype.removeChild,
                                a = Node.prototype.replaceChild;
                            Node.prototype.replaceChild = function(e, n) {
                                return e instanceof DocumentFragment ? (t.call(this, e, n), i.call(this, n)) : a.call(this, e, n), n
                            }, Document.prototype.createDocumentFragment = function() {
                                var t = this.createElement("df");
                                return t.__proto__ = DocumentFragment.prototype, t
                            };
                            var s = Document.prototype.importNode;
                            Document.prototype.importNode = function(t, e) {
                                return e = s.call(this, t, e || !1), t instanceof DocumentFragment && (e.__proto__ = DocumentFragment.prototype), e
                            }
                        }();
                        var i = Node.prototype.cloneNode,
                            a = Document.prototype.createElement,
                            s = Document.prototype.importNode,
                            l = Node.prototype.removeChild,
                            u = Node.prototype.appendChild,
                            c = Node.prototype.replaceChild,
                            d = DOMParser.prototype.parseFromString,
                            h = Object.getOwnPropertyDescriptor(window.HTMLElement.prototype, "innerHTML") || {
                                get: function() {
                                    return this.innerHTML
                                },
                                set: function(t) {
                                    this.innerHTML = t
                                }
                            },
                            f = Object.getOwnPropertyDescriptor(window.Node.prototype, "childNodes") || {
                                get: function() {
                                    return this.childNodes
                                }
                            },
                            p = Element.prototype.querySelectorAll,
                            v = Document.prototype.querySelectorAll,
                            m = DocumentFragment.prototype.querySelectorAll,
                            y = function() {
                                if (!n) {
                                    var t = document.createElement("template"),
                                        e = document.createElement("template");
                                    return e.content.appendChild(document.createElement("div")), t.content.appendChild(e), 0 === (t = t.cloneNode(!0)).content.childNodes.length || 0 === t.content.firstChild.content.childNodes.length || r
                                }
                            }();
                        if (n) {
                            var _ = document.implementation.createHTMLDocument("template"),
                                g = !0,
                                b = document.createElement("style");
                            b.textContent = "template{display:none;}";
                            var w = document.head;
                            w.insertBefore(b, w.firstElementChild), t.prototype = Object.create(HTMLElement.prototype);
                            var E = !document.createElement("div").hasOwnProperty("innerHTML");
                            t.Z = function(e) {
                                if (!e.content && e.namespaceURI === document.documentElement.namespaceURI) {
                                    e.content = _.createDocumentFragment();
                                    for (var n; n = e.firstChild;) u.call(e.content, n);
                                    if (E) e.__proto__ = t.prototype;
                                    else if (e.cloneNode = function(e) {
                                            return t.sa(this, e)
                                        }, g) try {
                                        C(e), N(e)
                                    } catch (t) {
                                        g = !1
                                    }
                                    t.bootstrap(e.content)
                                }
                            };
                            var S = {
                                    option: ["select"],
                                    thead: ["table"],
                                    col: ["colgroup", "table"],
                                    tr: ["tbody", "table"],
                                    th: ["tr", "tbody", "table"],
                                    td: ["tr", "tbody", "table"]
                                },
                                C = function(e) {
                                    Object.defineProperty(e, "innerHTML", {
                                        get: function() {
                                            return D(this)
                                        },
                                        set: function(e) {
                                            var n = S[(/<([a-z][^/\0>\x20\t\r\n\f]+)/i.exec(e) || ["", ""])[1].toLowerCase()];
                                            if (n)
                                                for (var r = 0; r < n.length; r++) e = "<" + n[r] + ">" + e + "</" + n[r] + ">";
                                            for (_.body.innerHTML = e, t.bootstrap(_); this.content.firstChild;) l.call(this.content, this.content.firstChild);
                                            if (e = _.body, n)
                                                for (r = 0; r < n.length; r++) e = e.lastChild;
                                            for (; e.firstChild;) u.call(this.content, e.firstChild)
                                        },
                                        configurable: !0
                                    })
                                },
                                N = function(t) {
                                    Object.defineProperty(t, "outerHTML", {
                                        get: function() {
                                            return "<template>" + this.innerHTML + "</template>"
                                        },
                                        set: function(t) {
                                            if (!this.parentNode) throw Error("Failed to set the 'outerHTML' property on 'Element': This element has no parent node.");
                                            for (_.body.innerHTML = t, t = this.ownerDocument.createDocumentFragment(); _.body.firstChild;) u.call(t, _.body.firstChild);
                                            c.call(this.parentNode, t, this)
                                        },
                                        configurable: !0
                                    })
                                };
                            C(t.prototype), N(t.prototype), t.bootstrap = function(n) {
                                for (var r, o = 0, i = (n = e(n, "template")).length; o < i && (r = n[o]); o++) t.Z(r)
                            }, document.addEventListener("DOMContentLoaded", (function() {
                                t.bootstrap(document)
                            })), Document.prototype.createElement = function() {
                                var e = a.apply(this, arguments);
                                return "template" === e.localName && t.Z(e), e
                            }, DOMParser.prototype.parseFromString = function() {
                                var e = d.apply(this, arguments);
                                return t.bootstrap(e), e
                            }, Object.defineProperty(HTMLElement.prototype, "innerHTML", {
                                get: function() {
                                    return D(this)
                                },
                                set: function(e) {
                                    h.set.call(this, e), t.bootstrap(this)
                                },
                                configurable: !0,
                                enumerable: !0
                            });
                            var x = /[&\u00A0"]/g,
                                T = /[&\u00A0<>]/g,
                                O = function(t) {
                                    switch (t) {
                                        case "&":
                                            return "&amp;";
                                        case "<":
                                            return "&lt;";
                                        case ">":
                                            return "&gt;";
                                        case '"':
                                            return "&quot;";
                                        case " ":
                                            return "&nbsp;"
                                    }
                                },
                                k = (b = function(t) {
                                    for (var e = {}, n = 0; n < t.length; n++) e[t[n]] = !0;
                                    return e
                                })("area base br col command embed hr img input keygen link meta param source track wbr".split(" ")),
                                P = b("style script xmp iframe noembed noframes plaintext noscript".split(" ")),
                                D = function t(e, n) {
                                    "template" === e.localName && (e = e.content);
                                    for (var r, o = "", i = n ? n(e) : f.get.call(e), a = 0, s = i.length; a < s && (r = i[a]); a++) {
                                        t: {
                                            var l = r,
                                                u = e,
                                                c = n;
                                            switch (l.nodeType) {
                                                case Node.ELEMENT_NODE:
                                                    for (var d = l.localName, h = "<" + d, p = l.attributes, v = 0; u = p[v]; v++) h += " " + u.name + '="' + u.value.replace(x, O) + '"';
                                                    h += ">", l = k[d] ? h : h + t(l, c) + "</" + d + ">";
                                                    break t;
                                                case Node.TEXT_NODE:
                                                    l = l.data, l = u && P[u.localName] ? l : l.replace(T, O);
                                                    break t;
                                                case Node.COMMENT_NODE:
                                                    l = "\x3c!--" + l.data + "--\x3e";
                                                    break t;
                                                default:
                                                    throw window.console.error(l), Error("not implemented")
                                            }
                                        }
                                        o += l
                                    }
                                    return o
                                }
                        }
                        if (n || y) {
                            t.sa = function(t, e) {
                                var n = i.call(t, !1);
                                return this.Z && this.Z(n), e && (u.call(n.content, i.call(t.content, !0)), A(n.content, t.content)), n
                            };
                            var A = function(n, r) {
                                    if (r.querySelectorAll && 0 !== (r = e(r, "template")).length)
                                        for (var o, i, a = 0, s = (n = e(n, "template")).length; a < s; a++) i = r[a], o = n[a], t && t.Z && t.Z(i), c.call(o.parentNode, M.call(i, !0), o)
                                },
                                M = Node.prototype.cloneNode = function(e) {
                                    if (!o && r && this instanceof DocumentFragment) {
                                        if (!e) return this.ownerDocument.createDocumentFragment();
                                        var n = j.call(this.ownerDocument, this, !0)
                                    } else n = this.nodeType === Node.ELEMENT_NODE && "template" === this.localName && this.namespaceURI == document.documentElement.namespaceURI ? t.sa(this, e) : i.call(this, e);
                                    return e && A(n, this), n
                                },
                                j = Document.prototype.importNode = function(n, r) {
                                    if (r = r || !1, "template" === n.localName) return t.sa(n, r);
                                    var o = s.call(this, n, r);
                                    if (r) {
                                        A(o, n), n = e(o, 'script:not([type]),script[type="application/javascript"],script[type="text/javascript"]');
                                        for (var i, l = 0; l < n.length; l++) {
                                            i = n[l], (r = a.call(document, "script")).textContent = i.textContent;
                                            for (var u, d = i.attributes, h = 0; h < d.length; h++) u = d[h], r.setAttribute(u.name, u.value);
                                            c.call(i.parentNode, r, i)
                                        }
                                    }
                                    return o
                                }
                        }
                        n && (window.HTMLTemplateElement = t)
                    }(), ee.prototype.toJSON = function() {
                        return {}
                    };
                var oe = window.ShadyDOM || {};
                oe.Ya = !(!Element.prototype.attachShadow || !Node.prototype.getRootNode);
                var ie = Object.getOwnPropertyDescriptor(Node.prototype, "firstChild");

                function ae() {
                    return Document.prototype.msElementsFromPoint ? "msElementsFromPoint" : "elementsFromPoint"
                }

                function se(t) {
                    return (t = re(t)) && void 0 !== t.firstChild
                }

                function le(t) {
                    return t instanceof ShadowRoot
                }

                function ue(t) {
                    return (t = (t = re(t)) && t.root) && Kr(t)
                }
                oe.H = !!(ie && ie.configurable && ie.get), oe.ya = oe.force || !oe.Ya, oe.J = oe.noPatch || !1, oe.fa = oe.preferPerformance, oe.Aa = "on-demand" === oe.J, oe.Na = navigator.userAgent.match("Trident");
                var ce = Element.prototype,
                    de = ce.matches || ce.matchesSelector || ce.mozMatchesSelector || ce.msMatchesSelector || ce.oMatchesSelector || ce.webkitMatchesSelector,
                    he = document.createTextNode(""),
                    fe = 0,
                    pe = [];

                function ve(t) {
                    pe.push(t), he.textContent = fe++
                }
                new MutationObserver((function() {
                    for (; pe.length;) try {
                        pe.shift()()
                    } catch (t) {
                        throw he.textContent = fe++, t
                    }
                })).observe(he, {
                    characterData: !0
                });
                var me = document.contains ? function(t, e) {
                    return t.__shady_native_contains(e)
                } : function(t, e) {
                    return t === e || t.documentElement && t.documentElement.__shady_native_contains(e)
                };

                function ye(t, e) {
                    for (; e;) {
                        if (e == t) return !0;
                        e = e.__shady_parentNode
                    }
                    return !1
                }

                function _e(t) {
                    for (var e = t.length - 1; 0 <= e; e--) {
                        var n = t[e],
                            r = n.getAttribute("id") || n.getAttribute("name");
                        r && "length" !== r && isNaN(r) && (t[r] = n)
                    }
                    return t.item = function(e) {
                        return t[e]
                    }, t.namedItem = function(e) {
                        if ("length" !== e && isNaN(e) && t[e]) return t[e];
                        for (var n = l(t), r = n.next(); !r.done; r = n.next())
                            if (((r = r.value).getAttribute("id") || r.getAttribute("name")) == e) return r;
                        return null
                    }, t
                }

                function ge(t) {
                    var e = [];
                    for (t = t.__shady_native_firstChild; t; t = t.__shady_native_nextSibling) e.push(t);
                    return e
                }

                function be(t) {
                    var e = [];
                    for (t = t.__shady_firstChild; t; t = t.__shady_nextSibling) e.push(t);
                    return e
                }

                function we(t, e, n) {
                    if (n.configurable = !0, n.value) t[e] = n.value;
                    else try {
                        Object.defineProperty(t, e, n)
                    } catch (t) {}
                }

                function Ee(t, e, n, r) {
                    for (var o in n = void 0 === n ? "" : n, e) r && 0 <= r.indexOf(o) || we(t, n + o, e[o])
                }

                function Se(t, e) {
                    for (var n in e) n in t && we(t, n, e[n])
                }

                function Ce(t) {
                    var e = {};
                    return Object.getOwnPropertyNames(t).forEach((function(n) {
                        e[n] = Object.getOwnPropertyDescriptor(t, n)
                    })), e
                }

                function Ne(t, e) {
                    for (var n, r = Object.getOwnPropertyNames(e), o = 0; o < r.length; o++) t[n = r[o]] = e[n]
                }

                function xe(t) {
                    return t instanceof Node ? t : document.createTextNode("" + t)
                }

                function Te(t) {
                    for (var e = [], n = 0; n < arguments.length; ++n) e[n] = arguments[n];
                    if (1 === e.length) return xe(e[0]);
                    n = document.createDocumentFragment();
                    for (var r = (e = l(e)).next(); !r.done; r = e.next()) n.appendChild(xe(r.value));
                    return n
                }
                var Oe, ke = [];

                function Pe(t) {
                    Oe || (Oe = !0, ve(De)), ke.push(t)
                }

                function De() {
                    Oe = !1;
                    for (var t = !!ke.length; ke.length;) ke.shift()();
                    return t
                }

                function Ae() {
                    this.g = !1, this.addedNodes = [], this.removedNodes = [], this.oa = new Set
                }
                De.list = ke, Ae.prototype.flush = function() {
                    if (this.g) {
                        this.g = !1;
                        var t = this.takeRecords();
                        t.length && this.oa.forEach((function(e) {
                            e(t)
                        }))
                    }
                }, Ae.prototype.takeRecords = function() {
                    if (this.addedNodes.length || this.removedNodes.length) {
                        var t = [{
                            addedNodes: this.addedNodes,
                            removedNodes: this.removedNodes
                        }];
                        return this.addedNodes = [], this.removedNodes = [], t
                    }
                    return []
                };
                var Me = /[&\u00A0"]/g,
                    je = /[&\u00A0<>]/g;

                function Le(t) {
                    switch (t) {
                        case "&":
                            return "&amp;";
                        case "<":
                            return "&lt;";
                        case ">":
                            return "&gt;";
                        case '"':
                            return "&quot;";
                        case " ":
                            return "&nbsp;"
                    }
                }

                function Ie(t) {
                    for (var e = {}, n = 0; n < t.length; n++) e[t[n]] = !0;
                    return e
                }
                var Re = Ie("area base br col command embed hr img input keygen link meta param source track wbr".split(" ")),
                    Fe = Ie("style script xmp iframe noembed noframes plaintext noscript".split(" "));

                function Ue(t, e) {
                    "template" === t.localName && (t = t.content);
                    for (var n = "", r = e ? e(t) : t.childNodes, o = 0, i = r.length, a = void 0; o < i && (a = r[o]); o++) {
                        t: {
                            var s = a,
                                l = t,
                                u = e;
                            switch (s.nodeType) {
                                case Node.ELEMENT_NODE:
                                    for (var c, d = "<" + (l = s.localName), h = s.attributes, f = 0; c = h[f]; f++) d += " " + c.name + '="' + c.value.replace(Me, Le) + '"';
                                    d += ">", s = Re[l] ? d : d + Ue(s, u) + "</" + l + ">";
                                    break t;
                                case Node.TEXT_NODE:
                                    s = s.data, s = l && Fe[l.localName] ? s : s.replace(je, Le);
                                    break t;
                                case Node.COMMENT_NODE:
                                    s = "\x3c!--" + s.data + "--\x3e";
                                    break t;
                                default:
                                    throw window.console.error(s), Error("not implemented")
                            }
                        }
                        n += s
                    }
                    return n
                }
                var Be = oe.H,
                    He = {
                        querySelector: function(t) {
                            return this.__shady_native_querySelector(t)
                        },
                        querySelectorAll: function(t) {
                            return this.__shady_native_querySelectorAll(t)
                        }
                    },
                    Ze = {};

                function Ve(t) {
                    Ze[t] = function(e) {
                        return e["__shady_native_" + t]
                    }
                }

                function We(t, e) {
                    for (var n in Ee(t, e, "__shady_native_"), e) Ve(n)
                }

                function qe(t, e) {
                    e = void 0 === e ? [] : e;
                    for (var n = 0; n < e.length; n++) {
                        var r = e[n],
                            o = Object.getOwnPropertyDescriptor(t, r);
                        o && (Object.defineProperty(t, "__shady_native_" + r, o), o.value ? He[r] || (He[r] = o.value) : Ve(r))
                    }
                }
                var ze = document.createTreeWalker(document, NodeFilter.SHOW_ALL, null, !1),
                    Ge = document.createTreeWalker(document, NodeFilter.SHOW_ELEMENT, null, !1),
                    Xe = document.implementation.createHTMLDocument("inert");

                function Ke(t) {
                    for (var e; e = t.__shady_native_firstChild;) t.__shady_native_removeChild(e)
                }
                var Ye = ["firstElementChild", "lastElementChild", "children", "childElementCount"],
                    Je = ["querySelector", "querySelectorAll", "append", "prepend", "replaceChildren"];
                var $e = Ce({
                        get childNodes() {
                            return this.__shady_childNodes
                        },
                        get firstChild() {
                            return this.__shady_firstChild
                        },
                        get lastChild() {
                            return this.__shady_lastChild
                        },
                        get childElementCount() {
                            return this.__shady_childElementCount
                        },
                        get children() {
                            return this.__shady_children
                        },
                        get firstElementChild() {
                            return this.__shady_firstElementChild
                        },
                        get lastElementChild() {
                            return this.__shady_lastElementChild
                        },
                        get shadowRoot() {
                            return this.__shady_shadowRoot
                        }
                    }),
                    Qe = Ce({
                        get textContent() {
                            return this.__shady_textContent
                        },
                        set textContent(t) {
                            this.__shady_textContent = t
                        },
                        get innerHTML() {
                            return this.__shady_innerHTML
                        },
                        set innerHTML(t) {
                            this.__shady_innerHTML = t
                        }
                    }),
                    tn = Ce({
                        get parentElement() {
                            return this.__shady_parentElement
                        },
                        get parentNode() {
                            return this.__shady_parentNode
                        },
                        get nextSibling() {
                            return this.__shady_nextSibling
                        },
                        get previousSibling() {
                            return this.__shady_previousSibling
                        },
                        get nextElementSibling() {
                            return this.__shady_nextElementSibling
                        },
                        get previousElementSibling() {
                            return this.__shady_previousElementSibling
                        },
                        get className() {
                            return this.__shady_className
                        },
                        set className(t) {
                            this.__shady_className = t
                        }
                    });

                function en(t) {
                    for (var e in t) {
                        var n = t[e];
                        n && (n.enumerable = !1)
                    }
                }
                en($e), en(Qe), en(tn);
                var nn = oe.H || !0 === oe.J,
                    rn = nn ? function() {} : function(t) {
                        var e = ne(t);
                        e.Pa || (e.Pa = !0, Se(t, tn))
                    },
                    on = nn ? function() {} : function(t) {
                        var e = ne(t);
                        e.Oa || (e.Oa = !0, Se(t, $e), window.customElements && window.customElements.polyfillWrapFlushCallback && !oe.J || Se(t, Qe))
                    },
                    an = "__eventWrappers" + Date.now(),
                    sn = function() {
                        var t = Object.getOwnPropertyDescriptor(Event.prototype, "composed");
                        return t ? function(e) {
                            return t.get.call(e)
                        } : null
                    }(),
                    ln = function() {
                        function t() {}
                        var e = !1,
                            n = {
                                get capture() {
                                    return e = !0, !1
                                }
                            };
                        return window.addEventListener("test", t, n), window.removeEventListener("test", t, n), e
                    }();

                function un(t) {
                    if (t && "object" == typeof t) var e = !!t.capture,
                        n = !!t.once,
                        r = !!t.passive,
                        o = t.U;
                    else e = !!t, r = n = !1;
                    return {
                        La: o,
                        capture: e,
                        once: n,
                        passive: r,
                        Ja: ln ? t : e
                    }
                }
                var cn = {
                        blur: !0,
                        focus: !0,
                        focusin: !0,
                        focusout: !0,
                        click: !0,
                        dblclick: !0,
                        mousedown: !0,
                        mouseenter: !0,
                        mouseleave: !0,
                        mousemove: !0,
                        mouseout: !0,
                        mouseover: !0,
                        mouseup: !0,
                        wheel: !0,
                        beforeinput: !0,
                        input: !0,
                        keydown: !0,
                        keyup: !0,
                        compositionstart: !0,
                        compositionupdate: !0,
                        compositionend: !0,
                        touchstart: !0,
                        touchend: !0,
                        touchmove: !0,
                        touchcancel: !0,
                        pointerover: !0,
                        pointerenter: !0,
                        pointerdown: !0,
                        pointermove: !0,
                        pointerup: !0,
                        pointercancel: !0,
                        pointerout: !0,
                        pointerleave: !0,
                        gotpointercapture: !0,
                        lostpointercapture: !0,
                        dragstart: !0,
                        drag: !0,
                        dragenter: !0,
                        dragleave: !0,
                        dragover: !0,
                        drop: !0,
                        dragend: !0,
                        DOMActivate: !0,
                        DOMFocusIn: !0,
                        DOMFocusOut: !0,
                        keypress: !0
                    },
                    dn = {
                        DOMAttrModified: !0,
                        DOMAttributeNameChanged: !0,
                        DOMCharacterDataModified: !0,
                        DOMElementNameChanged: !0,
                        DOMNodeInserted: !0,
                        DOMNodeInsertedIntoDocument: !0,
                        DOMNodeRemoved: !0,
                        DOMNodeRemovedFromDocument: !0,
                        DOMSubtreeModified: !0
                    };

                function hn(t) {
                    return t instanceof Node ? t.__shady_getRootNode() : t
                }

                function fn(t, e) {
                    var n = [],
                        r = t;
                    for (t = hn(t); r;) n.push(r), r = r.__shady_assignedSlot ? r.__shady_assignedSlot : r.nodeType === Node.DOCUMENT_FRAGMENT_NODE && r.host && (e || r !== t) ? r.host : r.__shady_parentNode;
                    return n[n.length - 1] === document && n.push(window), n
                }

                function pn(t, e) {
                    if (!le) return t;
                    t = fn(t, !0);
                    for (var n, r, o = 0, i = void 0, a = void 0; o < e.length; o++)
                        if ((r = hn(n = e[o])) !== i && (a = t.indexOf(r), i = r), !le(r) || -1 < a) return n
                }

                function vn(t) {
                    function e(e, n) {
                        return (e = new t(e, n)).__composed = n && !!n.composed, e
                    }
                    return e.__proto__ = t, e.prototype = t.prototype, e
                }
                var mn = {
                    focus: !0,
                    blur: !0
                };

                function yn(t) {
                    return t.__target !== t.target || t.__relatedTarget !== t.relatedTarget
                }

                function _n(t, e, n) {
                    if (n = e.__handlers && e.__handlers[t.type] && e.__handlers[t.type][n])
                        for (var r, o = 0;
                            (r = n[o]) && (!yn(t) || t.target !== t.relatedTarget) && (r.call(e, t), !t.__immediatePropagationStopped); o++);
                }

                function gn(t) {
                    var e = t.composedPath(),
                        n = e.map((function(t) {
                            return pn(t, e)
                        })),
                        r = t.bubbles;
                    Object.defineProperty(t, "currentTarget", {
                        configurable: !0,
                        enumerable: !0,
                        get: function() {
                            return a
                        }
                    });
                    var o = Event.CAPTURING_PHASE;
                    Object.defineProperty(t, "eventPhase", {
                        configurable: !0,
                        enumerable: !0,
                        get: function() {
                            return o
                        }
                    });
                    for (var i = e.length - 1; 0 <= i; i--) {
                        var a = e[i];
                        if (o = a === n[i] ? Event.AT_TARGET : Event.CAPTURING_PHASE, _n(t, a, "capture"), t.ra) return
                    }
                    for (i = 0; i < e.length; i++) {
                        var s = (a = e[i]) === n[i];
                        if ((s || r) && (o = s ? Event.AT_TARGET : Event.BUBBLING_PHASE, _n(t, a, "bubble"), t.ra)) return
                    }
                    o = 0, a = null
                }

                function bn(t, e, n, r, o, i) {
                    for (var a = 0; a < t.length; a++) {
                        var s = t[a],
                            l = s.type,
                            u = s.capture,
                            c = s.once,
                            d = s.passive;
                        if (e === s.node && n === l && r === u && o === c && i === d) return a
                    }
                    return -1
                }

                function wn(t) {
                    return De(), !oe.fa && this instanceof Node && !me(document, this) ? (t.__target || Nn(t, this), gn(t)) : this.__shady_native_dispatchEvent(t)
                }

                function En(t, e, n) {
                    var r = un(n),
                        o = r.capture,
                        i = r.once,
                        a = r.passive,
                        s = r.La;
                    if (r = r.Ja, e) {
                        var l = typeof e;
                        if (("function" === l || "object" === l) && ("object" !== l || e.handleEvent && "function" == typeof e.handleEvent)) {
                            if (dn[t]) return this.__shady_native_addEventListener(t, e, r);
                            var u = s || this;
                            if (s = e[an]) {
                                if (-1 < bn(s, u, t, o, i, a)) return
                            } else e[an] = [];
                            s = function(r) {
                                if (i && this.__shady_removeEventListener(t, e, n), r.__target || Nn(r), u !== this) {
                                    var a = Object.getOwnPropertyDescriptor(r, "currentTarget");
                                    Object.defineProperty(r, "currentTarget", {
                                        get: function() {
                                            return u
                                        },
                                        configurable: !0
                                    });
                                    var s = Object.getOwnPropertyDescriptor(r, "eventPhase");
                                    Object.defineProperty(r, "eventPhase", {
                                        configurable: !0,
                                        enumerable: !0,
                                        get: function() {
                                            return o ? Event.CAPTURING_PHASE : Event.BUBBLING_PHASE
                                        }
                                    })
                                }
                                if (r.__previousCurrentTarget = r.currentTarget, (!le(u) && "slot" !== u.localName || -1 != r.composedPath().indexOf(u)) && (r.composed || -1 < r.composedPath().indexOf(u)))
                                    if (yn(r) && r.target === r.relatedTarget) r.eventPhase === Event.BUBBLING_PHASE && r.stopImmediatePropagation();
                                    else if (r.eventPhase === Event.CAPTURING_PHASE || r.bubbles || r.target === u || u instanceof Window) {
                                    var c = "function" === l ? e.call(u, r) : e.handleEvent && e.handleEvent(r);
                                    return u !== this && (a ? (Object.defineProperty(r, "currentTarget", a), a = null) : delete r.currentTarget, s ? (Object.defineProperty(r, "eventPhase", s), s = null) : delete r.eventPhase), c
                                }
                            }, e[an].push({
                                node: u,
                                type: t,
                                capture: o,
                                once: i,
                                passive: a,
                                pb: s
                            }), this.__handlers = this.__handlers || {}, this.__handlers[t] = this.__handlers[t] || {
                                capture: [],
                                bubble: []
                            }, this.__handlers[t][o ? "capture" : "bubble"].push(s), mn[t] || this.__shady_native_addEventListener(t, s, r)
                        }
                    }
                }

                function Sn(t, e, n) {
                    if (e) {
                        var r = un(n);
                        n = r.capture;
                        var o = r.once,
                            i = r.passive,
                            a = r.La;
                        if (r = r.Ja, dn[t]) return this.__shady_native_removeEventListener(t, e, r);
                        var s = a || this;
                        a = void 0;
                        var l = null;
                        try {
                            l = e[an]
                        } catch (t) {}
                        l && (-1 < (o = bn(l, s, t, n, o, i)) && (a = l.splice(o, 1)[0].pb, l.length || (e[an] = void 0))), this.__shady_native_removeEventListener(t, a || e, r), a && this.__handlers && this.__handlers[t] && (-1 < (e = (t = this.__handlers[t][n ? "capture" : "bubble"]).indexOf(a)) && t.splice(e, 1))
                    }
                }
                var Cn = Ce({
                    get composed() {
                        return void 0 === this.__composed && (sn ? this.__composed = "focusin" === this.type || "focusout" === this.type || sn(this) : !1 !== this.isTrusted && (this.__composed = cn[this.type])), this.__composed || !1
                    },
                    composedPath: function() {
                        return this.__composedPath || (this.__composedPath = fn(this.__target, this.composed)), this.__composedPath
                    },
                    get target() {
                        return pn(this.currentTarget || this.__previousCurrentTarget, this.composedPath())
                    },
                    get relatedTarget() {
                        return this.__relatedTarget ? (this.__relatedTargetComposedPath || (this.__relatedTargetComposedPath = fn(this.__relatedTarget, !0)), pn(this.currentTarget || this.__previousCurrentTarget, this.__relatedTargetComposedPath)) : null
                    },
                    stopPropagation: function() {
                        Event.prototype.stopPropagation.call(this), this.ra = !0
                    },
                    stopImmediatePropagation: function() {
                        Event.prototype.stopImmediatePropagation.call(this), this.ra = this.__immediatePropagationStopped = !0
                    }
                });

                function Nn(t, e) {
                    if (e = void 0 === e ? t.target : e, t.__target = e, t.__relatedTarget = t.relatedTarget, oe.H) {
                        if (!(e = Object.getPrototypeOf(t)).hasOwnProperty("__shady_patchedProto")) {
                            var n = Object.create(e);
                            n.__shady_sourceProto = e, Ee(n, Cn), e.__shady_patchedProto = n
                        }
                        t.__proto__ = e.__shady_patchedProto
                    } else Ee(t, Cn)
                }
                var xn = vn(Event),
                    Tn = vn(CustomEvent),
                    On = vn(MouseEvent);
                var kn = Object.getOwnPropertyNames(Element.prototype).filter((function(t) {
                        return "on" === t.substring(0, 2)
                    })),
                    Pn = Object.getOwnPropertyNames(HTMLElement.prototype).filter((function(t) {
                        return "on" === t.substring(0, 2)
                    }));

                function Dn(t) {
                    return {
                        set: function(e) {
                            var n = ne(this),
                                r = t.substring(2);
                            n.T || (n.T = {}), n.T[t] && this.removeEventListener(r, n.T[t]), this.__shady_addEventListener(r, e), n.T[t] = e
                        },
                        get: function() {
                            var e = re(this);
                            return e && e.T && e.T[t]
                        },
                        configurable: !0
                    }
                }

                function An(t, e) {
                    return {
                        index: t,
                        ga: [],
                        na: e
                    }
                }

                function Mn(t, e, n, r) {
                    var o = 0,
                        i = 0,
                        a = 0,
                        s = 0,
                        l = Math.min(e - o, r - i);
                    if (0 == o && 0 == i) t: {
                        for (a = 0; a < l; a++)
                            if (t[a] !== n[a]) break t;a = l
                    }
                    if (e == t.length && r == n.length) {
                        s = t.length;
                        for (var u = n.length, c = 0; c < l - a && jn(t[--s], n[--u]);) c++;
                        s = c
                    }
                    if (i += a, r -= s, 0 == (e -= s) - (o += a) && 0 == r - i) return [];
                    if (o == e) {
                        for (e = An(o, 0); i < r;) e.ga.push(n[i++]);
                        return [e]
                    }
                    if (i == r) return [An(o, e - o)];
                    for (r = r - (a = i) + 1, s = e - (l = o) + 1, e = Array(r), u = 0; u < r; u++) e[u] = Array(s), e[u][0] = u;
                    for (u = 0; u < s; u++) e[0][u] = u;
                    for (u = 1; u < r; u++)
                        for (c = 1; c < s; c++)
                            if (t[l + c - 1] === n[a + u - 1]) e[u][c] = e[u - 1][c - 1];
                            else {
                                var d = e[u - 1][c] + 1,
                                    h = e[u][c - 1] + 1;
                                e[u][c] = d < h ? d : h
                            }
                    for (l = e.length - 1, a = e[0].length - 1, r = e[l][a], t = []; 0 < l || 0 < a;) 0 == l ? (t.push(2), a--) : 0 == a ? (t.push(3), l--) : (s = e[l - 1][a - 1], (d = (u = e[l - 1][a]) < (c = e[l][a - 1]) ? u < s ? u : s : c < s ? c : s) == s ? (s == r ? t.push(0) : (t.push(1), r = s), l--, a--) : d == u ? (t.push(3), l--, r = u) : (t.push(2), a--, r = c));
                    for (t.reverse(), e = void 0, l = [], a = 0; a < t.length; a++) switch (t[a]) {
                        case 0:
                            e && (l.push(e), e = void 0), o++, i++;
                            break;
                        case 1:
                            e || (e = An(o, 0)), e.na++, o++, e.ga.push(n[i]), i++;
                            break;
                        case 2:
                            e || (e = An(o, 0)), e.na++, o++;
                            break;
                        case 3:
                            e || (e = An(o, 0)), e.ga.push(n[i]), i++
                    }
                    return e && l.push(e), l
                }

                function jn(t, e) {
                    return t === e
                }
                var Ln = Ce({
                        dispatchEvent: wn,
                        addEventListener: En,
                        removeEventListener: Sn
                    }),
                    In = null;

                function Rn() {
                    return In || (In = window.ShadyCSS && window.ShadyCSS.ScopingShim), In || null
                }

                function Fn(t, e, n) {
                    var r = Rn();
                    return !(!r || "class" !== e) && (r.setElementClass(t, n), !0)
                }

                function Un(t, e) {
                    var n = Rn();
                    n && n.unscopeNode(t, e)
                }

                function Bn(t, e) {
                    var n = Rn();
                    if (!n) return !0;
                    if (t.nodeType === Node.DOCUMENT_FRAGMENT_NODE) {
                        for (n = !0, t = t.__shady_firstChild; t; t = t.__shady_nextSibling) n = n && Bn(t, e);
                        return n
                    }
                    return t.nodeType !== Node.ELEMENT_NODE || n.currentScopeForNode(t) === e
                }

                function Hn(t) {
                    if (t.nodeType !== Node.ELEMENT_NODE) return "";
                    var e = Rn();
                    return e ? e.currentScopeForNode(t) : ""
                }

                function Zn(t, e) {
                    if (t)
                        for (t.nodeType === Node.ELEMENT_NODE && e(t), t = t.__shady_firstChild; t; t = t.__shady_nextSibling) t.nodeType === Node.ELEMENT_NODE && Zn(t, e)
                }
                var Vn = window.document,
                    Wn = oe.fa,
                    qn = Object.getOwnPropertyDescriptor(Node.prototype, "isConnected"),
                    zn = qn && qn.get;

                function Gn(t) {
                    for (var e; e = t.__shady_firstChild;) t.__shady_removeChild(e)
                }

                function Xn(t) {
                    var e = re(t);
                    if (e && void 0 !== e.qa)
                        for (e = t.__shady_firstChild; e; e = e.__shady_nextSibling) Xn(e);
                    (t = re(t)) && (t.qa = void 0)
                }

                function Kn(t) {
                    var e = t;
                    if (t && "slot" === t.localName) {
                        var n = re(t);
                        (n = n && n.aa) && (e = n.length ? n[0] : Kn(t.__shady_nextSibling))
                    }
                    return e
                }

                function Yn(t, e, n) {
                    if (t = (t = re(t)) && t.ea) {
                        if (e)
                            if (e.nodeType === Node.DOCUMENT_FRAGMENT_NODE)
                                for (var r = 0, o = e.childNodes.length; r < o; r++) t.addedNodes.push(e.childNodes[r]);
                            else t.addedNodes.push(e);
                        n && t.removedNodes.push(n),
                            function(t) {
                                t.g || (t.g = !0, ve((function() {
                                    t.flush()
                                })))
                            }(t)
                    }
                }
                var Jn = Ce({
                        get parentNode() {
                            var t = re(this);
                            return void 0 !== (t = t && t.parentNode) ? t : this.__shady_native_parentNode
                        },
                        get firstChild() {
                            var t = re(this);
                            return void 0 !== (t = t && t.firstChild) ? t : this.__shady_native_firstChild
                        },
                        get lastChild() {
                            var t = re(this);
                            return void 0 !== (t = t && t.lastChild) ? t : this.__shady_native_lastChild
                        },
                        get nextSibling() {
                            var t = re(this);
                            return void 0 !== (t = t && t.nextSibling) ? t : this.__shady_native_nextSibling
                        },
                        get previousSibling() {
                            var t = re(this);
                            return void 0 !== (t = t && t.previousSibling) ? t : this.__shady_native_previousSibling
                        },
                        get childNodes() {
                            if (se(this)) {
                                var t = re(this);
                                if (!t.childNodes) {
                                    t.childNodes = [];
                                    for (var e = this.__shady_firstChild; e; e = e.__shady_nextSibling) t.childNodes.push(e)
                                }
                                var n = t.childNodes
                            } else n = this.__shady_native_childNodes;
                            return n.item = function(t) {
                                return n[t]
                            }, n
                        },
                        get parentElement() {
                            var t = re(this);
                            return (t = t && t.parentNode) && t.nodeType !== Node.ELEMENT_NODE && (t = null), void 0 !== t ? t : this.__shady_native_parentElement
                        },
                        get isConnected() {
                            if (zn && zn.call(this)) return !0;
                            if (this.nodeType == Node.DOCUMENT_FRAGMENT_NODE) return !1;
                            var t = this.ownerDocument;
                            if (null === t || me(t, this)) return !0;
                            for (t = this; t && !(t instanceof Document);) t = t.__shady_parentNode || (le(t) ? t.host : void 0);
                            return !!(t && t instanceof Document)
                        },
                        get textContent() {
                            if (se(this)) {
                                for (var t = [], e = this.__shady_firstChild; e; e = e.__shady_nextSibling) e.nodeType !== Node.COMMENT_NODE && t.push(e.__shady_textContent);
                                return t.join("")
                            }
                            return this.__shady_native_textContent
                        },
                        set textContent(t) {
                            switch (null == t && (t = ""), this.nodeType) {
                                case Node.ELEMENT_NODE:
                                case Node.DOCUMENT_FRAGMENT_NODE:
                                    if (!se(this) && oe.H) {
                                        var e = this.__shady_firstChild;
                                        (e != this.__shady_lastChild || e && e.nodeType != Node.TEXT_NODE) && Gn(this), this.__shady_native_textContent = t
                                    } else Gn(this), (0 < t.length || this.nodeType === Node.ELEMENT_NODE) && this.__shady_insertBefore(document.createTextNode(t));
                                    break;
                                default:
                                    this.nodeValue = t
                            }
                        },
                        insertBefore: function(t, e) {
                            if (this.ownerDocument !== Vn && t.ownerDocument !== Vn) return this.__shady_native_insertBefore(t, e), t;
                            if (t === this) throw Error("Failed to execute 'appendChild' on 'Node': The new child element contains the parent.");
                            if (e) {
                                var n = re(e);
                                if (void 0 !== (n = n && n.parentNode) && n !== this || void 0 === n && e.__shady_native_parentNode !== this) throw Error("Failed to execute 'insertBefore' on 'Node': The node before which the new node is to be inserted is not a child of this node.")
                            }
                            if (e === t) return t;
                            Yn(this, t);
                            var r = [],
                                o = (n = Qr(this)) ? n.host.localName : Hn(this),
                                i = t.__shady_parentNode;
                            if (i) {
                                var a = Hn(t),
                                    s = !!n || !Qr(t) || Wn && void 0 !== this.__noInsertionPoint;
                                i.__shady_removeChild(t, s)
                            }
                            i = !0;
                            var l = (!Wn || void 0 === t.__noInsertionPoint && void 0 === this.__noInsertionPoint) && !Bn(t, o),
                                c = n && !t.__noInsertionPoint && (!Wn || t.nodeType === Node.DOCUMENT_FRAGMENT_NODE);
                            return (c || l) && (l && (a = a || Hn(t)), Zn(t, (function(t) {
                                if (c && "slot" === t.localName && r.push(t), l) {
                                    var e = a;
                                    Rn() && (e && Un(t, e), (e = Rn()) && e.scopeNode(t, o))
                                }
                            }))), r.length && (qr(n), n.i.push.apply(n.i, u(r)), Br(n)), se(this) && (function(t, e, n) {
                                kr(e, 2);
                                var r = ne(e);
                                if (void 0 !== r.firstChild && (r.childNodes = null), t.nodeType === Node.DOCUMENT_FRAGMENT_NODE)
                                    for (t = t.__shady_native_firstChild; t; t = t.__shady_native_nextSibling) Pr(t, e, r, n);
                                else Pr(t, e, r, n)
                            }(t, this, e), (s = re(this)).root ? (i = !1, ue(this) && Br(s.root)) : n && "slot" === this.localName && (i = !1, Br(n))), i ? (n = le(this) ? this.host : this, e ? (e = Kn(e), n.__shady_native_insertBefore(t, e)) : n.__shady_native_appendChild(t)) : t.ownerDocument !== this.ownerDocument && this.ownerDocument.adoptNode(t), t
                        },
                        appendChild: function(t) {
                            if (this != t || !le(t)) return this.__shady_insertBefore(t)
                        },
                        removeChild: function(t, e) {
                            if (e = void 0 !== e && e, this.ownerDocument !== Vn) return this.__shady_native_removeChild(t);
                            if (t.__shady_parentNode !== this) throw Error("The node to be removed is not a child of this node: " + t);
                            Yn(this, null, t);
                            var n = Qr(t),
                                r = n && function(t, e) {
                                    if (t.g) {
                                        zr(t);
                                        var n, r = t.h;
                                        for (n in r)
                                            for (var o = r[n], i = 0; i < o.length; i++) {
                                                var a = o[i];
                                                if (ye(e, a)) {
                                                    o.splice(i, 1);
                                                    var s = t.g.indexOf(a);
                                                    if (0 <= s && (t.g.splice(s, 1), (s = re(a.__shady_parentNode)) && s.ia && s.ia--), i--, s = (a = re(a)).aa)
                                                        for (var l = 0; l < s.length; l++) {
                                                            var u = s[l],
                                                                c = u.__shady_native_parentNode;
                                                            c && c.__shady_native_removeChild(u)
                                                        }
                                                    a.aa = [], a.assignedNodes = [], s = !0
                                                }
                                            }
                                        return s
                                    }
                                }(n, t),
                                o = re(this);
                            if (se(this) && (function(t, e) {
                                    var n = ne(t);
                                    e = ne(e), t === e.firstChild && (e.firstChild = n.nextSibling), t === e.lastChild && (e.lastChild = n.previousSibling), t = n.previousSibling;
                                    var r = n.nextSibling;
                                    t && (ne(t).nextSibling = r), r && (ne(r).previousSibling = t), n.parentNode = n.previousSibling = n.nextSibling = void 0, void 0 !== e.childNodes && (e.childNodes = null)
                                }(t, this), ue(this))) {
                                Br(o.root);
                                var i = !0
                            }
                            if (Rn() && !e && n && t.nodeType !== Node.TEXT_NODE) {
                                var a = Hn(t);
                                Zn(t, (function(t) {
                                    Un(t, a)
                                }))
                            }
                            return Xn(t), n && ((e = "slot" === this.localName) && (i = !0), (r || e) && Br(n)), i || (i = le(this) ? this.host : this, (!o.root && "slot" !== t.localName || i === t.__shady_native_parentNode) && i.__shady_native_removeChild(t)), t
                        },
                        replaceChild: function(t, e) {
                            return this.__shady_insertBefore(t, e), this.__shady_removeChild(e), t
                        },
                        cloneNode: function(t) {
                            if ("template" == this.localName) return this.__shady_native_cloneNode(t);
                            var e = this.__shady_native_cloneNode(!1);
                            if (t && e.nodeType !== Node.ATTRIBUTE_NODE) {
                                t = this.__shady_firstChild;
                                for (var n; t; t = t.__shady_nextSibling) n = t.__shady_cloneNode(!0), e.__shady_appendChild(n)
                            }
                            return e
                        },
                        getRootNode: function(t) {
                            if (this && this.nodeType) {
                                var e = ne(this),
                                    n = e.qa;
                                return void 0 === n && (le(this) ? (n = this, e.qa = n) : (n = (n = this.__shady_parentNode) ? n.__shady_getRootNode(t) : this, document.documentElement.__shady_native_contains(this) && (e.qa = n))), n
                            }
                        },
                        contains: function(t) {
                            return ye(this, t)
                        }
                    }),
                    $n = Ce({
                        get assignedSlot() {
                            var t = this.__shady_parentNode;
                            return (t = t && t.__shady_shadowRoot) && Hr(t), (t = re(this)) && t.assignedSlot || null
                        }
                    });

                function Qn(t, e, n) {
                    var r = [];
                    return tr(t, e, n, r), r
                }

                function tr(t, e, n, r) {
                    for (t = t.__shady_firstChild; t; t = t.__shady_nextSibling) {
                        var o;
                        if (o = t.nodeType === Node.ELEMENT_NODE) {
                            var i = e,
                                a = n,
                                s = r,
                                l = i(o = t);
                            l && s.push(o), a && a(l) ? o = l : (tr(o, i, a, s), o = void 0)
                        }
                        if (o) break
                    }
                }
                var er = {
                        get firstElementChild() {
                            var t = re(this);
                            if (t && void 0 !== t.firstChild) {
                                for (t = this.__shady_firstChild; t && t.nodeType !== Node.ELEMENT_NODE;) t = t.__shady_nextSibling;
                                return t
                            }
                            return this.__shady_native_firstElementChild
                        },
                        get lastElementChild() {
                            var t = re(this);
                            if (t && void 0 !== t.lastChild) {
                                for (t = this.__shady_lastChild; t && t.nodeType !== Node.ELEMENT_NODE;) t = t.__shady_previousSibling;
                                return t
                            }
                            return this.__shady_native_lastElementChild
                        },
                        get children() {
                            return se(this) ? _e(Array.prototype.filter.call(be(this), (function(t) {
                                return t.nodeType === Node.ELEMENT_NODE
                            }))) : this.__shady_native_children
                        },
                        get childElementCount() {
                            var t = this.__shady_children;
                            return t ? t.length : 0
                        }
                    },
                    nr = Ce((er.append = function(t) {
                        for (var e = [], n = 0; n < arguments.length; ++n) e[n] = arguments[n];
                        this.__shady_insertBefore(Te.apply(null, u(e)), null)
                    }, er.prepend = function(t) {
                        for (var e = [], n = 0; n < arguments.length; ++n) e[n] = arguments[n];
                        this.__shady_insertBefore(Te.apply(null, u(e)), this.__shady_firstChild)
                    }, er.replaceChildren = function(t) {
                        for (var e = [], n = 0; n < arguments.length; ++n) e[n] = arguments[n];
                        for (; null !== (n = this.__shady_firstChild);) this.__shady_removeChild(n);
                        this.__shady_insertBefore(Te.apply(null, u(e)), null)
                    }, er)),
                    rr = Ce({
                        querySelector: function(t) {
                            return Qn(this, (function(e) {
                                return de.call(e, t)
                            }), (function(t) {
                                return !!t
                            }))[0] || null
                        },
                        querySelectorAll: function(t, e) {
                            if (e) {
                                e = Array.prototype.slice.call(this.__shady_native_querySelectorAll(t));
                                var n = this.__shady_getRootNode();
                                return _e(e.filter((function(t) {
                                    return t.__shady_getRootNode() == n
                                })))
                            }
                            return _e(Qn(this, (function(e) {
                                return de.call(e, t)
                            })))
                        }
                    }),
                    or = oe.fa && !oe.J ? Ne({}, nr) : nr;
                Ne(nr, rr);
                var ir = Ce({
                        after: function(t) {
                            for (var e = [], n = 0; n < arguments.length; ++n) e[n] = arguments[n];
                            if (null !== (n = this.__shady_parentNode)) {
                                var r = this.__shady_nextSibling;
                                n.__shady_insertBefore(Te.apply(null, u(e)), r)
                            }
                        },
                        before: function(t) {
                            for (var e = [], n = 0; n < arguments.length; ++n) e[n] = arguments[n];
                            null !== (n = this.__shady_parentNode) && n.__shady_insertBefore(Te.apply(null, u(e)), this)
                        },
                        remove: function() {
                            var t = this.__shady_parentNode;
                            null !== t && t.__shady_removeChild(this)
                        },
                        replaceWith: function(t) {
                            for (var e = [], n = 0; n < arguments.length; ++n) e[n] = arguments[n];
                            if (null !== (n = this.__shady_parentNode)) {
                                var r = this.__shady_nextSibling;
                                n.__shady_removeChild(this), n.__shady_insertBefore(Te.apply(null, u(e)), r)
                            }
                        }
                    }),
                    ar = window.document;

                function sr(t, e) {
                    if ("slot" === e) ue(t = t.__shady_parentNode) && Br(re(t).root);
                    else if ("slot" === t.localName && "name" === e && (e = Qr(t))) {
                        if (e.g) {
                            zr(e);
                            var n = t.Qa,
                                r = Gr(t);
                            if (r !== n) {
                                var o = (n = e.h[n]).indexOf(t);
                                0 <= o && n.splice(o, 1), (n = e.h[r] || (e.h[r] = [])).push(t), 1 < n.length && (e.h[r] = Xr(n))
                            }
                        }
                        Br(e)
                    }
                }
                var lr = Ce({
                    get previousElementSibling() {
                        var t = re(this);
                        if (t && void 0 !== t.previousSibling) {
                            for (t = this.__shady_previousSibling; t && t.nodeType !== Node.ELEMENT_NODE;) t = t.__shady_previousSibling;
                            return t
                        }
                        return this.__shady_native_previousElementSibling
                    },
                    get nextElementSibling() {
                        var t = re(this);
                        if (t && void 0 !== t.nextSibling) {
                            for (t = this.__shady_nextSibling; t && t.nodeType !== Node.ELEMENT_NODE;) t = t.__shady_nextSibling;
                            return t
                        }
                        return this.__shady_native_nextElementSibling
                    },
                    get slot() {
                        return this.getAttribute("slot")
                    },
                    set slot(t) {
                        this.__shady_setAttribute("slot", t)
                    },
                    get className() {
                        return this.getAttribute("class") || ""
                    },
                    set className(t) {
                        this.__shady_setAttribute("class", t)
                    },
                    setAttribute: function(t, e) {
                        this.ownerDocument !== ar ? this.__shady_native_setAttribute(t, e) : Fn(this, t, e) || (this.__shady_native_setAttribute(t, e), sr(this, t))
                    },
                    removeAttribute: function(t) {
                        this.ownerDocument !== ar ? this.__shady_native_removeAttribute(t) : Fn(this, t, "") ? "" === this.getAttribute(t) && this.__shady_native_removeAttribute(t) : (this.__shady_native_removeAttribute(t), sr(this, t))
                    }
                });
                oe.fa || kn.forEach((function(t) {
                    lr[t] = Dn(t)
                }));
                var ur = Ce({
                    attachShadow: function(t) {
                        if (!this) throw Error("Must provide a host.");
                        if (!t) throw Error("Not enough arguments.");
                        if (t.shadyUpgradeFragment && !oe.Na) {
                            var e = t.shadyUpgradeFragment;
                            if (e.__proto__ = ShadowRoot.prototype, Ur(e, this, t), Dr(e, e), t = e.__noInsertionPoint ? null : e.querySelectorAll("slot"), e.__noInsertionPoint = void 0, t && t.length) {
                                var n = e;
                                qr(n), n.i.push.apply(n.i, u(t)), Br(e)
                            }
                            e.host.__shady_native_appendChild(e)
                        } else e = new Fr(Lr, this, t);
                        return this.__CE_shadowRoot = e
                    },
                    get shadowRoot() {
                        var t = re(this);
                        return t && t.gb || null
                    }
                });
                Ne(lr, ur);
                var cr = document.implementation.createHTMLDocument("inert"),
                    dr = Ce({
                        get innerHTML() {
                            return se(this) ? Ue("template" === this.localName ? this.content : this, be) : this.__shady_native_innerHTML
                        },
                        set innerHTML(t) {
                            if ("template" === this.localName) this.__shady_native_innerHTML = t;
                            else {
                                Gn(this);
                                var e = this.localName || "div";
                                for (e = this.namespaceURI && this.namespaceURI !== cr.namespaceURI ? cr.createElementNS(this.namespaceURI, e) : cr.createElement(e), oe.H ? e.__shady_native_innerHTML = t : e.innerHTML = t; t = e.__shady_firstChild;) this.__shady_insertBefore(t)
                            }
                        }
                    }),
                    hr = Ce({
                        blur: function() {
                            var t = re(this);
                            (t = (t = t && t.root) && t.activeElement) ? t.__shady_blur(): this.__shady_native_blur()
                        }
                    });
                oe.fa || Pn.forEach((function(t) {
                    hr[t] = Dn(t)
                }));
                var fr = Ce({
                        assignedNodes: function(t) {
                            if ("slot" === this.localName) {
                                var e = this.__shady_getRootNode();
                                return e && le(e) && Hr(e), (e = re(this)) && (t && t.flatten ? e.aa : e.assignedNodes) || []
                            }
                        },
                        addEventListener: function(t, e, n) {
                            if ("slot" !== this.localName || "slotchange" === t) En.call(this, t, e, n);
                            else {
                                "object" != typeof n && (n = {
                                    capture: !!n
                                });
                                var r = this.__shady_parentNode;
                                if (!r) throw Error("ShadyDOM cannot attach event to slot unless it has a `parentNode`");
                                n.U = this, r.__shady_addEventListener(t, e, n)
                            }
                        },
                        removeEventListener: function(t, e, n) {
                            if ("slot" !== this.localName || "slotchange" === t) Sn.call(this, t, e, n);
                            else {
                                "object" != typeof n && (n = {
                                    capture: !!n
                                });
                                var r = this.__shady_parentNode;
                                if (!r) throw Error("ShadyDOM cannot attach event to slot unless it has a `parentNode`");
                                n.U = this, r.__shady_removeEventListener(t, e, n)
                            }
                        }
                    }),
                    pr = Ce({
                        getElementById: function(t) {
                            return "" === t ? null : Qn(this, (function(e) {
                                return e.id == t
                            }), (function(t) {
                                return !!t
                            }))[0] || null
                        }
                    });

                function vr(t, e) {
                    for (var n; e && !t.has(n = e.__shady_getRootNode());) e = n.host;
                    return e
                }
                var mr = "__shady_native_" + ae(),
                    yr = Ce({
                        get activeElement() {
                            var t = oe.H ? document.__shady_native_activeElement : document.activeElement;
                            if (!t || !t.nodeType) return null;
                            var e = !!le(this);
                            if (!(this === document || e && this.host !== t && this.host.__shady_native_contains(t))) return null;
                            for (e = Qr(t); e && e !== this;) e = Qr(t = e.host);
                            return this === document ? e ? null : t : e === this ? t : null
                        },
                        elementsFromPoint: function(t, e) {
                            t = [].slice.call(document[mr](t, e)), e = function(t) {
                                var e = new Set;
                                for (e.add(t); le(t) && t.host;) t = t.host.__shady_getRootNode(), e.add(t);
                                return e
                            }(this);
                            for (var n = new Set, r = 0; r < t.length; r++) n.add(vr(e, t[r]));
                            var o = [];
                            return n.forEach((function(t) {
                                return o.push(t)
                            })), o
                        },
                        elementFromPoint: function(t, e) {
                            return this.__shady_elementsFromPoint(t, e)[0] || null
                        }
                    }),
                    _r = window.document,
                    gr = Ce({
                        importNode: function(t, e) {
                            if (t.ownerDocument !== _r || "template" === t.localName) return this.__shady_native_importNode(t, e);
                            var n = this.__shady_native_importNode(t, !1);
                            if (e)
                                for (t = t.__shady_firstChild; t; t = t.__shady_nextSibling) e = this.__shady_importNode(t, !0), n.__shady_appendChild(e);
                            return n
                        }
                    }),
                    br = Ce({
                        dispatchEvent: wn,
                        addEventListener: En.bind(window),
                        removeEventListener: Sn.bind(window)
                    }),
                    wr = {};
                Object.getOwnPropertyDescriptor(HTMLElement.prototype, "parentElement") && (wr.parentElement = Jn.parentElement), Object.getOwnPropertyDescriptor(HTMLElement.prototype, "contains") && (wr.contains = Jn.contains), Object.getOwnPropertyDescriptor(HTMLElement.prototype, "children") && (wr.children = nr.children), Object.getOwnPropertyDescriptor(HTMLElement.prototype, "innerHTML") && (wr.innerHTML = dr.innerHTML), Object.getOwnPropertyDescriptor(HTMLElement.prototype, "className") && (wr.className = lr.className);
                var Er = {
                        EventTarget: [Ln],
                        Node: [Jn, window.EventTarget ? null : Ln],
                        Text: [$n],
                        Comment: [$n],
                        CDATASection: [$n],
                        ProcessingInstruction: [$n],
                        Element: [lr, nr, ir, $n, !oe.H || "innerHTML" in Element.prototype ? dr : null, window.HTMLSlotElement ? null : fr],
                        HTMLElement: [hr, wr],
                        HTMLSlotElement: [fr],
                        DocumentFragment: [or, pr],
                        Document: [gr, or, pr, yr],
                        Window: [br],
                        CharacterData: [ir]
                    },
                    Sr = oe.H ? null : ["innerHTML", "textContent"];

                function Cr(t, e, n, r) {
                    e.forEach((function(e) {
                        return t && e && Ee(t, e, n, r)
                    }))
                }

                function Nr(t) {
                    var e, n = t ? null : Sr;
                    for (e in Er) Cr(window[e] && window[e].prototype, Er[e], t, n)
                }

                function xr(t) {
                    return t.__shady_protoIsPatched = !0, Cr(t, Er.EventTarget), Cr(t, Er.Node), Cr(t, Er.Element), Cr(t, Er.HTMLElement), Cr(t, Er.HTMLSlotElement), t
                }["Text", "Comment", "CDATASection", "ProcessingInstruction"].forEach((function(t) {
                    var e = window[t],
                        n = Object.create(e.prototype);
                    n.__shady_protoIsPatched = !0, Cr(n, Er.EventTarget), Cr(n, Er.Node), Er[t] && Cr(n, Er[t]), e.prototype.__shady_patchedProto = n
                }));
                var Tr = oe.Aa,
                    Or = oe.H;

                function kr(t, e) {
                    if (Tr && !t.__shady_protoIsPatched && !le(t)) {
                        var n = Object.getPrototypeOf(t),
                            r = n.hasOwnProperty("__shady_patchedProto") && n.__shady_patchedProto;
                        r || (xr(r = Object.create(n)), n.__shady_patchedProto = r), Object.setPrototypeOf(t, r)
                    }
                    Or || (1 === e ? rn(t) : 2 === e && on(t))
                }

                function Pr(t, e, n, r) {
                    kr(t, 1), r = r || null;
                    var o = ne(t),
                        i = r ? ne(r) : null;
                    o.previousSibling = r ? i.previousSibling : e.__shady_lastChild, (i = re(o.previousSibling)) && (i.nextSibling = t), (i = re(o.nextSibling = r)) && (i.previousSibling = t), o.parentNode = e, r ? r === n.firstChild && (n.firstChild = t) : (n.lastChild = t, n.firstChild || (n.firstChild = t)), n.childNodes = null
                }

                function Dr(t, e) {
                    var n = ne(t);
                    if (e || void 0 === n.firstChild) {
                        n.childNodes = null;
                        var r = n.firstChild = t.__shady_native_firstChild;
                        for (n.lastChild = t.__shady_native_lastChild, kr(t, 2), n = r, r = void 0; n; n = n.__shady_native_nextSibling) {
                            var o = ne(n);
                            o.parentNode = e || t, o.nextSibling = n.__shady_native_nextSibling, o.previousSibling = r || null, r = n, kr(n, 1)
                        }
                    }
                }
                var Ar = Ce({
                    addEventListener: function(t, e, n) {
                        "object" != typeof n && (n = {
                            capture: !!n
                        }), n.U = n.U || this, this.host.__shady_addEventListener(t, e, n)
                    },
                    removeEventListener: function(t, e, n) {
                        "object" != typeof n && (n = {
                            capture: !!n
                        }), n.U = n.U || this, this.host.__shady_removeEventListener(t, e, n)
                    }
                });

                function Mr(t, e) {
                    Ee(t, Ar, e), Ee(t, yr, e), Ee(t, dr, e), Ee(t, nr, e), oe.J && !e ? (Ee(t, Jn, e), Ee(t, pr, e)) : oe.H || (Ee(t, tn), Ee(t, $e), Ee(t, Qe))
                }
                var jr, Lr = {},
                    Ir = oe.deferConnectionCallbacks && "loading" === document.readyState;

                function Rr(t) {
                    var e = [];
                    do {
                        e.unshift(t)
                    } while (t = t.__shady_parentNode);
                    return e
                }

                function Fr(t, e, n) {
                    if (t !== Lr) throw new TypeError("Illegal constructor");
                    this.g = null, Ur(this, e, n)
                }

                function Ur(t, e, n) {
                    if (t.host = e, t.mode = n && n.mode, Dr(t.host), (e = ne(t.host)).root = t, e.gb = "closed" !== t.mode ? t : null, (e = ne(t)).firstChild = e.lastChild = e.parentNode = e.nextSibling = e.previousSibling = null, oe.preferPerformance)
                        for (; e = t.host.__shady_native_firstChild;) t.host.__shady_native_removeChild(e);
                    else Br(t)
                }

                function Br(t) {
                    t.Y || (t.Y = !0, Pe((function() {
                        return Hr(t)
                    })))
                }

                function Hr(t) {
                    var e;
                    if (e = t.Y) {
                        for (var n; t;) t.Y && (n = t), le(t = (e = t).host.__shady_getRootNode()) && (e = re(e.host)) && 0 < e.ia || (t = void 0);
                        e = n
                    }(n = e) && n._renderSelf()
                }

                function Zr(t, e, n) {
                    var r = ne(e),
                        o = r.ua;
                    r.ua = null, n || (n = (t = t.h[e.__shady_slot || "__catchall"]) && t[0]), n ? (ne(n).assignedNodes.push(e), r.assignedSlot = n) : r.assignedSlot = void 0, o !== r.assignedSlot && r.assignedSlot && (ne(r.assignedSlot).xa = !0)
                }

                function Vr(t, e, n) {
                    for (var r = 0, o = void 0; r < n.length && (o = n[r]); r++)
                        if ("slot" == o.localName) {
                            var i = re(o).assignedNodes;
                            i && i.length && Vr(t, e, i)
                        } else e.push(n[r])
                }

                function Wr(t, e) {
                    e.__shady_native_dispatchEvent(new Event("slotchange")), (e = re(e)).assignedSlot && Wr(t, e.assignedSlot)
                }

                function qr(t) {
                    t.i = t.i || [], t.g = t.g || [], t.h = t.h || {}
                }

                function zr(t) {
                    if (t.i && t.i.length) {
                        for (var e, n = t.i, r = 0; r < n.length; r++) {
                            var o = n[r];
                            Dr(o);
                            var i = o.__shady_parentNode;
                            Dr(i), (i = re(i)).ia = (i.ia || 0) + 1, i = Gr(o), t.h[i] ? ((e = e || {})[i] = !0, t.h[i].push(o)) : t.h[i] = [o], t.g.push(o)
                        }
                        if (e)
                            for (var a in e) t.h[a] = Xr(t.h[a]);
                        t.i = []
                    }
                }

                function Gr(t) {
                    var e = t.name || t.getAttribute("name") || "__catchall";
                    return t.Qa = e
                }

                function Xr(t) {
                    return t.sort((function(t, e) {
                        t = Rr(t);
                        for (var n = Rr(e), r = 0; r < t.length; r++) {
                            e = t[r];
                            var o = n[r];
                            if (e !== o) return (t = be(e.__shady_parentNode)).indexOf(e) - t.indexOf(o)
                        }
                    }))
                }

                function Kr(t) {
                    return zr(t), !(!t.g || !t.g.length)
                }
                if (Fr.prototype._renderSelf = function() {
                        var t = Ir;
                        if (Ir = !0, this.Y = !1, this.g) {
                            zr(this);
                            for (var e, n = 0; n < this.g.length; n++) {
                                var r = re(e = this.g[n]),
                                    o = r.assignedNodes;
                                if (r.assignedNodes = [], r.aa = [], r.Ga = o)
                                    for (r = 0; r < o.length; r++) {
                                        var i = re(o[r]);
                                        i.ua = i.assignedSlot, i.assignedSlot === e && (i.assignedSlot = null)
                                    }
                            }
                            for (n = this.host.__shady_firstChild; n; n = n.__shady_nextSibling) Zr(this, n);
                            for (n = 0; n < this.g.length; n++) {
                                if (!(o = re(e = this.g[n])).assignedNodes.length)
                                    for (r = e.__shady_firstChild; r; r = r.__shady_nextSibling) Zr(this, r, e);
                                if ((r = (r = re(e.__shady_parentNode)) && r.root) && (Kr(r) || r.Y) && r._renderSelf(), Vr(this, o.aa, o.assignedNodes), r = o.Ga) {
                                    for (i = 0; i < r.length; i++) re(r[i]).ua = null;
                                    o.Ga = null, r.length > o.assignedNodes.length && (o.xa = !0)
                                }
                                o.xa && (o.xa = !1, Wr(this, e))
                            }
                            for (e = this.g, n = [], o = 0; o < e.length; o++)(i = re(r = e[o].__shady_parentNode)) && i.root || !(0 > n.indexOf(r)) || n.push(r);
                            for (e = 0; e < n.length; e++) {
                                for (o = (i = n[e]) === this ? this.host : i, r = [], i = i.__shady_firstChild; i; i = i.__shady_nextSibling)
                                    if ("slot" == i.localName)
                                        for (var a = re(i).aa, s = 0; s < a.length; s++) r.push(a[s]);
                                    else r.push(i);
                                i = ge(o), a = Mn(r, r.length, i, i.length);
                                for (var l = s = 0, u = void 0; s < a.length && (u = a[s]); s++) {
                                    for (var c = 0, d = void 0; c < u.ga.length && (d = u.ga[c]); c++) d.__shady_native_parentNode === o && o.__shady_native_removeChild(d), i.splice(u.index + l, 1);
                                    l -= u.na
                                }
                                for (l = 0, u = void 0; l < a.length && (u = a[l]); l++)
                                    for (s = i[u.index], c = u.index; c < u.index + u.na; c++) d = r[c], o.__shady_native_insertBefore(d, s), i.splice(c, 0, d)
                            }
                        }
                        if (!oe.preferPerformance && !this.Fa)
                            for (n = this.host.__shady_firstChild; n; n = n.__shady_nextSibling) e = re(n), n.__shady_native_parentNode !== this.host || "slot" !== n.localName && e.assignedSlot || this.host.__shady_native_removeChild(n);
                        this.Fa = !0, Ir = t, jr && jr()
                    }, function(t) {
                        t.__proto__ = DocumentFragment.prototype, Mr(t, "__shady_"), Mr(t), Object.defineProperties(t, {
                            nodeType: {
                                value: Node.DOCUMENT_FRAGMENT_NODE,
                                configurable: !0
                            },
                            nodeName: {
                                value: "#document-fragment",
                                configurable: !0
                            },
                            nodeValue: {
                                value: null,
                                configurable: !0
                            }
                        }), ["localName", "namespaceURI", "prefix"].forEach((function(e) {
                            Object.defineProperty(t, e, {
                                value: void 0,
                                configurable: !0
                            })
                        })), ["ownerDocument", "baseURI", "isConnected"].forEach((function(e) {
                            Object.defineProperty(t, e, {
                                get: function() {
                                    return this.host[e]
                                },
                                configurable: !0
                            })
                        }))
                    }(Fr.prototype), window.customElements && window.customElements.define && oe.ya && !oe.preferPerformance) {
                    var Yr = new Map;
                    jr = function() {
                        var t = [];
                        Yr.forEach((function(e, n) {
                            t.push([n, e])
                        })), Yr.clear();
                        for (var e = 0; e < t.length; e++) {
                            var n = t[e][0];
                            t[e][1] ? n.__shadydom_connectedCallback() : n.__shadydom_disconnectedCallback()
                        }
                    }, Ir && document.addEventListener("readystatechange", (function() {
                        Ir = !1, jr()
                    }), {
                        once: !0
                    });
                    var Jr = window.customElements.define,
                        $r = function(t, e) {
                            var n = e.prototype.connectedCallback,
                                r = e.prototype.disconnectedCallback;
                            Jr.call(window.customElements, t, function(t, e, n) {
                                var r = 0,
                                    o = "__isConnected" + r++;
                                return (e || n) && (t.prototype.connectedCallback = t.prototype.__shadydom_connectedCallback = function() {
                                    Ir ? Yr.set(this, !0) : this[o] || (this[o] = !0, e && e.call(this))
                                }, t.prototype.disconnectedCallback = t.prototype.__shadydom_disconnectedCallback = function() {
                                    Ir ? this.isConnected || Yr.set(this, !1) : this[o] && (this[o] = !1, n && n.call(this))
                                }), t
                            }(e, n, r)), e.prototype.connectedCallback = n, e.prototype.disconnectedCallback = r
                        };
                    window.customElements.define = $r, Object.defineProperty(window.CustomElementRegistry.prototype, "define", {
                        value: $r,
                        configurable: !0
                    })
                }

                function Qr(t) {
                    if (le(t = t.__shady_getRootNode())) return t
                }

                function to(t) {
                    this.node = t
                }

                function eo(t) {
                    Object.defineProperty(to.prototype, t, {
                        get: function() {
                            return this.node["__shady_" + t]
                        },
                        set: function(e) {
                            this.node["__shady_" + t] = e
                        },
                        configurable: !0
                    })
                }(t = to.prototype).addEventListener = function(t, e, n) {
                    return this.node.__shady_addEventListener(t, e, n)
                }, t.removeEventListener = function(t, e, n) {
                    return this.node.__shady_removeEventListener(t, e, n)
                }, t.appendChild = function(t) {
                    return this.node.__shady_appendChild(t)
                }, t.insertBefore = function(t, e) {
                    return this.node.__shady_insertBefore(t, e)
                }, t.removeChild = function(t) {
                    return this.node.__shady_removeChild(t)
                }, t.replaceChild = function(t, e) {
                    return this.node.__shady_replaceChild(t, e)
                }, t.cloneNode = function(t) {
                    return this.node.__shady_cloneNode(t)
                }, t.getRootNode = function(t) {
                    return this.node.__shady_getRootNode(t)
                }, t.contains = function(t) {
                    return this.node.__shady_contains(t)
                }, t.dispatchEvent = function(t) {
                    return this.node.__shady_dispatchEvent(t)
                }, t.setAttribute = function(t, e) {
                    this.node.__shady_setAttribute(t, e)
                }, t.getAttribute = function(t) {
                    return this.node.__shady_native_getAttribute(t)
                }, t.hasAttribute = function(t) {
                    return this.node.__shady_native_hasAttribute(t)
                }, t.removeAttribute = function(t) {
                    this.node.__shady_removeAttribute(t)
                }, t.attachShadow = function(t) {
                    return this.node.__shady_attachShadow(t)
                }, t.focus = function() {
                    this.node.__shady_native_focus()
                }, t.blur = function() {
                    this.node.__shady_blur()
                }, t.importNode = function(t, e) {
                    if (this.node.nodeType === Node.DOCUMENT_NODE) return this.node.__shady_importNode(t, e)
                }, t.getElementById = function(t) {
                    if (this.node.nodeType === Node.DOCUMENT_NODE) return this.node.__shady_getElementById(t)
                }, t.elementsFromPoint = function(t, e) {
                    return this.node.__shady_elementsFromPoint(t, e)
                }, t.elementFromPoint = function(t, e) {
                    return this.node.__shady_elementFromPoint(t, e)
                }, t.querySelector = function(t) {
                    return this.node.__shady_querySelector(t)
                }, t.querySelectorAll = function(t, e) {
                    return this.node.__shady_querySelectorAll(t, e)
                }, t.assignedNodes = function(t) {
                    if ("slot" === this.node.localName) return this.node.__shady_assignedNodes(t)
                }, t.append = function(t) {
                    for (var e = [], n = 0; n < arguments.length; ++n) e[n] = arguments[n];
                    return this.node.__shady_append.apply(this.node, u(e))
                }, t.prepend = function(t) {
                    for (var e = [], n = 0; n < arguments.length; ++n) e[n] = arguments[n];
                    return this.node.__shady_prepend.apply(this.node, u(e))
                }, t.after = function(t) {
                    for (var e = [], n = 0; n < arguments.length; ++n) e[n] = arguments[n];
                    return this.node.__shady_after.apply(this.node, u(e))
                }, t.before = function(t) {
                    for (var e = [], n = 0; n < arguments.length; ++n) e[n] = arguments[n];
                    return this.node.__shady_before.apply(this.node, u(e))
                }, t.remove = function() {
                    return this.node.__shady_remove()
                }, t.replaceWith = function(t) {
                    for (var e = [], n = 0; n < arguments.length; ++n) e[n] = arguments[n];
                    return this.node.__shady_replaceWith.apply(this.node, u(e))
                }, i.Object.defineProperties(to.prototype, {
                    activeElement: {
                        configurable: !0,
                        enumerable: !0,
                        get: function() {
                            if (le(this.node) || this.node.nodeType === Node.DOCUMENT_NODE) return this.node.__shady_activeElement
                        }
                    },
                    _activeElement: {
                        configurable: !0,
                        enumerable: !0,
                        get: function() {
                            return this.activeElement
                        }
                    },
                    host: {
                        configurable: !0,
                        enumerable: !0,
                        get: function() {
                            if (le(this.node)) return this.node.host
                        }
                    },
                    parentNode: {
                        configurable: !0,
                        enumerable: !0,
                        get: function() {
                            return this.node.__shady_parentNode
                        }
                    },
                    firstChild: {
                        configurable: !0,
                        enumerable: !0,
                        get: function() {
                            return this.node.__shady_firstChild
                        }
                    },
                    lastChild: {
                        configurable: !0,
                        enumerable: !0,
                        get: function() {
                            return this.node.__shady_lastChild
                        }
                    },
                    nextSibling: {
                        configurable: !0,
                        enumerable: !0,
                        get: function() {
                            return this.node.__shady_nextSibling
                        }
                    },
                    previousSibling: {
                        configurable: !0,
                        enumerable: !0,
                        get: function() {
                            return this.node.__shady_previousSibling
                        }
                    },
                    childNodes: {
                        configurable: !0,
                        enumerable: !0,
                        get: function() {
                            return this.node.__shady_childNodes
                        }
                    },
                    parentElement: {
                        configurable: !0,
                        enumerable: !0,
                        get: function() {
                            return this.node.__shady_parentElement
                        }
                    },
                    firstElementChild: {
                        configurable: !0,
                        enumerable: !0,
                        get: function() {
                            return this.node.__shady_firstElementChild
                        }
                    },
                    lastElementChild: {
                        configurable: !0,
                        enumerable: !0,
                        get: function() {
                            return this.node.__shady_lastElementChild
                        }
                    },
                    nextElementSibling: {
                        configurable: !0,
                        enumerable: !0,
                        get: function() {
                            return this.node.__shady_nextElementSibling
                        }
                    },
                    previousElementSibling: {
                        configurable: !0,
                        enumerable: !0,
                        get: function() {
                            return this.node.__shady_previousElementSibling
                        }
                    },
                    children: {
                        configurable: !0,
                        enumerable: !0,
                        get: function() {
                            return this.node.__shady_children
                        }
                    },
                    childElementCount: {
                        configurable: !0,
                        enumerable: !0,
                        get: function() {
                            return this.node.__shady_childElementCount
                        }
                    },
                    shadowRoot: {
                        configurable: !0,
                        enumerable: !0,
                        get: function() {
                            return this.node.__shady_shadowRoot
                        }
                    },
                    assignedSlot: {
                        configurable: !0,
                        enumerable: !0,
                        get: function() {
                            return this.node.__shady_assignedSlot
                        }
                    },
                    isConnected: {
                        configurable: !0,
                        enumerable: !0,
                        get: function() {
                            return this.node.__shady_isConnected
                        }
                    },
                    innerHTML: {
                        configurable: !0,
                        enumerable: !0,
                        get: function() {
                            return this.node.__shady_innerHTML
                        },
                        set: function(t) {
                            this.node.__shady_innerHTML = t
                        }
                    },
                    textContent: {
                        configurable: !0,
                        enumerable: !0,
                        get: function() {
                            return this.node.__shady_textContent
                        },
                        set: function(t) {
                            this.node.__shady_textContent = t
                        }
                    },
                    slot: {
                        configurable: !0,
                        enumerable: !0,
                        get: function() {
                            return this.node.__shady_slot
                        },
                        set: function(t) {
                            this.node.__shady_slot = t
                        }
                    },
                    className: {
                        configurable: !0,
                        enumerable: !0,
                        get: function() {
                            return this.node.__shady_className
                        },
                        set: function(t) {
                            this.node.__shady_className = t
                        }
                    }
                }), kn.forEach((function(t) {
                    return eo(t)
                })), Pn.forEach((function(t) {
                    return eo(t)
                }));
                var no = new WeakMap;

                function ro(t) {
                    if (le(t) || t instanceof to) return t;
                    var e = no.get(t);
                    return e || (e = new to(t), no.set(t, e)), e
                }
                if (oe.ya) {
                    var oo = oe.H ? function(t) {
                            return t
                        } : function(t) {
                            return on(t), rn(t), t
                        },
                        io = {
                            inUse: oe.ya,
                            patch: oo,
                            isShadyRoot: le,
                            enqueue: Pe,
                            flush: De,
                            flushInitial: function(t) {
                                !t.Fa && t.Y && Hr(t)
                            },
                            settings: oe,
                            filterMutations: function(t, e) {
                                var n = e.getRootNode();
                                return t.map((function(t) {
                                    var e = n === t.target.getRootNode();
                                    if (e && t.addedNodes) {
                                        if ((e = [].slice.call(t.addedNodes).filter((function(t) {
                                                return n === t.getRootNode()
                                            }))).length) return t = Object.create(t), Object.defineProperty(t, "addedNodes", {
                                            value: e,
                                            configurable: !0
                                        }), t
                                    } else if (e) return t
                                })).filter((function(t) {
                                    return t
                                }))
                            },
                            observeChildren: function(t, e) {
                                var n = ne(t);
                                n.ea || (n.ea = new Ae), n.ea.oa.add(e);
                                var r = n.ea;
                                return {
                                    Ra: e,
                                    X: r,
                                    Sa: t,
                                    takeRecords: function() {
                                        return r.takeRecords()
                                    }
                                }
                            },
                            unobserveChildren: function(t) {
                                var e = t && t.X;
                                e && (e.oa.delete(t.Ra), e.oa.size || (ne(t.Sa).ea = null))
                            },
                            deferConnectionCallbacks: oe.deferConnectionCallbacks,
                            preferPerformance: oe.preferPerformance,
                            handlesDynamicScoping: !0,
                            wrap: oe.J ? ro : oo,
                            wrapIfNeeded: !0 === oe.J ? ro : function(t) {
                                return t
                            },
                            Wrapper: to,
                            composedPath: function(t) {
                                return t.__composedPath || (t.__composedPath = fn(t.target, !0)), t.__composedPath
                            },
                            noPatch: oe.J,
                            patchOnDemand: oe.Aa,
                            nativeMethods: He,
                            nativeTree: Ze,
                            patchElementProto: xr
                        };
                    window.ShadyDOM = io,
                        function() {
                            var t = ["dispatchEvent", "addEventListener", "removeEventListener"];
                            window.EventTarget ? (qe(window.EventTarget.prototype, t), void 0 === window.__shady_native_addEventListener && qe(Window.prototype, t)) : (qe(Node.prototype, t), qe(Window.prototype, t)), Be ? qe(Node.prototype, "parentNode firstChild lastChild previousSibling nextSibling childNodes parentElement textContent".split(" ")) : We(Node.prototype, {
                                parentNode: {
                                    get: function() {
                                        return ze.currentNode = this, ze.parentNode()
                                    }
                                },
                                firstChild: {
                                    get: function() {
                                        return ze.currentNode = this, ze.firstChild()
                                    }
                                },
                                lastChild: {
                                    get: function() {
                                        return ze.currentNode = this, ze.lastChild()
                                    }
                                },
                                previousSibling: {
                                    get: function() {
                                        return ze.currentNode = this, ze.previousSibling()
                                    }
                                },
                                nextSibling: {
                                    get: function() {
                                        return ze.currentNode = this, ze.nextSibling()
                                    }
                                },
                                childNodes: {
                                    get: function() {
                                        var t = [];
                                        ze.currentNode = this;
                                        for (var e = ze.firstChild(); e;) t.push(e), e = ze.nextSibling();
                                        return t
                                    }
                                },
                                parentElement: {
                                    get: function() {
                                        return Ge.currentNode = this, Ge.parentNode()
                                    }
                                },
                                textContent: {
                                    get: function() {
                                        switch (this.nodeType) {
                                            case Node.ELEMENT_NODE:
                                            case Node.DOCUMENT_FRAGMENT_NODE:
                                                for (var t, e = document.createTreeWalker(this, NodeFilter.SHOW_TEXT, null, !1), n = ""; t = e.nextNode();) n += t.nodeValue;
                                                return n;
                                            default:
                                                return this.nodeValue
                                        }
                                    },
                                    set: function(t) {
                                        switch (null == t && (t = ""), this.nodeType) {
                                            case Node.ELEMENT_NODE:
                                            case Node.DOCUMENT_FRAGMENT_NODE:
                                                Ke(this), (0 < t.length || this.nodeType === Node.ELEMENT_NODE) && this.__shady_native_insertBefore(document.createTextNode(t), void 0);
                                                break;
                                            default:
                                                this.nodeValue = t
                                        }
                                    }
                                }
                            }), qe(Node.prototype, "appendChild insertBefore removeChild replaceChild cloneNode contains".split(" ")), qe(HTMLElement.prototype, ["parentElement", "contains"]), t = {
                                firstElementChild: {
                                    get: function() {
                                        return Ge.currentNode = this, Ge.firstChild()
                                    }
                                },
                                lastElementChild: {
                                    get: function() {
                                        return Ge.currentNode = this, Ge.lastChild()
                                    }
                                },
                                children: {
                                    get: function() {
                                        var t = [];
                                        Ge.currentNode = this;
                                        for (var e = Ge.firstChild(); e;) t.push(e), e = Ge.nextSibling();
                                        return _e(t)
                                    }
                                },
                                childElementCount: {
                                    get: function() {
                                        return this.children ? this.children.length : 0
                                    }
                                }
                            }, Be ? (qe(Element.prototype, Ye), qe(Element.prototype, ["previousElementSibling", "nextElementSibling", "innerHTML", "className"]), qe(HTMLElement.prototype, ["children", "innerHTML", "className"])) : (We(Element.prototype, t), We(Element.prototype, {
                                previousElementSibling: {
                                    get: function() {
                                        return Ge.currentNode = this, Ge.previousSibling()
                                    }
                                },
                                nextElementSibling: {
                                    get: function() {
                                        return Ge.currentNode = this, Ge.nextSibling()
                                    }
                                },
                                innerHTML: {
                                    get: function() {
                                        return Ue(this, ge)
                                    },
                                    set: function(t) {
                                        var e = "template" === this.localName ? this.content : this;
                                        Ke(e);
                                        var n = this.localName || "div";
                                        for ((n = this.namespaceURI && this.namespaceURI !== Xe.namespaceURI ? Xe.createElementNS(this.namespaceURI, n) : Xe.createElement(n)).innerHTML = t, t = "template" === this.localName ? n.content : n; n = t.__shady_native_firstChild;) e.__shady_native_insertBefore(n, void 0)
                                    }
                                },
                                className: {
                                    get: function() {
                                        return this.getAttribute("class") || ""
                                    },
                                    set: function(t) {
                                        this.setAttribute("class", t)
                                    }
                                }
                            })), qe(Element.prototype, "setAttribute getAttribute hasAttribute removeAttribute focus blur".split(" ")), qe(Element.prototype, Je), qe(HTMLElement.prototype, ["focus", "blur"]), window.HTMLTemplateElement && qe(window.HTMLTemplateElement.prototype, ["innerHTML"]), Be ? qe(DocumentFragment.prototype, Ye) : We(DocumentFragment.prototype, t), qe(DocumentFragment.prototype, Je), Be ? (qe(Document.prototype, Ye), qe(Document.prototype, ["activeElement"])) : We(Document.prototype, t), qe(Document.prototype, ["importNode", "getElementById", "elementFromPoint", ae()]), qe(Document.prototype, Je)
                        }(), Nr("__shady_"), Object.defineProperty(document, "_activeElement", yr.activeElement), Ee(Window.prototype, br, "__shady_"), oe.J ? oe.Aa && Ee(Element.prototype, ur) : (Nr(), function() {
                            if (!sn && Object.getOwnPropertyDescriptor(Event.prototype, "isTrusted")) {
                                var t = function() {
                                    var t = new MouseEvent("click", {
                                        bubbles: !0,
                                        cancelable: !0,
                                        composed: !0
                                    });
                                    this.__shady_dispatchEvent(t)
                                };
                                Element.prototype.click ? Element.prototype.click = t : HTMLElement.prototype.click && (HTMLElement.prototype.click = t)
                            }
                        }()),
                        function() {
                            for (var t in mn) window.__shady_native_addEventListener(t, (function(t) {
                                t.__target || (Nn(t), gn(t))
                            }), !0)
                        }(), window.Event = xn, window.CustomEvent = Tn, window.MouseEvent = On, window.ShadowRoot = Fr
                }
                var ao = window.Document.prototype.createElement,
                    so = window.Document.prototype.createElementNS,
                    lo = window.Document.prototype.importNode,
                    uo = window.Document.prototype.prepend,
                    co = window.Document.prototype.append,
                    ho = window.DocumentFragment.prototype.prepend,
                    fo = window.DocumentFragment.prototype.append,
                    po = window.Node.prototype.cloneNode,
                    vo = window.Node.prototype.appendChild,
                    mo = window.Node.prototype.insertBefore,
                    yo = window.Node.prototype.removeChild,
                    _o = window.Node.prototype.replaceChild,
                    go = Object.getOwnPropertyDescriptor(window.Node.prototype, "textContent"),
                    bo = window.Element.prototype.attachShadow,
                    wo = Object.getOwnPropertyDescriptor(window.Element.prototype, "innerHTML"),
                    Eo = window.Element.prototype.getAttribute,
                    So = window.Element.prototype.setAttribute,
                    Co = window.Element.prototype.removeAttribute,
                    No = window.Element.prototype.getAttributeNS,
                    xo = window.Element.prototype.setAttributeNS,
                    To = window.Element.prototype.removeAttributeNS,
                    Oo = window.Element.prototype.insertAdjacentElement,
                    ko = window.Element.prototype.insertAdjacentHTML,
                    Po = window.Element.prototype.prepend,
                    Do = window.Element.prototype.append,
                    Ao = window.Element.prototype.before,
                    Mo = window.Element.prototype.after,
                    jo = window.Element.prototype.replaceWith,
                    Lo = window.Element.prototype.remove,
                    Io = window.HTMLElement,
                    Ro = Object.getOwnPropertyDescriptor(window.HTMLElement.prototype, "innerHTML"),
                    Fo = window.HTMLElement.prototype.insertAdjacentElement,
                    Uo = window.HTMLElement.prototype.insertAdjacentHTML,
                    Bo = new Set;

                function Ho(t) {
                    var e = Bo.has(t);
                    return t = /^[a-z][.0-9_a-z]*-[-.0-9_a-z]*$/.test(t), !e && t
                }
                "annotation-xml color-profile font-face font-face-src font-face-uri font-face-format font-face-name missing-glyph".split(" ").forEach((function(t) {
                    return Bo.add(t)
                }));
                var Zo = document.contains ? document.contains.bind(document) : document.documentElement.contains.bind(document.documentElement);

                function Vo(t) {
                    var e = t.isConnected;
                    if (void 0 !== e) return e;
                    if (Zo(t)) return !0;
                    for (; t && !(t.__CE_isImportDocument || t instanceof Document);) t = t.parentNode || (window.ShadowRoot && t instanceof ShadowRoot ? t.host : void 0);
                    return !(!t || !(t.__CE_isImportDocument || t instanceof Document))
                }

                function Wo(t) {
                    var e = t.children;
                    if (e) return Array.prototype.slice.call(e);
                    for (e = [], t = t.firstChild; t; t = t.nextSibling) t.nodeType === Node.ELEMENT_NODE && e.push(t);
                    return e
                }

                function qo(t, e) {
                    for (; e && e !== t && !e.nextSibling;) e = e.parentNode;
                    return e && e !== t ? e.nextSibling : null
                }

                function zo(t, e, n) {
                    for (var r = t; r;) {
                        if (r.nodeType === Node.ELEMENT_NODE) {
                            var o = r;
                            e(o);
                            var i = o.localName;
                            if ("link" === i && "import" === o.getAttribute("rel")) {
                                if (r = o.import, void 0 === n && (n = new Set), r instanceof Node && !n.has(r))
                                    for (n.add(r), r = r.firstChild; r; r = r.nextSibling) zo(r, e, n);
                                r = qo(t, o);
                                continue
                            }
                            if ("template" === i) {
                                r = qo(t, o);
                                continue
                            }
                            if (o = o.__CE_shadowRoot)
                                for (o = o.firstChild; o; o = o.nextSibling) zo(o, e, n)
                        }
                        r = r.firstChild ? r.firstChild : qo(t, r)
                    }
                }

                function Go() {
                    var t = !(null == pi || !pi.noDocumentConstructionObserver),
                        e = !(null == pi || !pi.shadyDomFastWalk);
                    this.ca = [], this.g = [], this.W = !1, this.shadyDomFastWalk = e, this.nb = !t
                }

                function Xo(t, e, n, r) {
                    var o = window.ShadyDOM;
                    if (t.shadyDomFastWalk && o && o.inUse) {
                        if (e.nodeType === Node.ELEMENT_NODE && n(e), e.querySelectorAll)
                            for (t = o.nativeMethods.querySelectorAll.call(e, "*"), e = 0; e < t.length; e++) n(t[e])
                    } else zo(e, n, r)
                }

                function Ko(t, e) {
                    t.W && Xo(t, e, (function(e) {
                        return Yo(t, e)
                    }))
                }

                function Yo(t, e) {
                    if (t.W && !e.__CE_patched) {
                        e.__CE_patched = !0;
                        for (var n = 0; n < t.ca.length; n++) t.ca[n](e);
                        for (n = 0; n < t.g.length; n++) t.g[n](e)
                    }
                }

                function Jo(t, e) {
                    var n = [];
                    for (Xo(t, e, (function(t) {
                            return n.push(t)
                        })), e = 0; e < n.length; e++) {
                        var r = n[e];
                        1 === r.__CE_state ? t.connectedCallback(r) : ti(t, r)
                    }
                }

                function $o(t, e) {
                    var n = [];
                    for (Xo(t, e, (function(t) {
                            return n.push(t)
                        })), e = 0; e < n.length; e++) {
                        var r = n[e];
                        1 === r.__CE_state && t.disconnectedCallback(r)
                    }
                }

                function Qo(t, e, n) {
                    var r = (n = void 0 === n ? {} : n).ob,
                        o = n.upgrade || function(e) {
                            return ti(t, e)
                        },
                        i = [];
                    for (Xo(t, e, (function(e) {
                            if (t.W && Yo(t, e), "link" === e.localName && "import" === e.getAttribute("rel")) {
                                var n = e.import;
                                n instanceof Node && (n.__CE_isImportDocument = !0, n.__CE_registry = document.__CE_registry), n && "complete" === n.readyState ? n.__CE_documentLoadHandled = !0 : e.addEventListener("load", (function() {
                                    var n = e.import;
                                    if (!n.__CE_documentLoadHandled) {
                                        n.__CE_documentLoadHandled = !0;
                                        var i = new Set;
                                        r && (r.forEach((function(t) {
                                            return i.add(t)
                                        })), i.delete(n)), Qo(t, n, {
                                            ob: i,
                                            upgrade: o
                                        })
                                    }
                                }))
                            } else i.push(e)
                        }), r), e = 0; e < i.length; e++) o(i[e])
                }

                function ti(t, e) {
                    try {
                        var n = e.ownerDocument,
                            r = n.__CE_registry,
                            o = r && (n.defaultView || n.__CE_isImportDocument) ? ci(r, e.localName) : void 0;
                        if (o && void 0 === e.__CE_state) {
                            o.constructionStack.push(e);
                            try {
                                try {
                                    if (new o.constructorFunction !== e) throw Error("The custom element constructor did not produce the element being upgraded.")
                                } finally {
                                    o.constructionStack.pop()
                                }
                            } catch (t) {
                                throw e.__CE_state = 2, t
                            }
                            if (e.__CE_state = 1, e.__CE_definition = o, o.attributeChangedCallback && e.hasAttributes()) {
                                var i = o.observedAttributes;
                                for (o = 0; o < i.length; o++) {
                                    var a = i[o],
                                        s = e.getAttribute(a);
                                    null !== s && t.attributeChangedCallback(e, a, null, s, null)
                                }
                            }
                            Vo(e) && t.connectedCallback(e)
                        }
                    } catch (t) {
                        ni(t)
                    }
                }

                function ei(t, e, n, r) {
                    var o = e.__CE_registry;
                    if (o && (null === r || "http://www.w3.org/1999/xhtml" === r) && (o = ci(o, n))) try {
                        var i = new o.constructorFunction;
                        if (void 0 === i.__CE_state || void 0 === i.__CE_definition) throw Error("Failed to construct '" + n + "': The returned value was not constructed with the HTMLElement constructor.");
                        if ("http://www.w3.org/1999/xhtml" !== i.namespaceURI) throw Error("Failed to construct '" + n + "': The constructed element's namespace must be the HTML namespace.");
                        if (i.hasAttributes()) throw Error("Failed to construct '" + n + "': The constructed element must not have any attributes.");
                        if (null !== i.firstChild) throw Error("Failed to construct '" + n + "': The constructed element must not have any children.");
                        if (null !== i.parentNode) throw Error("Failed to construct '" + n + "': The constructed element must not have a parent node.");
                        if (i.ownerDocument !== e) throw Error("Failed to construct '" + n + "': The constructed element's owner document is incorrect.");
                        if (i.localName !== n) throw Error("Failed to construct '" + n + "': The constructed element's local name is incorrect.");
                        return i
                    } catch (o) {
                        return ni(o), e = null === r ? ao.call(e, n) : so.call(e, r, n), Object.setPrototypeOf(e, HTMLUnknownElement.prototype), e.__CE_state = 2, e.__CE_definition = void 0, Yo(t, e), e
                    }
                    return Yo(t, e = null === r ? ao.call(e, n) : so.call(e, r, n)), e
                }

                function ni(t) {
                    var e = t.message,
                        n = t.sourceURL || t.fileName || "",
                        r = t.line || t.lineNumber || 0,
                        o = t.column || t.columnNumber || 0,
                        i = void 0;
                    void 0 === ErrorEvent.prototype.initErrorEvent ? i = new ErrorEvent("error", {
                        cancelable: !0,
                        message: e,
                        filename: n,
                        lineno: r,
                        colno: o,
                        error: t
                    }) : ((i = document.createEvent("ErrorEvent")).initErrorEvent("error", !1, !0, e, n, r), i.preventDefault = function() {
                        Object.defineProperty(this, "defaultPrevented", {
                            configurable: !0,
                            get: function() {
                                return !0
                            }
                        })
                    }), void 0 === i.error && Object.defineProperty(i, "error", {
                        configurable: !0,
                        enumerable: !0,
                        get: function() {
                            return t
                        }
                    }), window.dispatchEvent(i), i.defaultPrevented
                }

                function ri() {
                    var t = this;
                    this.I = void 0, this.Ha = new Promise((function(e) {
                        t.g = e
                    }))
                }

                function oi(t) {
                    var e = document;
                    this.X = void 0, this.S = t, this.g = e, Qo(this.S, this.g), "loading" === this.g.readyState && (this.X = new MutationObserver(this.h.bind(this)), this.X.observe(this.g, {
                        childList: !0,
                        subtree: !0
                    }))
                }

                function ii(t) {
                    t.X && t.X.disconnect()
                }

                function ai(t) {
                    this.ka = new Map, this.la = new Map, this.Ca = new Map, this.ta = !1, this.wa = new Map, this.ja = function(t) {
                        return t()
                    }, this.V = !1, this.ma = [], this.S = t, this.Da = t.nb ? new oi(t) : void 0
                }

                function si(t, e) {
                    if (!Ho(e)) throw new SyntaxError("The element name '" + e + "' is not valid.");
                    if (ci(t, e)) throw Error("A custom element with name '" + e + "' has already been defined.");
                    if (t.ta) throw Error("A custom element is already being defined.")
                }

                function li(t, e, n) {
                    var r;
                    t.ta = !0;
                    try {
                        var o = n.prototype;
                        if (!(o instanceof Object)) throw new TypeError("The custom element constructor's prototype is not an object.");
                        var i = function(t) {
                                var e = o[t];
                                if (void 0 !== e && !(e instanceof Function)) throw Error("The '" + t + "' callback must be a function.");
                                return e
                            },
                            a = i("connectedCallback"),
                            s = i("disconnectedCallback"),
                            l = i("adoptedCallback"),
                            u = (r = i("attributeChangedCallback")) && n.observedAttributes || []
                    } catch (t) {
                        throw t
                    } finally {
                        t.ta = !1
                    }
                    return n = {
                        localName: e,
                        constructorFunction: n,
                        connectedCallback: a,
                        disconnectedCallback: s,
                        adoptedCallback: l,
                        attributeChangedCallback: r,
                        observedAttributes: u,
                        constructionStack: []
                    }, t.la.set(e, n), t.Ca.set(n.constructorFunction, n), n
                }

                function ui(t) {
                    if (!1 !== t.V) {
                        t.V = !1;
                        for (var e = [], n = t.ma, r = new Map, o = 0; o < n.length; o++) r.set(n[o], []);
                        for (Qo(t.S, document, {
                                upgrade: function(n) {
                                    if (void 0 === n.__CE_state) {
                                        var o = n.localName,
                                            i = r.get(o);
                                        i ? i.push(n) : t.la.has(o) && e.push(n)
                                    }
                                }
                            }), o = 0; o < e.length; o++) ti(t.S, e[o]);
                        for (o = 0; o < n.length; o++) {
                            for (var i = n[o], a = r.get(i), s = 0; s < a.length; s++) ti(t.S, a[s]);
                            (i = t.wa.get(i)) && i.resolve(void 0)
                        }
                        n.length = 0
                    }
                }

                function ci(t, e) {
                    var n = t.la.get(e);
                    if (n) return n;
                    if (n = t.ka.get(e)) {
                        t.ka.delete(e);
                        try {
                            return li(t, e, n())
                        } catch (t) {
                            ni(t)
                        }
                    }
                }

                function di(t, e, n) {
                    function r(e) {
                        return function(n) {
                            for (var r = [], o = 0; o < arguments.length; ++o) r[o] = arguments[o];
                            o = [];
                            for (var i = [], a = 0; a < r.length; a++) {
                                var s = r[a];
                                if (s instanceof Element && Vo(s) && i.push(s), s instanceof DocumentFragment)
                                    for (s = s.firstChild; s; s = s.nextSibling) o.push(s);
                                else o.push(s)
                            }
                            for (e.apply(this, r), r = 0; r < i.length; r++) $o(t, i[r]);
                            if (Vo(this))
                                for (r = 0; r < o.length; r++)(i = o[r]) instanceof Element && Jo(t, i)
                        }
                    }
                    void 0 !== n.prepend && (e.prepend = r(n.prepend)), void 0 !== n.append && (e.append = r(n.append))
                }

                function hi(t) {
                    function e(e, n) {
                        Object.defineProperty(e, "innerHTML", {
                            enumerable: n.enumerable,
                            configurable: !0,
                            get: n.get,
                            set: function(e) {
                                var r = this,
                                    o = void 0;
                                if (Vo(this) && (o = [], Xo(t, this, (function(t) {
                                        t !== r && o.push(t)
                                    }))), n.set.call(this, e), o)
                                    for (var i = 0; i < o.length; i++) {
                                        var a = o[i];
                                        1 === a.__CE_state && t.disconnectedCallback(a)
                                    }
                                return this.ownerDocument.__CE_registry ? Qo(t, this) : Ko(t, this), e
                            }
                        })
                    }

                    function n(e, n) {
                        e.insertAdjacentElement = function(e, r) {
                            var o = Vo(r);
                            return e = n.call(this, e, r), o && $o(t, r), Vo(e) && Jo(t, r), e
                        }
                    }

                    function r(e, n) {
                        function r(e, n) {
                            for (var r = []; e !== n; e = e.nextSibling) r.push(e);
                            for (n = 0; n < r.length; n++) Qo(t, r[n])
                        }
                        e.insertAdjacentHTML = function(t, e) {
                            if ("beforebegin" === (t = t.toLowerCase())) {
                                var o = this.previousSibling;
                                n.call(this, t, e), r(o || this.parentNode.firstChild, this)
                            } else if ("afterbegin" === t) o = this.firstChild, n.call(this, t, e), r(this.firstChild, o);
                            else if ("beforeend" === t) o = this.lastChild, n.call(this, t, e), r(o || this.firstChild, null);
                            else {
                                if ("afterend" !== t) throw new SyntaxError("The value provided (" + String(t) + ") is not one of 'beforebegin', 'afterbegin', 'beforeend', or 'afterend'.");
                                o = this.nextSibling, n.call(this, t, e), r(this.nextSibling, o)
                            }
                        }
                    }
                    bo && (Element.prototype.attachShadow = function(e) {
                            if (e = bo.call(this, e), t.W && !e.__CE_patched) {
                                e.__CE_patched = !0;
                                for (var n = 0; n < t.ca.length; n++) t.ca[n](e)
                            }
                            return this.__CE_shadowRoot = e
                        }), wo && wo.get ? e(Element.prototype, wo) : Ro && Ro.get ? e(HTMLElement.prototype, Ro) : function(t, e) {
                            t.W = !0, t.g.push(e)
                        }(t, (function(t) {
                            e(t, {
                                enumerable: !0,
                                configurable: !0,
                                get: function() {
                                    return po.call(this, !0).innerHTML
                                },
                                set: function(t) {
                                    var e = "template" === this.localName,
                                        n = e ? this.content : this,
                                        r = so.call(document, this.namespaceURI, this.localName);
                                    for (r.innerHTML = t; 0 < n.childNodes.length;) yo.call(n, n.childNodes[0]);
                                    for (t = e ? r.content : r; 0 < t.childNodes.length;) vo.call(n, t.childNodes[0])
                                }
                            })
                        })), Element.prototype.setAttribute = function(e, n) {
                            if (1 !== this.__CE_state) return So.call(this, e, n);
                            var r = Eo.call(this, e);
                            So.call(this, e, n), n = Eo.call(this, e), t.attributeChangedCallback(this, e, r, n, null)
                        }, Element.prototype.setAttributeNS = function(e, n, r) {
                            if (1 !== this.__CE_state) return xo.call(this, e, n, r);
                            var o = No.call(this, e, n);
                            xo.call(this, e, n, r), r = No.call(this, e, n), t.attributeChangedCallback(this, n, o, r, e)
                        }, Element.prototype.removeAttribute = function(e) {
                            if (1 !== this.__CE_state) return Co.call(this, e);
                            var n = Eo.call(this, e);
                            Co.call(this, e), null !== n && t.attributeChangedCallback(this, e, n, null, null)
                        }, Element.prototype.removeAttributeNS = function(e, n) {
                            if (1 !== this.__CE_state) return To.call(this, e, n);
                            var r = No.call(this, e, n);
                            To.call(this, e, n);
                            var o = No.call(this, e, n);
                            r !== o && t.attributeChangedCallback(this, n, r, o, e)
                        }, Fo ? n(HTMLElement.prototype, Fo) : Oo && n(Element.prototype, Oo), Uo ? r(HTMLElement.prototype, Uo) : ko && r(Element.prototype, ko), di(t, Element.prototype, {
                            prepend: Po,
                            append: Do
                        }),
                        function(t) {
                            function e(e) {
                                return function(n) {
                                    for (var r = [], o = 0; o < arguments.length; ++o) r[o] = arguments[o];
                                    o = [];
                                    for (var i = [], a = 0; a < r.length; a++) {
                                        var s = r[a];
                                        if (s instanceof Element && Vo(s) && i.push(s), s instanceof DocumentFragment)
                                            for (s = s.firstChild; s; s = s.nextSibling) o.push(s);
                                        else o.push(s)
                                    }
                                    for (e.apply(this, r), r = 0; r < i.length; r++) $o(t, i[r]);
                                    if (Vo(this))
                                        for (r = 0; r < o.length; r++)(i = o[r]) instanceof Element && Jo(t, i)
                                }
                            }
                            var n = Element.prototype;
                            void 0 !== Ao && (n.before = e(Ao)), void 0 !== Mo && (n.after = e(Mo)), void 0 !== jo && (n.replaceWith = function(e) {
                                for (var n = [], r = 0; r < arguments.length; ++r) n[r] = arguments[r];
                                r = [];
                                for (var o = [], i = 0; i < n.length; i++) {
                                    var a = n[i];
                                    if (a instanceof Element && Vo(a) && o.push(a), a instanceof DocumentFragment)
                                        for (a = a.firstChild; a; a = a.nextSibling) r.push(a);
                                    else r.push(a)
                                }
                                for (i = Vo(this), jo.apply(this, n), n = 0; n < o.length; n++) $o(t, o[n]);
                                if (i)
                                    for ($o(t, this), n = 0; n < r.length; n++)(o = r[n]) instanceof Element && Jo(t, o)
                            }), void 0 !== Lo && (n.remove = function() {
                                var e = Vo(this);
                                Lo.call(this), e && $o(t, this)
                            })
                        }(t)
                }
                Go.prototype.connectedCallback = function(t) {
                    var e = t.__CE_definition;
                    if (e.connectedCallback) try {
                        e.connectedCallback.call(t)
                    } catch (t) {
                        ni(t)
                    }
                }, Go.prototype.disconnectedCallback = function(t) {
                    var e = t.__CE_definition;
                    if (e.disconnectedCallback) try {
                        e.disconnectedCallback.call(t)
                    } catch (t) {
                        ni(t)
                    }
                }, Go.prototype.attributeChangedCallback = function(t, e, n, r, o) {
                    var i = t.__CE_definition;
                    if (i.attributeChangedCallback && -1 < i.observedAttributes.indexOf(e)) try {
                        i.attributeChangedCallback.call(t, e, n, r, o)
                    } catch (t) {
                        ni(t)
                    }
                }, ri.prototype.resolve = function(t) {
                    if (this.I) throw Error("Already resolved.");
                    this.I = t, this.g(t)
                }, oi.prototype.h = function(t) {
                    var e = this.g.readyState;
                    for ("interactive" !== e && "complete" !== e || ii(this), e = 0; e < t.length; e++)
                        for (var n = t[e].addedNodes, r = 0; r < n.length; r++) Qo(this.S, n[r])
                }, (t = ai.prototype).eb = function(t, e) {
                    var n = this;
                    if (!(e instanceof Function)) throw new TypeError("Custom element constructor getters must be functions.");
                    si(this, t), this.ka.set(t, e), this.ma.push(t), this.V || (this.V = !0, this.ja((function() {
                        return ui(n)
                    })))
                }, t.define = function(t, e) {
                    var n = this;
                    if (!(e instanceof Function)) throw new TypeError("Custom element constructors must be functions.");
                    si(this, t), li(this, t, e), this.ma.push(t), this.V || (this.V = !0, this.ja((function() {
                        return ui(n)
                    })))
                }, t.upgrade = function(t) {
                    Qo(this.S, t)
                }, t.get = function(t) {
                    if (t = ci(this, t)) return t.constructorFunction
                }, t.whenDefined = function(t) {
                    if (!Ho(t)) return Promise.reject(new SyntaxError("'" + t + "' is not a valid custom element name."));
                    var e = this.wa.get(t);
                    if (e) return e.Ha;
                    e = new ri, this.wa.set(t, e);
                    var n = this.la.has(t) || this.ka.has(t);
                    return t = -1 === this.ma.indexOf(t), n && t && e.resolve(void 0), e.Ha
                }, t.polyfillWrapFlushCallback = function(t) {
                    this.Da && ii(this.Da);
                    var e = this.ja;
                    this.ja = function(n) {
                        return t((function() {
                            return e(n)
                        }))
                    }
                }, window.CustomElementRegistry = ai, ai.prototype.define = ai.prototype.define, ai.prototype.upgrade = ai.prototype.upgrade, ai.prototype.get = ai.prototype.get, ai.prototype.whenDefined = ai.prototype.whenDefined, ai.prototype.polyfillDefineLazy = ai.prototype.eb, ai.prototype.polyfillWrapFlushCallback = ai.prototype.polyfillWrapFlushCallback;
                var fi = {};
                var pi = window.customElements;

                function vi() {
                    var t = new Go;
                    ! function(t) {
                        function e() {
                            var e = this.constructor,
                                n = document.__CE_registry.Ca.get(e);
                            if (!n) throw Error("Failed to construct a custom element: The constructor was not registered with `customElements`.");
                            var r = n.constructionStack;
                            if (0 === r.length) return r = ao.call(document, n.localName), Object.setPrototypeOf(r, e.prototype), r.__CE_state = 1, r.__CE_definition = n, Yo(t, r), r;
                            var o = r.length - 1,
                                i = r[o];
                            if (i === fi) throw Error("Failed to construct '" + n.localName + "': This element was already constructed.");
                            return r[o] = fi, Object.setPrototypeOf(i, e.prototype), Yo(t, i), i
                        }
                        e.prototype = Io.prototype, Object.defineProperty(HTMLElement.prototype, "constructor", {
                            writable: !0,
                            configurable: !0,
                            enumerable: !1,
                            value: e
                        }), window.HTMLElement = e
                    }(t),
                    function(t) {
                        Document.prototype.createElement = function(e) {
                            return ei(t, this, e, null)
                        }, Document.prototype.importNode = function(e, n) {
                            return e = lo.call(this, e, !!n), this.__CE_registry ? Qo(t, e) : Ko(t, e), e
                        }, Document.prototype.createElementNS = function(e, n) {
                            return ei(t, this, n, e)
                        }, di(t, Document.prototype, {
                            prepend: uo,
                            append: co
                        })
                    }(t), di(t, DocumentFragment.prototype, {
                            prepend: ho,
                            append: fo
                        }),
                        function(t) {
                            function e(e, n) {
                                Object.defineProperty(e, "textContent", {
                                    enumerable: n.enumerable,
                                    configurable: !0,
                                    get: n.get,
                                    set: function(e) {
                                        if (this.nodeType === Node.TEXT_NODE) n.set.call(this, e);
                                        else {
                                            var r = void 0;
                                            if (this.firstChild) {
                                                var o = this.childNodes,
                                                    i = o.length;
                                                if (0 < i && Vo(this)) {
                                                    r = Array(i);
                                                    for (var a = 0; a < i; a++) r[a] = o[a]
                                                }
                                            }
                                            if (n.set.call(this, e), r)
                                                for (e = 0; e < r.length; e++) $o(t, r[e])
                                        }
                                    }
                                })
                            }
                            Node.prototype.insertBefore = function(e, n) {
                                if (e instanceof DocumentFragment) {
                                    var r = Wo(e);
                                    if (e = mo.call(this, e, n), Vo(this))
                                        for (n = 0; n < r.length; n++) Jo(t, r[n]);
                                    return e
                                }
                                return r = e instanceof Element && Vo(e), n = mo.call(this, e, n), r && $o(t, e), Vo(this) && Jo(t, e), n
                            }, Node.prototype.appendChild = function(e) {
                                if (e instanceof DocumentFragment) {
                                    var n = Wo(e);
                                    if (e = vo.call(this, e), Vo(this))
                                        for (var r = 0; r < n.length; r++) Jo(t, n[r]);
                                    return e
                                }
                                return n = e instanceof Element && Vo(e), r = vo.call(this, e), n && $o(t, e), Vo(this) && Jo(t, e), r
                            }, Node.prototype.cloneNode = function(e) {
                                return e = po.call(this, !!e), this.ownerDocument.__CE_registry ? Qo(t, e) : Ko(t, e), e
                            }, Node.prototype.removeChild = function(e) {
                                var n = e instanceof Element && Vo(e),
                                    r = yo.call(this, e);
                                return n && $o(t, e), r
                            }, Node.prototype.replaceChild = function(e, n) {
                                if (e instanceof DocumentFragment) {
                                    var r = Wo(e);
                                    if (e = _o.call(this, e, n), Vo(this))
                                        for ($o(t, n), n = 0; n < r.length; n++) Jo(t, r[n]);
                                    return e
                                }
                                r = e instanceof Element && Vo(e);
                                var o = _o.call(this, e, n),
                                    i = Vo(this);
                                return i && $o(t, n), r && $o(t, e), i && Jo(t, e), o
                            }, go && go.get ? e(Node.prototype, go) : function(t, e) {
                                t.W = !0, t.ca.push(e)
                            }(t, (function(t) {
                                e(t, {
                                    enumerable: !0,
                                    configurable: !0,
                                    get: function() {
                                        for (var t = [], e = this.firstChild; e; e = e.nextSibling) e.nodeType !== Node.COMMENT_NODE && t.push(e.textContent);
                                        return t.join("")
                                    },
                                    set: function(t) {
                                        for (; this.firstChild;) yo.call(this, this.firstChild);
                                        null != t && "" !== t && vo.call(this, document.createTextNode(t))
                                    }
                                })
                            }))
                        }(t), hi(t), t = new ai(t), document.__CE_registry = t, Object.defineProperty(window, "customElements", {
                            configurable: !0,
                            enumerable: !0,
                            value: t
                        })
                }

                function mi() {
                    this.end = this.start = 0, this.rules = this.parent = this.previous = null, this.cssText = this.parsedCssText = "", this.atRule = !1, this.type = 0, this.parsedSelector = this.selector = this.keyframesName = ""
                }

                function yi(t) {
                    var e = t = t.replace(xi, "").replace(Ti, ""),
                        n = new mi;
                    n.start = 0, n.end = e.length;
                    for (var r = n, o = 0, i = e.length; o < i; o++)
                        if ("{" === e[o]) {
                            r.rules || (r.rules = []);
                            var a = r,
                                s = a.rules[a.rules.length - 1] || null;
                            (r = new mi).start = o + 1, r.parent = a, r.previous = s, a.rules.push(r)
                        } else "}" === e[o] && (r.end = o + 1, r = r.parent || n);
                    return _i(n, t)
                }

                function _i(t, e) {
                    var n = e.substring(t.start, t.end - 1);
                    if (t.parsedCssText = t.cssText = n.trim(), t.parent && (n = (n = (n = function(t) {
                            return t.replace(/\\([0-9a-f]{1,6})\s/gi, (function(t, e) {
                                for (e = 6 - (t = e).length; e--;) t = "0" + t;
                                return "\\" + t
                            }))
                        }(n = e.substring(t.previous ? t.previous.end : t.parent.start, t.start - 1))).replace(Mi, " ")).substring(n.lastIndexOf(";") + 1), n = t.parsedSelector = t.selector = n.trim(), t.atRule = 0 === n.indexOf("@"), t.atRule ? 0 === n.indexOf("@media") ? t.type = Ci : n.match(Ai) && (t.type = Si, t.keyframesName = t.selector.split(Mi).pop()) : t.type = 0 === n.indexOf("--") ? Ni : Ei), n = t.rules)
                        for (var r = 0, o = n.length, i = void 0; r < o && (i = n[r]); r++) _i(i, e);
                    return t
                }

                function gi(t, e, n) {
                    n = void 0 === n ? "" : n;
                    var r = "";
                    if (t.cssText || t.rules) {
                        var o, i = t.rules;
                        if ((o = i) && (o = !((o = i[0]) && o.selector && 0 === o.selector.indexOf("--"))), o) {
                            o = 0;
                            for (var a = i.length, s = void 0; o < a && (s = i[o]); o++) r = gi(s, e, r)
                        } else e ? e = t.cssText : e = (e = (e = t.cssText).replace(Oi, "").replace(ki, "")).replace(Pi, "").replace(Di, ""), (r = e.trim()) && (r = "  " + r + "\n")
                    }
                    return r && (t.selector && (n += t.selector + " {\n"), n += r, t.selector && (n += "}\n\n")), n
                }
                pi && !pi.forcePolyfill && "function" == typeof pi.define && "function" == typeof pi.get || vi(), window.__CE_installPolyfill = vi;
                var bi, wi, Ei = 1,
                    Si = 7,
                    Ci = 4,
                    Ni = 1e3,
                    xi = /\/\*[^*]*\*+([^/*][^*]*\*+)*\//gim,
                    Ti = /@import[^;]*;/gim,
                    Oi = /(?:^[^;\-\s}]+)?--[^;{}]*?:[^{};]*?(?:[;\n]|$)/gim,
                    ki = /(?:^[^;\-\s}]+)?--[^;{}]*?:[^{};]*?{[^}]*?}(?:[;\n]|$)?/gim,
                    Pi = /@apply\s*\(?[^);]*\)?\s*(?:[;\n]|$)?/gim,
                    Di = /[^;:]*?:[^;]*?var\([^;]*\)(?:[;\n]|$)?/gim,
                    Ai = /^@[^\s]*keyframes/,
                    Mi = /\s+/g,
                    ji = !(window.ShadyDOM && window.ShadyDOM.inUse);

                function Li(t) {
                    bi = (!t || !t.shimcssproperties) && (ji || !(navigator.userAgent.match(/AppleWebKit\/601|Edge\/15/) || !window.CSS || !CSS.supports || !CSS.supports("box-shadow", "0 0 0 var(--foo)")))
                }
                window.ShadyCSS && void 0 !== window.ShadyCSS.cssBuild && (wi = window.ShadyCSS.cssBuild);
                var Ii = !(!window.ShadyCSS || !window.ShadyCSS.disableRuntime);
                window.ShadyCSS && void 0 !== window.ShadyCSS.nativeCss ? bi = window.ShadyCSS.nativeCss : window.ShadyCSS ? (Li(window.ShadyCSS), window.ShadyCSS = void 0) : Li(window.WebComponents && window.WebComponents.flags);
                var Ri = bi,
                    Fi = /(?:^|[;\s{]\s*)(--[\w-]*?)\s*:\s*(?:((?:'(?:\\'|.)*?'|"(?:\\"|.)*?"|\([^)]*?\)|[^};{])+)|\{([^}]*)\}(?:(?=[;\s}])|$))/gi,
                    Ui = /(?:^|\W+)@apply\s*\(?([^);\n]*)\)?/gi,
                    Bi = /(--[\w-]+)\s*([:,;)]|$)/gi,
                    Hi = /(animation\s*:)|(animation-name\s*:)/,
                    Zi = /@media\s(.*)/,
                    Vi = /\{[^}]*\}/g,
                    Wi = new Set;

                function qi(t, e) {
                    return t ? ("string" == typeof t && (t = yi(t)), e && Xi(t, e), gi(t, Ri)) : ""
                }

                function zi(t) {
                    return !t.__cssRules && t.textContent && (t.__cssRules = yi(t.textContent)), t.__cssRules || null
                }

                function Gi(t) {
                    return !!t.parent && t.parent.type === Si
                }

                function Xi(t, e, n, r) {
                    if (t) {
                        var o = !1,
                            i = t.type;
                        if (r && i === Ci) {
                            var a = t.selector.match(Zi);
                            a && (window.matchMedia(a[1]).matches || (o = !0))
                        }
                        if (i === Ei ? e(t) : n && i === Si ? n(t) : i === Ni && (o = !0), (t = t.rules) && !o)
                            for (o = 0, i = t.length, a = void 0; o < i && (a = t[o]); o++) Xi(a, e, n, r)
                    }
                }

                function Ki(t, e, n, r) {
                    var o = document.createElement("style");
                    return e && o.setAttribute("scope", e), o.textContent = t, $i(o, n, r), o
                }
                var Yi = null;

                function Ji(t) {
                    t = document.createComment(" Shady DOM styles for " + t + " ");
                    var e = document.head;
                    return e.insertBefore(t, (Yi ? Yi.nextSibling : null) || e.firstChild), Yi = t
                }

                function $i(t, e, n) {
                    (e = e || document.head).insertBefore(t, n && n.nextSibling || e.firstChild), Yi ? t.compareDocumentPosition(Yi) === Node.DOCUMENT_POSITION_PRECEDING && (Yi = t) : Yi = t
                }

                function Qi(t, e) {
                    for (var n = 0, r = t.length; e < r; e++)
                        if ("(" === t[e]) n++;
                        else if (")" === t[e] && 0 == --n) return e;
                    return -1
                }

                function ta(t, e) {
                    var n = t.indexOf("var(");
                    if (-1 === n) return e(t, "", "", "");
                    var r = Qi(t, n + 3),
                        o = t.substring(n + 4, r);
                    return n = t.substring(0, n), t = ta(t.substring(r + 1), e), -1 === (r = o.indexOf(",")) ? e(n, o.trim(), "", t) : e(n, o.substring(0, r).trim(), o.substring(r + 1).trim(), t)
                }

                function ea(t, e) {
                    ji ? t.setAttribute("class", e) : window.ShadyDOM.nativeMethods.setAttribute.call(t, "class", e)
                }
                var na = window.ShadyDOM && window.ShadyDOM.wrap || function(t) {
                    return t
                };

                function ra(t) {
                    var e = t.localName,
                        n = "";
                    return e ? -1 < e.indexOf("-") || (n = e, e = t.getAttribute && t.getAttribute("is") || "") : (e = t.is, n = t.extends), {
                        is: e,
                        ha: n
                    }
                }

                function oa(t) {
                    for (var e = [], n = "", r = 0; 0 <= r && r < t.length; r++)
                        if ("(" === t[r]) {
                            var o = Qi(t, r);
                            n += t.slice(r, o + 1), r = o
                        } else "," === t[r] ? (e.push(n), n = "") : n += t[r];
                    return n && e.push(n), e
                }

                function ia(t) {
                    if (void 0 !== wi) return wi;
                    if (void 0 === t.__cssBuild) {
                        var e = t.getAttribute("css-build");
                        if (e) t.__cssBuild = e;
                        else {
                            if ("" !== (e = (e = "template" === t.localName ? t.content.firstChild : t.firstChild) instanceof Comment && "css-build" === (e = e.textContent.trim().split(":"))[0] ? e[1] : "")) {
                                var n = "template" === t.localName ? t.content.firstChild : t.firstChild;
                                n.parentNode.removeChild(n)
                            }
                            t.__cssBuild = e
                        }
                    }
                    return t.__cssBuild || ""
                }

                function aa(t) {
                    return !("" === (t = void 0 === t ? "" : t) || !Ri) && (ji ? "shadow" === t : "shady" === t)
                }

                function sa() {}

                function la(t, e, n) {
                    var r;
                    if (e.nodeType === Node.ELEMENT_NODE && n(e), r = "template" === e.localName ? (e.content || e._content || e).childNodes : e.children || e.childNodes)
                        for (e = 0; e < r.length; e++) la(t, r[e], n)
                }

                function ua(t, e, n) {
                    if (e)
                        if (t.classList) n ? (t.classList.remove("style-scope"), t.classList.remove(e)) : (t.classList.add("style-scope"), t.classList.add(e));
                        else if (t.getAttribute) {
                        var r = t.getAttribute("class");
                        n ? r && ea(t, e = r.replace("style-scope", "").replace(e, "")) : ea(t, (r ? r + " " : "") + "style-scope " + e)
                    }
                }

                function ca(t, e, n) {
                    la(xa, t, (function(t) {
                        ua(t, e, !0), ua(t, n)
                    }))
                }

                function da(t, e) {
                    la(xa, t, (function(t) {
                        ua(t, e || "", !0)
                    }))
                }

                function ha(t, e, n, r, o) {
                    var i = xa;
                    return "" === (o = void 0 === o ? "" : o) && (ji || "shady" === (void 0 === r ? "" : r) ? o = qi(e, n) : o = function(t, e, n, r, o) {
                        var i = fa(n, r);
                        return n = n ? "." + n : "", qi(e, (function(e) {
                            e.i || (e.selector = e.F = pa(t, e, t.h, n, i), e.i = !0), o && o(e, n, i)
                        }))
                    }(i, e, (t = ra(t)).is, t.ha, n) + "\n\n"), o.trim()
                }

                function fa(t, e) {
                    return e ? "[is=" + t + "]" : t
                }

                function pa(t, e, n, r, o) {
                    var i = oa(e.selector);
                    if (!Gi(e)) {
                        e = 0;
                        for (var a = i.length, s = void 0; e < a && (s = i[e]); e++) i[e] = n.call(t, s, r, o)
                    }
                    return i.filter((function(t) {
                        return !!t
                    })).join(",")
                }

                function va(t) {
                    return t.replace(_a, (function(t, e, n) {
                        return -1 < n.indexOf("+") ? n = n.replace(/\+/g, "___") : -1 < n.indexOf("___") && (n = n.replace(/___/g, "+")), ":" + e + "(" + n + ")"
                    }))
                }

                function ma(t, e) {
                    t = t.split(/(\[.+?\])/);
                    for (var n = [], r = 0; r < t.length; r++)
                        if (1 == r % 2) n.push(t[r]);
                        else {
                            var o = t[r];
                            "" === o && r === t.length - 1 || ((o = o.split(":"))[0] += e, n.push(o.join(":")))
                        }
                    return n.join("")
                }

                function ya(t) {
                    ":root" === t.selector && (t.selector = "html")
                }
                sa.prototype.h = function(t, e, n) {
                    var r = !1;
                    t = t.trim();
                    var o = _a.test(t);
                    o && (t = va(t = t.replace(_a, (function(t, e, n) {
                        return ":" + e + "(" + n.replace(/\s/g, "") + ")"
                    }))));
                    var i = Na.test(t);
                    if (i) {
                        var a = function(t) {
                            for (var e, n = []; e = t.match(Na);) {
                                var r = e.index,
                                    o = Qi(t, r);
                                if (-1 === o) throw Error(e.input + " selector missing ')'");
                                e = t.slice(r, o + 1), t = t.replace(e, ""), n.push(e)
                            }
                            return {
                                Ba: t,
                                matches: n
                            }
                        }(t);
                        t = a.Ba, a = a.matches
                    }
                    return t = (t = t.replace(wa, ":host $1")).replace(ga, (function(t, o, i) {
                        return r || (t = function(t, e, n, r) {
                            var o = t.indexOf("::slotted");
                            if (0 <= t.indexOf(":host") ? t = function(t, e) {
                                    var n = t.match(Ea);
                                    return (n = n && n[2].trim() || "") ? n[0].match(ba) ? t.replace(Ea, (function(t, n, r) {
                                        return e + r
                                    })) : n.split(ba)[0] === e ? n : "should_not_match" : t.replace(":host", e)
                                }(t, r) : 0 !== o && (t = n ? ma(t, n) : t), n = !1, 0 <= o && (e = "", n = !0), n) {
                                var i = !0;
                                n && (t = t.replace(Sa, (function(t, e) {
                                    return " > " + e
                                })))
                            }
                            return {
                                value: t,
                                Ua: e,
                                stop: i
                            }
                        }(i, o, e, n), r = r || t.stop, o = t.Ua, i = t.value), o + i
                    })), i && (t = function(t, e) {
                        var n = t.split("");
                        return e.reduce((function(t, e, r) {
                            return t + e + n[r + 1]
                        }), n[0])
                    }(t, a)), o && (t = va(t)), t.replace(Ca, (function(t, e, n, r) {
                        return '[dir="' + n + '"] ' + e + r + ", " + e + '[dir="' + n + '"]' + r
                    }))
                }, sa.prototype.i = function(t) {
                    return t.match(":host") ? "" : t.match("::slotted") ? this.h(t, ":not(.style-scope)") : ma(t.trim(), ":not(.style-scope)")
                }, i.Object.defineProperties(sa.prototype, {
                    g: {
                        configurable: !0,
                        enumerable: !0,
                        get: function() {
                            return "style-scope"
                        }
                    }
                });
                var _a = /:(nth[-\w]+)\(([^)]+)\)/,
                    ga = /(^|[\s>+~]+)((?:\[.+?\]|[^\s>+~=[])+)/g,
                    ba = /[[.:#*]/,
                    wa = /^(::slotted)/,
                    Ea = /(:host)(?:\(((?:\([^)(]*\)|[^)(]*)+?)\))/,
                    Sa = /(?:::slotted)(?:\(((?:\([^)(]*\)|[^)(]*)+?)\))/,
                    Ca = /(.*):dir\((?:(ltr|rtl))\)(.*)/,
                    Na = /:(?:matches|any|-(?:webkit|moz)-any)/,
                    xa = new sa;

                function Ta(t, e, n, r, o) {
                    this.M = t || null, this.h = e || null, this.za = n || [], this.K = null, this.cssBuild = o || "", this.ha = r || "", this.g = this.L = this.R = null
                }

                function Oa(t) {
                    return t ? t.__styleInfo : null
                }

                function ka(t, e) {
                    return t.__styleInfo = e
                }

                function Pa(t) {
                    var e = this.matches || this.matchesSelector || this.mozMatchesSelector || this.msMatchesSelector || this.oMatchesSelector || this.webkitMatchesSelector;
                    return e && e.call(this, t)
                }
                Ta.prototype.i = function() {
                    return this.M
                }, Ta.prototype._getStyleRules = Ta.prototype.i;
                var Da = /:host\s*>\s*/,
                    Aa = navigator.userAgent.match("Trident");

                function Ma() {}

                function ja(t) {
                    if (!t.D) {
                        var e = {},
                            n = {};
                        La(t, n) && (e.P = n, t.rules = null), e.cssText = t.parsedCssText.replace(Vi, "").replace(Fi, ""), t.D = e
                    }
                }

                function La(t, e) {
                    var n = t.D;
                    if (!n) {
                        n = t.parsedCssText;
                        for (var r; t = Fi.exec(n);) "inherit" === (r = (t[2] || t[3]).trim()) && "unset" === r || (e[t[1].trim()] = r), r = !0;
                        return r
                    }
                    if (n.P) return Object.assign(e, n.P), !0
                }

                function Ia(t, e, n) {
                    return e && (e = 0 <= e.indexOf(";") ? Ra(t, e, n) : ta(e, (function(e, r, o, i) {
                        return r ? ((r = Ia(t, n[r], n)) && "initial" !== r ? "apply-shim-inherit" === r && (r = "inherit") : r = Ia(t, n[o] || o, n) || o, e + (r || "") + i) : e + i
                    }))), e && e.trim() || ""
                }

                function Ra(t, e, n) {
                    e = e.split(";");
                    for (var r, o, i = 0; i < e.length; i++)
                        if (r = e[i]) {
                            if (Ui.lastIndex = 0, o = Ui.exec(r)) r = Ia(t, n[o[1]], n);
                            else if (-1 !== (o = r.indexOf(":"))) {
                                var a = r.substring(o);
                                a = Ia(t, a = a.trim(), n) || a, r = r.substring(0, o) + a
                            }
                            e[i] = r && r.lastIndexOf(";") === r.length - 1 ? r.slice(0, -1) : r || ""
                        }
                    return e.join(";")
                }

                function Fa(t, e, n) {
                    var r = {},
                        o = {};
                    return Xi(e, (function(e) {
                        ! function(t, e, n, r) {
                            if (e.D || ja(e), e.D.P) {
                                var o = ra(t);
                                t = o.is, o = o.ha, o = t ? fa(t, o) : "html";
                                var i = e.parsedSelector,
                                    a = !!i.match(Da) || "html" === o && -1 < i.indexOf("html"),
                                    s = 0 === i.indexOf(":host") && !a;
                                "shady" === n && (s = !(a = i === o + " > *." + o || -1 !== i.indexOf("html")) && 0 === i.indexOf(o)), (a || s) && (n = o, s && (e.F || (e.F = pa(xa, e, xa.h, t ? "." + t : "", o)), n = e.F || o), a && "html" === o && (n = e.F || e.O), r({
                                    Ba: n,
                                    ab: s,
                                    qb: a
                                }))
                            }
                        }(t, e, n, (function(n) {
                            Pa.call(t._element || t, n.Ba) && (n.ab ? La(e, r) : La(e, o))
                        }))
                    }), null, !0), {
                        hb: o,
                        Za: r
                    }
                }

                function Ua(t, e, n, r) {
                    var o = ra(e),
                        i = fa(o.is, o.ha),
                        a = new RegExp("(?:^|[^.#[:])" + (e.extends ? "\\" + i.slice(0, -1) + "\\]" : i) + "($|[.:[\\s>+~])"),
                        s = Oa(e);
                    o = s.M, s = s.cssBuild;
                    var l = function(t, e) {
                        t = t.h;
                        var n = {};
                        if (!ji && t)
                            for (var r = 0, o = t[r]; r < t.length; o = t[++r]) {
                                var i = o,
                                    a = e;
                                i.u = new RegExp("\\b" + i.keyframesName + "(?!\\B|-)", "g"), i.g = i.keyframesName + "-" + a, i.F = i.F || i.selector, i.selector = i.F.replace(i.keyframesName, i.g), n[o.keyframesName] = Ba(o)
                            }
                        return n
                    }(o, r);
                    return ha(e, o, (function(e) {
                        var o = "";
                        if (e.D || ja(e), e.D.cssText && (o = Ra(t, e.D.cssText, n)), e.cssText = o, !ji && !Gi(e) && e.cssText) {
                            var s = o = e.cssText;
                            if (null == e.Ia && (e.Ia = Hi.test(o)), e.Ia)
                                if (null == e.pa)
                                    for (var u in e.pa = [], l) o !== (s = (s = l[u])(o)) && (o = s, e.pa.push(u));
                                else {
                                    for (u = 0; u < e.pa.length; ++u) o = (s = l[e.pa[u]])(o);
                                    s = o
                                }
                            e.cssText = s, e.F = e.F || e.selector, o = "." + r, s = 0;
                            for (var c = (u = oa(e.F)).length, d = void 0; s < c && (d = u[s]); s++) u[s] = d.match(a) ? d.replace(i, o) : o + " " + d;
                            e.selector = u.join(",")
                        }
                    }), s)
                }

                function Ba(t) {
                    return function(e) {
                        return e.replace(t.u, t.g)
                    }
                }

                function Ha(t, e) {
                    var n = Za,
                        r = zi(t);
                    t.textContent = qi(r, (function(t) {
                        var r = t.cssText = t.parsedCssText;
                        t.D && t.D.cssText && (r = r.replace(Oi, "").replace(ki, ""), t.cssText = Ra(n, r, e))
                    }))
                }
                i.Object.defineProperties(Ma.prototype, {
                    g: {
                        configurable: !0,
                        enumerable: !0,
                        get: function() {
                            return "x-scope"
                        }
                    }
                });
                var Za = new Ma,
                    Va = {},
                    Wa = window.customElements;
                if (Wa && !ji && !Ii) {
                    var qa = Wa.define;
                    Wa.define = function(t, e, n) {
                        Va[t] || (Va[t] = Ji(t)), qa.call(Wa, t, e, n)
                    }
                }

                function za() {
                    this.cache = {}
                }

                function Ga() {}
                za.prototype.store = function(t, e, n, r) {
                    var o = this.cache[t] || [];
                    o.push({
                        P: e,
                        styleElement: n,
                        L: r
                    }), 100 < o.length && o.shift(), this.cache[t] = o
                };
                var Xa = new RegExp(xa.g + "\\s*([^\\s]*)");

                function Ka(t) {
                    return (t = (t.classList && t.classList.value ? t.classList.value : t.getAttribute("class") || "").match(Xa)) ? t[1] : ""
                }

                function Ya(t) {
                    var e = na(t).getRootNode();
                    return e === t || e === t.ownerDocument ? "" : (t = e.host) ? ra(t).is : ""
                }

                function Ja(t) {
                    for (var e = 0; e < t.length; e++) {
                        var n = t[e];
                        if (n.target !== document.documentElement && n.target !== document.head)
                            for (var r = 0; r < n.addedNodes.length; r++) {
                                var o = n.addedNodes[r];
                                if (o.nodeType === Node.ELEMENT_NODE) {
                                    var i = o.getRootNode(),
                                        a = Ka(o);
                                    if (a && i === o.ownerDocument && ("style" !== o.localName && "template" !== o.localName || "" === ia(o))) da(o, a);
                                    else if (i instanceof ShadowRoot)
                                        for ((i = Ya(o)) !== a && ca(o, a, i), o = window.ShadyDOM.nativeMethods.querySelectorAll.call(o, ":not(." + xa.g + ")"), a = 0; a < o.length; a++) {
                                            var s = Ya(i = o[a]);
                                            s && ua(i, s)
                                        }
                                }
                            }
                    }
                }
                if (!(ji || window.ShadyDOM && window.ShadyDOM.handlesDynamicScoping)) {
                    var $a = new MutationObserver(Ja),
                        Qa = function(t) {
                            $a.observe(t, {
                                childList: !0,
                                subtree: !0
                            })
                        };
                    if (window.customElements && !window.customElements.polyfillWrapFlushCallback) Qa(document);
                    else {
                        var ts = function() {
                            Qa(document.body)
                        };
                        window.HTMLImports ? window.HTMLImports.whenReady(ts) : requestAnimationFrame((function() {
                            if ("loading" === document.readyState) {
                                document.addEventListener("readystatechange", (function t() {
                                    ts(), document.removeEventListener("readystatechange", t)
                                }))
                            } else ts()
                        }))
                    }
                    Ga = function() {
                        Ja($a.takeRecords())
                    }
                }
                var es = {},
                    ns = Promise.resolve();

                function rs(t) {
                    (t = es[t]) && (t._applyShimCurrentVersion = t._applyShimCurrentVersion || 0, t._applyShimValidatingVersion = t._applyShimValidatingVersion || 0, t._applyShimNextVersion = (t._applyShimNextVersion || 0) + 1)
                }

                function os(t) {
                    return t._applyShimCurrentVersion === t._applyShimNextVersion
                }
                var is = {},
                    as = new za;

                function ss() {
                    this.da = {}, this.i = document.documentElement;
                    var t = new mi;
                    t.rules = [], this.u = ka(this.i, new Ta(t)), this.O = !1, this.g = this.h = null
                }

                function ls(t) {
                    var e = ra(t),
                        n = e.is;
                    e = e.ha;
                    var r = Va[n] || null,
                        o = es[n];
                    if (o) return ka(t, e = new Ta(n = o._styleAst, r, o.g, e, o = ia(o))), e
                }

                function us(t) {
                    if (!t.h && window.ShadyCSS && window.ShadyCSS.ApplyShim) {
                        t.h = window.ShadyCSS.ApplyShim, t.h.invalidCallback = rs;
                        var e = !0
                    } else e = !1;
                    return function(t) {
                        !t.g && window.ShadyCSS && window.ShadyCSS.CustomStyleInterface && (t.g = window.ShadyCSS.CustomStyleInterface, t.g.transformCallback = function(e) {
                            t.Ma(e)
                        }, t.g.validateCallback = function() {
                            requestAnimationFrame((function() {
                                (t.g.enqueued || t.O) && t.flushCustomStyles()
                            }))
                        })
                    }(t), e
                }

                function cs(t, e, n) {
                    var r = ra(e).is;
                    if (n.K) {
                        var o, i = n.K;
                        for (o in i) null === o ? e.style.removeProperty(o) : e.style.setProperty(o, i[o])
                    }!(i = es[r]) && e !== t.i || i && "" !== ia(i) || !i || !i._style || os(i) || ((os(i) || i._applyShimValidatingVersion !== i._applyShimNextVersion) && (us(t), t.h && t.h.transformRules(i._styleAst, r), i._style.textContent = ha(e, n.M), function(t) {
                        t._applyShimValidatingVersion = t._applyShimNextVersion, t._validating || (t._validating = !0, ns.then((function() {
                            t._applyShimCurrentVersion = t._applyShimNextVersion, t._validating = !1
                        })))
                    }(i)), ji && (t = e.shadowRoot) && (t = t.querySelector("style")) && (t.textContent = ha(e, n.M)), n.M = i._styleAst)
                }

                function ds(t, e) {
                    return (e = na(e).getRootNode().host) ? Oa(e) || ls(e) ? e : ds(t, e) : t.i
                }

                function hs(t, e, n) {
                    var r = ds(t, e),
                        o = Oa(r),
                        i = o.R;
                    for (var a in r === t.i || i || (hs(t, r, o), i = o.R), t = Object.create(i || null), r = Fa(e, n.M, n.cssBuild), e = function(t, e) {
                            var n = {},
                                r = [];
                            return Xi(t, (function(t) {
                                t.D || ja(t);
                                var o = t.F || t.parsedSelector;
                                e && t.D.P && o && Pa.call(e, o) && (La(t, n), t = t.index, o = parseInt(t / 32, 10), r[o] = (r[o] || 0) | 1 << t % 32)
                            }), null, !0), {
                                P: n,
                                key: r
                            }
                        }(o.M, e).P, Object.assign(t, r.Za, e, r.hb), e = n.K)((o = e[a]) || 0 === o) && (t[a] = o);
                    for (a = Za, e = Object.getOwnPropertyNames(t), o = 0; o < e.length; o++) t[r = e[o]] = Ia(a, t[r], t);
                    n.R = t
                }(t = ss.prototype).flush = function() {
                    Ga()
                }, t.Xa = function(t) {
                    return zi(t)
                }, t.lb = function(t) {
                    return qi(t)
                }, t.prepareTemplate = function(t, e, n) {
                    this.prepareTemplateDom(t, e), this.prepareTemplateStyles(t, e, n)
                }, t.prepareTemplateStyles = function(t, e, n) {
                    if (!t._prepared && !Ii) {
                        ji || Va[e] || (Va[e] = Ji(e)), t._prepared = !0, t.name = e, t.extends = n, es[e] = t;
                        var r = ia(t),
                            o = aa(r);
                        n = {
                            is: e,
                            extends: n
                        };
                        for (var i = [], a = t.content.querySelectorAll("style"), s = 0; s < a.length; s++) {
                            var l = a[s];
                            if (l.hasAttribute("shady-unscoped")) {
                                if (!ji) {
                                    var u = l.textContent;
                                    if (!Wi.has(u)) {
                                        Wi.add(u);
                                        var c = document.createElement("style");
                                        c.setAttribute("shady-unscoped", ""), c.textContent = u, document.head.appendChild(c)
                                    }
                                    l.parentNode.removeChild(l)
                                }
                            } else i.push(l.textContent), l.parentNode.removeChild(l)
                        }
                        i = i.join("").trim() + (is[e] || ""), us(this), o || ((a = !r) && (a = Ui.test(i) || Fi.test(i), Ui.lastIndex = 0, Fi.lastIndex = 0), s = yi(i), a && Ri && this.h && this.h.transformRules(s, e), t._styleAst = s), a = [], Ri || (a = function(t) {
                            var e = {},
                                n = [],
                                r = 0;
                            for (var o in Xi(t, (function(t) {
                                    ja(t), t.index = r++, t = t.D.cssText;
                                    for (var n; n = Bi.exec(t);) {
                                        var o = n[1];
                                        ":" !== n[2] && (e[o] = !0)
                                    }
                                }), (function(t) {
                                    n.push(t)
                                })), t.h = n, t = [], e) t.push(o);
                            return t
                        }(t._styleAst)), a.length && !Ri || (s = ji ? t.content : null, e = Va[e] || null, r = (r = ha(n, t._styleAst, null, r, o ? i : "")).length ? Ki(r, n.is, s, e) : null, t._style = r), t.g = a
                    }
                }, t.fb = function(t, e) {
                    is[e] = t.join(" ")
                }, t.prepareTemplateDom = function(t, e) {
                    if (!Ii) {
                        var n = ia(t);
                        ji || "shady" === n || t._domPrepared || (t._domPrepared = !0, function(t, e) {
                            la(xa, t, (function(t) {
                                ua(t, e || "")
                            }))
                        }(t.content, e))
                    }
                }, t.flushCustomStyles = function() {
                    if (!Ii) {
                        var t = us(this);
                        if (this.g) {
                            var e = this.g.processStyles();
                            if ((t || this.g.enqueued) && !aa(this.u.cssBuild)) {
                                if (Ri) {
                                    if (!this.u.cssBuild)
                                        for (t = 0; t < e.length; t++) {
                                            var n = this.g.getStyleForCustomStyle(e[t]);
                                            if (n && Ri && this.h) {
                                                var r = zi(n);
                                                us(this), this.h.transformRules(r), n.textContent = qi(r)
                                            }
                                        }
                                } else {
                                    for (function(t, e) {
                                            (e = e.map((function(e) {
                                                return t.g.getStyleForCustomStyle(e)
                                            })).filter((function(t) {
                                                return !!t
                                            }))).sort((function(t, e) {
                                                return (t = e.compareDocumentPosition(t)) & Node.DOCUMENT_POSITION_FOLLOWING ? 1 : t & Node.DOCUMENT_POSITION_PRECEDING ? -1 : 0
                                            })), t.u.M.rules = e.map((function(t) {
                                                return zi(t)
                                            }))
                                        }(this, e), hs(this, this.i, this.u), t = 0; t < e.length; t++)(n = this.g.getStyleForCustomStyle(e[t])) && Ha(n, this.u.R);
                                    this.O && this.styleDocument()
                                }
                                this.g.enqueued = !1
                            }
                        }
                    }
                }, t.styleElement = function(t, e) {
                    if (Ii) {
                        if (e) {
                            Oa(t) || ka(t, new Ta(null));
                            var n = Oa(t);
                            n.K = n.K || {}, Object.assign(n.K, e), cs(this, t, n)
                        }
                    } else if (n = Oa(t) || ls(t))
                        if (t !== this.i && (this.O = !0), e && (n.K = n.K || {}, Object.assign(n.K, e)), Ri) cs(this, t, n);
                        else if (this.flush(), hs(this, t, n), n.za && n.za.length) {
                        var r;
                        e = ra(t).is;
                        t: {
                            if (r = as.cache[e])
                                for (var o = r.length - 1; 0 <= o; o--) {
                                    var i = r[o];
                                    e: {
                                        for (var a = n.za, s = 0; s < a.length; s++) {
                                            var l = a[s];
                                            if (i.P[l] !== n.R[l]) {
                                                a = !1;
                                                break e
                                            }
                                        }
                                        a = !0
                                    }
                                    if (a) {
                                        r = i;
                                        break t
                                    }
                                }
                            r = void 0
                        }
                        a = r ? r.styleElement : null, o = n.L, (i = r && r.L) || (i = e + "-" + (i = this.da[e] = (this.da[e] || 0) + 1)), n.L = i, i = n.L, s = Za, s = a ? a.textContent || "" : Ua(s, t, n.R, i);
                        var u = (l = Oa(t)).g;
                        u && !ji && u !== a && (u._useCount--, 0 >= u._useCount && u.parentNode && u.parentNode.removeChild(u)), ji ? l.g ? (l.g.textContent = s, a = l.g) : s && (a = Ki(s, i, t.shadowRoot, l.h)) : a ? a.parentNode || (Aa && -1 < s.indexOf("@media") && (a.textContent = s), $i(a, null, l.h)) : s && (a = Ki(s, i, null, l.h)), a && (a._useCount = a._useCount || 0, l.g != a && a._useCount++, l.g = a), i = a, ji || (a = n.L, l = s = t.getAttribute("class") || "", o && (l = s.replace(new RegExp("\\s*x-scope\\s*" + o + "\\s*", "g"), " ")), s !== (l += (l ? " " : "") + "x-scope " + a) && ea(t, l)), r || as.store(e, n.R, i, n.L)
                    }
                }, t.styleDocument = function(t) {
                    this.styleSubtree(this.i, t)
                }, t.styleSubtree = function(t, e) {
                    var n = na(t),
                        r = n.shadowRoot,
                        o = t === this.i;
                    if ((r || o) && this.styleElement(t, e), t = o ? n : r)
                        for (t = Array.from(t.querySelectorAll("*")).filter((function(t) {
                                return na(t).shadowRoot
                            })), e = 0; e < t.length; e++) this.styleSubtree(t[e])
                }, t.Ma = function(t) {
                    var e = this,
                        n = ia(t);
                    if (n !== this.u.cssBuild && (this.u.cssBuild = n), !aa(n)) {
                        var r = zi(t);
                        Xi(r, (function(t) {
                            if (ji) ya(t);
                            else {
                                var r = xa;
                                t.selector = t.parsedSelector, ya(t), t.selector = t.F = pa(r, t, r.i, void 0, void 0)
                            }
                            Ri && "" === n && (us(e), e.h && e.h.transformRule(t))
                        })), Ri ? t.textContent = qi(r) : this.u.M.rules.push(r)
                    }
                }, t.getComputedStyleValue = function(t, e) {
                    var n;
                    return Ri || (n = (Oa(t) || Oa(ds(this, t))).R[e]), (n = n || window.getComputedStyle(t).getPropertyValue(e)) ? n.trim() : ""
                }, t.kb = function(t, e) {
                    var n = na(t).getRootNode();
                    if (e = e ? ("string" == typeof e ? e : String(e)).split(/\s/) : [], !(n = n.host && n.host.localName)) {
                        var r = t.getAttribute("class");
                        if (r) {
                            r = r.split(/\s/);
                            for (var o = 0; o < r.length; o++)
                                if (r[o] === xa.g) {
                                    n = r[o + 1];
                                    break
                                }
                        }
                    }
                    n && e.push(xa.g, n), Ri || (n = Oa(t)) && n.L && e.push(Za.g, n.L), ea(t, e.join(" "))
                }, t.Ta = function(t) {
                    return Oa(t)
                }, t.jb = function(t, e) {
                    ua(t, e)
                }, t.mb = function(t, e) {
                    ua(t, e, !0)
                }, t.ib = function(t) {
                    return Ya(t)
                }, t.Va = function(t) {
                    return Ka(t)
                }, ss.prototype.flush = ss.prototype.flush, ss.prototype.prepareTemplate = ss.prototype.prepareTemplate, ss.prototype.styleElement = ss.prototype.styleElement, ss.prototype.styleDocument = ss.prototype.styleDocument, ss.prototype.styleSubtree = ss.prototype.styleSubtree, ss.prototype.getComputedStyleValue = ss.prototype.getComputedStyleValue, ss.prototype.setElementClass = ss.prototype.kb, ss.prototype._styleInfoForNode = ss.prototype.Ta, ss.prototype.transformCustomStyleForDocument = ss.prototype.Ma, ss.prototype.getStyleAst = ss.prototype.Xa, ss.prototype.styleAstToString = ss.prototype.lb, ss.prototype.flushCustomStyles = ss.prototype.flushCustomStyles, ss.prototype.scopeNode = ss.prototype.jb, ss.prototype.unscopeNode = ss.prototype.mb, ss.prototype.scopeForNode = ss.prototype.ib, ss.prototype.currentScopeForNode = ss.prototype.Va, ss.prototype.prepareAdoptedCssText = ss.prototype.fb, Object.defineProperties(ss.prototype, {
                    nativeShadow: {
                        get: function() {
                            return ji
                        }
                    },
                    nativeCss: {
                        get: function() {
                            return Ri
                        }
                    }
                });
                var fs, ps, vs = new ss;
                window.ShadyCSS && (fs = window.ShadyCSS.ApplyShim, ps = window.ShadyCSS.CustomStyleInterface), window.ShadyCSS = {
                        ScopingShim: vs,
                        prepareTemplate: function(t, e, n) {
                            vs.flushCustomStyles(), vs.prepareTemplate(t, e, n)
                        },
                        prepareTemplateDom: function(t, e) {
                            vs.prepareTemplateDom(t, e)
                        },
                        prepareTemplateStyles: function(t, e, n) {
                            vs.flushCustomStyles(), vs.prepareTemplateStyles(t, e, n)
                        },
                        styleSubtree: function(t, e) {
                            vs.flushCustomStyles(), vs.styleSubtree(t, e)
                        },
                        styleElement: function(t) {
                            vs.flushCustomStyles(), vs.styleElement(t)
                        },
                        styleDocument: function(t) {
                            vs.flushCustomStyles(), vs.styleDocument(t)
                        },
                        flushCustomStyles: function() {
                            vs.flushCustomStyles()
                        },
                        getComputedStyleValue: function(t, e) {
                            return vs.getComputedStyleValue(t, e)
                        },
                        nativeCss: Ri,
                        nativeShadow: ji,
                        cssBuild: wi,
                        disableRuntime: Ii
                    }, fs && (window.ShadyCSS.ApplyShim = fs), ps && (window.ShadyCSS.CustomStyleInterface = ps),
                    function(t) {
                        function e(t) {
                            return "" == t && (i.call(this), this.m = !0), t.toLowerCase()
                        }

                        function n(t) {
                            var e = t.charCodeAt(0);
                            return 32 < e && 127 > e && -1 == [34, 35, 60, 62, 63, 96].indexOf(e) ? t : encodeURIComponent(t)
                        }

                        function r(t) {
                            var e = t.charCodeAt(0);
                            return 32 < e && 127 > e && -1 == [34, 35, 60, 62, 96].indexOf(e) ? t : encodeURIComponent(t)
                        }

                        function o(t, o, a) {
                            function s(t) {
                                y.push(t)
                            }
                            var l = o || "scheme start",
                                f = 0,
                                p = "",
                                v = !1,
                                m = !1,
                                y = [];
                            t: for (;
                                (null != t[f - 1] || 0 == f) && !this.m;) {
                                var _ = t[f];
                                switch (l) {
                                    case "scheme start":
                                        if (!_ || !d.test(_)) {
                                            if (o) {
                                                s("Invalid scheme.");
                                                break t
                                            }
                                            p = "", l = "no scheme";
                                            continue
                                        }
                                        p += _.toLowerCase(), l = "scheme";
                                        break;
                                    case "scheme":
                                        if (_ && h.test(_)) p += _.toLowerCase();
                                        else {
                                            if (":" != _) {
                                                if (o) {
                                                    null != _ && s("Code point not allowed in scheme: " + _);
                                                    break t
                                                }
                                                p = "", f = 0, l = "no scheme";
                                                continue
                                            }
                                            if (this.l = p, p = "", o) break t;
                                            void 0 !== u[this.l] && (this.G = !0), l = "file" == this.l ? "relative" : this.G && a && a.l == this.l ? "relative or authority" : this.G ? "authority first slash" : "scheme data"
                                        }
                                        break;
                                    case "scheme data":
                                        "?" == _ ? (this.A = "?", l = "query") : "#" == _ ? (this.C = "#", l = "fragment") : null != _ && "\t" != _ && "\n" != _ && "\r" != _ && (this.va += n(_));
                                        break;
                                    case "no scheme":
                                        if (a && void 0 !== u[a.l]) {
                                            l = "relative";
                                            continue
                                        }
                                        s("Missing scheme."), i.call(this), this.m = !0;
                                        break;
                                    case "relative or authority":
                                        if ("/" != _ || "/" != t[f + 1]) {
                                            s("Expected /, got: " + _), l = "relative";
                                            continue
                                        }
                                        l = "authority ignore slashes";
                                        break;
                                    case "relative":
                                        if (this.G = !0, "file" != this.l && (this.l = a.l), null == _) {
                                            this.o = a.o, this.v = a.v, this.s = a.s.slice(), this.A = a.A, this.B = a.B, this.j = a.j;
                                            break t
                                        }
                                        if ("/" == _ || "\\" == _) "\\" == _ && s("\\ is an invalid code point."), l = "relative slash";
                                        else if ("?" == _) this.o = a.o, this.v = a.v, this.s = a.s.slice(), this.A = "?", this.B = a.B, this.j = a.j, l = "query";
                                        else {
                                            if ("#" != _) {
                                                l = t[f + 1];
                                                var g = t[f + 2];
                                                ("file" != this.l || !d.test(_) || ":" != l && "|" != l || null != g && "/" != g && "\\" != g && "?" != g && "#" != g) && (this.o = a.o, this.v = a.v, this.B = a.B, this.j = a.j, this.s = a.s.slice(), this.s.pop()), l = "relative path";
                                                continue
                                            }
                                            this.o = a.o, this.v = a.v, this.s = a.s.slice(), this.A = a.A, this.C = "#", this.B = a.B, this.j = a.j, l = "fragment"
                                        }
                                        break;
                                    case "relative slash":
                                        if ("/" != _ && "\\" != _) {
                                            "file" != this.l && (this.o = a.o, this.v = a.v, this.B = a.B, this.j = a.j), l = "relative path";
                                            continue
                                        }
                                        "\\" == _ && s("\\ is an invalid code point."), l = "file" == this.l ? "file host" : "authority ignore slashes";
                                        break;
                                    case "authority first slash":
                                        if ("/" != _) {
                                            s("Expected '/', got: " + _), l = "authority ignore slashes";
                                            continue
                                        }
                                        l = "authority second slash";
                                        break;
                                    case "authority second slash":
                                        if (l = "authority ignore slashes", "/" != _) {
                                            s("Expected '/', got: " + _);
                                            continue
                                        }
                                        break;
                                    case "authority ignore slashes":
                                        if ("/" != _ && "\\" != _) {
                                            l = "authority";
                                            continue
                                        }
                                        s("Expected authority, got: " + _);
                                        break;
                                    case "authority":
                                        if ("@" == _) {
                                            for (v && (s("@ already seen."), p += "%40"), v = !0, _ = 0; _ < p.length; _++) "\t" == (g = p[_]) || "\n" == g || "\r" == g ? s("Invalid whitespace in authority.") : ":" == g && null === this.j ? this.j = "" : (g = n(g), null !== this.j ? this.j += g : this.B += g);
                                            p = ""
                                        } else {
                                            if (null == _ || "/" == _ || "\\" == _ || "?" == _ || "#" == _) {
                                                f -= p.length, p = "", l = "host";
                                                continue
                                            }
                                            p += _
                                        }
                                        break;
                                    case "file host":
                                        if (null == _ || "/" == _ || "\\" == _ || "?" == _ || "#" == _) {
                                            2 != p.length || !d.test(p[0]) || ":" != p[1] && "|" != p[1] ? (0 != p.length && (this.o = e.call(this, p), p = ""), l = "relative path start") : l = "relative path";
                                            continue
                                        }
                                        "\t" == _ || "\n" == _ || "\r" == _ ? s("Invalid whitespace in file host.") : p += _;
                                        break;
                                    case "host":
                                    case "hostname":
                                        if (":" != _ || m) {
                                            if (null == _ || "/" == _ || "\\" == _ || "?" == _ || "#" == _) {
                                                if (this.o = e.call(this, p), p = "", l = "relative path start", o) break t;
                                                continue
                                            }
                                            "\t" != _ && "\n" != _ && "\r" != _ ? ("[" == _ ? m = !0 : "]" == _ && (m = !1), p += _) : s("Invalid code point in host/hostname: " + _)
                                        } else if (this.o = e.call(this, p), p = "", l = "port", "hostname" == o) break t;
                                        break;
                                    case "port":
                                        if (/[0-9]/.test(_)) p += _;
                                        else {
                                            if (null == _ || "/" == _ || "\\" == _ || "?" == _ || "#" == _ || o) {
                                                if ("" != p && ((p = parseInt(p, 10)) != u[this.l] && (this.v = p + ""), p = ""), o) break t;
                                                l = "relative path start";
                                                continue
                                            }
                                            "\t" == _ || "\n" == _ || "\r" == _ ? s("Invalid code point in port: " + _) : (i.call(this), this.m = !0)
                                        }
                                        break;
                                    case "relative path start":
                                        if ("\\" == _ && s("'\\' not allowed in path."), l = "relative path", "/" != _ && "\\" != _) continue;
                                        break;
                                    case "relative path":
                                        null != _ && "/" != _ && "\\" != _ && (o || "?" != _ && "#" != _) ? "\t" != _ && "\n" != _ && "\r" != _ && (p += n(_)) : ("\\" == _ && s("\\ not allowed in relative path."), (g = c[p.toLowerCase()]) && (p = g), ".." == p ? (this.s.pop(), "/" != _ && "\\" != _ && this.s.push("")) : "." == p && "/" != _ && "\\" != _ ? this.s.push("") : "." != p && ("file" == this.l && 0 == this.s.length && 2 == p.length && d.test(p[0]) && "|" == p[1] && (p = p[0] + ":"), this.s.push(p)), p = "", "?" == _ ? (this.A = "?", l = "query") : "#" == _ && (this.C = "#", l = "fragment"));
                                        break;
                                    case "query":
                                        o || "#" != _ ? null != _ && "\t" != _ && "\n" != _ && "\r" != _ && (this.A += r(_)) : (this.C = "#", l = "fragment");
                                        break;
                                    case "fragment":
                                        null != _ && "\t" != _ && "\n" != _ && "\r" != _ && (this.C += _)
                                }
                                f++
                            }
                        }

                        function i() {
                            this.B = this.va = this.l = "", this.j = null, this.v = this.o = "", this.s = [], this.C = this.A = "", this.G = this.m = !1
                        }

                        function a(t, e) {
                            void 0 === e || e instanceof a || (e = new a(String(e))), this.g = t, i.call(this), o.call(this, this.g.replace(/^[ \t\r\n\f]+|[ \t\r\n\f]+$/g, ""), null, e)
                        }
                        var s = !1;
                        try {
                            var l = new URL("b", "http://a");
                            l.pathname = "c%20d", s = "http://a/c%20d" === l.href
                        } catch (t) {}
                        if (!s) {
                            var u = Object.create(null);
                            u.ftp = 21, u.file = 0, u.gopher = 70, u.http = 80, u.https = 443, u.ws = 80, u.wss = 443;
                            var c = Object.create(null);
                            c["%2e"] = ".", c[".%2e"] = "..", c["%2e."] = "..", c["%2e%2e"] = "..";
                            var d = /[a-zA-Z]/,
                                h = /[a-zA-Z0-9+\-.]/;
                            a.prototype = {
                                toString: function() {
                                    return this.href
                                },
                                get href() {
                                    if (this.m) return this.g;
                                    var t = "";
                                    return "" == this.B && null == this.j || (t = this.B + (null != this.j ? ":" + this.j : "") + "@"), this.protocol + (this.G ? "//" + t + this.host : "") + this.pathname + this.A + this.C
                                },
                                set href(t) {
                                    i.call(this), o.call(this, t)
                                },
                                get protocol() {
                                    return this.l + ":"
                                },
                                set protocol(t) {
                                    this.m || o.call(this, t + ":", "scheme start")
                                },
                                get host() {
                                    return this.m ? "" : this.v ? this.o + ":" + this.v : this.o
                                },
                                set host(t) {
                                    !this.m && this.G && o.call(this, t, "host")
                                },
                                get hostname() {
                                    return this.o
                                },
                                set hostname(t) {
                                    !this.m && this.G && o.call(this, t, "hostname")
                                },
                                get port() {
                                    return this.v
                                },
                                set port(t) {
                                    !this.m && this.G && o.call(this, t, "port")
                                },
                                get pathname() {
                                    return this.m ? "" : this.G ? "/" + this.s.join("/") : this.va
                                },
                                set pathname(t) {
                                    !this.m && this.G && (this.s = [], o.call(this, t, "relative path start"))
                                },
                                get search() {
                                    return this.m || !this.A || "?" == this.A ? "" : this.A
                                },
                                set search(t) {
                                    !this.m && this.G && (this.A = "?", "?" == t[0] && (t = t.slice(1)), o.call(this, t, "query"))
                                },
                                get hash() {
                                    return this.m || !this.C || "#" == this.C ? "" : this.C
                                },
                                set hash(t) {
                                    this.m || (t ? (this.C = "#", "#" == t[0] && (t = t.slice(1)), o.call(this, t, "fragment")) : this.C = "")
                                },
                                get origin() {
                                    var t;
                                    if (this.m || !this.l) return "";
                                    switch (this.l) {
                                        case "data":
                                        case "file":
                                        case "javascript":
                                        case "mailto":
                                            return "null"
                                    }
                                    return (t = this.host) ? this.l + "://" + t : ""
                                }
                            };
                            var f = t.URL;
                            f && (a.createObjectURL = function(t) {
                                return f.createObjectURL.apply(f, arguments)
                            }, a.revokeObjectURL = function(t) {
                                f.revokeObjectURL(t)
                            }), t.URL = a
                        }
                    }(window);
                var ms = window.customElements,
                    ys = !1,
                    _s = null;

                function gs() {
                    window.HTMLTemplateElement.bootstrap && window.HTMLTemplateElement.bootstrap(window.document), _s && _s(), ys = !0, window.WebComponents.ready = !0, document.dispatchEvent(new CustomEvent("WebComponentsReady", {
                        bubbles: !0
                    }))
                }
                ms.polyfillWrapFlushCallback && ms.polyfillWrapFlushCallback((function(t) {
                    _s = t, ys && t()
                })), "complete" !== document.readyState ? (window.addEventListener("load", gs), window.addEventListener("DOMContentLoaded", (function() {
                    window.removeEventListener("load", gs), gs()
                }))) : gs()
            }).call(this)
        },
        39609: function() {
            ! function() {
                "use strict";
                if ("object" == typeof window)
                    if ("IntersectionObserver" in window && "IntersectionObserverEntry" in window && "intersectionRatio" in window.IntersectionObserverEntry.prototype) "isIntersecting" in window.IntersectionObserverEntry.prototype || Object.defineProperty(window.IntersectionObserverEntry.prototype, "isIntersecting", {
                        get: function() {
                            return this.intersectionRatio > 0
                        }
                    });
                    else {
                        var t = window.document,
                            e = [];
                        r.prototype.THROTTLE_TIMEOUT = 100, r.prototype.POLL_INTERVAL = null, r.prototype.USE_MUTATION_OBSERVER = !0, r.prototype.observe = function(t) {
                            if (!this._observationTargets.some((function(e) {
                                    return e.element == t
                                }))) {
                                if (!t || 1 != t.nodeType) throw new Error("target must be an Element");
                                this._registerInstance(), this._observationTargets.push({
                                    element: t,
                                    entry: null
                                }), this._monitorIntersections(), this._checkForIntersections()
                            }
                        }, r.prototype.unobserve = function(t) {
                            this._observationTargets = this._observationTargets.filter((function(e) {
                                return e.element != t
                            })), this._observationTargets.length || (this._unmonitorIntersections(), this._unregisterInstance())
                        }, r.prototype.disconnect = function() {
                            this._observationTargets = [], this._unmonitorIntersections(), this._unregisterInstance()
                        }, r.prototype.takeRecords = function() {
                            var t = this._queuedEntries.slice();
                            return this._queuedEntries = [], t
                        }, r.prototype._initThresholds = function(t) {
                            var e = t || [0];
                            return Array.isArray(e) || (e = [e]), e.sort().filter((function(t, e, n) {
                                if ("number" != typeof t || isNaN(t) || t < 0 || t > 1) throw new Error("threshold must be a number between 0 and 1 inclusively");
                                return t !== n[e - 1]
                            }))
                        }, r.prototype._parseRootMargin = function(t) {
                            var e = (t || "0px").split(/\s+/).map((function(t) {
                                var e = /^(-?\d*\.?\d+)(px|%)$/.exec(t);
                                if (!e) throw new Error("rootMargin must be specified in pixels or percent");
                                return {
                                    value: parseFloat(e[1]),
                                    unit: e[2]
                                }
                            }));
                            return e[1] = e[1] || e[0], e[2] = e[2] || e[0], e[3] = e[3] || e[1], e
                        }, r.prototype._monitorIntersections = function() {
                            this._monitoringIntersections || (this._monitoringIntersections = !0, this.POLL_INTERVAL ? this._monitoringInterval = setInterval(this._checkForIntersections, this.POLL_INTERVAL) : (o(window, "resize", this._checkForIntersections, !0), o(t, "scroll", this._checkForIntersections, !0), this.USE_MUTATION_OBSERVER && "MutationObserver" in window && (this._domObserver = new MutationObserver(this._checkForIntersections), this._domObserver.observe(t, {
                                attributes: !0,
                                childList: !0,
                                characterData: !0,
                                subtree: !0
                            }))))
                        }, r.prototype._unmonitorIntersections = function() {
                            this._monitoringIntersections && (this._monitoringIntersections = !1, clearInterval(this._monitoringInterval), this._monitoringInterval = null, i(window, "resize", this._checkForIntersections, !0), i(t, "scroll", this._checkForIntersections, !0), this._domObserver && (this._domObserver.disconnect(), this._domObserver = null))
                        }, r.prototype._checkForIntersections = function() {
                            var t = this._rootIsInDom(),
                                e = t ? this._getRootRect() : {
                                    top: 0,
                                    bottom: 0,
                                    left: 0,
                                    right: 0,
                                    width: 0,
                                    height: 0
                                };
                            this._observationTargets.forEach((function(r) {
                                var o = r.element,
                                    i = a(o),
                                    s = this._rootContainsTarget(o),
                                    l = r.entry,
                                    u = t && s && this._computeTargetAndRootIntersection(o, e),
                                    c = r.entry = new n({
                                        time: window.performance && performance.now && performance.now(),
                                        target: o,
                                        boundingClientRect: i,
                                        rootBounds: e,
                                        intersectionRect: u
                                    });
                                l ? t && s ? this._hasCrossedThreshold(l, c) && this._queuedEntries.push(c) : l && l.isIntersecting && this._queuedEntries.push(c) : this._queuedEntries.push(c)
                            }), this), this._queuedEntries.length && this._callback(this.takeRecords(), this)
                        }, r.prototype._computeTargetAndRootIntersection = function(e, n) {
                            if ("none" != window.getComputedStyle(e).display) {
                                for (var r, o, i, s, u, c, d, h, f = a(e), p = l(e), v = !1; !v;) {
                                    var m = null,
                                        y = 1 == p.nodeType ? window.getComputedStyle(p) : {};
                                    if ("none" == y.display) return;
                                    if (p == this.root || p == t ? (v = !0, m = n) : p != t.body && p != t.documentElement && "visible" != y.overflow && (m = a(p)), m && (r = m, o = f, i = void 0, s = void 0, u = void 0, c = void 0, d = void 0, h = void 0, i = Math.max(r.top, o.top), s = Math.min(r.bottom, o.bottom), u = Math.max(r.left, o.left), c = Math.min(r.right, o.right), h = s - i, !(f = (d = c - u) >= 0 && h >= 0 && {
                                            top: i,
                                            bottom: s,
                                            left: u,
                                            right: c,
                                            width: d,
                                            height: h
                                        }))) break;
                                    p = l(p)
                                }
                                return f
                            }
                        }, r.prototype._getRootRect = function() {
                            var e;
                            if (this.root) e = a(this.root);
                            else {
                                var n = t.documentElement,
                                    r = t.body;
                                e = {
                                    top: 0,
                                    left: 0,
                                    right: n.clientWidth || r.clientWidth,
                                    width: n.clientWidth || r.clientWidth,
                                    bottom: n.clientHeight || r.clientHeight,
                                    height: n.clientHeight || r.clientHeight
                                }
                            }
                            return this._expandRectByRootMargin(e)
                        }, r.prototype._expandRectByRootMargin = function(t) {
                            var e = this._rootMarginValues.map((function(e, n) {
                                    return "px" == e.unit ? e.value : e.value * (n % 2 ? t.width : t.height) / 100
                                })),
                                n = {
                                    top: t.top - e[0],
                                    right: t.right + e[1],
                                    bottom: t.bottom + e[2],
                                    left: t.left - e[3]
                                };
                            return n.width = n.right - n.left, n.height = n.bottom - n.top, n
                        }, r.prototype._hasCrossedThreshold = function(t, e) {
                            var n = t && t.isIntersecting ? t.intersectionRatio || 0 : -1,
                                r = e.isIntersecting ? e.intersectionRatio || 0 : -1;
                            if (n !== r)
                                for (var o = 0; o < this.thresholds.length; o++) {
                                    var i = this.thresholds[o];
                                    if (i == n || i == r || i < n != i < r) return !0
                                }
                        }, r.prototype._rootIsInDom = function() {
                            return !this.root || s(t, this.root)
                        }, r.prototype._rootContainsTarget = function(e) {
                            return s(this.root || t, e)
                        }, r.prototype._registerInstance = function() {
                            e.indexOf(this) < 0 && e.push(this)
                        }, r.prototype._unregisterInstance = function() {
                            var t = e.indexOf(this); - 1 != t && e.splice(t, 1)
                        }, window.IntersectionObserver = r, window.IntersectionObserverEntry = n
                    }
                function n(t) {
                    this.time = t.time, this.target = t.target, this.rootBounds = t.rootBounds, this.boundingClientRect = t.boundingClientRect, this.intersectionRect = t.intersectionRect || {
                        top: 0,
                        bottom: 0,
                        left: 0,
                        right: 0,
                        width: 0,
                        height: 0
                    }, this.isIntersecting = !!t.intersectionRect;
                    var e = this.boundingClientRect,
                        n = e.width * e.height,
                        r = this.intersectionRect,
                        o = r.width * r.height;
                    this.intersectionRatio = n ? Number((o / n).toFixed(4)) : this.isIntersecting ? 1 : 0
                }

                function r(t, e) {
                    var n, r, o, i = e || {};
                    if ("function" != typeof t) throw new Error("callback must be a function");
                    if (i.root && 1 != i.root.nodeType) throw new Error("root must be an Element");
                    this._checkForIntersections = (n = this._checkForIntersections.bind(this), r = this.THROTTLE_TIMEOUT, o = null, function() {
                        o || (o = setTimeout((function() {
                            n(), o = null
                        }), r))
                    }), this._callback = t, this._observationTargets = [], this._queuedEntries = [], this._rootMarginValues = this._parseRootMargin(i.rootMargin), this.thresholds = this._initThresholds(i.threshold), this.root = i.root || null, this.rootMargin = this._rootMarginValues.map((function(t) {
                        return t.value + t.unit
                    })).join(" ")
                }

                function o(t, e, n, r) {
                    "function" == typeof t.addEventListener ? t.addEventListener(e, n, r || !1) : "function" == typeof t.attachEvent && t.attachEvent("on" + e, n)
                }

                function i(t, e, n, r) {
                    "function" == typeof t.removeEventListener ? t.removeEventListener(e, n, r || !1) : "function" == typeof t.detatchEvent && t.detatchEvent("on" + e, n)
                }

                function a(t) {
                    var e;
                    try {
                        e = t.getBoundingClientRect()
                    } catch (t) {}
                    return e ? (e.width && e.height || (e = {
                        top: e.top,
                        right: e.right,
                        bottom: e.bottom,
                        left: e.left,
                        width: e.right - e.left,
                        height: e.bottom - e.top
                    }), e) : {
                        top: 0,
                        bottom: 0,
                        left: 0,
                        right: 0,
                        width: 0,
                        height: 0
                    }
                }

                function s(t, e) {
                    for (var n = e; n;) {
                        if (n == t) return !0;
                        n = l(n)
                    }
                    return !1
                }

                function l(t) {
                    var e = t.parentNode;
                    return e && 11 == e.nodeType && e.host ? e.host : e && e.assignedSlot ? e.assignedSlot.parentNode : e
                }
            }()
        },
        72033: function(t, e, n) {
            "use strict";
            var r = n(12128);

            function o() {}
            t.exports = function() {
                function t(t, e, n, o, i, a) {
                    if (a !== r) {
                        var s = new Error("Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types");
                        throw s.name = "Invariant Violation", s
                    }
                }

                function e() {
                    return t
                }
                t.isRequired = t;
                var n = {
                    array: t,
                    bool: t,
                    func: t,
                    number: t,
                    object: t,
                    string: t,
                    symbol: t,
                    any: t,
                    arrayOf: e,
                    element: t,
                    instanceOf: e,
                    node: t,
                    objectOf: e,
                    oneOf: e,
                    oneOfType: e,
                    shape: e,
                    exact: e
                };
                return n.checkPropTypes = o, n.PropTypes = n, n
            }
        },
        47924: function(t, e, n) {
            t.exports = n(72033)()
        },
        12128: function(t) {
            "use strict";
            t.exports = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED"
        },
        77822: function(t, e) {
            "use strict";

            function n(t) {
                return function(e) {
                    var n = e.dispatch,
                        r = e.getState;
                    return function(e) {
                        return function(o) {
                            return "function" == typeof o ? o(n, r, t) : e(o)
                        }
                    }
                }
            }
            var r = n();
            r.withExtraArgument = n, e.Z = r
        },
        29591: function(t, e, n) {
            "use strict";
            n.d(e, {
                md: function() {
                    return A
                },
                DE: function() {
                    return k
                },
                UY: function() {
                    return T
                },
                qC: function() {
                    return P
                },
                MT: function() {
                    return N
                }
            });
            var r = "object" == typeof global && global && global.Object === Object && global,
                o = "object" == typeof self && self && self.Object === Object && self,
                i = (r || o || Function("return this")()).Symbol,
                a = Object.prototype,
                s = a.hasOwnProperty,
                l = a.toString,
                u = i ? i.toStringTag : void 0;
            var c = function(t) {
                    var e = s.call(t, u),
                        n = t[u];
                    try {
                        t[u] = void 0;
                        var r = !0
                    } catch (t) {}
                    var o = l.call(t);
                    return r && (e ? t[u] = n : delete t[u]), o
                },
                d = Object.prototype.toString;
            var h = function(t) {
                    return d.call(t)
                },
                f = i ? i.toStringTag : void 0;
            var p = function(t) {
                return null == t ? void 0 === t ? "[object Undefined]" : "[object Null]" : f && f in Object(t) ? c(t) : h(t)
            };
            var v = function(t, e) {
                return function(n) {
                    return t(e(n))
                }
            }(Object.getPrototypeOf, Object);
            var m = function(t) {
                    return null != t && "object" == typeof t
                },
                y = Function.prototype,
                _ = Object.prototype,
                g = y.toString,
                b = _.hasOwnProperty,
                w = g.call(Object);
            var E = function(t) {
                    if (!m(t) || "[object Object]" != p(t)) return !1;
                    var e = v(t);
                    if (null === e) return !0;
                    var n = b.call(e, "constructor") && e.constructor;
                    return "function" == typeof n && n instanceof n && g.call(n) == w
                },
                S = n(84408),
                C = "@@redux/INIT";

            function N(t, e, n) {
                var r;
                if ("function" == typeof e && void 0 === n && (n = e, e = void 0), void 0 !== n) {
                    if ("function" != typeof n) throw new Error("Expected the enhancer to be a function.");
                    return n(N)(t, e)
                }
                if ("function" != typeof t) throw new Error("Expected the reducer to be a function.");
                var o = t,
                    i = e,
                    a = [],
                    s = a,
                    l = !1;

                function u() {
                    s === a && (s = a.slice())
                }

                function c() {
                    return i
                }

                function d(t) {
                    if ("function" != typeof t) throw new Error("Expected listener to be a function.");
                    var e = !0;
                    return u(), s.push(t),
                        function() {
                            if (e) {
                                e = !1, u();
                                var n = s.indexOf(t);
                                s.splice(n, 1)
                            }
                        }
                }

                function h(t) {
                    if (!E(t)) throw new Error("Actions must be plain objects. Use custom middleware for async actions.");
                    if (void 0 === t.type) throw new Error('Actions may not have an undefined "type" property. Have you misspelled a constant?');
                    if (l) throw new Error("Reducers may not dispatch actions.");
                    try {
                        l = !0, i = o(i, t)
                    } finally {
                        l = !1
                    }
                    for (var e = a = s, n = 0; n < e.length; n++) {
                        (0, e[n])()
                    }
                    return t
                }
                return h({
                    type: C
                }), (r = {
                    dispatch: h,
                    subscribe: d,
                    getState: c,
                    replaceReducer: function(t) {
                        if ("function" != typeof t) throw new Error("Expected the nextReducer to be a function.");
                        o = t, h({
                            type: C
                        })
                    }
                })[S.Z] = function() {
                    var t, e = d;
                    return (t = {
                        subscribe: function(t) {
                            if ("object" != typeof t) throw new TypeError("Expected the observer to be an object.");

                            function n() {
                                t.next && t.next(c())
                            }
                            return n(), {
                                unsubscribe: e(n)
                            }
                        }
                    })[S.Z] = function() {
                        return this
                    }, t
                }, r
            }

            function x(t, e) {
                var n = e && e.type;
                return "Given action " + (n && '"' + n.toString() + '"' || "an action") + ', reducer "' + t + '" returned undefined. To ignore an action, you must explicitly return the previous state. If you want this reducer to hold no value, you can return null instead of undefined.'
            }

            function T(t) {
                for (var e = Object.keys(t), n = {}, r = 0; r < e.length; r++) {
                    var o = e[r];
                    0, "function" == typeof t[o] && (n[o] = t[o])
                }
                var i = Object.keys(n);
                var a = void 0;
                try {
                    ! function(t) {
                        Object.keys(t).forEach((function(e) {
                            var n = t[e];
                            if (void 0 === n(void 0, {
                                    type: C
                                })) throw new Error('Reducer "' + e + "\" returned undefined during initialization. If the state passed to the reducer is undefined, you must explicitly return the initial state. The initial state may not be undefined. If you don't want to set a value for this reducer, you can use null instead of undefined.");
                            if (void 0 === n(void 0, {
                                    type: "@@redux/PROBE_UNKNOWN_ACTION_" + Math.random().toString(36).substring(7).split("").join(".")
                                })) throw new Error('Reducer "' + e + "\" returned undefined when probed with a random type. Don't try to handle " + C + ' or other actions in "redux/*" namespace. They are considered private. Instead, you must return the current state for any unknown actions, unless it is undefined, in which case you must return the initial state, regardless of the action type. The initial state may not be undefined, but can be null.')
                        }))
                    }(n)
                } catch (t) {
                    a = t
                }
                return function() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                        e = arguments[1];
                    if (a) throw a;
                    for (var r = !1, o = {}, s = 0; s < i.length; s++) {
                        var l = i[s],
                            u = n[l],
                            c = t[l],
                            d = u(c, e);
                        if (void 0 === d) {
                            var h = x(l, e);
                            throw new Error(h)
                        }
                        o[l] = d, r = r || d !== c
                    }
                    return r ? o : t
                }
            }

            function O(t, e) {
                return function() {
                    return e(t.apply(void 0, arguments))
                }
            }

            function k(t, e) {
                if ("function" == typeof t) return O(t, e);
                if ("object" != typeof t || null === t) throw new Error("bindActionCreators expected an object or a function, instead received " + (null === t ? "null" : typeof t) + '. Did you write "import ActionCreators from" instead of "import * as ActionCreators from"?');
                for (var n = Object.keys(t), r = {}, o = 0; o < n.length; o++) {
                    var i = n[o],
                        a = t[i];
                    "function" == typeof a && (r[i] = O(a, e))
                }
                return r
            }

            function P() {
                for (var t = arguments.length, e = Array(t), n = 0; n < t; n++) e[n] = arguments[n];
                return 0 === e.length ? function(t) {
                    return t
                } : 1 === e.length ? e[0] : e.reduce((function(t, e) {
                    return function() {
                        return t(e.apply(void 0, arguments))
                    }
                }))
            }
            var D = Object.assign || function(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = arguments[e];
                    for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (t[r] = n[r])
                }
                return t
            };

            function A() {
                for (var t = arguments.length, e = Array(t), n = 0; n < t; n++) e[n] = arguments[n];
                return function(t) {
                    return function(n, r, o) {
                        var i, a = t(n, r, o),
                            s = a.dispatch,
                            l = {
                                getState: a.getState,
                                dispatch: function(t) {
                                    return s(t)
                                }
                            };
                        return i = e.map((function(t) {
                            return t(l)
                        })), s = P.apply(void 0, i)(a.dispatch), D({}, a, {
                            dispatch: s
                        })
                    }
                }
            }
        },
        19271: function(t) {
            var e = function(t) {
                "use strict";
                var e, n = Object.prototype,
                    r = n.hasOwnProperty,
                    o = "function" == typeof Symbol ? Symbol : {},
                    i = o.iterator || "@@iterator",
                    a = o.asyncIterator || "@@asyncIterator",
                    s = o.toStringTag || "@@toStringTag";

                function l(t, e, n) {
                    return Object.defineProperty(t, e, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }), t[e]
                }
                try {
                    l({}, "")
                } catch (t) {
                    l = function(t, e, n) {
                        return t[e] = n
                    }
                }

                function u(t, e, n, r) {
                    var o = e && e.prototype instanceof m ? e : m,
                        i = Object.create(o.prototype),
                        a = new O(r || []);
                    return i._invoke = function(t, e, n) {
                        var r = d;
                        return function(o, i) {
                            if (r === f) throw new Error("Generator is already running");
                            if (r === p) {
                                if ("throw" === o) throw i;
                                return P()
                            }
                            for (n.method = o, n.arg = i;;) {
                                var a = n.delegate;
                                if (a) {
                                    var s = N(a, n);
                                    if (s) {
                                        if (s === v) continue;
                                        return s
                                    }
                                }
                                if ("next" === n.method) n.sent = n._sent = n.arg;
                                else if ("throw" === n.method) {
                                    if (r === d) throw r = p, n.arg;
                                    n.dispatchException(n.arg)
                                } else "return" === n.method && n.abrupt("return", n.arg);
                                r = f;
                                var l = c(t, e, n);
                                if ("normal" === l.type) {
                                    if (r = n.done ? p : h, l.arg === v) continue;
                                    return {
                                        value: l.arg,
                                        done: n.done
                                    }
                                }
                                "throw" === l.type && (r = p, n.method = "throw", n.arg = l.arg)
                            }
                        }
                    }(t, n, a), i
                }

                function c(t, e, n) {
                    try {
                        return {
                            type: "normal",
                            arg: t.call(e, n)
                        }
                    } catch (t) {
                        return {
                            type: "throw",
                            arg: t
                        }
                    }
                }
                t.wrap = u;
                var d = "suspendedStart",
                    h = "suspendedYield",
                    f = "executing",
                    p = "completed",
                    v = {};

                function m() {}

                function y() {}

                function _() {}
                var g = {};
                g[i] = function() {
                    return this
                };
                var b = Object.getPrototypeOf,
                    w = b && b(b(k([])));
                w && w !== n && r.call(w, i) && (g = w);
                var E = _.prototype = m.prototype = Object.create(g);

                function S(t) {
                    ["next", "throw", "return"].forEach((function(e) {
                        l(t, e, (function(t) {
                            return this._invoke(e, t)
                        }))
                    }))
                }

                function C(t, e) {
                    function n(o, i, a, s) {
                        var l = c(t[o], t, i);
                        if ("throw" !== l.type) {
                            var u = l.arg,
                                d = u.value;
                            return d && "object" == typeof d && r.call(d, "__await") ? e.resolve(d.__await).then((function(t) {
                                n("next", t, a, s)
                            }), (function(t) {
                                n("throw", t, a, s)
                            })) : e.resolve(d).then((function(t) {
                                u.value = t, a(u)
                            }), (function(t) {
                                return n("throw", t, a, s)
                            }))
                        }
                        s(l.arg)
                    }
                    var o;
                    this._invoke = function(t, r) {
                        function i() {
                            return new e((function(e, o) {
                                n(t, r, e, o)
                            }))
                        }
                        return o = o ? o.then(i, i) : i()
                    }
                }

                function N(t, n) {
                    var r = t.iterator[n.method];
                    if (r === e) {
                        if (n.delegate = null, "throw" === n.method) {
                            if (t.iterator.return && (n.method = "return", n.arg = e, N(t, n), "throw" === n.method)) return v;
                            n.method = "throw", n.arg = new TypeError("The iterator does not provide a 'throw' method")
                        }
                        return v
                    }
                    var o = c(r, t.iterator, n.arg);
                    if ("throw" === o.type) return n.method = "throw", n.arg = o.arg, n.delegate = null, v;
                    var i = o.arg;
                    return i ? i.done ? (n[t.resultName] = i.value, n.next = t.nextLoc, "return" !== n.method && (n.method = "next", n.arg = e), n.delegate = null, v) : i : (n.method = "throw", n.arg = new TypeError("iterator result is not an object"), n.delegate = null, v)
                }

                function x(t) {
                    var e = {
                        tryLoc: t[0]
                    };
                    1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e)
                }

                function T(t) {
                    var e = t.completion || {};
                    e.type = "normal", delete e.arg, t.completion = e
                }

                function O(t) {
                    this.tryEntries = [{
                        tryLoc: "root"
                    }], t.forEach(x, this), this.reset(!0)
                }

                function k(t) {
                    if (t) {
                        var n = t[i];
                        if (n) return n.call(t);
                        if ("function" == typeof t.next) return t;
                        if (!isNaN(t.length)) {
                            var o = -1,
                                a = function n() {
                                    for (; ++o < t.length;)
                                        if (r.call(t, o)) return n.value = t[o], n.done = !1, n;
                                    return n.value = e, n.done = !0, n
                                };
                            return a.next = a
                        }
                    }
                    return {
                        next: P
                    }
                }

                function P() {
                    return {
                        value: e,
                        done: !0
                    }
                }
                return y.prototype = E.constructor = _, _.constructor = y, y.displayName = l(_, s, "GeneratorFunction"), t.isGeneratorFunction = function(t) {
                    var e = "function" == typeof t && t.constructor;
                    return !!e && (e === y || "GeneratorFunction" === (e.displayName || e.name))
                }, t.mark = function(t) {
                    return Object.setPrototypeOf ? Object.setPrototypeOf(t, _) : (t.__proto__ = _, l(t, s, "GeneratorFunction")), t.prototype = Object.create(E), t
                }, t.awrap = function(t) {
                    return {
                        __await: t
                    }
                }, S(C.prototype), C.prototype[a] = function() {
                    return this
                }, t.AsyncIterator = C, t.async = function(e, n, r, o, i) {
                    void 0 === i && (i = Promise);
                    var a = new C(u(e, n, r, o), i);
                    return t.isGeneratorFunction(n) ? a : a.next().then((function(t) {
                        return t.done ? t.value : a.next()
                    }))
                }, S(E), l(E, s, "Generator"), E[i] = function() {
                    return this
                }, E.toString = function() {
                    return "[object Generator]"
                }, t.keys = function(t) {
                    var e = [];
                    for (var n in t) e.push(n);
                    return e.reverse(),
                        function n() {
                            for (; e.length;) {
                                var r = e.pop();
                                if (r in t) return n.value = r, n.done = !1, n
                            }
                            return n.done = !0, n
                        }
                }, t.values = k, O.prototype = {
                    constructor: O,
                    reset: function(t) {
                        if (this.prev = 0, this.next = 0, this.sent = this._sent = e, this.done = !1, this.delegate = null, this.method = "next", this.arg = e, this.tryEntries.forEach(T), !t)
                            for (var n in this) "t" === n.charAt(0) && r.call(this, n) && !isNaN(+n.slice(1)) && (this[n] = e)
                    },
                    stop: function() {
                        this.done = !0;
                        var t = this.tryEntries[0].completion;
                        if ("throw" === t.type) throw t.arg;
                        return this.rval
                    },
                    dispatchException: function(t) {
                        if (this.done) throw t;
                        var n = this;

                        function o(r, o) {
                            return s.type = "throw", s.arg = t, n.next = r, o && (n.method = "next", n.arg = e), !!o
                        }
                        for (var i = this.tryEntries.length - 1; i >= 0; --i) {
                            var a = this.tryEntries[i],
                                s = a.completion;
                            if ("root" === a.tryLoc) return o("end");
                            if (a.tryLoc <= this.prev) {
                                var l = r.call(a, "catchLoc"),
                                    u = r.call(a, "finallyLoc");
                                if (l && u) {
                                    if (this.prev < a.catchLoc) return o(a.catchLoc, !0);
                                    if (this.prev < a.finallyLoc) return o(a.finallyLoc)
                                } else if (l) {
                                    if (this.prev < a.catchLoc) return o(a.catchLoc, !0)
                                } else {
                                    if (!u) throw new Error("try statement without catch or finally");
                                    if (this.prev < a.finallyLoc) return o(a.finallyLoc)
                                }
                            }
                        }
                    },
                    abrupt: function(t, e) {
                        for (var n = this.tryEntries.length - 1; n >= 0; --n) {
                            var o = this.tryEntries[n];
                            if (o.tryLoc <= this.prev && r.call(o, "finallyLoc") && this.prev < o.finallyLoc) {
                                var i = o;
                                break
                            }
                        }
                        i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null);
                        var a = i ? i.completion : {};
                        return a.type = t, a.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, v) : this.complete(a)
                    },
                    complete: function(t, e) {
                        if ("throw" === t.type) throw t.arg;
                        return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), v
                    },
                    finish: function(t) {
                        for (var e = this.tryEntries.length - 1; e >= 0; --e) {
                            var n = this.tryEntries[e];
                            if (n.finallyLoc === t) return this.complete(n.completion, n.afterLoc), T(n), v
                        }
                    },
                    catch: function(t) {
                        for (var e = this.tryEntries.length - 1; e >= 0; --e) {
                            var n = this.tryEntries[e];
                            if (n.tryLoc === t) {
                                var r = n.completion;
                                if ("throw" === r.type) {
                                    var o = r.arg;
                                    T(n)
                                }
                                return o
                            }
                        }
                        throw new Error("illegal catch attempt")
                    },
                    delegateYield: function(t, n, r) {
                        return this.delegate = {
                            iterator: k(t),
                            resultName: n,
                            nextLoc: r
                        }, "next" === this.method && (this.arg = e), v
                    }
                }, t
            }(t.exports);
            try {
                regeneratorRuntime = e
            } catch (t) {
                Function("r", "regeneratorRuntime = r")(e)
            }
        },
        84408: function(t, e, n) {
            "use strict";
            n.d(e, {
                Z: function() {
                    return r
                }
            }), t = n.hmd(t);
            var r = function(t) {
                var e, n = t.Symbol;
                return "function" == typeof n ? n.observable ? e = n.observable : (e = n("observable"), n.observable = e) : e = "@@observable", e
            }("undefined" != typeof self ? self : "undefined" != typeof window ? window : void 0 !== n.g ? n.g : t)
        },
        45473: function(t, e, n) {
            "use strict";
            n.d(e, {
                Tb: function() {
                    return f
                }
            });
            var r = function(t, e) {
                    return {
                        name: t,
                        value: void 0 === e ? -1 : e,
                        delta: 0,
                        entries: [],
                        id: "v1-".concat(Date.now(), "-").concat(Math.floor(8999999999999 * Math.random()) + 1e12)
                    }
                },
                o = function(t, e) {
                    try {
                        if (PerformanceObserver.supportedEntryTypes.includes(t)) {
                            if ("first-input" === t && !("PerformanceEventTiming" in self)) return;
                            var n = new PerformanceObserver((function(t) {
                                return t.getEntries().map(e)
                            }));
                            return n.observe({
                                type: t,
                                buffered: !0
                            }), n
                        }
                    } catch (t) {}
                },
                i = function(t, e) {
                    var n = function n(r) {
                        "pagehide" !== r.type && "hidden" !== document.visibilityState || (t(r), e && (removeEventListener("visibilitychange", n, !0), removeEventListener("pagehide", n, !0)))
                    };
                    addEventListener("visibilitychange", n, !0), addEventListener("pagehide", n, !0)
                },
                a = function(t) {
                    addEventListener("pageshow", (function(e) {
                        e.persisted && t(e)
                    }), !0)
                },
                s = "function" == typeof WeakSet ? new WeakSet : new Set,
                l = function(t, e, n) {
                    var r;
                    return function() {
                        e.value >= 0 && (n || s.has(e) || "hidden" === document.visibilityState) && (e.delta = e.value - (r || 0), (e.delta || void 0 === r) && (r = e.value, t(e)))
                    }
                },
                u = -1,
                c = function() {
                    return "hidden" === document.visibilityState ? 0 : 1 / 0
                },
                d = function() {
                    i((function(t) {
                        var e = t.timeStamp;
                        u = e
                    }), !0)
                },
                h = function() {
                    return u < 0 && (u = c(), d(), a((function() {
                        setTimeout((function() {
                            u = c(), d()
                        }), 0)
                    }))), {
                        get timeStamp() {
                            return u
                        }
                    }
                },
                f = (new Date, function(t, e) {
                    var n, u = h(),
                        c = r("LCP"),
                        d = function(t) {
                            var e = t.startTime;
                            e < u.timeStamp && (c.value = e, c.entries.push(t)), n()
                        },
                        f = o("largest-contentful-paint", d);
                    if (f) {
                        n = l(t, c, e);
                        var p = function() {
                            s.has(c) || (f.takeRecords().map(d), f.disconnect(), s.add(c), n())
                        };
                        ["keydown", "click"].forEach((function(t) {
                            addEventListener(t, p, {
                                once: !0,
                                capture: !0
                            })
                        })), i(p, !0), a((function(o) {
                            c = r("LCP"), n = l(t, c, e), requestAnimationFrame((function() {
                                requestAnimationFrame((function() {
                                    c.value = performance.now() - o.timeStamp, s.add(c), n()
                                }))
                            }))
                        }))
                    }
                })
        }
    }
]);
//# sourceMappingURL=https://shopee.sg/assets/2360.87300ebe7a29d9fae243.js.map