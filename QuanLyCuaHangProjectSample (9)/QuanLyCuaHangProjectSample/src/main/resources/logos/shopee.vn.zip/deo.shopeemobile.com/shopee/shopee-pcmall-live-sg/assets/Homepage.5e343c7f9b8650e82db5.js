(("undefined" != typeof self ? self : this).webpackChunkshopee_pc = ("undefined" != typeof self ? self : this).webpackChunkshopee_pc || []).push([
    [4037, 8798], {
        95963: function(e, t, n) {
            "use strict";
            n.d(t, {
                yV: function() {
                    return L
                },
                c5: function() {
                    return I
                },
                qC: function() {
                    return A
                },
                Bn: function() {
                    return R
                },
                kW: function() {
                    return B
                },
                pg: function() {
                    return N
                }
            });
            var r = n(69068),
                a = n(19511),
                o = n(3792),
                i = n(86764),
                c = n(72609),
                u = n(68214),
                s = n.n(u),
                l = n(47546),
                p = n(41236),
                m = n(5078);

            function f() {
                return (f = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(this, arguments)
            }
            var d = {
                    location: "location",
                    longitude: "longitude",
                    latitude: "latitude",
                    token: "token",
                    preview_params: "preview_params"
                },
                h = f({}, d, {
                    type: "type",
                    category_id: "category_id",
                    group_id: "group_id",
                    version: "version"
                });
            f({}, d, {
                version: "__version__"
            });

            function g(e) {
                return (0, l.Z)(e, ["response"], (function(e) {
                    var t = e.data;
                    return f({}, function(e, t) {
                        if (null == e) return {};
                        var n, r, a = {},
                            o = Object.keys(e);
                        for (r = 0; r < o.length; r++) n = o[r], t.indexOf(n) >= 0 || (a[n] = e[n]);
                        return a
                    }(e, ["data"]), t, {
                        banners: t && t.banners ? t.banners : []
                    })
                }))
            }

            function v() {
                return (v = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(this, arguments)
            }

            function _(e) {
                var t = e.types,
                    n = e.providedPlatform,
                    r = function(e, t) {
                        if (null == e) return {};
                        var n, r, a = {},
                            o = Object.keys(e);
                        for (r = 0; r < o.length; r++) n = o[r], t.indexOf(n) >= 0 || (a[n] = e[n]);
                        return a
                    }(e, ["types", "providedPlatform"]),
                    a = s()(t.map((function(e) {
                        return e.type
                    })).sort().join(","));
                return (0, c.jsonPost)("/api/v4/banner/batch_list", v({}, r, {
                    location: JSON.stringify(r.location),
                    preview_params: JSON.stringify(r.preview_params),
                    types: t,
                    version: a.toString()
                })).then((function(e) {
                    var t, r, a = function(e) {
                            var t = (0, i.n)(e);
                            return function(e) {
                                return Object.keys(e).reduce((function(n, r) {
                                    return n[r] = (0, l.Z)(e[r], ["banners"], (function(e) {
                                        return (e || []).filter(t)
                                    })), n
                                }), {})
                            }
                        }(n),
                        c = (t = e, r = (0, o.Z)(t, ["response", "data", "banners"], []), (0, m.Z)(t, ["response", "banners"], r.reduce((function(e, t) {
                            var n;
                            return f({}, e, ((n = {})[t.type] = t, n))
                        }), {})));
                    return (0, l.Z)(c, ["response", "banners"], a)
                }))
            }

            function y(e) {
                return (0, c.fetchInfo)("/api/v4/banner/get_list" + (t = e, n = f({}, t, {
                    preview_params: JSON.stringify(t.preview_params)
                }), (0, p.a)(h)(n))).then((function(e) {
                    return (0, l.Z)(g(e), ["response", "banners"], (function(e) {
                        return e.filter(i.D)
                    }))
                }));
                var t, n
            }
            var E = n(48173);

            function b() {
                return (b = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(this, arguments)
            }

            function C(e, t, n) {
                return void 0 === n && (n = {}), y(b({}, n, {
                    type: "category",
                    category_id: e,
                    version: t
                }))
            }

            function w(e, t, n) {
                return void 0 === n && (n = {}), y(b({}, n, {
                    type: "group",
                    group_id: e,
                    version: t
                }))
            }

            function S(e, t, n) {
                return void 0 === t && (t = null), void 0 === n && (n = {}), y(b({}, n, {
                    type: "official_shop",
                    category_id: e,
                    version: t
                }))
            }

            function P(e, t) {
                return void 0 === e && (e = null), void 0 === t && (t = {}), y(b({}, t, {
                    type: E.Zi.MALL_POPUP,
                    version: e
                }))
            }

            function k() {
                return (k = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(this, arguments)
            }

            function T(e, t, n, r, a, o, i) {
                try {
                    var c = e[o](i),
                        u = c.value
                } catch (e) {
                    return void n(e)
                }
                c.done ? t(u) : Promise.resolve(u).then(r, a)
            }

            function O(e) {
                return function() {
                    var t = this,
                        n = arguments;
                    return new Promise((function(r, a) {
                        var o = e.apply(t, n);

                        function i(e) {
                            T(o, r, a, i, c, "next", e)
                        }

                        function c(e) {
                            T(o, r, a, i, c, "throw", e)
                        }
                        i(void 0)
                    }))
                }
            }
            var I = function() {
                return function() {
                    var e = O(regeneratorRuntime.mark((function e(t) {
                        return regeneratorRuntime.wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    t((0, r.a)(E.WY));
                                case 1:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })));
                    return function(t) {
                        return e.apply(this, arguments)
                    }
                }()
            };

            function N(e, t) {
                return function() {
                    var n = O(regeneratorRuntime.mark((function n(r, o) {
                        return regeneratorRuntime.wrap((function(n) {
                            for (;;) switch (n.prev = n.next) {
                                case 0:
                                    return n.next = 2, (0, a.Z)({
                                        apiCall: function() {
                                            return S(e, null, t)
                                        },
                                        actions: [{
                                            type: E.c8.REQUESTED
                                        }, {
                                            type: E.c8.SUCCESS,
                                            payload: function(t, n, r) {
                                                return k({}, r, {
                                                    categoryId: e
                                                })
                                            }
                                        }, {
                                            type: E.c8.FAILED,
                                            payload: function(e, t, n) {
                                                return {
                                                    error: n.error
                                                }
                                            }
                                        }]
                                    }, r, o, "" + e);
                                case 2:
                                case "end":
                                    return n.stop()
                            }
                        }), n)
                    })));
                    return function(e, t) {
                        return n.apply(this, arguments)
                    }
                }()
            }

            function A(e, t) {
                var n = void 0 === t ? {} : t,
                    r = n.getBannerState,
                    i = void 0 === r ? function(e) {
                        return e.banner
                    } : r,
                    c = n.params,
                    u = void 0 === c ? {} : c;
                return function() {
                    var t = O(regeneratorRuntime.mark((function t(n, r) {
                        return regeneratorRuntime.wrap((function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return t.next = 2, (0, a.Z)({
                                        apiCall: function() {
                                            var t = i(r()),
                                                n = (0, o.Z)(t, ["categoryBanners", e, "version"], null);
                                            return C(e, n, u)
                                        },
                                        actions: [{
                                            type: E.UJ.REQUESTED
                                        }, {
                                            type: E.UJ.SUCCESS,
                                            payload: function(t, n, r) {
                                                return k({}, r, {
                                                    categoryId: e
                                                })
                                            }
                                        }, {
                                            type: E.UJ.FAILED,
                                            payload: function(e, t, n) {
                                                return {
                                                    error: n.error
                                                }
                                            }
                                        }]
                                    }, n, r);
                                case 2:
                                case "end":
                                    return t.stop()
                            }
                        }), t)
                    })));
                    return function(e, n) {
                        return t.apply(this, arguments)
                    }
                }()
            }

            function L(e, t) {
                var n = void 0 === t ? {} : t,
                    r = n.getBannerState,
                    i = void 0 === r ? function(e) {
                        return e.banner
                    } : r,
                    c = n.params,
                    u = void 0 === c ? {} : c,
                    s = n.updatedLocation,
                    l = n.shouldNormalizeBanners,
                    p = n.normalType,
                    m = n.providedPlatform;
                return function() {
                    var t = O(regeneratorRuntime.mark((function t(n, r) {
                        return regeneratorRuntime.wrap((function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return t.next = 2, (0, a.Z)({
                                        apiCall: function() {
                                            var t = O(regeneratorRuntime.mark((function t() {
                                                var n, a, c, s, l;
                                                return regeneratorRuntime.wrap((function(t) {
                                                    for (;;) switch (t.prev = t.next) {
                                                        case 0:
                                                            return n = i(r()), a = e.filter((function(e) {
                                                                return !!e
                                                            })), c = a.map((function(e) {
                                                                var t = (0, o.Z)(n, [e, "version"], null);
                                                                return t ? {
                                                                    type: e,
                                                                    version: t
                                                                } : {
                                                                    type: e
                                                                }
                                                            })), s = k({}, u, {
                                                                types: c,
                                                                providedPlatform: m
                                                            }), l = _(s), t.abrupt("return", l);
                                                        case 6:
                                                        case "end":
                                                            return t.stop()
                                                    }
                                                }), t)
                                            })));
                                            return function() {
                                                return t.apply(this, arguments)
                                            }
                                        }(),
                                        actions: [{
                                            type: E.Dj.REQUESTED
                                        }, {
                                            type: E.Dj.SUCCESS,
                                            payload: function(e, t, n) {
                                                return k({
                                                    updatedLocation: s,
                                                    shouldNormalizeBanners: !!l,
                                                    normalType: p
                                                }, n)
                                            }
                                        }, {
                                            type: E.Dj.FAILED,
                                            payload: function(e, t, n) {
                                                return {
                                                    error: n.error
                                                }
                                            }
                                        }]
                                    }, n, r);
                                case 2:
                                case "end":
                                    return t.stop()
                            }
                        }), t)
                    })));
                    return function(e, n) {
                        return t.apply(this, arguments)
                    }
                }()
            }

            function R(e, t) {
                var n = void 0 === t ? {} : t,
                    r = n.getBannerState,
                    i = void 0 === r ? function(e) {
                        return e.banner
                    } : r,
                    c = n.params,
                    u = void 0 === c ? {} : c;
                return function() {
                    var t = O(regeneratorRuntime.mark((function t(n, r) {
                        return regeneratorRuntime.wrap((function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return t.next = 2, (0, a.Z)({
                                        apiCall: function() {
                                            var t = i(r()),
                                                n = (0, o.Z)(t, ["groupBanners", "version"], null);
                                            return w(e, n, u)
                                        },
                                        actions: [{
                                            type: E.Z3.REQUESTED
                                        }, {
                                            type: E.Z3.SUCCESS,
                                            payload: function(t, n, r) {
                                                return k({}, r, {
                                                    groupId: e
                                                })
                                            }
                                        }, {
                                            type: E.Z3.FAILED,
                                            payload: function(e, t, n) {
                                                return {
                                                    error: n.error
                                                }
                                            }
                                        }]
                                    }, n, r);
                                case 2:
                                case "end":
                                    return t.stop()
                            }
                        }), t)
                    })));
                    return function(e, n) {
                        return t.apply(this, arguments)
                    }
                }()
            }
            var B = function(e) {
                var t = void 0 === e ? {} : e,
                    n = t.getBannerState,
                    r = void 0 === n ? function(e) {
                        return e.banner
                    } : n,
                    i = t.params,
                    c = void 0 === i ? {} : i;
                return function() {
                    var e = O(regeneratorRuntime.mark((function e(t, n) {
                        return regeneratorRuntime.wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return e.next = 2, (0, a.Z)({
                                        apiCall: function() {
                                            var e = r(n());
                                            return P((0, o.Z)(e, [E.Zi.MALL_POPUP, "version"], null), c)
                                        },
                                        actions: [{
                                            type: E.Uz.REQUESTED
                                        }, {
                                            type: E.Uz.SUCCESS,
                                            payload: function(e, t, n) {
                                                return n
                                            }
                                        }, {
                                            type: E.Uz.FAILED,
                                            payload: function(e, t, n) {
                                                return {
                                                    error: n.error
                                                }
                                            }
                                        }]
                                    }, t, n);
                                case 2:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })));
                    return function(t, n) {
                        return e.apply(this, arguments)
                    }
                }()
            }
        },
        50949: function(e, t, n) {
            "use strict";
            n.d(t, {
                tj: function() {
                    return a
                },
                Lv: function() {
                    return o
                },
                Ds: function() {
                    return i
                },
                qV: function() {
                    return c
                },
                X: function() {
                    return u
                },
                Sr: function() {
                    return s
                },
                dt: function() {
                    return p
                },
                wM: function() {
                    return m
                },
                X5: function() {
                    return f
                },
                ED: function() {
                    return d
                },
                UK: function() {
                    return h
                },
                Ms: function() {
                    return g
                },
                o8: function() {
                    return v
                },
                $g: function() {
                    return _
                },
                tV: function() {
                    return y
                }
            });
            var r = n(48173),
                a = function(e) {
                    return e[r.N3]
                },
                o = function(e, t) {
                    var n, r;
                    return (null == e || null === (n = e.categoryBanners) || void 0 === n || null === (r = n[t]) || void 0 === r ? void 0 : r.banners) || []
                },
                i = function(e, t) {
                    var n = e.officialShopBanners[t];
                    return n ? n.banners : []
                },
                c = function(e) {
                    return e.popup.banners
                },
                u = function(e) {
                    return e.activity.banners
                },
                s = function(e) {
                    return e.floating.banners
                },
                l = function(e) {
                    return null == e || null == e.data ? [] : e.data.map((function(t) {
                        return {
                            start: e.start,
                            end: e.end,
                            banner_image_hash: t.mobile_image,
                            pc_banner_image_hash: t.pc_image,
                            pc_banner_image_hash_gif: t.pc_image_gif,
                            banner_image: "",
                            id: e.id,
                            navigate_params: {
                                url: t.url,
                                navbar: {}
                            },
                            display: e.display
                        }
                    }))
                },
                p = function(e) {
                    var t, n;
                    return e.skinny_v2 ? l(null == e || null === (t = e.skinny_v2) || void 0 === t || null === (n = t.banners) || void 0 === n ? void 0 : n[0]) : e.skinny.banners
                },
                m = function(e) {
                    return e.pc_home_squares && e.pc_home_squares.banners.length > 0
                },
                f = function(e) {
                    return m(e) ? e.pc_home_squares.banners : e.pc_home_circles.banners
                },
                d = function(e, t) {
                    return e && e.groupBanners && e.groupBanners[t] && e.groupBanners[t].banners ? e.groupBanners[t].banners : []
                },
                h = function(e) {
                    return e.homepage_mall_banner.banners
                },
                g = function(e) {
                    return e.mall_popup.banners
                },
                v = function(e) {
                    return e.mart_activity.banners
                },
                _ = function(e, t) {
                    var n;
                    return void 0 === t && (t = 4), ((null == e || null === (n = e.mart_skinny_v2) || void 0 === n ? void 0 : n.banners) || []).slice(0, t).map((function(e) {
                        return l(e)
                    }))
                };

            function y(e, t) {
                return !e && !e || !(!e || !t) && (e.length === t.length && e.every((function(e, n) {
                    return function(e, t) {
                        return !e && !t || !(!e || !t) && e.length === t.length && e.every((function(e, n) {
                            return t[n].id === e.id
                        }))
                    }(e, t[n])
                })))
            }
        },
        80850: function(e) {
            e.exports = {}
        },
        87661: function(e, t, n) {
            "use strict";
            n.d(t, {
                LZ: function() {
                    return T
                },
                Fk: function() {
                    return S
                },
                HQ: function() {
                    return O
                },
                Uw: function() {
                    return I
                },
                hy: function() {
                    return p
                },
                tf: function() {
                    return l
                },
                qZ: function() {
                    return k
                },
                cY: function() {
                    return P
                }
            });
            var r = n(15263),
                a = n(72609);
            n(92027);
            var o = n(69068),
                i = (0, o.n)("FETCH_HOMEPAGE_CATEGORY_LIST_V4"),
                c = (0, o.n)("FETCH_CATEGORY_TREE_V4"),
                u = (0, o.n)("FETCH_SUB_CATEGORY_LIST_V4"),
                s = (0, o.n)("FETCH_CATEGORY_BY_ID_V4");

            function l() {
                return (0, r.Z)({
                    apiCall: function() {
                        return (0, a.fetchInfo)("/api/v4/pages/get_homepage_category_list")
                    },
                    actions: [function() {
                        return {
                            type: i.REQUESTED
                        }
                    }, function(e, t) {
                        return {
                            type: i.SUCCESS,
                            payload: {
                                data: t.data
                            }
                        }
                    }, function(e, t) {
                        return {
                            type: i.FAILED,
                            payload: {
                                error: t.error
                            }
                        }
                    }]
                })
            }

            function p() {
                return (0, r.Z)({
                    apiCall: function() {
                        return (0, a.fetchInfo)("/api/v4/pages/get_category_tree")
                    },
                    actions: [function() {
                        return {
                            type: c.REQUESTED
                        }
                    }, function(e, t) {
                        return {
                            type: c.SUCCESS,
                            payload: {
                                data: t.data
                            }
                        }
                    }, function(e, t) {
                        return {
                            type: c.FAILED,
                            payload: {
                                error: t.error
                            }
                        }
                    }]
                })
            }
            var m, f, d, h, g = n(14081),
                v = n(18363);

            function _() {
                return (_ = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(this, arguments)
            }
            var y = {
                    homepageCategories: {
                        progress: v.Z.INIT,
                        error: 0,
                        data: null
                    },
                    categoryTree: {
                        progress: v.Z.INIT,
                        error: 0,
                        data: null
                    },
                    subCategories: {},
                    categoryById: {}
                },
                E = ((m = {})[i.REQUESTED] = function(e) {
                    return _({}, e, {
                        homepageCategories: _({}, e.homepageCategories, {
                            progress: v.Z.REQ
                        })
                    })
                }, m[i.SUCCESS] = function(e, t) {
                    var n = t.payload;
                    return _({}, e, {
                        homepageCategories: _({}, e.homepageCategories, {
                            progress: v.Z.OK,
                            data: n.data
                        })
                    })
                }, m[i.FAILED] = function(e, t) {
                    var n = t.payload;
                    return _({}, e, {
                        homepageCategories: _({}, e.homepageCategories, {
                            error: n.error,
                            progress: v.Z.ERR
                        })
                    })
                }, m),
                b = ((f = {})[c.REQUESTED] = function(e) {
                    return _({}, e, {
                        categoryTree: _({}, e.categoryTree, {
                            progress: v.Z.REQ
                        })
                    })
                }, f[c.SUCCESS] = function(e, t) {
                    var n = t.payload;
                    return _({}, e, {
                        categoryTree: _({}, e.categoryTree, {
                            progress: v.Z.OK,
                            data: n.data
                        })
                    })
                }, f[c.FAILED] = function(e, t) {
                    var n = t.payload;
                    return _({}, e, {
                        categoryTree: _({}, e.categoryTree, {
                            error: n.error,
                            progress: v.Z.ERR
                        })
                    })
                }, f),
                C = ((d = {})[u.REQUESTED] = function(e, t) {
                    var n, r = t.payload;
                    return _({}, e, {
                        subCategories: _({}, e.subCategories, (n = {}, n[r.parent_catid] = _({}, e.subCategories[r.parent_catid], {
                            progress: v.Z.REQ
                        }), n))
                    })
                }, d[u.SUCCESS] = function(e, t) {
                    var n, r = t.payload;
                    return _({}, e, {
                        subCategories: _({}, e.subCategories, (n = {}, n[r.parent_catid] = _({}, e.subCategories[r.parent_catid], {
                            progress: v.Z.OK,
                            data: r.data
                        }), n))
                    })
                }, d[u.FAILED] = function(e, t) {
                    var n, r = t.payload;
                    return _({}, e, {
                        subCategories: _({}, e.subCategories, (n = {}, n[r.parent_catid] = _({}, e.subCategories[r.parent_catid], {
                            progress: v.Z.ERR
                        }), n))
                    })
                }, d),
                w = ((h = {})[s.REQUESTED] = function(e, t) {
                    var n, r = t.payload;
                    return _({}, e, {
                        categoryById: _({}, e.categoryById, (n = {}, n[r.catid] = _({}, e.categoryById[r.catid], {
                            progress: v.Z.REQ
                        }), n))
                    })
                }, h[s.SUCCESS] = function(e, t) {
                    var n, r = t.payload;
                    return _({}, e, {
                        categoryById: _({}, e.categoryById, (n = {}, n[r.catid] = _({}, e.categoryById[r.catid], {
                            progress: v.Z.OK,
                            data: r.data
                        }), n))
                    })
                }, h[s.FAILED] = function(e, t) {
                    var n, r = t.payload;
                    return _({}, e, {
                        categoryById: _({}, e.categoryById, (n = {}, n[r.catid] = _({}, e.categoryById[r.catid], {
                            progress: v.Z.ERR
                        }), n))
                    })
                }, h),
                S = (0, g.Z)(_({}, E, b, C, w), y);

            function P(e) {
                return null == e ? void 0 : e.homepageCategories
            }

            function k(e) {
                return null == e ? void 0 : e.categoryTree
            }
            var T = "categoryV4";

            function O(e) {
                return {
                    no_sub: !1,
                    image: e.image,
                    display_name: e.display_name,
                    catid: e.catid,
                    block_buyer_platform: e.block_buyer_platform
                }
            }

            function I(e) {
                var t = e.display_name,
                    n = e.name,
                    r = e.catid,
                    a = e.image,
                    o = e.selected_image,
                    i = e.unselected_image,
                    c = e.block_buyer_platform,
                    u = e.children;
                return {
                    main: {
                        display_name: t,
                        name: n,
                        catid: r,
                        image: a,
                        selected_image: o,
                        unselected_image: i,
                        parent_category: 0,
                        is_adult: 0,
                        sort_weight: 0,
                        block_buyer_platform: c
                    },
                    sub: (null != u ? u : []).map((function(t) {
                        return {
                            display_name: t.display_name,
                            name: t.name,
                            catid: t.catid,
                            image: t.image,
                            block_buyer_platform: t.block_buyer_platform,
                            parent_category: e.catid,
                            is_adult: 0,
                            sort_weight: 0,
                            sub_sub: null
                        }
                    }))
                }
            }
        },
        9315: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return c
                }
            });
            var r = n(27378),
                a = n(60710),
                o = n(312),
                i = function(e) {
                    var t = e.customHeader;
                    return r.createElement("img", {
                        src: (0, a.Jn)(t.image),
                        style: {
                            width: t.display_width ? (0, o.Z)(t.display_width) : "auto",
                            height: t.display_height ? (0, o.Z)(t.display_height) : "auto"
                        }
                    })
                },
                c = function(e) {
                    var t = e.headerText,
                        n = e.customHeader;
                    return n ? n.image ? r.createElement(i, {
                        customHeader: {
                            image: n.image,
                            display_width: n.display_width,
                            display_height: n.display_height
                        }
                    }) : r.createElement("span", {
                        style: {
                            color: n.color || void 0
                        }
                    }, t) : r.createElement(r.Fragment, null, t) || null
                }
        },
        62198: function(e, t, n) {
            "use strict";
            var r = n(27378),
                a = n.n(r),
                o = n(31474),
                i = n(60710),
                c = n(2149),
                u = n(48173),
                s = n(84571);

            function l() {
                return (l = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(this, arguments)
            }
            t.Z = function(e) {
                var t = e.banner,
                    n = e.bannerType,
                    r = e.width,
                    p = e.height,
                    m = e.style,
                    f = void 0 === m ? {} : m,
                    d = e.hidePlaceholderIcon,
                    h = void 0 !== d && d,
                    g = e.location,
                    v = e.targetType,
                    _ = l({
                        width: r,
                        height: p
                    }, f),
                    y = t && t.navigate_params ? (0, c.e)(t.navigate_params.url) : {
                        type: c.G.EXTERNAL,
                        link: "#"
                    },
                    E = function(e, t) {
                        if (!e || !t) return null;
                        switch (e) {
                            case u.Zi.FLOATING_ICONS:
                                return t.images && t.images.image_floating_pc ? (0, i.Jn)(t.images.image_floating_pc) : null;
                            case u.Zi.SKINNY_BANNERS:
                                return t.pc_banner_image || (0, i.Jn)(t.pc_banner_image_hash);
                            default:
                                return t.pc_banner_image
                        }
                    }(n, t),
                    b = function(e, t) {
                        if (!e || !t) return null;
                        switch (e) {
                            case u.Zi.FLOATING_ICONS:
                                return t.images && t.images.image_floating_pc_gif ? (0, i.Jn)(t.images.image_floating_pc_gif) : null;
                            case u.Zi.SKINNY_BANNERS:
                                return t.pc_banner_image_gif || (0, i.Jn)(t.pc_banner_image_hash_gif);
                            default:
                                return t.pc_banner_image_gif
                        }
                    }(n, t);
                return a().createElement("div", {
                    className: "shopee-skinny-banner__container"
                }, a().createElement(s.LinkWithTrackImpression, {
                    to: y.link,
                    className: "shopee-skinny-banner",
                    style: _,
                    bannerUrl: t && t.navigate_params ? t.navigate_params.url : "#",
                    location: g,
                    targetType: v || n,
                    id: t && t.id
                }, a().createElement(o.Y, {
                    src: E,
                    gifSrc: b,
                    wrapperClassName: "shopee-skinny-banner__full-height",
                    className: "shopee-skinny-banner__full-height",
                    hidePlaceholder: h,
                    placeholderClassName: "shopee-skinny-banner__placeholder",
                    isCovered: !0
                })))
            }
        },
        41236: function(e, t, n) {
            "use strict";
            n.d(t, {
                f: function() {
                    return a
                },
                a: function() {
                    return o
                }
            });
            var r = n(92027);

            function a(e) {
                return function(t) {
                    if (!t) return {};
                    var n = {};
                    for (var r in e) {
                        var a = e[r],
                            o = "function" == typeof a ? a(t) : t[a];
                        n[r] = o
                    }
                    return n
                }
            }

            function o(e) {
                var t = {};
                for (var n in e) t[e[n]] = n;
                return function(e) {
                    return (0, r.Wc)(a(t)(e))
                }
            }
        },
        61309: function(e, t, n) {
            "use strict";
            n.d(t, {
                l1: function() {
                    return r
                },
                nt: function() {
                    return m
                },
                Ty: function() {
                    return d
                }
            });
            var r, a, o = n(27378),
                i = n(79308),
                c = n(97953),
                u = n(73180),
                s = n(8205);
            ! function(e) {
                e[e.homepageGroupbuySection = 0] = "homepageGroupbuySection", e[e.userPageMyGroupsSection = 1] = "userPageMyGroupsSection"
            }(r || (r = {}));
            var l = c.Xb.getLocale(),
                p = ((a = {})[r.homepageGroupbuySection] = ["SG"], a[r.userPageMyGroupsSection] = ["TW", "SG"], a);

            function m(e) {
                return function(e, t) {
                    if ("TW" === l && (e = !0), void 0 !== t) {
                        var n = p[t];
                        if (n) return e && n.includes(l)
                    }
                    return e
                }((0, i.useSelector)((function(e) {
                    return (0, u.Au)(e.featureToggles, s.MEi)
                })), e)
            }

            function f() {
                return (f = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(this, arguments)
            }
            var d = function(e, t) {
                var n = o.forwardRef((function(n, r) {
                        var a = m(t);
                        return o.createElement(e, f({}, n, {
                            enableGroupBuy: a,
                            ref: r
                        }))
                    })),
                    r = function(e) {
                        return e.displayName || e.name || "Component"
                    }(n);
                return n.displayName = "WithEnableGroupBuy(" + r + ")", n
            }
        },
        32666: function(e, t, n) {
            "use strict";
            n.d(t, {
                S: function() {
                    return g
                }
            });
            var r = n(27378),
                a = n.n(r),
                o = n(60042),
                i = n.n(o),
                c = n(98466),
                u = n(95802),
                s = n(4918),
                l = n(70510),
                p = n(9315),
                m = n(60710);

            function f(e, t) {
                if (null == e) return {};
                var n, r, a = {},
                    o = Object.keys(e);
                for (r = 0; r < o.length; r++) n = o[r], t.indexOf(n) >= 0 || (a[n] = e[n]);
                return a
            }

            function d() {
                return (d = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(this, arguments)
            }
            var h = function(e) {
                    var t = e.headerButton,
                        n = e.onHeaderButtonClick,
                        r = e.simpleVersion,
                        o = e.hasNoNavigation,
                        i = e.customButtonContent,
                        c = e.headerButtonStyle,
                        p = e.headerSectionButtonProps,
                        m = t.linkTo,
                        f = i || a().createElement(a().Fragment, null, t.text, " ", a().createElement(s.Z, null)),
                        h = r ? a().createElement(l.Rd, d({
                            targetType: "SeeAllButton",
                            style: c
                        }, p), f) : a().createElement(l.s7, d({
                            targetType: "SeeAllButton",
                            style: c
                        }, p), f);
                    return o ? a().createElement("div", {
                        className: "shopee-header-section__header-link",
                        onClick: function(e) {
                            n && n(e)
                        }
                    }, h) : a().createElement(u.Z, {
                        to: m,
                        className: "shopee-header-section__header-link",
                        onClick: function(e) {
                            n && n(e)
                        }
                    }, h)
                },
                g = (0, c.Z)((function(e) {
                    var t = e.headerText,
                        n = e.headerButton,
                        r = e.children,
                        o = e.simpleVersion,
                        c = e.classNames,
                        u = e.customButtonContent,
                        s = e.hasNoNavigation,
                        l = e.onHeaderButtonClick,
                        g = e.style,
                        v = void 0 === g ? {} : g,
                        _ = e.trackingRef,
                        y = e.headerStyle,
                        E = void 0 === y ? {} : y,
                        b = e.customHeader,
                        C = f(e, ["headerText", "headerButton", "children", "simpleVersion", "classNames", "customButtonContent", "hasNoNavigation", "onHeaderButtonClick", "style", "trackingRef", "headerStyle", "customHeader"]),
                        w = {
                            backgroundImage: b && b.background_image ? "url(" + (0, m.Jn)(b.background_image) + ")" : void 0
                        },
                        S = (E.seeAllColor, f(E, ["seeAllColor"]));
                    return a().createElement("div", {
                        className: i()("shopee-header-section", c, !!o && "shopee-header-section--simple"),
                        ref: _ || null,
                        style: v
                    }, a().createElement("div", {
                        className: "shopee-header-section__header",
                        style: w
                    }, a().createElement("div", {
                        className: "shopee-header-section__header__title",
                        style: S
                    }, a().createElement(p.Z, {
                        headerText: t,
                        customHeader: b
                    })), !!n && a().createElement(h, {
                        headerButton: n,
                        simpleVersion: !!o,
                        hasNoNavigation: !!s,
                        customButtonContent: u,
                        onHeaderButtonClick: l,
                        headerButtonStyle: E && E.seeAllColor ? {
                            color: E.seeAllColor
                        } : E && E.color ? {
                            color: E.color
                        } : {},
                        headerSectionButtonProps: d({}, C)
                    })), a().createElement("div", {
                        className: "shopee-header-section__content"
                    }, r))
                }), "HeaderSection", {
                    reportOnce: !0
                })
        },
        48422: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return rr
                }
            });
            var r = n(27378),
                a = n.n(r),
                o = n(70405),
                i = n(47924),
                c = n.n(i),
                u = n(12142),
                s = n(88623),
                l = n(79110),
                p = n(79308),
                m = n(26624),
                f = n(98845),
                d = n(49101),
                h = n(8013),
                g = n(69748),
                v = n(93049),
                _ = n(7283),
                y = n(99096),
                E = n(3140),
                b = n(70590),
                C = n(3792),
                w = n(8205),
                S = n(22333),
                P = n(98466),
                k = n(26235),
                T = n(6965),
                O = n(33379),
                I = n(91208);

            function N() {
                return (N = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(this, arguments)
            }

            function A(e, t, n, r, a, o, i) {
                try {
                    var c = e[o](i),
                        u = c.value
                } catch (e) {
                    return void n(e)
                }
                c.done ? t(u) : Promise.resolve(u).then(r, a)
            }

            function L(e) {
                return function() {
                    var t = this,
                        n = arguments;
                    return new Promise((function(r, a) {
                        var o = e.apply(t, n);

                        function i(e) {
                            A(o, r, a, i, c, "next", e)
                        }

                        function c(e) {
                            A(o, r, a, i, c, "throw", e)
                        }
                        i(void 0)
                    }))
                }
            }

            function R(e, t) {
                return (R = Object.setPrototypeOf || function(e, t) {
                    return e.__proto__ = t, e
                })(e, t)
            }
            for (var B = [], x = 0; x < 5; x++) B.push(r.createElement("div", {
                className: "shopee-product-recommend-items__item-wrapper"
            }, r.createElement(_.ZP, {
                isPlaceholder: !0,
                layout: _.HS.HOME_PAGE
            })));
            var U = function(e) {
                var t, n;

                function a(t) {
                    var n;
                    return (n = e.call(this, t) || this).state = {
                        isFetching: !1
                    }, n
                }
                n = e, (t = a).prototype = Object.create(n.prototype), t.prototype.constructor = t, R(t, n);
                var o = a.prototype;
                return o.UNSAFE_componentWillMount = function() {
                    var e = this;
                    this.setState({
                        isFetching: !0
                    }), L(regeneratorRuntime.mark((function t() {
                        return regeneratorRuntime.wrap((function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return t.next = 2, e.universalDataFetch();
                                case 2:
                                case "end":
                                    return t.stop()
                            }
                        }), t)
                    })))()
                }, o.universalDataFetch = function() {
                    var e = this.props.shouldPersonalized;
                    return this.fetchFlashSaleContent(e)
                }, o.UNSAFE_componentWillReceiveProps = function(e) {
                    var t = this,
                        n = this.props.shouldPersonalized;
                    e.shouldPersonalized !== n && L(regeneratorRuntime.mark((function n() {
                        return regeneratorRuntime.wrap((function(n) {
                            for (;;) switch (n.prev = n.next) {
                                case 0:
                                    return n.next = 2, t.fetchFlashSaleContent(e.shouldPersonalized);
                                case 2:
                                case "end":
                                    return n.stop()
                            }
                        }), n)
                    })))()
                }, o.fetchFlashSaleContent = function() {
                    var e = L(regeneratorRuntime.mark((function e(t) {
                        var n = this;
                        return regeneratorRuntime.wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return e.next = 2, this.props.fetchFlashSaleItems({
                                        shouldPersonalized: t,
                                        filterSoldout: !0
                                    }, 0, f.zN, (function(e) {
                                        return n.setState({
                                            isFetching: e
                                        })
                                    }), (function() {
                                        return n.setState({
                                            isFetching: !1
                                        })
                                    }));
                                case 2:
                                case "end":
                                    return e.stop()
                            }
                        }), e, this)
                    })));
                    return function(t) {
                        return e.apply(this, arguments)
                    }
                }(), o.render = function() {
                    var e = this.props,
                        t = e.meta,
                        n = e.isShowSeeAll,
                        a = void 0 === n || n,
                        o = e.itemInfo,
                        i = e.trackingClick,
                        c = e.customHeader,
                        u = e.responsiveLayoutInfo,
                        s = o && o.items,
                        l = t ? t.end_time : -1,
                        p = t ? t.start_time : -1,
                        m = t ? t.promotionid : null;
                    return this.state.isFetching || s && !(s.length < 6) ? this.state.isFetching ? r.createElement("div", {
                        className: "shopee-flash-sale-overview-carousel"
                    }) : r.createElement("div", {
                        className: "shopee-flash-sale-overview-carousel"
                    }, r.createElement(S.ZP, {
                        targetType: "FlashSaleOverviewCarousel"
                    }, r.createElement(d.S, {
                        headerText: r.createElement(v.Z, {
                            startTime: p,
                            endTime: l,
                            country: g.LOCALE.toLowerCase()
                        }),
                        simpleVersion: !0,
                        onHeaderButtonClick: i,
                        headerButton: a && m ? {
                            text: k.default.t("label_see_all"),
                            linkTo: (0, y.getFlashSaleLandingPage)({
                                promotionId: m
                            })
                        } : null,
                        customHeader: c
                    }, r.createElement(h.lr, {
                        showArrowOnHover: !0,
                        showArrowHint: !0,
                        numItemsPerRow: u.numItemsPerRow,
                        padding: "0px",
                        items: s && s.length >= 6 && !this.state.isFetching ? s.map((function(e, t) {
                            return r.createElement("div", {
                                className: "shopee-product-recommend-items__item-wrapper",
                                key: "flash-sale-overview-item-" + t
                            }, e ? r.createElement(_.ZP, {
                                item: e,
                                index: t,
                                isOngoing: !0,
                                layout: _.HS.HOME_PAGE,
                                displayBuyNowButton: !1,
                                overwriteCardLink: (0, y.getFlashSaleLandingPage)({
                                    promotionId: m,
                                    fromItem: e.itemid
                                }),
                                displayFlashSaleProgressBar: !0,
                                setShowDiscountBadge: !0
                            }) : r.createElement("div", null))
                        })) : B
                    })))) : null
                }, a
            }(r.Component);
            U.QUERY = {
                filterSoldout: !0
            };
            var F = (0, p.connect)((function(e) {
                    var t = e.featureToggles.toggles[w.Xgy],
                        n = void 0 !== t && t;
                    return {
                        shouldPersonalized: n,
                        meta: (0, m.fg)(e),
                        itemInfo: (0, m.Kj)(e, {
                            filterSoldout: !0,
                            shouldPersonalized: n
                        })
                    }
                }), {
                    fetchFlashSaleItems: m.HU
                })((0, T.withI18nCollections)([O.L, O.GC])((0, P.Z)((0, I.xQ)({
                    mapLayoutTypeToUsedLayoutValue: function(e) {
                        return e === I.V2.Tiny ? {
                            numItemsPerRow: 4
                        } : e === I.V2.Portrait ? {
                            numItemsPerRow: 5
                        } : {
                            numItemsPerRow: 6
                        }
                    }
                })((function(e) {
                    return r.createElement(E.Z.Consumer, null, (function(t) {
                        var n = t.customHeader;
                        return r.createElement(U, N({
                            customHeader: (0, C.Z)(n, [b.u.FLASH_SALE]) || null
                        }, e))
                    }))
                })), "FlashSaleOverviewCarousel"))),
                D = n(11540),
                Z = n(60042),
                H = n.n(Z),
                j = "_2FKNxQ",
                M = "-ZWMTR";

            function V(e) {
                var t = e.className,
                    n = e.isReady,
                    a = e.children;
                return r.createElement("div", {
                    className: H()(t, j, n && M)
                }, a)
            }
            var W, G = n(23046),
                K = n(83367),
                J = n(108),
                z = n(50949),
                Q = n(95963),
                Y = n(73180),
                X = n(23169),
                q = n(29591),
                $ = n(41153),
                ee = n(30085),
                te = n(79093),
                ne = n(29540),
                re = n(73041),
                ae = n(73727),
                oe = n(40605),
                ie = n(60710),
                ce = n(39894),
                ue = n(18272),
                se = n(13384),
                le = "_5XYhbS",
                pe = "WCwWZw",
                me = "uuQ6nw",
                fe = "_3K5s_h",
                de = "_3DLGAG",
                he = "_13sfos",
                ge = "_2bc8OF";
            var ve = (0, P.Z)((function(e) {
                    var t = e.isPlaceholder,
                        n = e.imageUrl,
                        r = e.displayName,
                        o = e.trackingRef,
                        i = e.trackingClick;
                    return a().createElement("div", {
                        className: le,
                        onClick: i,
                        ref: o
                    }, a().createElement("div", {
                        className: pe
                    }, a().createElement(se.p, {
                        src: n,
                        wrapperClassName: fe,
                        placeholderClassName: me,
                        className: fe,
                        imageServerWidthOperator: 320
                    })), a().createElement("div", {
                        className: de
                    }, t ? a().createElement(a().Fragment, null, a().createElement("div", {
                        className: H()("skeleton skeleton-medium", ge)
                    }), a().createElement("div", {
                        className: H()("skeleton skeleton-medium", ge)
                    })) : a().createElement("div", {
                        className: he
                    }, r)))
                }), "CategoryItem"),
                _e = n(32666),
                ye = n(95262),
                Ee = n(87661);

            function be(e, t) {
                return (be = Object.setPrototypeOf || function(e, t) {
                    return e.__proto__ = t, e
                })(e, t)
            }
            for (var Ce = [], we = 0; we < 20; we++) Ce.push(r.createElement("div", {
                className: "home-category-list__category-grid",
                key: we
            }, r.createElement(ve, {
                isPlaceholder: !0
            })));
            var Se = function(e) {
                    var t, n;

                    function a(t) {
                        var n, r;
                        return r = e.call(this, t) || this, t.injectAsyncReducer(((n = {})[Ee.LZ] = Ee.Fk, n)), r
                    }
                    n = e, (t = a).prototype = Object.create(n.prototype), t.prototype.constructor = t, be(t, n);
                    var o = a.prototype;
                    return o.UNSAFE_componentWillMount = function() {
                        this.universalDataFetch()
                    }, o.universalDataFetch = function() {
                        var e = this.props,
                            t = e.useCategoryV4Api,
                            n = e.loadCategoryList,
                            r = e.fetchHomepageCategoryList;
                        return t ? r() : n(oe.t4)
                    }, o.shouldComponentUpdate = function(e) {
                        return (e.categories !== this.props.categories || e.responsiveLayoutInfo.responsiveCategoryItemSize !== this.props.responsiveLayoutInfo.responsiveCategoryItemSize) && e.categories && !!e.categories.length
                    }, o.render = function() {
                        var e = this.props,
                            t = e.categories,
                            n = void 0 === t ? [] : t,
                            a = e.style,
                            o = e.responsiveLayoutInfo,
                            i = (o = void 0 === o ? {} : o).responsiveCategoryItemSize,
                            c = void 0 === i ? 20 : i,
                            u = Ce;
                        n.length > 0 && (u = n.map((function(e, t) {
                            var n = e.catid,
                                a = e.display_name;
                            return r.createElement(ae.Link, {
                                to: ce.rj.getUrl({
                                    categoryId: n,
                                    categoryName: a
                                }),
                                className: "home-category-list__category-grid",
                                key: n
                            }, r.createElement(ve, {
                                imageUrl: (0, ie.Jn)(e.image, !0),
                                displayName: a,
                                catId: n,
                                index: t
                            }))
                        })));
                        var s = [];
                        u.forEach((function(e, t) {
                            t % 2 == 0 ? s.push([e]) : s[(t - 1) / 2].push(e)
                        }));
                        var l = s.map((function(e, t) {
                            return r.createElement("div", {
                                className: "home-category-list__group",
                                key: t
                            }, e[0], 1 === e.length ? r.createElement("div", {
                                className: "home-category-list__category-grid home-category-list__category-grid--empty"
                            }) : e[1])
                        }));
                        return r.createElement("div", {
                            className: "home-category-list"
                        }, r.createElement(E.Z.Consumer, null, (function(e) {
                            var t = e.customHeader;
                            return r.createElement(_e.S, {
                                headerText: (0, T.t)("home_page_label_categories"),
                                simpleVersion: !0,
                                style: a,
                                customHeader: (0, C.Z)(t, [b.u.CATEGORY])
                            }, r.createElement(h.lr, {
                                showArrowOnHover: !0,
                                showArrowHint: !0,
                                numItemsPerRow: u.length > c ? c / 2 : Math.floor(u.length / 2),
                                padding: "0px",
                                items: l
                            }))
                        })))
                    }, a
                }(r.Component),
                Pe = {
                    loadCategoryList: ye.o1,
                    fetchHomepageCategoryList: Ee.tf
                };
            var ke = (0, q.qC)((0, p.connect)((function(e) {
                    var t, n = (0, Y.Au)(e.featureToggles, w._Bh);
                    if (n) {
                        var r = e[Ee.LZ] && (0, Ee.cY)(e[Ee.LZ]);
                        t = r && r.data ? r.data.category_list.map(Ee.HQ) : []
                    } else t = (0, ue.AT)(e.sharedCategory);
                    return {
                        useCategoryV4Api: n,
                        categories: t
                    }
                }), Pe), ee.withInjectReducer, (0, I.xQ)({
                    mapLayoutTypeToUsedLayoutValue: function(e) {
                        return {
                            responsiveCategoryItemSize: e === I.V2.Tiny ? 12 : e === I.V2.Portrait ? 16 : 20
                        }
                    }
                }))(Se),
                Te = n(45141),
                Oe = "XIR7Xg",
                Ie = "UtpFyQ";
            var Ne = function() {
                return r.createElement("div", {
                    className: Oe
                }, r.createElement(Te.Z, {
                    show: !0,
                    hideOverlay: !0,
                    spinnerClassName: Ie
                }))
            };

            function Ae(e, t) {
                return (Ae = Object.setPrototypeOf || function(e, t) {
                    return e.__proto__ = t, e
                })(e, t)
            }
            var Le = function(e) {
                    var t, n;

                    function a(t) {
                        var n;
                        return (n = e.call(this, t) || this).state = {
                            style: {}
                        }, n.updateDimensions = n.updateDimensions.bind(function(e) {
                            if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                            return e
                        }(n)), n
                    }
                    n = e, (t = a).prototype = Object.create(n.prototype), t.prototype.constructor = t, Ae(t, n);
                    var o = a.prototype;
                    return o.componentDidMount = function() {
                        window.addEventListener("resize", this.updateDimensions), this.updateDimensions()
                    }, o.componentWillUnmount = function() {
                        window.removeEventListener("resize", this.updateDimensions)
                    }, o.updateDimensions = function() {
                        var e = {};
                        window.innerWidth > 1464 ? e.left = window.innerWidth / 2 + 600 + 18 : (e.float = "right", e.right = "30px"), this.setState({
                            style: e
                        })
                    }, o.render = function() {
                        return r.createElement("div", {
                            className: "shopee-floating-icons__wrapper",
                            style: this.state.style
                        }, this.props.children)
                    }, a
                }(r.Component),
                Re = n(62198),
                Be = n(48173),
                xe = function(e) {
                    var t = e.skinnyBanners;
                    return t && t.length ? r.createElement("div", {
                        style: {
                            marginTop: 20
                        }
                    }, t.slice(0, Be.Hb).map((function(e, n) {
                        return r.createElement(Re.Z, {
                            key: "skinny-banner-" + n,
                            width: 1200 / Math.min(Be.Hb, t.length) + "px",
                            height: "110px",
                            style: {
                                borderRadius: 2
                            },
                            hidePlaceholderIcon: !0,
                            banner: e,
                            bannerType: Be.Zi.SKINNY_BANNERS,
                            targetType: "SkinnyBanner",
                            location: n
                        })
                    }))) : null
                },
                Ue = n(67205),
                Fe = n(6976),
                De = n(17555);

            function Ze() {
                return (Ze = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(this, arguments)
            }
            var He, je = (0, J.h9)()((function(e) {
                    var t = function(e, t) {
                        var n = (0, De.O)();
                        return (0, r.useCallback)((function(r, a) {
                            switch (r) {
                                case "IMPRESSION":
                                    n({
                                        type: "impression",
                                        timestamp: Date.now(),
                                        info: {
                                            targetType: e + "." + t,
                                            impressions: [{
                                                targetData: Ze({}, a, {
                                                    isFromBMS: !0
                                                })
                                            }]
                                        }
                                    });
                                    break;
                                case "CLICK":
                                    n({
                                        type: "click",
                                        timestamp: Date.now(),
                                        info: {
                                            targetType: e + "." + t,
                                            targetData: Ze({}, a, {
                                                isFromBMS: !0
                                            })
                                        }
                                    })
                            }
                        }), [e, n])
                    }(e.contextTargetType, "WelcomePackageBanner");
                    return a().createElement("div", {
                        style: {
                            marginTop: 20
                        }
                    }, a().createElement(Ue.ZJ, {
                        spaceKey: "PC-" + (0, Fe.Kd)() + "-HOME_NUZ_CAROUSEL_01",
                        onEventCallback: t,
                        baseUrl: window.origin || (0, ie.SV)(),
                        useFallback: !1,
                        max: 1
                    }))
                })),
                Me = n(43058),
                Ve = n(69068),
                We = n(18363),
                Ge = (0, Ve.n)("FETCH_HOME_CAMPAIGN_MODULES"),
                Ke = n(14081);

            function Je() {
                return (Je = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(this, arguments)
            }
            var ze = Je({}, We.e, {
                    campaign_top_visual: null,
                    featured_products: null,
                    featured_shops: null,
                    featured_collections: null,
                    campaign_bottom_visual: null,
                    cached: !1,
                    version: "init"
                }),
                Qe = (0, Ke.Z)(((He = {})[Ge.SUCCESS] = function(e, t) {
                    return Je({}, e, We.e, t.payload.data, {
                        cached: !1,
                        version: t.payload.version,
                        apiProgress: We.Z.OK
                    })
                }, He[Ge.FAILED] = function(e, t) {
                    return Je({}, e, We.e, {
                        cached: !1,
                        apiProgress: We.Z.ERR,
                        error: t.payload
                    })
                }, He.RESTORE_HOME_CAMPAIGN_MODULES_CACHE = function(e, t) {
                    return e.apiProgress !== We.Z.OK ? Je({}, e, t.payload, {
                        cached: !0,
                        apiProgress: e.apiProgress,
                        error: e.error,
                        error_msg: e.error_msg
                    }) : e
                }, He), ze),
                Ye = n(19511),
                Xe = n(72609);

            function qe(e, t, n, r, a, o, i) {
                try {
                    var c = e[o](i),
                        u = c.value
                } catch (e) {
                    return void n(e)
                }
                c.done ? t(u) : Promise.resolve(u).then(r, a)
            }
            var $e = "P1JRX7",
                et = "q6V5oo",
                tt = n(29657),
                nt = n(42363),
                rt = n(49792),
                at = n(28743),
                ot = n(25653);

            function it(e) {
                if (!e) return null;
                var t = e.data && e.data.image_pc,
                    n = e.data && e.data.image_ratio_pc,
                    r = e.data && e.data.redirection_url;
                return t ? {
                    image: t,
                    ratio: n,
                    linkTo: r
                } : null
            }
            var ct = n(92027),
                ut = n(95802),
                st = n(17312),
                lt = "_2dRoLS";

            function pt(e, t) {
                return (pt = Object.setPrototypeOf || function(e, t) {
                    return e.__proto__ = t, e
                })(e, t)
            }
            var mt = function(e) {
                var t, n;

                function r() {
                    for (var t, n = arguments.length, r = new Array(n), a = 0; a < n; a++) r[a] = arguments[a];
                    return (t = e.call.apply(e, [this].concat(r)) || this).handleRef = function(e) {
                        t.imgRef = e
                    }, t
                }
                n = e, (t = r).prototype = Object.create(n.prototype), t.prototype.constructor = t, pt(t, n);
                var o = r.prototype;
                return o.componentDidMount = function() {
                    var e = this.imgRef;
                    if (null != e && this.props.ratio) {
                        var t = e.getBoundingClientRect().width;
                        e.style.height = t / this.props.ratio + "px"
                    }
                }, o.render = function() {
                    var e = this.props,
                        t = e.image,
                        n = e.linkTo;
                    return n ? a().createElement(ut.Z, {
                        to: (0, ct.OE)(n)
                    }, a().createElement(st.Z, {
                        ref: this.handleRef,
                        src: (0, ie.Jn)(t),
                        className: lt,
                        imageServerWidthOperator: 1200
                    })) : a().createElement(st.Z, {
                        ref: this.handleRef,
                        src: (0, ie.Jn)(t),
                        className: lt,
                        imageServerWidthOperator: 1200
                    })
                }, r
            }(a().PureComponent);
            var ft = (0, P.Z)((function(e) {
                    var t = e.trackingClick,
                        n = e.trackingRef;
                    return a().createElement("div", {
                        ref: n,
                        onClick: function() {
                            t && t()
                        }
                    }, a().createElement(mt, e))
                }), "HomeCampaignTopVisual"),
                dt = n(41310),
                ht = "_1pv87h",
                gt = "_2mSgrt",
                vt = "_2pV081";

            function _t(e) {
                var t = e.url,
                    n = e.color,
                    r = e.trackingClick,
                    o = e.trackingRef;
                return a().createElement("a", {
                    href: t,
                    ref: o,
                    style: {
                        color: n
                    },
                    className: vt,
                    onClick: r
                }, (0, T.t)("promo_label_see_more"), a().createElement(dt.Z, null))
            }
            var yt = {
                hot_product: (0, P.Z)(_t, "HotProductSeeMore"),
                hot_collection: (0, P.Z)(_t, "HotCollectionSeeMore"),
                hot_brand: (0, P.Z)(_t, "HotBrandSeeMore")
            };

            function Et(e) {
                var t = e.text,
                    n = e.textColor,
                    r = e.headerSeeMoreTextColor,
                    o = e.seeMoreLink,
                    i = e.backgroundColor,
                    c = e.section,
                    u = yt[c],
                    s = i ? {
                        backgroundColor: i
                    } : {};
                return a().createElement("div", {
                    className: ht,
                    style: s
                }, a().createElement("span", {
                    style: {
                        color: n
                    },
                    className: gt
                }, t), o && a().createElement(u, {
                    url: o,
                    color: r
                }))
            }
            var bt = "o7ehE-",
                Ct = "Flsiyn",
                wt = "SutD9V",
                St = "_1NUoEB",
                Pt = "_1efKXr",
                kt = "_1q_SrC",
                Tt = "vrtrZV",
                Ot = "_2iNVI-",
                It = n(51816),
                Nt = (0, Fe.of)(),
                At = function(e) {
                    e.target.onerror = null
                };
            var Lt = "kQ0_Jy",
                Rt = "_3Vw4cV",
                Bt = "_2jKTmZ",
                xt = (0, P.Z)((function(e) {
                    var t = e.item,
                        n = e.textColor,
                        r = e.trackingClick,
                        o = e.trackingRef,
                        i = e.hideTag,
                        c = t.image,
                        u = t.text,
                        s = t.linkTo,
                        l = t.textTitle;
                    return a().createElement(ae.Link, {
                        to: s,
                        className: bt,
                        onClick: r,
                        innerRef: o
                    }, a().createElement(se.p, {
                        imageServerWidthOperator: 320,
                        className: Ct,
                        src: c
                    }), t.hasOwnProperty("logo") && a().createElement("div", {
                        className: wt
                    }, a().createElement("img", {
                        className: St,
                        onError: At,
                        src: t.logo
                    })), l && a().createElement("div", {
                        className: H()(Tt)
                    }, l), a().createElement("div", {
                        className: H()(Pt)
                    }, a().createElement("div", {
                        style: {
                            color: n
                        },
                        className: H()(kt)
                    }, u)), !i && t.discount ? a().createElement("div", {
                        className: Ot
                    }, a().createElement(It.OO, {
                        rawDiscount: t.discount,
                        language: Nt,
                        offText: (0, T.t)("pr_badge_label_off")
                    })) : null)
                }), "CampaignHotCollection");

            function Ut(e) {
                var t = e.headerText,
                    n = e.headerTextColor,
                    r = e.textColor,
                    o = e.seeMoreLink,
                    i = e.items,
                    c = e.sectionBackgroundColor,
                    u = e.headerSeeMoreTextColor,
                    s = e.single,
                    l = e.hideTag;
                return a().createElement("div", {
                    className: s ? Rt : Lt
                }, a().createElement(Et, {
                    text: t,
                    textColor: n,
                    seeMoreLink: o,
                    backgroundColor: c,
                    headerSeeMoreTextColor: u,
                    section: "hot_collection"
                }), a().createElement("div", {
                    className: Bt,
                    style: {
                        backgroundColor: c
                    }
                }, i.slice(0, s ? 6 : 3).map((function(e, t) {
                    return a().createElement(xt, {
                        hideTag: l,
                        key: t,
                        item: e,
                        textColor: r,
                        location: t
                    })
                }))))
            }

            function Ft(e) {
                return a().createElement(mt, e)
            }
            var Dt = n(14490);

            function Zt() {
                return (Zt = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(this, arguments)
            }

            function Ht(e, t) {
                return (Ht = Object.setPrototypeOf || function(e, t) {
                    return e.__proto__ = t, e
                })(e, t)
            }
            var jt = function(e) {
                var t, n;

                function a(t) {
                    var n;
                    return (n = e.call(this, t) || this).props.injectAsyncReducer({
                        homeCampaign: Qe
                    }), n
                }
                n = e, (t = a).prototype = Object.create(n.prototype), t.prototype.constructor = t, Ht(t, n);
                var o = a.prototype;
                return o.componentDidMount = function() {
                    this.universalDataFetch()
                }, o.universalDataFetch = function() {
                    return this.props.fetchHomeCampaignModules()
                }, o.render = function() {
                    var e = this.props,
                        t = e.isHomeCampaignVisible,
                        n = e.isFeaturedProductsVisible,
                        a = e.isFeaturedCollectionsVisible,
                        o = e.isFeaturedShopsVisible,
                        i = e.topVisual,
                        c = e.featuredProducts,
                        u = e.featuredCollections,
                        s = e.featuredShops,
                        l = e.bottomVisual,
                        p = e.hideTag;
                    if (!t) return null;
                    var m = [];
                    return n && m.push({
                        component: Ut,
                        data: c
                    }), o && m.push({
                        data: s
                    }), a && m.length < 2 && m.push({
                        data: u
                    }), 1 === m.length && (0, C.Z)(m, [0, "data", "items", "length"], 0) < 6 ? null : r.createElement("div", {
                        className: et
                    }, i && i.image && r.createElement(ft, {
                        image: i ? i.image : "",
                        ratio: i ? i.ratio : 1,
                        linkTo: i ? i.linkTo : ""
                    }), r.createElement(Dt.Z, {
                        src: (0, ie.Jn)(this.props.backgroundImage),
                        className: $e
                    }, m.map((function(e, t) {
                        var n = e.data;
                        return r.createElement(Ut, Zt({}, n, {
                            key: t,
                            hideTag: p,
                            single: 1 === m.length
                        }))
                    }))), l && l.image && r.createElement(Ft, {
                        image: l ? l.image : "",
                        ratio: l ? l.ratio : 1
                    }))
                }, a
            }(r.Component);
            var Mt = (0, Me.qC)(ee.withInjectReducer, (0, p.connect)((function(e) {
                    var t = it(function(e) {
                            return e && e.campaign_top_visual
                        }(e.homeCampaign)),
                        n = function(e) {
                            return e && e.campaign_images && e.campaign_images.data
                        }(e.homeCampaign),
                        r = function(e, t) {
                            if (!e) return null;
                            if (e.items.length < 3) return null;
                            var n = e.banner_image || t && t.one_row_image;
                            return {
                                items: e.items.slice(0, 6).map((function(e) {
                                    return {
                                        image: (0, ie.Jn)(e.transparent_background_image ? e.transparent_background_image : e.image, !0),
                                        text: e.hidden_price_display || (0, tt.JL)(e.price),
                                        linkTo: at.O.getUrl({
                                            shopId: e.shopid,
                                            itemId: e.itemid,
                                            seoName: e.name
                                        }),
                                        item: e,
                                        discount: e.raw_discount
                                    }
                                })),
                                backgroundImage: (0, ie.Jn)(n || ""),
                                headerText: e.header_text,
                                headerTextColor: e.header_text_color,
                                textColor: e.price_text_color,
                                headerSeeMoreTextColor: e.header_text_color,
                                seeMoreLink: e.see_more_link,
                                sectionBackgroundColor: e.section_background_color
                            }
                        }(function(e) {
                            return e && e.featured_products
                        }(e.homeCampaign), n),
                        a = (0, C.Z)(e.homeCampaign, ["campaign_images", "data", "image_pc"]),
                        o = function(e, t) {
                            if (!e) return null;
                            if (e.collections.length < 3) return null;
                            var n = e.banner_image || t && t.one_row_image;
                            return {
                                items: e.collections.slice(0, 6).map((function(e) {
                                    return {
                                        image: (0, ie.Jn)(e.collection_asset_image),
                                        text: e.collection_asset_text || e.collection_name || "",
                                        linkTo: ot.Hh.getUrl({
                                            collection: e.collection_name,
                                            collectionId: e.collection_id
                                        }),
                                        item: e
                                    }
                                })),
                                backgroundImage: (0, ie.Jn)(n || ""),
                                headerText: e.header_text,
                                headerTextColor: e.header_text_color,
                                headerSeeMoreTextColor: e.header_text_color,
                                textColor: e.collection_title_text_color,
                                seeMoreLink: e.see_more_link,
                                sectionBackgroundColor: e.section_background_color
                            }
                        }(function(e) {
                            return e && e.featured_collections
                        }(e.homeCampaign), n),
                        i = function(e, t) {
                            if (!e) return null;
                            if (e.shops.length < 3) return null;
                            var n = e.banner_image || t && t.one_row_image;
                            return {
                                items: e.shops.slice(0, 6).map((function(t) {
                                    var n = t.first_voucher,
                                        r = t.shop_asset_text || (n ? (0, T.t)("get_discount_percentage_off", {
                                            discount: n.discount_percent ? (0, nt.gC)(__LOCALE__, n.discount_percent) + ("TW" === __LOCALE__ ? "折" : "%") : (0, tt.rH)(n.discount_value)
                                        }) : e.default_shop_text) || e.default_shop_text || "";
                                    return {
                                        logo: (0, ie.Jn)(t.shop_account_portrait, !0),
                                        image: (0, ie.Jn)(t.shop_asset_image),
                                        text: r,
                                        linkTo: rt.Ri.getUrl({
                                            shopId: t.shopid
                                        }),
                                        item: t
                                    }
                                })),
                                backgroundImage: (0, ie.Jn)(n || ""),
                                headerText: e.header_text,
                                headerTextColor: e.header_text_color,
                                headerSeeMoreTextColor: e.header_text_color,
                                textColor: e.promo_text_color,
                                seeMoreLink: e.see_more_link,
                                sectionBackgroundColor: e.section_background_color
                            }
                        }(function(e) {
                            return e && e.featured_shops
                        }(e.homeCampaign), n),
                        c = !!r,
                        u = !!o,
                        s = !!i;
                    return {
                        topVisual: t,
                        featuredProducts: r,
                        featuredCollections: o,
                        featuredShops: i,
                        bottomVisual: it(function(e) {
                            return e && e.campaign_bottom_visual
                        }(e.homeCampaign)),
                        isHomeCampaignVisible: c || u || s,
                        isFeaturedProductsVisible: c,
                        isFeaturedCollectionsVisible: u,
                        isFeaturedShopsVisible: s,
                        backgroundImage: a
                    }
                }), {
                    fetchHomeCampaignModules: function() {
                        return function() {
                            var e, t = (e = regeneratorRuntime.mark((function e(t, n) {
                                return regeneratorRuntime.wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return e.next = 2, (0, Ye.Z)({
                                                apiCall: function() {
                                                    return (0, Xe.fetchInfo)("/api/v4/homepage/campaign_modules")
                                                },
                                                actions: [{
                                                    type: Ge.REQUESTED
                                                }, {
                                                    type: Ge.SUCCESS,
                                                    payload: function(e, t, n) {
                                                        return n
                                                    }
                                                }, {
                                                    type: Ge.FAILED,
                                                    payload: function(e, t, n) {
                                                        return n.error
                                                    }
                                                }]
                                            }, t, n);
                                        case 2:
                                            return e.abrupt("return", e.sent);
                                        case 3:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e)
                            })), function() {
                                var t = this,
                                    n = arguments;
                                return new Promise((function(r, a) {
                                    var o = e.apply(t, n);

                                    function i(e) {
                                        qe(o, r, a, i, c, "next", e)
                                    }

                                    function c(e) {
                                        qe(o, r, a, i, c, "throw", e)
                                    }
                                    i(void 0)
                                }))
                            });
                            return function(e, n) {
                                return t.apply(this, arguments)
                            }
                        }()
                    }
                }))(jt),
                Vt = n(21065),
                Wt = n(40011),
                Gt = (0, P.Z)((function(e) {
                    var t = e.welcomeDisplayBanner,
                        n = e.clickWPBanner,
                        a = e.trackingRef,
                        o = e.trackingClick;
                    return r.createElement(Dt.Z, {
                        className: "welcome-package-banner",
                        ref: a,
                        onClick: function() {
                            o(), n()
                        },
                        src: (0, Wt.R)(t.banner_image, 3),
                        imageServerWidthOperator: 1800
                    })
                }), "WelcomePackageBanner");
            var Kt = function(e) {
                    var t = e.img,
                        n = e.link;
                    return r.createElement("div", {
                        className: "welcomePopup"
                    }, r.createElement(ae.Link, {
                        to: n
                    }, r.createElement("img", {
                        src: (0, Wt.R)(t, 2),
                        alt: "welcome_img_banner"
                    })))
                },
                Jt = n(13751),
                zt = n(56431);
            var Qt = n(99959),
                Yt = n(59318);

            function Xt(e) {
                var t = e.locale;
                return a().createElement(o.Helmet, null, a().createElement("link", {
                    rel: "alternate",
                    href: Qt.mg[t]
                }), a().createElement("link", {
                    rel: "alternate",
                    href: Qt.xs[t]
                }), a().createElement("meta", {
                    property: "al:ios:url",
                    content: Qt.JZ[t]
                }), a().createElement("meta", {
                    property: "al:ios:app_store_id",
                    content: Qt.cJ[t]
                }), a().createElement("meta", {
                    property: "al:ios:app_name",
                    content: Qt.iC[t]
                }), a().createElement("meta", {
                    property: "al:android:package",
                    content: Qt.Zv[t]
                }), a().createElement("meta", {
                    property: "al:android:url",
                    content: Qt.JZ[t]
                }), a().createElement("meta", {
                    property: "al:android:app_name",
                    content: Qt.iC[t]
                }), a().createElement("meta", {
                    property: "al:web:url",
                    content: Qt.Rx + "://" + Yt.R2[t]
                }))
            }
            var qt, $t = n(3858),
                en = n(3727),
                tn = n(27222),
                nn = n(64653),
                rn = n(63951),
                an = n(9982),
                on = n(61309),
                cn = n(93519),
                un = n(10291);
            ! function(e) {
                e[e.ImageLoadTargetCountReached = 0] = "ImageLoadTargetCountReached", e[e.WaitAfterDomCompleted = 1] = "WaitAfterDomCompleted", e[e.BeforeUnload = 2] = "BeforeUnload", e[e.HistoryChange = 3] = "HistoryChange"
            }(qt || (qt = {}));
            var sn = function(e) {
                    var t = e.maxImageCount,
                        n = e.history;
                    return un.Z.changeTargetCount(t), new Promise((function(e) {
                        un.Z.whenExceedTargetCount().then((function() {
                            return e(qt.ImageLoadTargetCountReached)
                        })), ("complete" === document.readyState ? Promise.resolve() : new Promise((function(e) {
                            document.addEventListener("readystatechange", (function() {
                                "complete" === document.readyState && e()
                            }))
                        }))).then((function() {
                            return e = 1e4, new Promise((function(t) {
                                return setTimeout((function() {
                                    return t()
                                }), e)
                            }));
                            var e
                        })).then((function() {
                            return e(qt.WaitAfterDomCompleted)
                        })), window.addEventListener("beforeunload", (function() {
                            return e(qt.BeforeUnload)
                        })), n.listen((function() {
                            e(qt.HistoryChange)
                        }))
                    }))
                },
                ln = n(27213);

            function pn(e, t) {
                var n;
                if ("undefined" == typeof Symbol || null == e[Symbol.iterator]) {
                    if (Array.isArray(e) || (n = function(e, t) {
                            if (!e) return;
                            if ("string" == typeof e) return mn(e, t);
                            var n = Object.prototype.toString.call(e).slice(8, -1);
                            "Object" === n && e.constructor && (n = e.constructor.name);
                            if ("Map" === n || "Set" === n) return Array.from(e);
                            if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return mn(e, t)
                        }(e)) || t && e && "number" == typeof e.length) {
                        n && (e = n);
                        var r = 0;
                        return function() {
                            return r >= e.length ? {
                                done: !0
                            } : {
                                done: !1,
                                value: e[r++]
                            }
                        }
                    }
                    throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }
                return (n = e[Symbol.iterator]()).next.bind(n)
            }

            function mn(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                return r
            }
            var fn = ["domainLookupStart", "domainLookupEnd", "connectStart", "connectEnd", "requestStart", "responseStart", "responseEnd", "domInteractive", "domContentLoadedEventStart", "domContentLoadedEventEnd", "domComplete"],
                dn = function() {
                    var e = {},
                        t = void 0;
                    if (performance && "function" == typeof performance.getEntriesByType) {
                        var n = performance.getEntriesByType("navigation");
                        Array.isArray(n) && n[0] && (e = n[0], t = 0)
                    } else {
                        if (!performance || !performance.timing) return;
                        e = performance.timing, t = performance.timing.navigationStart
                    }
                    if (void 0 !== t) {
                        for (var r, a = {}, o = pn(fn); !(r = o()).done;) {
                            var i = r.value,
                                c = (0, ln.N)(e[i] - t);
                            !c || isNaN(c) || c < 0 || (a[i] = c)
                        }
                        return a
                    }
                },
                hn = function() {
                    return (e = window.PerformanceObserver) && e.supportedEntryTypes && e.supportedEntryTypes.includes("largest-contentful-paint") ? new Promise((function(e) {
                        new PerformanceObserver((function(t) {
                            var n = t.getEntries();
                            if (0 !== n.length) {
                                for (var r = n.length - 1; r >= 0; r--) {
                                    var a = n[r];
                                    if ((!a.element || "home-page" !== a.element.className) && a.url) {
                                        var o = n[n.length - 1],
                                            i = o.startTime,
                                            c = o.element;
                                        return e({
                                            startTime: i,
                                            className: (null == c ? void 0 : c.className) || ""
                                        })
                                    }
                                }
                                e()
                            }
                        })).observe({
                            type: "largest-contentful-paint",
                            buffered: !0
                        })
                    })) : Promise.resolve();
                    var e
                };

            function gn() {
                return (gn = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(this, arguments)
            }

            function vn(e, t) {
                var n;
                if ("undefined" == typeof Symbol || null == e[Symbol.iterator]) {
                    if (Array.isArray(e) || (n = function(e, t) {
                            if (!e) return;
                            if ("string" == typeof e) return _n(e, t);
                            var n = Object.prototype.toString.call(e).slice(8, -1);
                            "Object" === n && e.constructor && (n = e.constructor.name);
                            if ("Map" === n || "Set" === n) return Array.from(e);
                            if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _n(e, t)
                        }(e)) || t && e && "number" == typeof e.length) {
                        n && (e = n);
                        var r = 0;
                        return function() {
                            return r >= e.length ? {
                                done: !0
                            } : {
                                done: !1,
                                value: e[r++]
                            }
                        }
                    }
                    throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }
                return (n = e[Symbol.iterator]()).next.bind(n)
            }

            function _n(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                return r
            }
            var yn, En = function(e) {
                    var t = e.maxImageCount,
                        n = e.imagesLoadedInPreviousPage;
                    if (performance && performance.getEntriesByType && performance.getEntriesByType("resource")) {
                        var r = performance.getEntriesByType("resource");
                        if (0 !== r.length) {
                            var a = r.filter((function(e) {
                                return !n.has(e.name) && (("img" === e.initiatorType || "css" === e.initiatorType) && !e.name.endsWith(".woff") && e.name.startsWith("https://cf.shopee"))
                            })).sort((function(e, t) {
                                return e.startTime - t.startTime
                            })).slice(0, t || Number.MAX_VALUE);
                            if (0 !== a.length) {
                                for (var o, i = 0, c = 0, u = 0, s = vn(a); !(o = s()).done;) {
                                    var l = o.value;
                                    0 !== l.transferSize && (i += l.transferSize, c = l.duration), u += l.decodedBodySize
                                }
                                var p = 0 !== c ? (0, ln.N)(i / c) : void 0;
                                return gn({
                                    totalImageBytes: u,
                                    transferBytes: i
                                }, p && {
                                    imageLoadSpeed: p
                                })
                            }
                        }
                    }
                },
                bn = n(77090);
            (0, n(45473).Tb)((function(e) {
                yn = e.value
            }));
            var Cn = function() {
                return yn
            };

            function wn() {
                return (wn = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(this, arguments)
            }

            function Sn(e, t, n, r, a, o, i) {
                try {
                    var c = e[o](i),
                        u = c.value
                } catch (e) {
                    return void n(e)
                }
                c.done ? t(u) : Promise.resolve(u).then(r, a)
            }

            function Pn(e) {
                return function() {
                    var t = this,
                        n = arguments;
                    return new Promise((function(r, a) {
                        var o = e.apply(t, n);

                        function i(e) {
                            Sn(o, r, a, i, c, "next", e)
                        }

                        function c(e) {
                            Sn(o, r, a, i, c, "throw", e)
                        }
                        i(void 0)
                    }))
                }
            }
            var kn = function() {
                    if (!window.performance || !window.performance.getEntriesByType || !window.performance.getEntriesByType("resource")) return new Set;
                    var e = performance.getEntriesByType("resource");
                    return new Set(e.filter((function(e) {
                        return ("img" === e.initiatorType || "css" === e.initiatorType) && !e.name.endsWith(".woff") && e.name.startsWith("https://cf.shopee")
                    })).map((function(e) {
                        return e.name
                    })))
                },
                Tn = function() {
                    var e = Pn(regeneratorRuntime.mark((function e(t) {
                        var n, r, a, o, i, c, u;
                        return regeneratorRuntime.wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    if (n = t.enableImageServer, r = t.maxImageCount, a = t.history, n || !(Math.random() > .05)) {
                                        e.next = 3;
                                        break
                                    }
                                    return e.abrupt("return");
                                case 3:
                                    return e.next = 5, new Promise((function(e) {
                                        var t = new Image;
                                        t.src = "data:image/webp;base64,UklGRjoAAABXRUJQVlA4IC4AAACyAgCdASoCAAIALmk0mk0iIiIiIgBoSygABc6WWgAA/veff/0PP8bA//LwYAAA", t.onload = t.onerror = function() {
                                            e(2 === t.height)
                                        }
                                    }));
                                case 5:
                                    if (o = e.sent, !n || o) {
                                        e.next = 8;
                                        break
                                    }
                                    return e.abrupt("return");
                                case 8:
                                    return i = kn(), c = Date.now(), u = new cn.PerformanceTrace("ImageServer"), e.abrupt("return", sn({
                                        maxImageCount: r || Number.MAX_VALUE,
                                        history: a
                                    }).then(function() {
                                        var e = Pn(regeneratorRuntime.mark((function e(t) {
                                            var a, o, s, l, p, m, f;
                                            return regeneratorRuntime.wrap((function(e) {
                                                for (;;) switch (e.prev = e.next) {
                                                    case 0:
                                                        return a = {
                                                            attributes: {
                                                                enableImageServer: n.toString(),
                                                                reportScenario: t.toString()
                                                            },
                                                            metrics: {}
                                                        }, (o = dn()) && (a.metrics = wn({}, a.metrics, o)), e.next = 5, hn();
                                                    case 5:
                                                        (s = e.sent) && (a.metrics.lcpStartTime = s.startTime, a.attributes.lcpClassname = s.className), (l = En({
                                                            maxImageCount: r,
                                                            imagesLoadedInPreviousPage: i
                                                        })) && (a.metrics = wn({}, a.metrics, l)), (p = bn.c.getResult()) && (a.metrics = wn({}, a.metrics, p), bn.c.clear()), (m = bn.I.getResult()) && (a.metrics = wn({}, a.metrics, {
                                                            nonWebpErrorCount: m.errorCount,
                                                            nonWebpSuccessRate: m.successRate
                                                        }), bn.I.clear()), (f = Cn()) && (a.metrics.webVitalLCP = f), u.record(c, Date.now() - c, a);
                                                    case 16:
                                                    case "end":
                                                        return e.stop()
                                                }
                                            }), e)
                                        })));
                                        return function(t) {
                                            return e.apply(this, arguments)
                                        }
                                    }()));
                                case 12:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })));
                    return function(t) {
                        return e.apply(this, arguments)
                    }
                }(),
                On = n(11812),
                In = n(98345),
                Nn = n(15874);

            function An(e, t, n, r, a, o, i) {
                try {
                    var c = e[o](i),
                        u = c.value
                } catch (e) {
                    return void n(e)
                }
                c.done ? t(u) : Promise.resolve(u).then(r, a)
            }

            function Ln(e) {
                return function() {
                    var t = this,
                        n = arguments;
                    return new Promise((function(r, a) {
                        var o = e.apply(t, n);

                        function i(e) {
                            An(o, r, a, i, c, "next", e)
                        }

                        function c(e) {
                            An(o, r, a, i, c, "throw", e)
                        }
                        i(void 0)
                    }))
                }
            }
            var Rn = (0, Fe.Kd)(),
                Bn = (0, ie.SV)();

            function xn(e) {
                var t, n, r, a;
                return ((null == e || null === (t = e.response) || void 0 === t || null === (n = t.data) || void 0 === n || null === (r = n.space_banners) || void 0 === r || null === (a = r[0]) || void 0 === a ? void 0 : a.banners) || []).map((function(e) {
                    return {
                        banner_image: e.image_url,
                        id: e.banner_metadata.banner_id,
                        navigate_params: {
                            url: e.target_url
                        },
                        metadata: e.banner_metadata,
                        originBMSBanner: e
                    }
                }))
            }
            var Un = function() {
                var e = (0, r.useState)([]),
                    t = e[0],
                    n = e[1];
                return (0, In.u)(Ln(regeneratorRuntime.mark((function e() {
                    var t, r;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return e.next = 2, (0, Nn.fetchBannerDataApi)([{
                                    space_key: "PC-" + Rn + "-HOME_CAROUSEL_01"
                                }], window.origin || Bn);
                            case 2:
                                t = e.sent, r = xn(t), n(r);
                            case 5:
                            case "end":
                                return e.stop()
                        }
                    }), e)
                }))), []), a().createElement(h.mE, {
                    banners: t
                })
            };

            function Fn() {
                return (Fn = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(this, arguments)
            }

            function Dn(e, t) {
                return (Dn = Object.setPrototypeOf || function(e, t) {
                    return e.__proto__ = t, e
                })(e, t)
            }
            var Zn, Hn = T.config.BASE_API_URL,
                jn = T.config.SHOPEE_BASE_URL,
                Mn = T.config.LOCALE,
                Vn = T.config.ENV,
                Wn = T.config.ROOT_DOMAIN,
                Gn = function(e) {
                    window.open("//" + Wn + "/docs/" + e)
                },
                Kn = 16,
                Jn = (Zn = function(e) {
                    return e ? e.txt_shopee_intro_full + " " + e.txt_shopee_key_features : ""
                }, a().memo((function(e) {
                    var t = e.env,
                        r = e.locale,
                        i = e.customOpenGraphDescription,
                        c = a().lazy((function() {
                            return n(77425)("./seo_meta_description-" + r + "-" + t + ".json").then((function(e) {
                                var t = Zn(e);
                                return {
                                    default: function() {
                                        return a().createElement(o.Helmet, null, a().createElement("meta", {
                                            name: "description",
                                            content: t
                                        }), a().createElement("meta", {
                                            property: "og:description",
                                            content: i || t
                                        }))
                                    }
                                }
                            }))
                        }));
                    return a().createElement(a().Suspense, {
                        fallback: null
                    }, a().createElement(c, null))
                }))),
                zn = Hn,
                Qn = Qt.sY ? tn.S : jn + tn.S,
                Yn = 1577638800,
                Xn = (0, Jt.Z)({
                    loader: function() {
                        return Promise.all([n.e(9291), n.e(442)]).then(n.bind(n, 68440))
                    }
                }),
                qn = (0, Jt.Z)({
                    loader: function() {
                        return n.e(2943).then(n.bind(n, 50811))
                    }
                }),
                $n = (0, Jt.Z)({
                    loader: function() {
                        return n.e(4193).then(n.bind(n, 88317))
                    }
                }),
                er = (0, Jt.Z)({
                    loader: function() {
                        return n.e(6927).then(n.bind(n, 60727))
                    }
                }),
                tr = r.lazy((function() {
                    return n.e(5637).then(n.bind(n, 90675))
                })),
                nr = function(e) {
                    var t, n;

                    function a(t) {
                        var n;
                        return (n = e.call(this, t) || this).welcomePopupShown = (0, rn.ej)("welcomePkgShown"), n.popupBannerShown = !1, n.shouldShowPopup = !0, n.state = {
                            showDailyDiscover: !1
                        }, Tn({
                            enableImageServer: t.isImageServerEnabledForUser,
                            maxImageCount: 80,
                            history: t.history
                        }), n
                    }
                    n = e, (t = a).prototype = Object.create(n.prototype), t.prototype.constructor = t, Dn(t, n);
                    var i = a.prototype;
                    return i.UNSAFE_componentWillMount = function() {
                        this.universalDataFetch(), (0, an.ap)()
                    }, i.universalDataFetch = function() {
                        var e = this.props,
                            t = e.isHomeBannerBMSEnabledForUser,
                            n = e.isHomeMallBannerBMSEnabledForUser,
                            r = e.loadHomePage,
                            a = [];
                        return t && a.push("activity"), n && a.push("homepage_mall_banner"), r({
                            bmsBanners: a
                        })
                    }, i.componentDidUpdate = function() {
                        this.showHomePagePopup(this.props)
                    }, i.showHomePagePopup = function(e) {
                        var t = this;
                        if (this.shouldShowPopup) {
                            var n = e.accountStatus === s.d.LOGGED_IN;
                            if (n) {
                                var a = e.accountInfo.ctime || -1,
                                    o = e.accountInfo.tosAcceptedTime || -1;
                                if ("PH" === Mn && a < Yn && o < Yn) return this.context.showPopup(r.createElement(Vt.hE, {
                                    title: (0, T.t)("label_shopee_privacy_policy_title"),
                                    primaryBtnText: (0, T.t)("label_privacy_policy"),
                                    complementBtnText: (0, T.t)("label_accept_button"),
                                    preventDismissPrimaryBtn: !0,
                                    onPrimaryBtnClick: function() {
                                        Gn(3591)
                                    },
                                    onComplementBtnClick: this.props.userAcceptPrivacyPolicy,
                                    message: (0, T.t)("label_shopee_privacy_policy_popup_content__PH")
                                })), void(this.shouldShowPopup = !1)
                            }
                            if (n && !this.popupBannerShown && T.TOGGLES.KYC_CONSENT && !(e.accountInfo.webOption & Kn)) return this.showKYCPopup(), void(this.shouldShowPopup = !1);
                            if (T.TOGGLES.WELCOME_PACKAGE_POPUP_FIRST) {
                                var i = e.welcomeDisplayPopup;
                                if (e.accountInfo.isNewUser && i && !this.welcomePopupShown) return this.welcomePopupLogic(i), this.setBannersShown(), void(this.shouldShowPopup = !1)
                            }
                            if (!this.popupBannerShown && e.homePopupBanner && "true" !== (0, rn.ej)("CY_HIDE_POPUP")) {
                                var c = (0, an.lK)(e.homePopupBanner),
                                    u = c && c[0] && (0, h.fq)(c[0]);
                                u && (this.setBannersShown(c), this.context.showPopup(r.createElement(re.D.Provider, {
                                    value: {
                                        enable: e.isImageServerEnabledForUser
                                    }
                                }, r.createElement(h.aR, {
                                    image: u.image,
                                    imageGif: u.image_gif,
                                    link: u.link,
                                    linkType: u.type,
                                    location: 0,
                                    id: u.id,
                                    targetType: "PopupBanner"
                                })), !0, (function() {
                                    return t.trackClose(c[0])
                                })))
                            }
                        }
                    }, i.showKYCPopup = function() {
                        this.context.showPopup(r.createElement(Vt.hE, {
                            primaryBtnText: (0, T.t)("home_page_kyc_popup_primary_button"),
                            complementBtnText: (0, T.t)("home_page_kyc_popup_secondary_button"),
                            preventDismissPrimaryBtn: !0,
                            onPrimaryBtnClick: function() {
                                Gn(4505)
                            },
                            onComplementBtnClick: this.props.setKYCConsent,
                            message: (0, T.t)("msg_kyc_popup")
                        })), this.popupBannerShown = !0
                    }, i.welcomePopupLogic = function(e) {
                        this.context.showPopup(r.createElement(Kt, {
                            img: e.banner_image,
                            link: e.navigate_params.url
                        }), !0)
                    }, i.setBannersShown = function(e) {
                        void 0 === e && (e = []), this.popupBannerShown = !0, this.welcomePopupShown = "true", (0, rn.pC)("welcomePkgShown", "true"), (0, an.MJ)(e)
                    }, i.trackClose = function(e) {
                        (0, K.Z)({
                            action: "home_click_close_popup_banner",
                            data: {
                                bannerUrl: e.navigate_params.seo_url || e.navigate_params.url,
                                location: 0,
                                bannerId: e.id
                            },
                            track: this.props.contextOnTrack
                        })
                    }, i.render = function() {
                        var e = this,
                            t = this.props,
                            n = t.floatingIcons,
                            a = t.skinnyBanners,
                            i = t.homeBanners,
                            c = t.enableGroupBuy,
                            u = t.homeCircles,
                            s = t.welcomeDisplayBanner,
                            l = t.accountInfo,
                            p = t.isWelcomePackageEnabledForUser,
                            m = t.isSquareBanner,
                            f = t.isCampaignDiscountTagForUser,
                            d = t.isImageServerEnabledForUser,
                            g = t.isHomeBannerBMSEnabledForUser,
                            v = t.isNUZBannerBMSEnabledForUser,
                            _ = u.filter((function(e) {
                                return e && e.display && e.display.pc
                            })).slice(0, 10),
                            y = 0 === n.length && (!a || 0 === a.length) && 0 === i.length && 0 === u.length,
                            b = n && n.length ? n[0] : null,
                            C = document.body && document.body.clientWidth || document.documentElement && document.documentElement.clientWidth || window.innerWidth;
                        C = C > 1200 ? C : 1200;
                        var w = !(_ && _.length && _.length > 3),
                            S = ["BR", "MX", "CO", "CL", "PL", "ES"].includes(__LOCALE__),
                            P = r.createElement("div", {
                                key: "category-list",
                                className: "section-category-list"
                            }, r.createElement(ke, null)),
                            k = r.createElement(F, {
                                key: "flash-sale-overview"
                            }),
                            T = r.createElement(V, {
                                key: "group-buy",
                                isReady: c
                            }, c && r.createElement(zt.Z, {
                                slotName: "pcmall-groupbuy",
                                spexNamespace: "app.web_fe.pc.groupbuy",
                                slotProps: {
                                    componentType: "HomeGroupBuySection"
                                }
                            })),
                            O = r.createElement(xe, {
                                key: "skinny-banners",
                                skinnyBanners: a
                            }),
                            I = (0, On.jv)() ? r.createElement(Xn, {
                                key: "official-shop"
                            }) : null,
                            N = r.createElement("div", {
                                className: "section-trending-search-list",
                                key: "trending-search"
                            }, r.createElement(qn, null)),
                            A = r.createElement($n, {
                                key: "home-top-product"
                            }),
                            L = "PL" === __LOCALE__ ? [k, T, O, A, P, I, N] : S ? [k, T, O, P, I, N, A] : [P, k, T, O, I, N, A];
                        return r.createElement(E.Z.Consumer, null, (function(t) {
                            var n = t.HomeBanner,
                                a = t.customHeader;
                            return r.createElement(re.D.Provider, {
                                value: {
                                    enable: d
                                }
                            }, r.createElement("div", {
                                className: "home-page",
                                style: n
                            }, r.createElement(o.Helmet, null, r.createElement("meta", {
                                name: "robots",
                                content: "live" === __ENV__ ? "all" : "noindex"
                            }), r.createElement("link", {
                                rel: "canonical",
                                href: zn
                            }), r.createElement("meta", {
                                property: "og:type",
                                content: "website"
                            }), r.createElement("meta", {
                                property: "og:url",
                                content: zn
                            }), r.createElement("meta", {
                                property: "og:image",
                                content: Qn
                            }), r.createElement("meta", {
                                name: "msvalidate.01",
                                content: Qt.wR
                            }), r.createElement("meta", {
                                name: "ahrefs-site-verification",
                                content: Qt.Z5
                            }), r.createElement("meta", {
                                property: "fb:pages",
                                content: Qt.Bi[__LOCALE__]
                            })), r.createElement(Jn, {
                                locale: Mn,
                                env: Vn
                            }), r.createElement($t.Z, {
                                getPageRegionalRoute: function() {
                                    return ""
                                }
                            }), r.createElement(Xt, {
                                locale: __LOCALE__
                            }), r.createElement(Le, {
                                containsFloatingIcon: !0,
                                containsSkinnyBanner: !1
                            }, !!b && r.createElement(Re.Z, {
                                bannerType: Be.Zi.FLOATING_ICONS,
                                banner: b,
                                width: "82px",
                                height: "82px",
                                location: 0,
                                targetType: "FloatingBanner"
                            })), r.createElement("div", {
                                role: "main",
                                className: "container"
                            }, r.createElement("div", {
                                className: "section-banner-hotword--" + (w || n ? "with" : "no") + "-skin",
                                style: w ? {} : {
                                    width: C + "px",
                                    marginLeft: (1200 - C) / 2 + "px"
                                }
                            }, r.createElement("div", {
                                className: "full-home-banners-wrapper"
                            }, g ? r.createElement(Un, null) : r.createElement(h.mE, {
                                banners: i
                            }), r.createElement(h.Jt, {
                                isSquareBanner: m,
                                items: _,
                                isLoading: y
                            }))), p ? v ? r.createElement("div", {
                                onClickCapture: function() {
                                    e.context.showPopup(r.createElement(D.Z, null), !0)
                                }
                            }, r.createElement(je, null)) : l.isNewUser && s && r.createElement(Gt, {
                                welcomeDisplayBanner: s,
                                clickWPBanner: function() {
                                    return e.context.showPopup(r.createElement(D.Z, null), !0)
                                }
                            }) : null, r.createElement(Mt, {
                                hideTag: !f
                            }), r.createElement("div", {
                                className: "section-below-the-fold"
                            }, L, r.createElement("div", {
                                className: "section-recommend-products-wrapper"
                            }, r.createElement(re.D.Provider, {
                                value: {
                                    enable: !1
                                }
                            }, r.createElement(er, {
                                customHeader: a
                            }))), "live" !== Vn && "liveish" !== Vn && r.createElement(tr, null)))))
                        }))
                    }, a
                }(r.Component);
            nr.contextTypes = {
                showPopup: c().func
            };
            var rr = (0, q.qC)($.EN, (0, u.u)(), (0, p.connect)((function(e) {
                var t, n = e.banner && e.banner.welcome_package_entrance && e.banner.welcome_package_entrance.banners ? e.banner.welcome_package_entrance.banners : [],
                    r = Date.now() / 1e3,
                    a = n.find((function(e) {
                        return e.display && e.display.pc && e.start < r && e.end > r
                    })),
                    o = (e.banner && e.banner.welcome_package_popup && e.banner.welcome_package_popup.banners ? e.banner.welcome_package_popup.banners : []).find((function(e) {
                        return e.display && e.display.pc && e.start < r && e.end > r
                    })),
                    i = (0, X.isFeatureEnabled)(w.HfP),
                    c = (0, X.isFeatureEnabled)(w.JEy),
                    u = (t = (0, Y.Au)(e.featureToggles, w.iC5), "boolean" == typeof W ? W : W = t),
                    s = (0, Y.Au)(e.featureToggles, w.UMP, !0),
                    l = (0, Y.Au)(e.featureToggles, w.OFd);
                return {
                    homeBanners: (0, z.X)((0, z.tj)(e)),
                    homePopupBanner: (0, z.qV)((0, z.tj)(e)),
                    skinnyBanners: (0, z.dt)((0, z.tj)(e)),
                    floatingIcons: (0, z.Sr)((0, z.tj)(e)),
                    homeCircles: (0, z.X5)((0, z.tj)(e)),
                    isSquareBanner: (0, z.wM)((0, z.tj)(e)),
                    welcomeDisplayBanner: a,
                    welcomeDisplayPopup: o,
                    isWelcomePackageEnabledForUser: i,
                    isCampaignDiscountTagForUser: c,
                    isImageServerEnabledForUser: u,
                    isHomeBannerBMSEnabledForUser: s,
                    isHomeMallBannerBMSEnabledForUser: l,
                    isNUZBannerBMSEnabledForUser: !0
                }
            }), Fn({}, G, {
                dismissFloatingIcons: Q.c5,
                loadHomePage: function(e) {
                    var t = e.bmsBanners;
                    return function(e) {
                        return e({
                            type: "LOAD_HOME_PAGE"
                        }), e((0, Q.yV)(["activity", "pc_home_circles", "pc_home_squares", "popup", "floating", "skinny_v2", "welcome_package_popup", "welcome_package_entrance", "homepage_mall_banner"].filter((function(e) {
                            return !t.includes(e)
                        })), {}))
                    }
                },
                userAcceptPrivacyPolicy: l.jO
            })), ee.withInjectReducer, (0, T.withI18nCollections)([nn.Nz], Ne), (0, te.NS)(888, 42, "HomePage"), (0, J.ou)(), (0, ne.withHeader)(), (0, en.withFooter)({
                pageType: en.FOOTER_PAGE_TYPE.HOME
            }))((0, on.Ty)(nr, on.l1.homepageGroupbuySection))
        },
        33379: function(e, t, n) {
            "use strict";
            n.d(t, {
                Yg: function() {
                    return f
                },
                Bc: function() {
                    return a
                },
                An: function() {
                    return o
                },
                GC: function() {
                    return l
                },
                x7: function() {
                    return i
                },
                pq: function() {
                    return p
                },
                F9: function() {
                    return c
                },
                w4: function() {
                    return m
                },
                L: function() {
                    return r
                },
                ez: function() {
                    return u
                },
                fW: function() {
                    return s
                }
            });
            var r = 58,
                a = 65,
                o = 63,
                i = 57,
                c = 52,
                u = 71,
                s = 64,
                l = 57,
                p = 208,
                m = 247,
                f = {
                    DEFAULT: 0,
                    FREE_GIFT: 1,
                    SUB_PURCHASE: 2
                }
        },
        27222: function(e, t, n) {
            "use strict";
            n.d(t, {
                S: function() {
                    return o
                }
            });
            var r = n.p + "d010b985fc1475e559b6db819889703c.png",
                a = n.p + "b442e8ea12a22339552628bb3bc5b774.jpg",
                o = "TW" === __LOCALE__ ? a : r
        },
        3858: function(e, t, n) {
            "use strict";
            var r = n(27378),
                a = n.n(r),
                o = n(70405),
                i = n(59318),
                c = {
                    SG: "en-SG",
                    MY: "en-MY",
                    TH: "th-TH",
                    TW: "zh-TW",
                    ID: "id-ID",
                    VN: "vi-VN",
                    PH: "en-PH",
                    BR: "pt-BR",
                    MX: "es-MX",
                    CO: "es-CO",
                    CL: "es-CL",
                    PL: "pl-PL",
                    ES: "es-ES"
                };
            t.Z = function(e) {
                var t = e.getPageRegionalRoute,
                    n = e.getToggle,
                    r = void 0 === n ? function() {
                        return !0
                    } : n,
                    u = e.removeHreflangDefault,
                    s = void 0 !== u && u ? [] : [a().createElement("link", {
                        key: "hreflang-default",
                        rel: "alternate",
                        href: "https://shopee.com",
                        hrefLang: "x-default"
                    })];
                for (var l in c)
                    if (r(l)) {
                        var p = "https://" + i.R2[l] + t(l);
                        s.push(a().createElement("link", {
                            key: "hreflang-" + l,
                            rel: "alternate",
                            href: p,
                            hrefLang: c[l]
                        }))
                    }
                return a().createElement(o.Helmet, null, s)
            }
        },
        42363: function(e, t, n) {
            "use strict";
            n.d(t, {
                gC: function() {
                    return p
                },
                ld: function() {
                    return m
                },
                us: function() {
                    return f
                },
                U: function() {
                    return d
                },
                y5: function() {
                    return h
                },
                x2: function() {
                    return g
                },
                Ho: function() {
                    return v
                },
                AS: function() {
                    return _
                },
                G: function() {
                    return y
                },
                ce: function() {
                    return E
                },
                yl: function() {
                    return b
                }
            });
            var r = n(6976),
                a = n(81392),
                o = n(53082),
                i = n(67139);

            function c() {
                return (c = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(this, arguments)
            }
            var u = (0, a.b5)((0, r.Kd)(), r.of ? (0, r.of)() : void 0),
                s = u.localizeCompactNumber,
                l = u.compactCurrency;

            function p(e, t) {
                return t = parseFloat(String(t || 0)), isFinite(t) ? "zh-Hant" === (0, r.of)() ? Math.round(100 - t) / 10 : Math.round(t) : t
            }
            var m = function(e, t) {
                switch (t) {
                    case "TH":
                    case "TW":
                        return (0, o.x)(t, (0, i.o)(e, t));
                    case "VN":
                        return l((0, i.o)(e, t), 3);
                    default:
                        return l((0, i.o)(e, t), 2)
                }
            };

            function f(e, t, n) {
                void 0 === n && (n = !1);
                var r = n ? {
                    symbol: ""
                } : void 0;
                switch (t) {
                    case "TW":
                        return (0, o.x)(t, (0, i.o)(e, t), r);
                    case "VN":
                        return l((0, i.o)(e, t), c({
                            maxPrecision: 3
                        }, r));
                    default:
                        return l((0, i.o)(e, t), r)
                }
            }

            function d(e, t) {
                return m(e, t)
            }

            function h(e, t) {
                return m(e, t)
            }

            function g(e, t) {
                return m(e, t)
            }

            function v(e, t) {
                switch (t) {
                    case "ID":
                        return s(e);
                    case "VN":
                        return l(e, {
                            symbol: "",
                            maxPrecision: 3
                        });
                    default:
                        return l(e, {
                            symbol: "",
                            precision: 0
                        }, [])
                }
            }

            function _(e, t) {
                return p(0, e)
            }
            var y = function(e) {
                    return l(e, {
                        symbol: "",
                        maxPrecision: 3
                    })
                },
                E = function(e, t) {
                    return l((0, i.o)(e, t), {
                        maxPrecision: 3
                    })
                },
                b = function(e, t) {
                    return l((0, i.o)(e, t), {
                        maxPrecision: 3
                    })
                }
        },
        79093: function(e, t, n) {
            "use strict";
            n.d(t, {
                FE: function() {
                    return H
                },
                NS: function() {
                    return M
                },
                ZP: function() {
                    return j
                }
            });
            var r = n(27378),
                a = n(43058),
                o = n(79308),
                i = n(41153),
                c = n(62399),
                u = n(108),
                s = n(30085),
                l = n.p + "fb73417afb1d1ff1a01ab1cec0d03507.png",
                p = n(6965),
                m = n(85989),
                f = "pAJkCU",
                d = "_1gN_jU",
                h = n(37472),
                g = n(47029),
                v = "_1VLvDx",
                _ = function(e) {
                    var t = e.error,
                        n = r.useState(g.a2.en),
                        a = n[0],
                        o = n[1];
                    return "Failed to execute 'removeChild' on 'Node': The node to be removed is not a child of this node." === t.message ? r.createElement("div", {
                        className: v
                    }, r.createElement("div", null, "Looks like this error may have been caused by Google translate. Usage of Google translate is not recommended as it may cause rendering problems"), r.createElement("div", null, r.createElement("label", {
                        htmlFor: "languages"
                    }, r.createElement("b", null, "Choose locale:"), " "), r.createElement("select", {
                        id: "languages",
                        onChange: function(e) {
                            o(e.target.value)
                        }
                    }, Object.keys(g.kn).map((function(e, t) {
                        return r.createElement("option", {
                            className: "notranslate",
                            key: t,
                            value: g.kn[e].default
                        }, e)
                    }))), r.createElement(h.Z, {
                        onClick: function() {
                            document.cookie = "language=" + a + "; path=/", window.location.reload()
                        },
                        size: "small",
                        text: "Fix Error"
                    }))) : r.createElement(r.Fragment, null)
                },
                y = m.v.ENV;
            var E = function(e) {
                    var t = e.error;
                    return r.createElement(r.Fragment, null, r.createElement("img", {
                        className: f,
                        src: l
                    }), r.createElement("div", {
                        className: d
                    }, (0, p.t)("title_crash")), "live" !== y && t && r.createElement(r.Fragment, null, r.createElement("h1", null, "Please screenshot this and report to", " ", r.createElement("a", {
                        href: "https://mattermost.garenanow.com/sea/channels/shopee-dev-pm",
                        target: "_blank",
                        rel: "noopener noreferrer"
                    }, "Mattermost")), r.createElement(_, {
                        error: t
                    }), r.createElement("pre", {
                        style: {
                            color: "red",
                            padding: 14,
                            backgroundColor: "#ffeeee"
                        }
                    }, t.stack)))
                },
                b = n(22333),
                C = n(60042),
                w = n.n(C),
                S = n(92027),
                P = n(88885),
                k = n(82500),
                T = p.config.IS_OFFICIAL_MALL_DOMAIN,
                O = new RegExp("^\\/" + "mall".toLowerCase() + "\\/.+-cat\\.(-?\\d+)\\/?$");

            function I(e) {
                var t = e.toLowerCase();
                return T && "/" === t || t === k.ROUTE_OFFICIAL_SHOP.toLowerCase() || t === k.ROUTE_OFFICIAL_SHOP.toLowerCase() + "/" || function(e) {
                    return e.toLowerCase().startsWith(k.ROUTE_OFFICIAL_SHOP_JUST_FOR_YOU.toLowerCase())
                }(e) || O.test(t)
            }
            var N = n(11812),
                A = n(78068),
                L = n.n(A),
                R = n(48189),
                B = n(83459),
                x = "_193wCc",
                U = "_3cVWns",
                F = "_3GgbTj";

            function D() {
                return (D = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(this, arguments)
            }

            function Z(e, t) {
                return (Z = Object.setPrototypeOf || function(e, t) {
                    return e.__proto__ = t, e
                })(e, t)
            }

            function H(e, t, n, l, m, f) {
                void 0 === l && (l = "unknown"), void 0 === m && (m = !1);
                var d = function(a) {
                    var o, i;

                    function c(e) {
                        var t;
                        return (t = a.call(this, e) || this).lastPageParams = null, t.trackingData = {
                            context: t.getPageParams(e)
                        }, t
                    }
                    i = a, (o = c).prototype = Object.create(i.prototype), o.prototype.constructor = o, Z(o, i);
                    var u = c.prototype;
                    return u.componentDidMount = function() {
                        this.trackPageStateEvent(this.props, !0, !0), this.props.injectAsyncReducer({
                            theme: R.I6
                        }), L()(888 === t, "PageWrapper no longer includes Header for you. Please import Header from '@shopee/pc-header' in your page and pass _888_ as the parameter to PageWrapper as ACK that you've migrated."), L()(42 === n, "PageWrapper no longer includes Footer for you. Please import { Footer } from '@shopee/footer-pc' in your page and pass _42_ as the parameter to PageWrapper as ACK that you've migrated.")
                    }, u.UNSAFE_componentWillReceiveProps = function(e) {
                        var t = this.props.location,
                            n = e.location,
                            r = (0, S.AW)(t.search),
                            a = (0, S.AW)(n.search),
                            o = !1;
                        f && "function" == typeof f.shouldSendPageViewEvent && (o = f.shouldSendPageViewEvent(r, a));
                        var i = n.pathname !== t.pathname || o;
                        this.trackPageStateEvent(e, i)
                    }, u.getPageParams = function(e) {
                        var t = e.location,
                            n = e.match.params,
                            r = e.trackingProps,
                            a = (0, N.KN)(t.pathname) || e.isOfficialShopTheme;
                        return (0, P.ZN)(D({}, n, (0, S.AW)(t.search), {
                            hash: t.hash
                        }, r, {
                            isOfficialShopTheme: a
                        }))
                    }, u.trackPageStateEvent = function(e, t, n) {
                        void 0 === t && (t = !1), void 0 === n && (n = !1);
                        var r = e.history,
                            a = e.location,
                            o = "POP" === r.action,
                            i = this.getPageParams(e);
                        if (JSON.stringify(i) !== JSON.stringify(this.lastPageParams) && (this.lastPageParams = i, n || !m || m && t)) {
                            var c = {
                                type: "pageState",
                                timestamp: Date.now(),
                                info: {
                                    id: a.key,
                                    pageType: l,
                                    initial: t,
                                    isBack: o,
                                    pageParams: i,
                                    href: "",
                                    title: ""
                                }
                            };
                            try {
                                c.info.href = window.location.href || "", c.info.title = document.title || ""
                            } catch (e) {}
                            this.props.contextOnTrack(c)
                        }
                    }, u.render = function() {
                        var t = this.props,
                            n = t.location,
                            a = t.className,
                            o = n.pathname;
                        return r.createElement(b.ZP, {
                            targetData: this.trackingData,
                            targetType: l
                        }, r.createElement("div", {
                            className: w()(x, I(o) ? F : "/" === o ? U : null, a)
                        }, r.createElement(e, this.props)))
                    }, c
                }(r.Component);
                return (0, a.qC)((0, c.R8)(E, {
                    errorLevel: "fatal"
                }), (0, u.ou)(), i.EN, s.withInjectReducer, (0, o.connect)((function(e) {
                    return {
                        isOfficialShopTheme: (0, R.H_)(e)
                    }
                })), (0, p.withI18nCollections)([B.TU]))(d)
            }
            var j = H;

            function M(e, t, n, r, a) {
                return void 0 === n && (n = "unknown"), void 0 === r && (r = !1),
                    function(o) {
                        return H(o, e, t, n, r, a)
                    }
            }
        },
        9982: function(e, t, n) {
            "use strict";
            n.d(t, {
                lK: function() {
                    return o
                },
                ap: function() {
                    return i
                },
                MJ: function() {
                    return c
                }
            });
            var r = n(5751),
                a = "POPUP_HISTORY",
                o = function(e) {
                    if (0 === e.length) return [];
                    var t = r.X.getItem(a);
                    return t || (t = {}), e.filter((function(e) {
                        var n = e.id;
                        return null == t[n]
                    }))
                },
                i = function() {
                    var e = r.X.getItem(a);
                    e && "object" == typeof e && (Object.keys(e).forEach((function(t) {
                        1e3 * e[t] < (new Date).getTime() && delete e[t]
                    })), r.X.setItem(a, e))
                },
                c = function(e) {
                    var t = e[0];
                    if (t) {
                        var n = r.X.getItem(a);
                        n || (n = {}), n[t.id] = t.end, r.X.setItem(a, n)
                    }
                }
        },
        11540: function(e, t, n) {
            "use strict";
            var r = n(27378),
                a = n.n(r),
                o = n(21065),
                i = n(97953).oc.t;
            t.Z = function(e) {
                var t = e.customTitle,
                    n = e.customDesc;
                return a().createElement("div", {
                    className: "card"
                }, a().createElement(o.bO, {
                    targetType: "WelcomePackagePopup",
                    customTitle: t || i("label_welcome_package_download"),
                    customDesc: n || i("label_welcome_package_get")
                }))
            }
        },
        93049: function(e, t, n) {
            "use strict";
            n.d(t, {
                _: function() {
                    return f
                }
            });
            var r = n(27378),
                a = n.n(r),
                o = n(94184),
                i = n.n(o),
                c = n(67360),
                u = n(6965),
                s = n(3140),
                l = n(9315),
                p = n(70590),
                m = n(3792);
            t.Z = function(e) {
                var t = e.endTime,
                    n = void 0 === t ? 0 : t,
                    r = e.startTime,
                    o = void 0 === r ? 0 : r,
                    f = e.layout,
                    d = e.onCountdownEnd,
                    h = e.endsInLogoType,
                    g = void 0 === h ? "" : h,
                    v = e.withHorizontalLineDecorators,
                    _ = void 0 !== v && v,
                    y = o && 1e3 * o < Date.now();
                return a().createElement(s.Z.Consumer, null, (function(e) {
                    var t = e.FlashSaleCountdownTimerColon,
                        r = e.FlashSaleCountdownTimerFlipBoard,
                        s = e.customHeader,
                        h = (0, m.Z)(s, [p.u.FLASH_SALE]) || null,
                        v = h && (h.image || h.color);
                    return a().createElement("div", {
                        className: "flash-sale-header-with-countdown-timer flash-sale-header-with-countdown-timer--" + f
                    }, a().createElement("div", {
                        className: i()("flash-sale-header-with-countdown-timer__wrapper flash-sale-header-with-countdown-timer__wrapper--" + f, _ && "flash-sale-header-with-countdown-timer__wrapper--with-horizontal-line-decorators")
                    }, v && h ? a().createElement(l.Z, {
                        headerText: (0, u.t)("label_flash_deals"),
                        customHeader: h
                    }) : a().createElement("div", {
                        className: "flash-sale-header-with-countdown-timer__header flash-sale-header-with-countdown-timer__header--" + __LOCALE__.toLowerCase()
                    }), g && a().createElement("div", {
                        className: "flash-sale-ends-in flash-sale-ends-in--" + g
                    }, y ? (0, u.t)("label_ends_in") : (0, u.t)("flash_sale_header_starts_at")), n > 0 && a().createElement(c.ZP, {
                        type: c.PR.COUNT_DOWN,
                        targetTimeInSeconds: y ? n : o,
                        flipRate: c.fE.SECOND,
                        onCountdownEnded: d,
                        classNames: "flash-sale-header-with-countdown-timer__countdown-timer",
                        flipBoardStyle: r,
                        colonStyle: t
                    })))
                }))
            };
            var f = {
                HOME_PAGE: "home-page",
                LANDING_PAGE: "landing-page",
                PRODUCT_PAGE: "product-page"
            }
        },
        98845: function(e, t, n) {
            "use strict";
            n.d(t, {
                zN: function() {
                    return a
                },
                LX: function() {
                    return o
                },
                bp: function() {
                    return u
                },
                Tx: function() {
                    return s
                },
                Vb: function() {
                    return r
                },
                T: function() {
                    return c
                },
                Xm: function() {
                    return i
                },
                r3: function() {
                    return l
                }
            });
            var r = {
                    default: "flash_sale",
                    SG: "flash_deal",
                    PH: "flash_deal",
                    MY: "shocking_sale",
                    ID: "flash_sale",
                    TW: "flash_sale",
                    VN: "flash_sale",
                    TH: "flash_sale",
                    BR: "flash_sale",
                    MX: "flash_sale",
                    CO: "flash_sale",
                    CL: "flash_sale",
                    PL: "flash_sale",
                    ES: "flash_sale"
                },
                a = 16,
                o = 12,
                i = 3,
                c = 2,
                u = {
                    ID: "https://shopee.co.id/events3/code/1409859301/",
                    VN: "https://shopee.vn/events3/code/124671459/",
                    PH: "https://shopee.ph/events3/code/182315693/",
                    TH: "https://shopee.co.th/web",
                    MY: "https://shopee.com.my/web",
                    SG: "https://shopee.sg/dp",
                    TW: "https://shopee.tw/m/DPonWeb",
                    BR: "https://shopee.com.br/web",
                    MX: "https://shopee.com.mx/web",
                    CO: "https://shopee.com.co/web",
                    CL: "https://shopee.cl/web",
                    PL: "https://shopee.pl/web",
                    ES: "https://shopee.es/web"
                },
                s = {
                    SHOPEE_ITEM: 0,
                    DIGITAL_PURCHASE: 1
                },
                l = 30
        },
        23046: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                PROGRESS: function() {
                    return g.ad
                },
                disableConfirmNavigate: function() {
                    return y
                },
                enableConfirmNavigate: function() {
                    return _
                },
                fetchAccountInfo: function() {
                    return c.M9
                },
                fetchFullCategoryList: function() {
                    return s
                },
                followUser: function() {
                    return p
                },
                loadAccountInfo: function() {
                    return c.LC
                },
                loadBatchItems: function() {
                    return i
                },
                loadCategoryList: function() {
                    return u
                },
                loadHomePage: function() {
                    return v
                },
                loadStaticAddressList: function() {
                    return h.V
                },
                recordSearchUserHistory: function() {
                    return l
                },
                setKYCConsent: function() {
                    return c.u6
                },
                setProgress: function() {
                    return g.eE
                },
                setProgressAlmostDone: function() {
                    return g.eW
                },
                setProgressDone: function() {
                    return g.He
                },
                setProgressStart: function() {
                    return g.jd
                },
                syncFollowUser: function() {
                    return f
                },
                syncUnfollowUser: function() {
                    return d
                },
                unfollowUser: function() {
                    return m
                },
                updateUserPhoneNumber: function() {
                    return c.xz
                }
            });
            var r = n(39942),
                a = n(83410);

            function o() {
                return (o = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(this, arguments)
            }

            function i(e, t) {
                return void 0 === t && (t = {}), (0, a.a)(r.nv, o({
                    itemShopIds: e
                }, t))
            }
            var c = n(36994);

            function u() {
                return (0, a.a)(r.lQ)
            }
            var s = {
                request: function() {
                    return (0, a.a)(r.dZ.REQUESTED)
                },
                success: function(e) {
                    return (0, a.a)(r.dZ.SUCCESS, {
                        response: e
                    })
                },
                fail: function(e) {
                    return (0, a.a)(r.dZ.FAILED, {
                        error: e
                    })
                }
            };

            function l(e) {
                return (0, a.a)(r.O9, {
                    data: e
                })
            }

            function p(e, t) {
                return (0, a.a)(r.OU, {
                    searchKey: e,
                    shopId: t
                })
            }

            function m(e, t) {
                return (0, a.a)(r.xR, {
                    searchKey: e,
                    shopId: t
                })
            }
            var f = {
                    request: function(e, t) {
                        return (0, a.a)(r.OA.REQUESTED, {
                            searchKey: e,
                            shopId: t
                        })
                    },
                    success: function(e, t) {
                        return (0, a.a)(r.OA.SUCCESS, {
                            searchKey: e,
                            shopId: t
                        })
                    },
                    fail: function(e, t, n) {
                        return (0, a.a)(r.OA.FAILED, {
                            searchKey: e,
                            shopId: t,
                            error: n
                        })
                    }
                },
                d = {
                    request: function(e, t) {
                        return (0, a.a)(r.Mz.REQUESTED, {
                            searchKey: e,
                            shopId: t
                        })
                    },
                    success: function(e, t) {
                        return (0, a.a)(r.Mz.SUCCESS, {
                            searchKey: e,
                            shopId: t
                        })
                    },
                    fail: function(e, t, n) {
                        return (0, a.a)(r.Mz.FAILED, {
                            searchKey: e,
                            shopId: t,
                            error: n
                        })
                    }
                },
                h = n(53685),
                g = n(82575);

            function v() {
                return (0, a.a)(r.ei)
            }

            function _(e) {
                return (0, a.a)(r.FC, e)
            }

            function y() {
                return (0, a.a)(r.VN)
            }
        },
        53685: function(e, t, n) {
            "use strict";
            n.d(t, {
                V: function() {
                    return o
                }
            });
            var r = n(6976),
                a = n(61922);

            function o(e) {
                return void 0 === e && (e = !1),
                    function(t) {
                        t((0, a.a3)((0, r.Kd)(), (0, r.dU)(), (0, r.of)(), e))
                    }
            }
        },
        49101: function(e, t, n) {
            "use strict";
            n.d(t, {
                S: function() {
                    return r.S
                }
            });
            var r = n(32666)
        },
        79110: function(e, t, n) {
            "use strict";
            n.d(t, {
                jO: function() {
                    return u
                }
            });
            n(76094);
            var r = n(90508),
                a = n(72609);
            n(92027);
            n(88483);
            var o = n(88929);

            function i(e, t, n, r, a, o, i) {
                try {
                    var c = e[o](i),
                        u = c.value
                } catch (e) {
                    return void n(e)
                }
                c.done ? t(u) : Promise.resolve(u).then(r, a)
            }

            function c(e) {
                return function() {
                    var t = this,
                        n = arguments;
                    return new Promise((function(r, a) {
                        var o = e.apply(t, n);

                        function c(e) {
                            i(o, r, a, c, u, "next", e)
                        }

                        function u(e) {
                            i(o, r, a, c, u, "throw", e)
                        }
                        c(void 0)
                    }))
                }
            }

            function u() {
                return function() {
                    var e = c(regeneratorRuntime.mark((function e(t) {
                        var n, i;
                        return regeneratorRuntime.wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return t({
                                        type: o.HH.REQUESTED
                                    }), e.next = 3, (0, a.jsonPost)(r.og, {
                                        tos_accepted_time: !0
                                    });
                                case 3:
                                    n = e.sent, i = n.error, t(i ? {
                                        type: o.HH.FAILED
                                    } : {
                                        type: o.HH.SUCCESS
                                    });
                                case 6:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })));
                    return function(t) {
                        return e.apply(this, arguments)
                    }
                }()
            }
        },
        26624: function(e, t, n) {
            "use strict";
            n.d(t, {
                IA: function() {
                    return a.IA
                },
                T1: function() {
                    return r.T1
                },
                HU: function() {
                    return r.HU
                },
                fg: function() {
                    return u
                },
                vr: function() {
                    return c
                },
                eQ: function() {
                    return s
                },
                ks: function() {
                    return l
                },
                Kj: function() {
                    return i
                }
            });
            var r = n(24019),
                a = n(99287),
                o = n(52203),
                i = function(e, t) {
                    var n = e.flashSale && e.flashSale.flashSaleItems,
                        r = (0, o.a)(t);
                    return n && t && n[r] ? n[r] : null
                },
                c = function(e) {
                    return e && e.flashSale ? e.flashSale.flashSaleSessions : []
                },
                u = function(e) {
                    var t = c(e),
                        n = Date.now() / 1e3;
                    return t.find((function(e) {
                        return e && e.start_time < n && e.end_time > n
                    }))
                },
                s = function(e, t) {
                    return {
                        flashSaleMeta: function(e, t) {
                            var n = c(e);
                            return n ? n.find((function(e) {
                                return e && e.promotionid === t
                            })) : null
                        }(e, t.promotionId),
                        flashSaleItems: i(e, t)
                    }
                },
                l = function(e, t) {
                    return e.flashSale.fetchItemProgress[(0, o.a)(t)]
                };
            n(30151)
        },
        77425: function(e, t, n) {
            var r = {
                "./seo_meta_description-BR-live.json": [41401, 1401],
                "./seo_meta_description-CL-live.json": [85056, 5056],
                "./seo_meta_description-CO-live.json": [92767, 2767],
                "./seo_meta_description-ES-live.json": [11603, 1603],
                "./seo_meta_description-ID-live.json": [62166, 2166],
                "./seo_meta_description-MX-live.json": [3689, 3689],
                "./seo_meta_description-MY-live.json": [17833, 7833],
                "./seo_meta_description-PH-live.json": [87558, 7558],
                "./seo_meta_description-PL-live.json": [42555, 2555],
                "./seo_meta_description-SG-live.json": [11408, 1408],
                "./seo_meta_description-TH-live.json": [82780, 2780],
                "./seo_meta_description-TW-live.json": [41986, 1986],
                "./seo_meta_description-VN-live.json": [38123, 8123]
            };

            function a(e) {
                if (!n.o(r, e)) return Promise.resolve().then((function() {
                    var t = new Error("Cannot find module '" + e + "'");
                    throw t.code = "MODULE_NOT_FOUND", t
                }));
                var t = r[e],
                    a = t[0];
                return n.e(t[1]).then((function() {
                    return n.t(a, 3)
                }))
            }
            a.keys = function() {
                return Object.keys(r)
            }, a.id = 77425, e.exports = a
        }
    }
]);
//# sourceMappingURL=https://shopee.sg/assets/Homepage.5e343c7f9b8650e82db5.js.map