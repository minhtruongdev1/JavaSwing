(("undefined" != typeof self ? self : this).webpackChunkshopee_pc = ("undefined" != typeof self ? self : this).webpackChunkshopee_pc || []).push([
    [442], {
        68440: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return Ae
                }
            });
            var r, a = n(27378),
                o = n.n(a),
                c = n(79308),
                i = n(55091),
                l = n(69068),
                s = n(18363),
                u = (0, l.n)("FETCH_HOME_OFFICIAL_MALL_SHOP"),
                p = n(14081);

            function f() {
                return (f = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(this, arguments)
            }
            var m = f({}, s.e, {
                    mallShops: []
                }),
                h = ((r = {})[u.SUCCESS] = function(e, t) {
                    var n;
                    return f({}, e, s.e, {
                        apiProgress: s.Z.OK,
                        mallShops: null != (n = t.payload.shops) ? n : [],
                        brandOfTheWeek: t.payload.brand_of_the_week
                    })
                }, r[u.FAILED] = function(e, t) {
                    return f({}, e, s.e, {
                        apiProgress: s.Z.ERR,
                        error: t.payload
                    })
                }, r),
                d = (0, p.Z)(h, m),
                v = n(72609),
                g = n(92027);
            var _ = n(19511);

            function y(e, t, n, r, a, o, c) {
                try {
                    var i = e[o](c),
                        l = i.value
                } catch (e) {
                    return void n(e)
                }
                i.done ? t(l) : Promise.resolve(l).then(r, a)
            }
            var E = n(30085),
                S = n(4918),
                b = n(84571),
                O = n(66156),
                k = n(95802),
                I = n(13384),
                w = n(98466),
                C = "_35r9oG",
                x = "_3GoGen",
                R = (0, w.Z)((function(e) {
                    var t = e.banner,
                        n = e.trackingRef,
                        r = e.trackingClick,
                        o = !!(t && t.navigate_params && t.navigate_params.url && "#" === t.navigate_params.url),
                        c = t.navigate_params && t.navigate_params.url;
                    return a.createElement("div", {
                        ref: n
                    }, a.createElement(k.Z, {
                        to: (0, g.OE)(c),
                        className: x,
                        style: o ? {
                            cursor: "default"
                        } : {},
                        onClick: function(e) {
                            o && e && e.preventDefault(), r && r()
                        }
                    }, a.createElement(I.p, {
                        className: x,
                        src: t.pc_banner_image ? t.pc_banner_image : null
                    })))
                }), "OfficialBanner");

            function F(e) {
                var t = e.banners;
                return a.createElement(O.ZP, {
                    indexType: t.length > 1 ? O.QV.DOTS : O.QV.NONE,
                    arrowDisplayType: O.sP.HIDDEN,
                    ratio: 1.1894736842105262,
                    className: C
                }, t.map((function(e, t) {
                    return a.createElement(R, {
                        banner: e,
                        key: e.id,
                        index: t
                    })
                })))
            }
            var L = n(8013),
                N = n(72323),
                M = n(6965),
                T = (0, c.connect)(null, {
                    setHomeOfficialShopSectionFocusIndex: N.eg
                })((0, w.Z)((function(e) {
                    var t = e.carouselFocusIndex,
                        n = e.link,
                        r = e.setHomeOfficialShopSectionFocusIndex,
                        o = e.trackingRef,
                        c = e.trackingClick;
                    return a.createElement(k.Z, {
                        to: (0, g.OE)(n),
                        className: "ofs-carousel__item ofs-seemore",
                        onClick: function() {
                            r(t), c && c()
                        },
                        _ref: o
                    }, a.createElement("div", {
                        className: "ofs-carousel__cover-image"
                    }), a.createElement("div", {
                        className: "ofs-seemore__content"
                    }, (0, M.t)("home_page_ofs_section_see_all"), a.createElement("div", {
                        className: "ofs-seemore__arrow"
                    }, a.createElement(S.Z, null))))
                }), "OfficialShopSeeMore")),
                P = n(40011);

            function A() {
                return (A = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(this, arguments)
            }
            var B = (0, c.connect)(null, {
                    setHomeOfficialShopSectionFocusIndex: N.eg
                })((0, w.Z)((function(e) {
                    var t = e.trackingRef,
                        n = e.trackingClick,
                        r = e.url,
                        o = e.backgroundImage,
                        c = e.labelText,
                        i = e.setHomeOfficialShopSectionFocusIndex,
                        l = e.carouselFocusIndex,
                        s = function(e, t) {
                            if (null == e) return {};
                            var n, r, a = {},
                                o = Object.keys(e);
                            for (r = 0; r < o.length; r++) n = o[r], t.indexOf(n) >= 0 || (a[n] = e[n]);
                            return a
                        }(e, ["trackingRef", "trackingClick", "url", "backgroundImage", "labelText", "setHomeOfficialShopSectionFocusIndex", "carouselFocusIndex"]),
                        u = "#" === r;
                    return a.createElement("div", A({
                        onClick: n,
                        ref: t,
                        className: "ofs-carousel__item"
                    }, s), a.createElement(k.Z, {
                        to: (0, g.OE)(r),
                        style: u ? {
                            cursor: "default"
                        } : {},
                        onClick: function(e) {
                            u ? e && e.preventDefault() : i(l)
                        },
                        className: "ofs-carousel__shop-cover-image"
                    }, a.createElement(I.p, {
                        className: "ofs-carousel__cover-image",
                        src: o ? (0, P.R)(o, 2) : null,
                        imageServerWidthOperator: 201
                    })), a.createElement("div", {
                        className: "ofs-carousel__item__text"
                    }, c))
                }), "OfficialShopCard")),
                D = n(60042),
                H = n.n(D),
                j = n(49792),
                Z = n(60710),
                U = {
                    ofsCarouselItems: "QKY3Jf",
                    ofsCarouselItemsShops: "_1QAEyW"
                };

            function G() {
                return (G = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(this, arguments)
            }

            function V(e, t) {
                return (V = Object.setPrototypeOf || function(e, t) {
                    return e.__proto__ = t, e
                })(e, t)
            }
            var K = function(e) {
                    var t, n;

                    function r() {
                        return e.apply(this, arguments) || this
                    }
                    n = e, (t = r).prototype = Object.create(n.prototype), t.prototype.constructor = t, V(t, n);
                    var o = r.prototype;
                    return o.oneRowShops = function() {
                        var e = this,
                            t = this.props,
                            n = t.shops,
                            r = t.seeAllLink;
                        return n.map((function(t, n) {
                            return a.createElement("div", {
                                key: n
                            }, e.individualShop(t, n))
                        })).concat(a.createElement(T, {
                            key: "n",
                            carouselFocusIndex: n.length,
                            link: r
                        }))
                    }, o.twoRowShops = function() {
                        var e = this,
                            t = this.props,
                            n = t.shops,
                            r = t.seeAllLink,
                            o = t.numRows,
                            c = n.length,
                            i = [];
                        n.forEach((function(t, n) {
                            var r = e.individualShop(t, n);
                            n % 2 ? i[n >> 1].push(r) : i.push([r])
                        }));
                        var l = a.createElement(T, {
                            key: "m",
                            carouselFocusIndex: Math.floor(c / o),
                            link: r
                        });
                        return c % 2 && i[i.length - 1].push(l), i.map((function(e, t) {
                            return a.createElement("div", {
                                key: t
                            }, e[0], e[1])
                        }))
                    }, o.individualShop = function(e, t) {
                        var n = e.url,
                            r = e.image,
                            o = e.promo_text,
                            c = function(e, t) {
                                if (null == e) return {};
                                var n, r, a = {},
                                    o = Object.keys(e);
                                for (r = 0; r < o.length; r++) n = o[r], t.indexOf(n) >= 0 || (a[n] = e[n]);
                                return a
                            }(e, ["url", "image", "promo_text"]);
                        return a.createElement(B, G({
                            key: t,
                            carouselFocusIndex: Math.floor(t / this.props.numRows),
                            url: n || j.Ri.getUrl({
                                shopId: e.shopid
                            }),
                            backgroundImage: (0, Z.Jn)(r),
                            labelText: o,
                            location: t
                        }, c))
                    }, o.render = function() {
                        var e = this.props,
                            t = e.hasBanner,
                            n = e.numItemsPerRow,
                            r = e.numRows,
                            o = e.carouselFocusIndex,
                            c = e.trackingRef;
                        return a.createElement("div", {
                            className: H()(U.ofsCarousel, t ? U.ofsCarouselItemsShops : U.ofsCarouselItems),
                            ref: c
                        }, a.createElement(L.lr, {
                            showArrowOnHover: !0,
                            numItemsPerRow: n,
                            padding: "0",
                            items: 1 === r ? this.oneRowShops() : this.twoRowShops(),
                            keepPreviousItemOnSlide: !1,
                            showArrowHint: !0,
                            focusIndex: o
                        }))
                    }, r
                }(a.Component),
                Q = (0, w.Z)(K, "OfficialShopCarousel"),
                W = n(73727),
                Y = n(3792),
                q = n(3140),
                J = n(9315),
                X = n(70590),
                z = "_2jXJnV",
                $ = "_2QwDm3",
                ee = function(e) {
                    var t = e.title;
                    return a.createElement(q.Z.Consumer, null, (function(e) {
                        var n = e.customHeader;
                        return a.createElement(J.Z, {
                            headerText: t,
                            customHeader: (0, Y.Z)(n, [X.u.OFFICIAL_MALL])
                        })
                    }))
                },
                te = (0, w.Z)((function(e) {
                    var t = e.headerLink,
                        n = e.title,
                        r = e.trackingClick;
                    return t ? a.createElement(W.Link, {
                        className: H()(z, $),
                        to: t,
                        onClick: function() {
                            r && r()
                        }
                    }, a.createElement(ee, {
                        title: n
                    })) : a.createElement("div", {
                        className: z,
                        onClick: function() {
                            r && r()
                        }
                    }, a.createElement(ee, {
                        title: n
                    }))
                }), "OfficialShopTitle"),
                ne = n(49101),
                re = n(89291),
                ae = n(108),
                oe = n(17555);

            function ce() {
                return (ce = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(this, arguments)
            }
            var ie = "_1gcn8R",
                le = n(6976);
            var se = (0, ae.h9)()((function(e) {
                    var t = e.contextTargetType,
                        n = e.onLoad,
                        r = function(e, t) {
                            var n = (0, oe.O)();
                            return (0, a.useCallback)((function(r, a) {
                                switch (r) {
                                    case "IMPRESSION":
                                        n({
                                            type: "impression",
                                            timestamp: Date.now(),
                                            info: {
                                                targetType: e + "." + (t ? t + "." : "") + "BannerItem",
                                                impressions: [{
                                                    targetData: ce({}, a, {
                                                        isFromBMS: !0
                                                    })
                                                }]
                                            }
                                        });
                                        break;
                                    case "CLICK":
                                        n({
                                            type: "click",
                                            timestamp: Date.now(),
                                            info: {
                                                targetType: e + "." + (t ? t + "." : "") + "BannerItem",
                                                targetData: ce({}, a, {
                                                    isFromBMS: !0
                                                })
                                            }
                                        })
                                }
                            }), [e, n])
                        }(t, "mall");
                    return o().createElement("div", {
                        className: ie
                    }, o().createElement(re.ZJ, {
                        spaceKey: "PC-" + (0, le.Kd)() + "-HOME_MALL_01",
                        onEventCallback: function(e, t) {
                            "LOAD" === e && n(t), r(e, t)
                        },
                        baseUrl: window.origin || (0, Z.SV)(),
                        ratio: 452 / 380
                    }))
                })),
                ue = n(64653),
                pe = n(72699),
                fe = n(8205),
                me = n(73180),
                he = n(29031),
                de = n(75975),
                ve = n(22333),
                ge = "_2V1-Vu",
                _e = "_19fjwV",
                ye = "_3WSAH5",
                Ee = "_2TyZyx",
                Se = "_2Kl5gH",
                be = "sQprQi",
                Oe = "_2SCKPT",
                ke = "FxuC02";

            function Ie(e, t) {
                return (Ie = Object.setPrototypeOf || function(e, t) {
                    return e.__proto__ = t, e
                })(e, t)
            }
            var we = (0, pe.qY.getUrl)(),
                Ce = {
                    linkTo: "#",
                    text: ""
                },
                xe = function(e) {
                    var t, n;

                    function r() {
                        return e.apply(this, arguments) || this
                    }
                    n = e, (t = r).prototype = Object.create(n.prototype), t.prototype.constructor = t, Ie(t, n);
                    var o = r.prototype;
                    return o.shouldComponentUpdate = function(e) {
                        var t = this.props;
                        return (0, he.Z)(t, e, ["categoryId", "numItemsPerRow", "numRows", "itemLink", "carouselFocusIndex", "seeAllLink", "isHomeMallBannerBMSEnabledForUser"], ["shops", "searchParams"])
                    }, o.render = function() {
                        var e = this.props,
                            t = e.seeAllLink,
                            n = e.banners,
                            r = e.carouselFocusIndex,
                            o = e.numItemsPerRow,
                            c = e.numRows,
                            i = e.shops,
                            l = e.isHomeMallBannerBMSEnabledForUser,
                            s = e.onBMSLoaded;
                        return a.createElement(ve.ZP, {
                            targetType: "OfficialShopSection"
                        }, a.createElement(q.Z.Consumer, null, (function(e) {
                            var u = e.customHeader;
                            return a.createElement(ne.S, {
                                hasNoNavigation: !0,
                                headerButton: Ce,
                                headerText: a.createElement("div", {
                                    className: ge
                                }, a.createElement(te, {
                                    headerLink: we,
                                    title: (0, M.t)("home_page_label_shopee_mall_header")
                                }), a.createElement("div", {
                                    className: Se
                                }, de.rv.map((function(e, t) {
                                    var n = e.Icon,
                                        r = e.tagTitle;
                                    return a.createElement("div", {
                                        className: be,
                                        key: t
                                    }, a.createElement(n, {
                                        className: Oe
                                    }), (0, M.t)(r))
                                })))),
                                customButtonContent: a.createElement(b.LinkWithTrackImpression, {
                                    className: _e,
                                    to: t,
                                    targetType: "SeeAllLink"
                                }, a.createElement("div", {
                                    className: ye
                                }, (0, M.t)("home_page_ofs_section_see_all"), a.createElement("div", {
                                    className: Ee
                                }, a.createElement(S.Z, null)))),
                                simpleVersion: !0,
                                customHeader: (0, Y.Z)(u, [X.u.OFFICIAL_MALL])
                            }, l ? a.createElement(se, {
                                onLoad: function(e) {
                                    var t;
                                    s && s((null == e || null === (t = e.data) || void 0 === t ? void 0 : t.space_banners) || [])
                                }
                            }) : n.length > 0 && a.createElement(F, {
                                banners: n
                            }), a.createElement(Q, {
                                shops: i,
                                hasBanner: n.length > 0,
                                carouselFocusIndex: r,
                                numItemsPerRow: o,
                                numRows: c,
                                seeAllLink: t
                            }))
                        })))
                    }, r
                }(a.Component);
            var Re = (0, i.qC)((0, c.connect)((function(e) {
                    return {
                        isHomeMallBannerBMSEnabledForUser: (0, me.Au)(e.featureToggles, fe.OFd)
                    }
                })), (0, M.withI18nCollections)([ue.ZE], (function() {
                    return a.createElement("div", {
                        className: ke
                    }, a.createElement("div", {
                        className: "skeleton skeleton-medium skeleton-line",
                        style: {
                            height: 16,
                            marginLeft: 10,
                            marginRight: 5
                        }
                    }), a.createElement("div", {
                        className: "flex",
                        style: {
                            height: 452
                        }
                    }, a.createElement("div", {
                        className: "skeleton skeleton-full",
                        style: {
                            width: 380,
                            margin: 10,
                            marginRight: 0
                        }
                    }), a.createElement("div", {
                        className: "flex flex-column",
                        style: {
                            flex: 1,
                            margin: 10
                        }
                    }, a.createElement("div", {
                        className: "skeleton skeleton-full",
                        style: {
                            flex: 1
                        }
                    }), a.createElement("div", {
                        className: "skeleton skeleton-full",
                        style: {
                            flex: 1,
                            marginTop: 10
                        }
                    }))))
                })), E.withInjectReducer)(xe),
                Fe = n(82500),
                Le = n(50949);

            function Ne() {
                return (Ne = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(this, arguments)
            }

            function Me(e, t) {
                return (Me = Object.setPrototypeOf || function(e, t) {
                    return e.__proto__ = t, e
                })(e, t)
            }
            var Te = pe.qY.getUrl,
                Pe = function(e) {
                    var t, n;

                    function r(t) {
                        var n;
                        return (n = e.call(this, t) || this).updateBMSBanners = function(e) {
                            n.setState({
                                bmsBanners: e
                            })
                        }, t.injectAsyncReducer({
                            officialMallShop: d
                        }), n.state = {
                            bmsBanners: []
                        }, n
                    }
                    n = e, (t = r).prototype = Object.create(n.prototype), t.prototype.constructor = t, Me(t, n);
                    var o = r.prototype;
                    return o.universalDataFetch = function() {
                        return this.props.fetchOfficialMallShopsLimitBy(23)
                    }, o.componentDidMount = function() {
                        this.universalDataFetch()
                    }, o.render = function() {
                        var e = this.props,
                            t = e.mallBanner,
                            n = e.mallShops,
                            r = e.focusIndex,
                            o = e.isHomeMallBannerBMSEnabledForUser,
                            c = this.state.bmsBanners,
                            i = o ? c : t,
                            l = i.length > 0,
                            s = {
                                categoryId: -2,
                                shops: n,
                                seeAllLink: Fe.ROUTE_OFFICIAL_SHOP,
                                itemLink: Te(),
                                carouselFocusIndex: r,
                                numItemsPerRow: l ? 4 : 6,
                                numRows: l ? 2 : 1,
                                banners: i || []
                            };
                        return a.createElement("div", {
                            className: "homepage-mall-section"
                        }, a.createElement(Re, Ne({}, s, {
                            onBMSLoaded: this.updateBMSBanners
                        })))
                    }, r
                }(a.PureComponent);
            var Ae = (0, i.qC)((0, c.connect)((function(e) {
                var t = (0, me.Au)(e.featureToggles, fe.OFd),
                    n = (0, me.Au)(e.featureToggles, fe.flO),
                    r = function(e) {
                        return e.mallShops
                    }(e.officialMallShop || {}) || [];
                return n || (r = r.slice(0, 15)), {
                    IS_MALL_SHOP_ENABLED: n,
                    isHomeMallBannerBMSEnabledForUser: t,
                    mallBanner: (0, Le.UK)((0, Le.tj)(e)),
                    mallShops: r,
                    focusIndex: (0, N.Qx)(e)
                }
            }), {
                fetchOfficialMallShopsLimitBy: function(e) {
                    return function() {
                        var t, n = (t = regeneratorRuntime.mark((function t(n, r) {
                            return regeneratorRuntime.wrap((function(t) {
                                for (;;) switch (t.prev = t.next) {
                                    case 0:
                                        return t.next = 2, (0, _.Z)({
                                            apiCall: function() {
                                                return t = {
                                                    limit: e
                                                }, (0, v.fetchInfo)("/api/v4/homepage/mall_shops" + (0, g.Wc)(t));
                                                var t
                                            },
                                            actions: [{
                                                type: u.REQUESTED
                                            }, {
                                                type: u.SUCCESS,
                                                payload: function(e, t, n) {
                                                    return n.data
                                                }
                                            }, {
                                                type: u.FAILED,
                                                payload: function(e, t, n) {
                                                    return n.error
                                                }
                                            }]
                                        }, n, r);
                                    case 2:
                                    case "end":
                                        return t.stop()
                                }
                            }), t)
                        })), function() {
                            var e = this,
                                n = arguments;
                            return new Promise((function(r, a) {
                                var o = t.apply(e, n);

                                function c(e) {
                                    y(o, r, a, c, i, "next", e)
                                }

                                function i(e) {
                                    y(o, r, a, c, i, "throw", e)
                                }
                                c(void 0)
                            }))
                        });
                        return function(e, t) {
                            return n.apply(this, arguments)
                        }
                    }()
                }
            }), E.withInjectReducer)(Pe)
        },
        75975: function(e, t, n) {
            "use strict";
            n.d(t, {
                rv: function() {
                    return R
                }
            });
            var r, a = n(6976);
            ! function(e) {
                e[e.Return_7Day = 0] = "Return_7Day", e[e.Return_15Day = 1] = "Return_15Day", e[e.Authentic = 2] = "Authentic", e[e.FreeShipping = 3] = "FreeShipping"
            }(r || (r = {}));
            var o, c = n.p + "6c502a2641457578b0d5f5153b53dd5d.png",
                i = n.p + "6c502a2641457578b0d5f5153b53dd5d.png",
                l = n.p + "6c502a2641457578b0d5f5153b53dd5d.png",
                s = n.p + "6c502a2641457578b0d5f5153b53dd5d.png",
                u = n.p + "16ead7e0a68c3cff9f32910e4be08122.png",
                p = n.p + "16ead7e0a68c3cff9f32910e4be08122.png",
                f = n.p + "16ead7e0a68c3cff9f32910e4be08122.png",
                m = n.p + "511aca04cc3ba9234ab0e4fcf20768a2.png",
                h = n.p + "511aca04cc3ba9234ab0e4fcf20768a2.png",
                d = n.p + "511aca04cc3ba9234ab0e4fcf20768a2.png",
                v = ((o = {})[c] = r.Return_7Day, o[i] = r.Return_7Day, o[l] = r.Return_15Day, o[s] = r.Return_15Day, o[u] = r.FreeShipping, o[p] = r.FreeShipping, o[f] = r.FreeShipping, o[m] = r.Authentic, o[h] = r.Authentic, o[d] = r.Authentic, o),
                g = [l, u, m],
                _ = {
                    ID: [c, h, p],
                    MY: [d, s, f],
                    PH: [h, i, f],
                    SG: [l, h, p],
                    TH: [h, l, u],
                    TW: g,
                    VN: g,
                    BR: g,
                    MX: g,
                    CO: g,
                    CL: g,
                    PL: g,
                    ES: g
                };

            function y(e) {
                return [1, 2, 3].map((function(t) {
                    return {
                        text: "label_official_shop_selling_points_" + t + "--" + e,
                        desc: "label_official_shop_selling_points_" + t + "_detail--" + e,
                        type: t
                    }
                }))
            }
            y("ID"), y("MY"), y("PH"), y("SG"), y("TH"), y("TW"), y("VN"), y("SG"), y("SG"), y("SG"), y("SG"), y("SG"), y("SG");
            var E, S = n(27378),
                b = n.n(S);

            function O() {
                return (O = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(this, arguments)
            }
            var k = ((E = {})[r.Authentic] = "authentic", E[r.FreeShipping] = "free_shipping", E[r.Return_7Day] = "7_day_return", E[r.Return_15Day] = "15_day_return", E),
                I = function(e) {
                    var t, n;
                    null === (t = e.locale) || void 0 === t || null === (n = t.toLowerCase) || void 0 === n || n.call(t), k[e.type];
                    return b().createElement("img", {
                        className: e.className,
                        src: e.icon
                    })
                };

            function w() {
                return (w = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(this, arguments)
            }
            var C = (0, a.Kd)(),
                x = function(e) {
                    return _[e].map((function(e) {
                        return {
                            icon: e,
                            type: v[e]
                        }
                    }))
                }(C),
                R = (y(C).map((function(e, t) {
                    return w({}, e, {
                        img: x[t].icon
                    })
                })), x.map((function(e, t) {
                    var n, r = t + 1 + ("TW" === C ? "" : "_" + C.toLowerCase());
                    return {
                        Icon: (n = {
                            icon: e.icon,
                            type: e.type,
                            locale: C
                        }, function(e) {
                            return b().createElement(I, O({}, n, e))
                        }),
                        tagTitle: "Label_selling_point_" + r,
                        tagText: "Msg_selling_point_" + r,
                        tagShortText: "Msg_selling_point_" + r + "_short"
                    }
                })))
        }
    }
]);
//# sourceMappingURL=https://shopee.sg/assets/HomeOfficialShopSection.d5d57209d9a70cf53ce8.js.map