(("undefined" != typeof self ? self : this).webpackChunkshopee_pc = ("undefined" != typeof self ? self : this).webpackChunkshopee_pc || []).push([
    [4055], {
        47687: function(e) {
            e.exports = function(e, n) {
                var t = 0,
                    r = {};
                e.addEventListener("message", (function(n) {
                    var t = n.data;
                    if ("RPC" === t.type)
                        if (t.id) {
                            var s = r[t.id];
                            s && (delete r[t.id], t.error ? s[1](Object.assign(Error(t.error.message), t.error)) : s[0](t.result))
                        } else {
                            var a = document.createEvent("Event");
                            a.initEvent(t.method, !1, !1), a.data = t.params, e.dispatchEvent(a)
                        }
                })), n.forEach((function(n) {
                    e[n] = function() {
                        var s = arguments;
                        return new Promise((function(a, o) {
                            var i = ++t;
                            r[i] = [a, o], e.postMessage({
                                type: "RPC",
                                id: i,
                                method: n,
                                params: [].slice.call(s)
                            })
                        }))
                    }
                }))
            }
        },
        64055: function(e, n, t) {
            var r = t(47687),
                s = ["getRuleSet", "injectRules", "v2ToV3"];
            e.exports = function() {
                var e = new Worker("/assets/2f2a4e4266f7f381286f.worker.js", {
                    name: "[fullhash].worker.js"
                });
                return r(e, s), e.ready = new Promise((function(n) {
                    e.addEventListener("ready", (function() {
                        n(e)
                    }))
                })), e
            }
        }
    }
]);
//# sourceMappingURL=https://shopee.sg/assets/4055.046fd824ac3d0e1473a0.js.map