(("undefined" != typeof self ? self : this).webpackChunkshopee_pc = ("undefined" != typeof self ? self : this).webpackChunkshopee_pc || []).push([
    [2060], {
        89288: function(e, r, t) {
            "use strict";
            t.d(r, {
                Gy: function() {
                    return n
                },
                qI: function() {
                    return o
                },
                $H: function() {
                    return c
                },
                sk: function() {
                    return a
                },
                Rd: function() {
                    return f
                }
            });
            var n, o, i = t(72609),
                u = t(92027);
            ! function(e) {
                e[e.OFFICIAL_MALL_INTERMEDIATE_PAGE = 1] = "OFFICIAL_MALL_INTERMEDIATE_PAGE", e[e.AFFILIATE_SHOP_INTERMEDIATE_PAGE = 2] = "AFFILIATE_SHOP_INTERMEDIATE_PAGE"
            }(n || (n = {})),
            function(e) {
                e[e.SIMILAR_PRODUCTS = 0] = "SIMILAR_PRODUCTS", e[e.DAILY_DISCOVER = 5] = "DAILY_DISCOVER", e[e.FROM_THE_SAME_SHOP = 9] = "FROM_THE_SAME_SHOP"
            }(o || (o = {}));

            function c(e) {
                var r = e.voucherCode,
                    t = e.promotionId,
                    n = e.signature;
                return (0, i.jsonPost)("/api/v2/voucher_wallet/save_voucher", {
                    voucher_code: r,
                    voucher_promotionid: t,
                    signature: n,
                    signature_source: "3"
                })
            }

            function a(e) {
                var r = e.pageType,
                    t = e.recommendType,
                    n = e.categoryId,
                    o = e.shopId,
                    c = e.itemId,
                    a = e.offset,
                    f = void 0 === a ? 0 : a,
                    s = e.limit,
                    d = (0, u.Wc)({
                        page: r,
                        recommend_type: t,
                        catid: n,
                        shopid: o,
                        itemid: c,
                        offset: f,
                        limit: s
                    });
                return (0, i.fetchInfo)("/api/v4/intermediate/recommend_items" + d)
            }

            function f(e) {
                var r = e.shopId,
                    t = e.itemId,
                    n = e.withClaimingStatus,
                    o = (0, u.Wc)({
                        shopid: r,
                        itemid: t,
                        with_claiming_status: n
                    });
                return (0, i.fetchInfo)("/api/v2/intermediate/get_vouchers" + o)
            }
        },
        79616: function(e, r, t) {
            "use strict";
            t.r(r), t.d(r, {
                isInLocalStorage: function() {
                    return s
                },
                saveVoucherToLocalStorage: function() {
                    return d
                },
                claimAllVouchersInLocalStorage: function() {
                    return v
                }
            });
            var n = t(89288),
                o = t(5751);

            function i(e, r) {
                var t;
                if ("undefined" == typeof Symbol || null == e[Symbol.iterator]) {
                    if (Array.isArray(e) || (t = function(e, r) {
                            if (!e) return;
                            if ("string" == typeof e) return u(e, r);
                            var t = Object.prototype.toString.call(e).slice(8, -1);
                            "Object" === t && e.constructor && (t = e.constructor.name);
                            if ("Map" === t || "Set" === t) return Array.from(e);
                            if ("Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t)) return u(e, r)
                        }(e)) || r && e && "number" == typeof e.length) {
                        t && (e = t);
                        var n = 0;
                        return function() {
                            return n >= e.length ? {
                                done: !0
                            } : {
                                done: !1,
                                value: e[n++]
                            }
                        }
                    }
                    throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }
                return (t = e[Symbol.iterator]()).next.bind(t)
            }

            function u(e, r) {
                (null == r || r > e.length) && (r = e.length);
                for (var t = 0, n = new Array(r); t < r; t++) n[t] = e[t];
                return n
            }
            var c = "@shopee/intermediate-utils";

            function a() {
                var e = o.X.getItem(c);
                if (!e || "object" != typeof e) return null;
                var r = e,
                    t = r.itemId,
                    n = r.vouchers;
                if ("number" != typeof t || !Array.isArray(n)) return null;
                for (var u, a = i(n); !(u = a()).done;) {
                    var f = u.value;
                    if (!f || "object" != typeof f) return null
                }
                return {
                    itemId: t,
                    vouchers: n
                }
            }

            function f(e) {
                null === e ? o.X.removeItem(c) : o.X.setItem(c, e)
            }

            function s(e, r) {
                var t = a();
                return (t && t.itemId === r ? t.vouchers : []).some((function(r) {
                    return r.voucherCode === e.voucher_code
                }))
            }

            function d(e, r) {
                var t = a(),
                    n = {
                        voucherCode: e.voucher_code,
                        promotionId: e.promotionid,
                        signature: e.signature
                    },
                    o = t && t.itemId === r ? t.vouchers : [];
                f({
                    itemId: r,
                    vouchers: o.some((function(r) {
                        return r.voucherCode === e.voucher_code
                    })) ? o : [].concat(o, [n])
                })
            }

            function v() {
                var e = a();
                if (f(null), e)
                    for (var r, t = i(e.vouchers); !(r = t()).done;) {
                        var o = r.value,
                            u = o.voucherCode,
                            c = o.promotionId,
                            s = o.signature;
                        (0, n.$H)({
                            voucherCode: u,
                            promotionId: c,
                            signature: s
                        })
                    }
            }
        }
    }
]);
//# sourceMappingURL=https://shopee.sg/assets/IntermediateVoucher.fde346c5913e5642b730.js.map