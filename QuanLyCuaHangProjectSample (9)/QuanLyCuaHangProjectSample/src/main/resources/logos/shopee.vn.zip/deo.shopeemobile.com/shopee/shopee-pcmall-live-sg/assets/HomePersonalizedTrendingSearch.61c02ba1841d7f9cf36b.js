(("undefined" != typeof self ? self : this).webpackChunkshopee_pc = ("undefined" != typeof self ? self : this).webpackChunkshopee_pc || []).push([
    [2943], {
        50811: function(e, n, t) {
            "use strict";
            t.r(n);
            var s = t(27378),
                f = t(84691),
                o = t(13751),
                i = t(62399),
                u = t(26235),
                c = (0, o.Z)({
                    loader: function() {
                        return t.e(2034).then(t.bind(t, 7550))
                    }
                });
            n.default = (0, f.compose)(i.Pf, (0, u.withI18nCollections)([119, 120]))((function() {
                return s.createElement(c, {
                    isLoaded: !0
                })
            }))
        }
    }
]);
//# sourceMappingURL=https://shopee.sg/assets/HomePersonalizedTrendingSearch.61c02ba1841d7f9cf36b.js.map