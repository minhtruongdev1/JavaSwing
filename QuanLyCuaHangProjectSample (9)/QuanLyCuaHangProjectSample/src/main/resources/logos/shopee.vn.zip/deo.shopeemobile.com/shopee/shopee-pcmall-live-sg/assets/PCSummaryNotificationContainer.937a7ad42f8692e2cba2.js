(("undefined" != typeof self ? self : this).webpackChunkshopee_pc = ("undefined" != typeof self ? self : this).webpackChunkshopee_pc || []).push([
    [1337], {
        36217: function(e, t, a) {
            "use strict";
            a.r(t), a.d(t, {
                default: function() {
                    return Ne
                }
            });
            var n = a(27378),
                i = a(79308),
                r = a(42718),
                c = a(97063),
                o = a(41153),
                l = a(13384),
                s = a(30791),
                m = a(52801),
                u = a(6965),
                d = "z_XZoL",
                p = "_3zF59m",
                f = "wctzw5",
                _ = "_1MMKUO",
                N = "_3kRBrD",
                E = "_5Xcals",
                v = "_1jiit9",
                y = a.p + "99e561e3944805a023e87a81d4869600.png",
                g = (0, o.EN)((function(e) {
                    var t = e.history;
                    return n.createElement("div", {
                        className: p
                    }, n.createElement("div", {
                        className: d
                    }, n.createElement(l.p, {
                        src: y,
                        wrapperClassName: _,
                        className: _,
                        useImgTag: !0,
                        hidePlaceholder: !0
                    }), n.createElement("p", {
                        className: N
                    }, (0, u.t)("label_noti_login_required"))), n.createElement("div", {
                        className: f
                    }, n.createElement("button", {
                        className: E,
                        onClick: function() {
                            t.push((0, m.FK)(s.zF.getUrl(), {
                                next: location.href,
                                from: location.href
                            }))
                        }
                    }, (0, u.t)("label_noti_signup")), n.createElement("button", {
                        className: v,
                        onClick: function() {
                            t.push((0, m.FK)(s.D_.getUrl(), {
                                next: location.href,
                                from: location.href
                            }))
                        }
                    }, (0, u.t)("label_noti_login"))))
                })),
                h = a(73727),
                I = a(27986),
                C = a(42286),
                T = a(52316),
                b = a(51816),
                k = a(97953),
                w = a(60710),
                A = a(6976),
                L = a(29659),
                S = {
                    container: "_1OHoC4",
                    content: "_2GEGIm",
                    imageContainer: "_1BZ510",
                    badgePromotionWrapper: "_69yh_7",
                    image: "_2u0rYP",
                    fieldOutsideText: "MZpYft",
                    originalPrice: "_3vI-Dp",
                    promotionPrice: "_2d_tiL",
                    promotionPriceValue: "_4YA36x",
                    promotionPriceSymbol: "_2Z_n3_"
                },
                Z = k.oc.t,
                O = (0, A.of)(),
                P = (0, A.Kd)(),
                U = L.Yn.bind(null, P);
            var x = function(e) {
                    var t = e.richContents;
                    return n.createElement("div", {
                        className: S.container
                    }, t.filter((function(e) {
                        return !!e.image
                    })).slice(0, 3).map((function(e, t) {
                        return n.createElement("div", {
                            key: t,
                            className: S.content
                        }, n.createElement("div", {
                            className: S.imageContainer
                        }, n.createElement(l.p, {
                            src: (0, w.Jn)(e.image),
                            wrapperClassName: S.wrapper,
                            className: S.image
                        }), "number" == typeof(a = e.discount) && a > 0 && a <= 100 && n.createElement("div", {
                            className: S.badgePromotionWrapper
                        }, n.createElement(b.OO, {
                            rawDiscount: e.discount,
                            language: O,
                            offText: Z("highest_discount_hotdeals")
                        }))), n.createElement("div", {
                            className: S.fieldOutsideText
                        }, !!e.original_price && n.createElement("div", {
                            className: S.originalPrice
                        }, (0, L.HI)(P, {
                            createSymbolElement: function(e, t) {
                                return n.createElement("span", {
                                    className: S.symbol,
                                    key: "currency-" + t
                                }, e)
                            },
                            createPriceElement: function(e, t) {
                                return n.createElement("span", {
                                    className: S.price,
                                    key: "price-" + t
                                }, e)
                            }
                        })(U(e.original_price))), !!e.promotion_price && n.createElement("div", {
                            className: S.promotionPrice
                        }, (0, L.HI)(P, {
                            createSymbolElement: function(e, t) {
                                return n.createElement("span", {
                                    className: S.promotionPriceSymbol,
                                    key: "currency-" + t
                                }, e)
                            },
                            createPriceElement: function(e, t) {
                                return n.createElement("span", {
                                    className: S.promotionPriceValue,
                                    key: "price-" + t
                                }, e)
                            }
                        })(U(e.promotion_price)))));
                        var a
                    })))
                },
                V = "X46-OD",
                R = "ORgfkT",
                D = "_3Ue29X";

            function G(e) {
                var t = e.images;
                return n.createElement("div", {
                    className: V
                }, t.filter((function(e) {
                    return !!e
                })).slice(0, 3).map((function(e, t) {
                    return n.createElement(l.p, {
                        key: t,
                        src: (0, w.Jn)(e),
                        wrapperClassName: R,
                        className: D
                    })
                })))
            }
            var F = "Rhigbp",
                H = "_1LTGR0",
                J = "_3Ez5zd";

            function z(e) {
                var t = e.image;
                return n.createElement("div", {
                    className: F
                }, n.createElement(l.p, {
                    src: (0, w.Jn)(t),
                    wrapperClassName: H,
                    className: J
                }))
            }
            var Y = a(53650),
                Q = a(90858),
                W = a(32616),
                M = a(91873),
                B = a(81545),
                K = "_2Nidx_",
                X = "w16lIY",
                q = "_1-Q8Ea",
                j = "_23T5k9",
                $ = "_1FqmQh",
                ee = {};

            function te(e) {
                var t = e.action,
                    a = e.location,
                    i = e.isUnread,
                    r = e.markNotificationAsRead,
                    c = t || ee,
                    o = c.images,
                    l = c.title,
                    s = c.content,
                    m = c.rich_images,
                    u = void 0 === m ? [] : m,
                    d = c.rich_contents,
                    p = void 0 === d ? [] : d,
                    f = c.ar_big_banner,
                    _ = void 0 === f ? "" : f,
                    N = {
                        action: t,
                        location: a,
                        isUnread: i
                    },
                    E = (0, Y.Z)("ActionCardSummary", N),
                    v = (0, Q.Z)("ActionCardSummary", N);
                return n.createElement(T.JG.W2, {
                    className: K,
                    onClick: function(e) {
                        e.preventDefault(), v(), i && r({
                            notiId: t.action_id,
                            notiType: W.tx.ACTION,
                            notiSubType: t.action_cate
                        }), M.a.handleClick(t)
                    },
                    isUnread: i,
                    ref: E
                }, n.createElement(T.JG.mo, {
                    className: X
                }, n.createElement(T.q$, {
                    images: o
                })), n.createElement(T.JG.OO, {
                    className: q
                }, n.createElement("div", {
                    className: j
                }, l), n.createElement("div", {
                    className: $,
                    dangerouslySetInnerHTML: {
                        __html: B.Z.sanitize(s)
                    }
                }), function() {
                    switch (M.a.getArDisplayType(_, p, u)) {
                        case W.HF.BIG_BANNER:
                            return n.createElement(z, {
                                image: _
                            });
                        case W.HF.RICH_CONTENTS:
                            return n.createElement(x, {
                                richContents: p
                            });
                        case W.HF.RICH_IMAGES:
                            return n.createElement(G, {
                                images: u
                            });
                        default:
                            return null
                    }
                }()))
            }
            var ae = (0, i.connect)((function(e, t) {
                    var a = t.action;
                    return {
                        isUnread: C.nZ.isNotificationUnread(e, {
                            notiId: a.action_id,
                            notiType: W.tx.ACTION,
                            notiSubType: a.action_cate
                        })
                    }
                }), {
                    chatWithUser: I.m0,
                    markNotificationAsRead: C.Nw.markNotificationAsRead
                })(n.memo(te)),
                ne = a(28713),
                ie = a(28163),
                re = {
                    notiListLabel: "_23sbfP",
                    notiListLinkViewAll: "_1sTwey"
                },
                ce = "_2TDp5S",
                oe = "_2dQCfo",
                le = "DdxtVj",
                se = "_2aybWU";

            function me(e) {
                var t = e.activity,
                    a = e.location,
                    r = M.l.getAvatarImage(t),
                    c = M.l.getDescription(t),
                    o = (0, i.useSelector)((function(e) {
                        return C.nZ.isNotificationUnread(e, {
                            notiId: t.activity_id,
                            notiType: W.tx.ACTIVITY,
                            notiSubType: t.type
                        })
                    })),
                    l = (0, i.useDispatch)(),
                    s = {
                        activity: t,
                        location: a,
                        isUnread: o
                    },
                    m = (0, Y.Z)("ActivityCardSummary", s),
                    u = (0, Q.Z)("ActivityCardSummary", s);
                return n.createElement(T.JG.W2, {
                    className: ce,
                    isUnread: o,
                    onClick: function(e) {
                        e.preventDefault(), u(), o && l(C.Nw.markNotificationAsRead({
                            notiId: t.activity_id,
                            notiType: W.tx.ACTIVITY,
                            notiSubType: t.type
                        })), M.l.handleClick(t)
                    },
                    ref: m
                }, n.createElement(T.JG.mo, {
                    className: oe
                }, n.createElement(T.F$, {
                    avatarImage: r
                })), n.createElement(T.JG.OO, {
                    className: le
                }, n.createElement("div", {
                    className: se,
                    dangerouslySetInnerHTML: {
                        __html: B.Z.sanitize(c)
                    }
                })))
            }
            var ue = n.memo(me);
            var de = function(e) {
                    var t = e.notifications,
                        a = (0, Q.Z)("NotificationListViewAllSummary", void 0);
                    return n.createElement(n.Fragment, null, n.createElement("div", {
                        className: re.notiListLabel
                    }, (0, u.t)("label_noti_recently_received")), n.createElement("div", {
                        className: re.notiListContainer
                    }, t.map((function(e, t) {
                        var a = (0, ie.W)(e);
                        if (!a) return null;
                        var i = a.notiType,
                            r = i + "-" + a.notiId;
                        switch (i) {
                            case W.tx.ACTION:
                                return n.createElement(ae, {
                                    key: r,
                                    action: e,
                                    location: t
                                });
                            case W.tx.ACTIVITY:
                                return n.createElement(ue, {
                                    key: r,
                                    activity: e,
                                    location: t
                                });
                            default:
                                return null
                        }
                    }))), n.createElement(h.Link, {
                        className: re.notiListLinkViewAll,
                        to: ne.N,
                        onClick: a
                    }, (0, u.t)("label_noti_view_all")))
                },
                pe = a(18363),
                fe = "_3OyQgy";
            var _e = {
                    updateLastViewedNotification: r.Nw.c
                },
                Ne = (0, i.connect)((function(e) {
                    return {
                        progress: r.nZ.getAPIProgress(e),
                        shouldUpdateLastViewedId: r.nZ.shouldUpdateLastViewedId(e)
                    }
                }), _e)((function(e) {
                    var t = e.isLoggedIn,
                        a = e.updateLastViewedNotification,
                        i = e.shouldUpdateLastViewedId,
                        r = e.notifications,
                        o = e.progress;
                    n.useEffect((function() {
                        o !== pe.Z.INIT && o !== pe.Z.REQ && i && a()
                    }), [o, i, a]);
                    var l = (0, Y.Z)("NotificationContainerSummary"),
                        s = r.length > 0,
                        m = n.createElement(c.Q, null);
                    return t ? s || o !== pe.Z.INIT && o !== pe.Z.REQ ? s && (m = n.createElement(de, {
                        notifications: r
                    })) : m = n.createElement(c.N, null) : m = n.createElement(g, null), n.createElement("div", {
                        className: fe,
                        ref: l
                    }, m)
                }))
        }
    }
]);
//# sourceMappingURL=https://shopee.sg/assets/PCSummaryNotificationContainer.937a7ad42f8692e2cba2.js.map