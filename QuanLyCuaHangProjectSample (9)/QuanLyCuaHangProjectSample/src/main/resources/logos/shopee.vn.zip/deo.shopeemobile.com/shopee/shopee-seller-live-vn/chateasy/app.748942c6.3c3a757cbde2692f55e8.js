! function(e) {
    function t(t) {
        for (var a, s, i = t[0], l = t[1], u = t[2], d = t[3] || [], f = 0, h = []; f < i.length; f++) s = i[f], Object.prototype.hasOwnProperty.call(r, s) && r[s] && h.push(r[s][0]), r[s] = 0;
        for (a in l) Object.prototype.hasOwnProperty.call(l, a) && (e[a] = l[a]);
        for (p && p(t), c.push.apply(c, d); h.length;) h.shift()();
        return o.push.apply(o, u || []), n()
    }

    function n() {
        for (var e, t = 0; t < o.length; t++) {
            for (var n = o[t], a = !0, l = 1; l < n.length; l++) {
                var u = n[l];
                0 !== r[u] && (a = !1)
            }
            a && (o.splice(t--, 1), e = i(i.s = n[0]))
        }
        return 0 === o.length && (c.forEach((function(e) {
            if (void 0 === r[e]) {
                r[e] = null;
                var t = document.createElement("link");
                i.nc && t.setAttribute("nonce", i.nc), t.rel = "prefetch", t.as = "script", t.href = s(e), document.head.appendChild(t)
            }
        })), c.length = 0), e
    }
    var a = {},
        r = {
            9: 0
        },
        o = [],
        c = [];

    function s(e) {
        return i.p + "" + ({
            7: "details.31ecd969",
            8: "details.91f4305a",
            11: "uploader.2a42e354",
            12: "uploader.31ecd969"
        }[e] || e) + "." + {
            7: "7539b5ed6f98f96b7bf6",
            8: "c280c0c8b7c0d4ab8c74",
            11: "fa4459b65ce7a808843b",
            12: "8999da1cc4038625bb6d"
        }[e] + ".js"
    }

    function i(t) {
        if (a[t]) return a[t].exports;
        var n = a[t] = {
            i: t,
            l: !1,
            exports: {}
        };
        return e[t].call(n.exports, n, n.exports, i), n.l = !0, n.exports
    }
    i.e = function(e) {
        var t = [],
            n = r[e];
        if (0 !== n)
            if (n) t.push(n[2]);
            else {
                var a = new Promise((function(t, a) {
                    n = r[e] = [t, a]
                }));
                t.push(n[2] = a);
                var o, c = document.createElement("script");
                c.charset = "utf-8", c.timeout = 120, i.nc && c.setAttribute("nonce", i.nc), c.src = s(e);
                var l = new Error;
                o = function(t) {
                    c.onerror = c.onload = null, clearTimeout(u);
                    var n = r[e];
                    if (0 !== n) {
                        if (n) {
                            var a = t && ("load" === t.type ? "missing" : t.type),
                                o = t && t.target && t.target.src;
                            l.message = "Loading chunk " + e + " failed.\n(" + a + ": " + o + ")", l.name = "ChunkLoadError", l.type = a, l.request = o, n[1](l)
                        }
                        r[e] = void 0
                    }
                };
                var u = setTimeout((function() {
                    o({
                        type: "timeout",
                        target: c
                    })
                }), 12e4);
                c.onerror = c.onload = o, document.head.appendChild(c)
            }
        return Promise.all(t)
    }, i.m = e, i.c = a, i.d = function(e, t, n) {
        i.o(e, t) || Object.defineProperty(e, t, {
            enumerable: !0,
            get: n
        })
    }, i.r = function(e) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
    }, i.t = function(e, t) {
        if (1 & t && (e = i(e)), 8 & t) return e;
        if (4 & t && "object" == typeof e && e && e.__esModule) return e;
        var n = Object.create(null);
        if (i.r(n), Object.defineProperty(n, "default", {
                enumerable: !0,
                value: e
            }), 2 & t && "string" != typeof e)
            for (var a in e) i.d(n, a, function(t) {
                return e[t]
            }.bind(null, a));
        return n
    }, i.n = function(e) {
        var t = e && e.__esModule ? function() {
            return e.default
        } : function() {
            return e
        };
        return i.d(t, "a", t), t
    }, i.o = function(e, t) {
        return Object.prototype.hasOwnProperty.call(e, t)
    }, i.p = "https://deo.shopeemobile.com/shopee/shopee-seller-live-vn/chateasy/", i.oe = function(e) {
        throw console.error(e), e
    };
    var l = window.miniJsonp = window.miniJsonp || [],
        u = l.push.bind(l);
    l.push = t, l = l.slice();
    for (var d = 0; d < l.length; d++) t(l[d]);
    var p = u,
        f = (o.push([0, 5, 4, 10, 1, 2, 3, 0, 6]), n());
    t([
        [], {},
        0, [5, 4, 1, 2, 3, 0, 6, 7, 8]
    ])
}({
    "+nW5": function(e, t, n) {
        "use strict";
        var a = n("q1tI"),
            r = n.n(a),
            o = n("17x9"),
            c = n.n(o),
            s = n("TSYQ"),
            i = n.n(s),
            l = n("ue+V"),
            u = n.n(l),
            d = n("MQp2"),
            p = n("FcmL"),
            f = n.n(p),
            h = n("vLVT"),
            m = n.n(h),
            v = n("lHcJ"),
            b = n.n(v),
            y = n("e2Ol"),
            g = n.n(y),
            w = n("vuYD"),
            C = n.n(w),
            O = {
                success: f.a,
                error: m.a,
                info: g.a,
                warn: b.a,
                resolved: f.a
            },
            R = function(e) {
                var t = e.type,
                    n = void 0 === t ? "info" : t,
                    a = e.showIcon,
                    o = e.icon,
                    c = e.closeable,
                    s = e.closeText,
                    l = e.onClose,
                    p = e.title,
                    f = e.message,
                    h = e.className;
                if (!f) return null;
                var m = a || o,
                    v = i()(u.a["alert-icon-".concat(n)], u.a.alertIcon, u.a.alertIconSize),
                    b = c || s,
                    y = i()(u.a.root, u.a[n], h);
                return r.a.createElement("div", {
                    className: y
                }, m && (O[n] ? r.a.createElement(d.Icon, {
                    svg: O[n],
                    className: v
                }) : null), r.a.createElement("div", {
                    className: u.a.content
                }, p && r.a.createElement("div", {
                    className: u.a.title
                }, p), r.a.createElement("div", {
                    className: u.a.message
                }, f)), b && r.a.createElement("div", {
                    className: u.a.alertClose,
                    onClick: function(e) {
                        return l && l(e)
                    }
                }, s || r.a.createElement(d.Icon, {
                    svg: C.a,
                    className: u.a.closeIcon
                })))
            };
        R.propTypes = {
            type: c.a.oneOf(["success", "error", "info", "warn", "resolved", "pending"]),
            showIcon: c.a.bool,
            icon: c.a.node,
            closeable: c.a.bool,
            closeText: c.a.node,
            onClose: c.a.func,
            message: c.a.node.isRequired,
            title: c.a.node,
            className: c.a.string
        }, t.a = R
    },
    0: function(e, t, n) {
        n("j36g"), n("87sv"), e.exports = n("tjUo")
    },
    1: function(e, t) {},
    "16Al": function(e, t, n) {
        "use strict";
        var a = n("WbBG");

        function r() {}

        function o() {}
        o.resetWarningCache = r, e.exports = function() {
            function e(e, t, n, r, o, c) {
                if (c !== a) {
                    var s = new Error("Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types");
                    throw s.name = "Invariant Violation", s
                }
            }

            function t() {
                return e
            }
            e.isRequired = e;
            var n = {
                array: e,
                bool: e,
                func: e,
                number: e,
                object: e,
                string: e,
                symbol: e,
                any: e,
                arrayOf: t,
                element: e,
                elementType: e,
                instanceOf: t,
                node: e,
                objectOf: t,
                oneOf: t,
                oneOfType: t,
                shape: t,
                exact: t,
                checkPropTypes: o,
                resetWarningCache: r
            };
            return n.PropTypes = n, n
        }
    },
    "17x9": function(e, t, n) {
        e.exports = n("16Al")()
    },
    2: function(e, t) {},
    "2e4M": function(e, t, n) {
        "use strict";
        (function(e) {
            n("I5cv");
            var a = n("lwsE"),
                r = n.n(a),
                o = n("W8MJ"),
                c = n.n(o),
                s = n("PJYZ"),
                i = n.n(s),
                l = n("7W2i"),
                u = n.n(l),
                d = n("a1gu"),
                p = n.n(d),
                f = n("Nsbk"),
                h = n.n(f),
                m = (n("2Spj"), n("q1tI")),
                v = n.n(m),
                b = n("17x9"),
                y = n.n(b),
                g = n("6xV8"),
                w = n.n(g),
                C = n("S4Or"),
                O = n.n(C);

            function R(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, a = h()(e);
                    if (t) {
                        var r = h()(this).constructor;
                        n = Reflect.construct(a, arguments, r)
                    } else n = a.apply(this, arguments);
                    return p()(this, n)
                }
            }
            var S = function(t) {
                u()(a, t);
                var n = R(a);

                function a(e) {
                    var t;
                    return r()(this, a), (t = n.call(this, e)).state = {
                        hasError: !1
                    }, t.handleReload = t.handleReload.bind(i()(t)), t
                }
                return c()(a, [{
                    key: "componentDidCatch",
                    value: function(e, t) {
                        this.setState({
                            hasError: !0
                        }), console.log("Minichat Component Error", e, "\n", t)
                    }
                }, {
                    key: "handleReload",
                    value: function() {
                        this.setState({
                            hasError: !1
                        }), this.forceUpdate()
                    }
                }, {
                    key: "render",
                    value: function() {
                        var t = v.a.createElement("div", {
                            className: w.a.error
                        }, v.a.createElement("img", {
                            className: w.a.img,
                            src: O.a
                        }), v.a.createElement("div", null, e("common.error.load_failed"), v.a.createElement("span", {
                            className: w.a.loadMore,
                            onClick: this.handleReload
                        }, e("common.error.click_retry"))));
                        return this.state.hasError ? t : this.props.children
                    }
                }]), a
            }(v.a.Component);
            S.propTypes = {
                children: y.a.node
            }, t.a = S
        }).call(this, n("kiXb").t)
    },
    "2r9f": function(e, t, n) {
        e.exports = n.p + "143e062750363ec2d5f8d5601a9b595a.png"
    },
    3: function(e, t) {},
    4: function(e, t) {},
    "7i0w": function(e, t, n) {
        "use strict";
        n.r(t), n.d(t, "on", (function() {
            return O
        })), n.d(t, "register", (function() {
            return R
        })), n.d(t, "remove", (function() {
            return S
        })), n.d(t, "dispatch", (function() {
            return E
        })), n.d(t, "watchModuleCenterChannel", (function() {
            return I
        }));
        var a = n("yXPU"),
            r = n.n(a),
            o = n("o0o1"),
            c = n.n(o),
            s = (n("8+KV"), n("Btvt"), n("VRzm"), n("xk4V")),
            i = n.n(s),
            l = n("wNa6"),
            u = n("rRWa"),
            d = n("5rFJ"),
            p = c.a.mark(N),
            f = c.a.mark(I),
            h = {},
            m = {},
            v = {},
            b = {},
            y = new MessageChannel,
            g = y.port1,
            w = y.port2,
            C = function(e, t) {
                g.postMessage(JSON.stringify({
                    moduleId: e,
                    action: t
                }))
            },
            O = function(e, t) {
                v[e] || (v[e] = t)
            },
            R = function(e) {
                if (!h[e]) {
                    h[e] = !0;
                    var t = m[e];
                    t && t.length && t.forEach((function(t) {
                        C(e, t)
                    }))
                }
            },
            S = function(e) {
                h[e] = !1, m[e] = null
            },
            k = function(e, t) {
                return new Promise(function() {
                    var a = r()(c.a.mark((function a(r, o) {
                        var s, u, d, p, f, v, y, g;
                        return c.a.wrap((function(a) {
                            for (;;) switch (a.prev = a.next) {
                                case 0:
                                    if (s = i()(), u = t.effect, d = t.actionName, p = t.actionPayload, f = t.couldDelay, v = void 0 !== f && f, y = {
                                            uuid: s
                                        }, b[s] = {
                                            actionName: d,
                                            effect: u,
                                            resolve: r,
                                            reject: o,
                                            actionPayload: p
                                        }, !h[e]) {
                                        a.next = 8;
                                        break
                                    }
                                    C(e, y), a.next = 20;
                                    break;
                                case 8:
                                    if (m[e] || (m[e] = []), m[e].push(y), v) {
                                        a.next = 20;
                                        break
                                    }
                                    g = null, a.t0 = e, a.next = "conversationDetail" === a.t0 ? 15 : 19;
                                    break;
                                case 15:
                                    return a.next = 17, Promise.all([n.e(5), n.e(4), n.e(1), n.e(2), n.e(3), n.e(0), n.e(6), n.e(7), n.e(8)]).then(n.bind(null, "Lzd8"));
                                case 17:
                                    return g = a.sent, a.abrupt("break", 19);
                                case 19:
                                    g && l.store.addModule(g.getModule());
                                case 20:
                                case "end":
                                    return a.stop()
                            }
                        }), a)
                    })));
                    return function(e, t) {
                        return a.apply(this, arguments)
                    }
                }())
            },
            E = {
                put: function(e, t) {
                    return t.effect = "put", console.log("dispatch put", e, t), k(e, t)
                },
                call: function(e, t) {
                    return t.effect = "call", k(e, t)
                }
            };

        function j() {
            return Object(u.eventChannel)((function(e) {
                return w.onmessage = function(t) {
                        e(JSON.parse(t.data))
                    },
                    function() {}
            }))
        }

        function N(e) {
            var t, n, a, r, o, s, i, l, u, f;
            return c.a.wrap((function(c) {
                for (;;) switch (c.prev = c.next) {
                    case 0:
                        t = e.moduleId, n = e.action, a = b[n.uuid], r = a.effect, o = a.actionName, s = a.actionPayload, i = a.resolve, l = a.reject, u = v[t][o], c.prev = 4, c.t0 = r, c.next = "put" === c.t0 ? 8 : "call" === c.t0 ? 12 : 17;
                        break;
                    case 8:
                        return c.next = 10, Object(d.put)(u(s));
                    case 10:
                        return i(), c.abrupt("break", 17);
                    case 12:
                        return c.next = 14, Object(d.call)(u, s);
                    case 14:
                        return f = c.sent, i(f), c.abrupt("break", 17);
                    case 17:
                        c.next = 22;
                        break;
                    case 19:
                        c.prev = 19, c.t1 = c.catch(4), l();
                    case 22:
                    case "end":
                        return c.stop()
                }
            }), p, null, [
                [4, 19]
            ])
        }

        function I() {
            var e;
            return c.a.wrap((function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return t.next = 2, Object(d.call)(j);
                    case 2:
                        return e = t.sent, t.next = 5, Object(d.takeEvery)(e, N);
                    case 5:
                    case "end":
                        return t.stop()
                }
            }), f)
        }
    },
    FL2V: function(e, t, n) {
        "use strict";
        var a = n("q1tI"),
            r = n.n(a),
            o = n("VLYj"),
            c = n("/MKj"),
            s = n("tvxL"),
            i = {
                operationRequest: s.conversationOperateRequested,
                showModal: s.showModal,
                closeModal: s.closeModal
            };
        t.a = Object(c.connect)((function(e, t) {
            return {
                lastMessage: Object(s.conversationLastMessageSelector)(t.conversation.id)(e)
            }
        }), i)((function(e) {
            return r.a.createElement(o.a, e)
        }))
    },
    FZfk: function(e, t, n) {
        "use strict";
        (function(e) {
            n("I5cv");
            var a = n("pVnL"),
                r = n.n(a),
                o = n("lwsE"),
                c = n.n(o),
                s = n("W8MJ"),
                i = n.n(s),
                l = n("PJYZ"),
                u = n.n(l),
                d = n("7W2i"),
                p = n.n(d),
                f = n("a1gu"),
                h = n.n(f),
                m = n("Nsbk"),
                v = n.n(m),
                b = (n("2Spj"), n("q1tI")),
                y = n.n(b),
                g = n("17x9"),
                w = n.n(g),
                C = n("gSTE"),
                O = n("b7p5"),
                R = n("XnKn"),
                S = n("+nW5"),
                k = n("LI8N"),
                E = n.n(k);

            function j(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, a = v()(e);
                    if (t) {
                        var r = v()(this).constructor;
                        n = Reflect.construct(a, arguments, r)
                    } else n = a.apply(this, arguments);
                    return h()(this, n)
                }
            }
            var N = function(t) {
                p()(a, t);
                var n = j(a);

                function a(e) {
                    var t;
                    return c()(this, a), (t = n.call(this, e)).handleCloseAlertTip = t.handleCloseAlertTip.bind(u()(t)), t.handleCloseStatusTip = t.handleCloseStatusTip.bind(u()(t)), t.state = {
                        shouldShowStatusTip: null
                    }, t
                }
                return i()(a, [{
                    key: "handleCloseAlertTip",
                    value: function() {
                        R.storage.set("mini-should-show-alert", !1), this.forceUpdate()
                    }
                }, {
                    key: "handleCloseStatusTip",
                    value: function() {
                        var e = this.state.shouldShowStatusTip;
                        this.setState({
                            shouldShowStatusTip: !e
                        })
                    }
                }, {
                    key: "mounted",
                    value: function() {
                        this.props.fetchDegradeConversationsDetail({})
                    }
                }, {
                    key: "render",
                    value: function() {
                        var t = this.state.shouldShowStatusTip,
                            n = this.props,
                            a = n.keyword,
                            o = n.socketFeedback,
                            c = n.networkStatus,
                            s = n.currentUser,
                            i = n.isScChat,
                            l = s.type,
                            u = s.distribution_status,
                            d = !1 !== R.storage.get("mini-should-show-alert"),
                            p = "subaccount" === l && "hang_up" === u && !0 !== t,
                            f = "online" === c ? o && o.network ? {
                                type: o.status,
                                message: o.content
                            } : null : {
                                type: "error",
                                message: e("common.network_offline")
                            };
                        return y.a.createElement("div", {
                            className: E.a.root
                        }, y.a.createElement(C.a, this.props), f && y.a.createElement(S.a, {
                            type: f.type,
                            showIcon: !0,
                            message: f.message
                        }), d && !i && y.a.createElement(S.a, {
                            type: "warn",
                            showIcon: !0,
                            closeable: !0,
                            message: e("common.alert"),
                            onClose: this.handleCloseAlertTip
                        }), p && y.a.createElement(S.a, {
                            type: "warn",
                            showIcon: !0,
                            closeable: !0,
                            message: e("common.hangup_tips"),
                            onClose: this.handleCloseStatusTip
                        }), y.a.createElement("div", {
                            className: E.a.conversationLists
                        }, y.a.createElement(O.a, r()({
                            isInSearch: !!a
                        }, this.props))))
                    }
                }]), a
            }(y.a.PureComponent);
            N.propTypes = {
                isScChat: w.a.bool,
                keyword: w.a.string,
                feedback: w.a.object,
                currentUser: w.a.object,
                networkStatus: w.a.string,
                socketFeedback: w.a.object,
                totalUnreadConversationsCount: w.a.number,
                fetchDegradeConversationsDetail: w.a.func
            }, t.a = N
        }).call(this, n("kiXb").t)
    },
    Hdln: function(e, t, n) {
        "use strict";
        var a = n("q1tI"),
            r = n.n(a),
            o = n("/MKj"),
            c = n("imT4"),
            s = n("tvxL"),
            i = {
                connectSocket: s.connectSocket,
                updateOpenedMenu: s.updateOpenedMenu,
                updateUserRequested: s.updateUserRequested,
                setToastInformation: s.setToastInformation,
                updateGuideRequested: s.updateGuideRequested,
                updateChatWindowStatus: s.updateChatWindowStatus,
                updateConversationDetailStatus: s.updateConversationDetailStatus,
                changeConversationStatusRequested: s.changeConversationStatusRequested
            };
        t.a = Object(o.connect)((function(e) {
            return {
                newbie: Object(s.newbieSelector)(e),
                toast: Object(s.toastSelector)(e),
                isScChat: Object(s.isScChatSelector)(e),
                openedMenu: Object(s.openedMenuSelector)(e),
                currentUser: Object(s.currentUserSelector)(e) || {},
                currentBuyer: Object(s.currentBuyerSelector)(e) || {},
                isSubAccount: Object(s.isSubAccountSelector)(e),
                loginSuccess: Object(s.loginSuccessSelector)(e),
                socketSuccess: Object(s.socketSuccessSelector)(e),
                totalUnreadCount: Object(s.totalUnreadConversationsCountSelector)(e),
                currentConversation: Object(s.currentConversationSelector)(e),
                currentConversationId: Object(s.currentConversationIdSelector)(e),
                showConversationDetail: Object(s.showConversationDetailSelector)(e)
            }
        }), i)((function(e) {
            return r.a.createElement(c.a, e)
        }))
    },
    Hxv6: function(e, t, n) {
        e.exports = n.p + "562e3d10ebf525cd541dd028a0acc192.png"
    },
    KmjB: function(e, t, n) {
        "use strict";
        (function(e) {
            n.d(t, "a", (function() {
                return a
            })), n.d(t, "f", (function() {
                return r
            })), n.d(t, "d", (function() {
                return o
            })), n.d(t, "b", (function() {
                return c
            })), n.d(t, "c", (function() {
                return s
            })), n.d(t, "e", (function() {
                return i
            })), n.d(t, "g", (function() {
                return l
            }));
            n("YJVH"), n("Vd3H"), n("8+KV"), n("V+eJ"), n("KKXr"), n("L9s1"), n("Z2Ku"), n("Tze0"), n("RW0V"), n("mGWK"), n("LK8F"), n("Oyvg"), n("pIFo"), n("Btvt"), n("h7Nl"), n("a1Th"), n("r1bV"), n("NO8f"), n("I78e"), n("f3/d"), n("ioFf"), n("HEwt"), n("XfO3"), n("yt8O"), n("rGqo");
            var a = function(e, t) {
                    return e.length === t.length && e.every((function(e, n) {
                        return e === t[n]
                    }))
                },
                r = function(e, t) {
                    return e > t
                },
                o = function(e) {
                    return e[e.length - 1]
                },
                c = function(e) {
                    return "string" == typeof e && (e = e.trim()), !(!e || 0 === Object.keys(e).length)
                },
                s = function(e, t) {
                    var n = null;
                    return function() {
                        for (var a = arguments.length, r = new Array(a), o = 0; o < a; o++) r[o] = arguments[o];
                        n && (clearTimeout(n), n = null), n = setTimeout((function() {
                            e.apply(void 0, r)
                        }), t)
                    }
                },
                i = function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "",
                        t = arguments.length > 1 ? arguments[1] : void 0,
                        n = document.createElement("input"),
                        a = document.getElementById(window.miniChatContainerId) || document.body;
                    n.setAttribute("readonly", "readonly"), n.setAttribute("value", e), a.appendChild(n), n.focus(), n.setSelectionRange(0, -1), document.execCommand("copy") && t && t(), a.removeChild(n)
                },
                l = function(t) {
                    return "string" == typeof t ? t : e(t.key, t.vars)
                }
        }).call(this, n("kiXb").t)
    },
    O8oF: function(e, t, n) {
        "use strict";
        var a = n("q1tI"),
            r = n.n(a),
            o = n("17x9"),
            c = n.n(o),
            s = n("SUBy"),
            i = n("WBRc"),
            l = n("AlKw"),
            u = n.n(l),
            d = n("tvxL"),
            p = function(e) {
                var t = e.style,
                    n = e.conversation,
                    a = e.keyword,
                    o = e.isSubAccount,
                    c = e.onClick,
                    l = e.shopFilter,
                    p = n.avatar,
                    f = n.avatar_hash,
                    h = n.to_name,
                    m = n.shop_name;
                return r.a.createElement("div", {
                    style: t,
                    className: u.a.root,
                    onClick: function() {
                        Object(d.tracker)({
                            type: "search_name_result"
                        }), c(n)
                    }
                }, r.a.createElement("div", {
                    className: u.a.avatar
                }, r.a.createElement(s.a, {
                    avatar: p,
                    avatarHash: f
                })), r.a.createElement("div", {
                    className: u.a.wrapper
                }, r.a.createElement("div", {
                    className: u.a.username
                }, r.a.createElement(i.a, {
                    highlightClassName: u.a.keyword,
                    searchWords: a,
                    textToHighlight: h
                })), o && !l && r.a.createElement("div", {
                    className: u.a.shop
                }, r.a.createElement("div", {
                    className: u.a.text,
                    title: m
                }, m))))
            };
        p.propTypes = {
            style: c.a.object,
            conversation: c.a.object,
            keyword: c.a.string,
            shopFilter: c.a.object,
            isSubAccount: c.a.bool,
            onClick: c.a.func.isRequired
        }, t.a = p
    },
    OTLN: function(e, t, n) {
        "use strict";
        n("I5cv"), n("RW0V"), n("ioFf"), n("0l/t"), n("mYba"), n("8+KV"), n("jm62"), n("WLL4"), n("HAE/");
        var a = n("lSNA"),
            r = n.n(a),
            o = n("lwsE"),
            c = n.n(o),
            s = n("W8MJ"),
            i = n.n(s),
            l = n("7W2i"),
            u = n.n(l),
            d = n("a1gu"),
            p = n.n(d),
            f = n("Nsbk"),
            h = n.n(f),
            m = n("q1tI"),
            v = n.n(m),
            b = n("17x9"),
            y = n.n(b),
            g = n("8Oat"),
            w = n.n(g),
            C = n("dRu9"),
            O = n("MQp2"),
            R = n("FcmL"),
            S = n.n(R),
            k = n("vLVT"),
            E = n.n(k),
            j = n("lHcJ"),
            N = n.n(j),
            I = n("e2Ol"),
            x = n.n(I),
            M = n("i8i4");

        function P(e, t) {
            var n = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var a = Object.getOwnPropertySymbols(e);
                t && (a = a.filter((function(t) {
                    return Object.getOwnPropertyDescriptor(e, t).enumerable
                }))), n.push.apply(n, a)
            }
            return n
        }

        function _(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n = null != arguments[t] ? arguments[t] : {};
                t % 2 ? P(Object(n), !0).forEach((function(t) {
                    r()(e, t, n[t])
                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : P(Object(n)).forEach((function(t) {
                    Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                }))
            }
            return e
        }

        function T(e) {
            var t = function() {
                if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                if (Reflect.construct.sham) return !1;
                if ("function" == typeof Proxy) return !0;
                try {
                    return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                } catch (e) {
                    return !1
                }
            }();
            return function() {
                var n, a = h()(e);
                if (t) {
                    var r = h()(this).constructor;
                    n = Reflect.construct(a, arguments, r)
                } else n = a.apply(this, arguments);
                return p()(this, n)
            }
        }
        var L = {
                transition: "opacity ".concat(200, "ms ease-in-out"),
                opacity: 0
            },
            W = {
                success: S.a,
                fail: E.a,
                error: E.a,
                info: x.a,
                warn: N.a
            },
            D = {
                entering: {
                    opacity: 0
                },
                entered: {
                    opacity: 1
                },
                exiting: {
                    opacity: 1
                },
                exited: {
                    opacity: 0
                }
            },
            A = function(e) {
                u()(n, e);
                var t = T(n);

                function n(e) {
                    var a;
                    return c()(this, n), (a = t.call(this, e)).state = {
                        show: !1
                    }, a.timer = null, a.eventListenerAdded = !1, a
                }
                return i()(n, [{
                    key: "componentWillUnmount",
                    value: function() {
                        this.timer && clearTimeout(this.timer)
                    }
                }, {
                    key: "render",
                    value: function() {
                        var e = this,
                            t = this.props,
                            n = t.toast,
                            a = n.type,
                            r = n.message,
                            o = t.isScChat,
                            c = this.state.show,
                            s = "".concat(o ? w.a.root : w.a.mall, " ").concat(c ? w.a.show : ""),
                            i = "".concat(w.a.icon, " ").concat(w.a[a]),
                            l = W[a];
                        return Object(M.createPortal)(v.a.createElement(C.a, { in: c,
                            timeout: 200,
                            addEndListener: function(t) {
                                e.eventListenerAdded || (t.addEventListener("transitionend", (function() {
                                    e.state.show && (e.timer && clearTimeout(e.timer), e.timer = setTimeout((function() {
                                        e.setState({
                                            show: !1
                                        }, (function() {
                                            e.timer && clearTimeout(e.timer), e.props.setToastInformation({
                                                toast: {
                                                    type: "",
                                                    message: "",
                                                    show: !1
                                                }
                                            })
                                        }))
                                    }), 1500))
                                }), !1), e.eventListenerAdded = !0)
                            }
                        }, (function(e) {
                            return v.a.createElement("div", {
                                className: s,
                                style: _(_({}, L), D[e])
                            }, l && v.a.createElement(O.Icon, {
                                svg: l,
                                className: i
                            }), v.a.createElement("div", {
                                className: w.a.message
                            }, r))
                        })), document.body)
                    }
                }], [{
                    key: "getDerivedStateFromProps",
                    value: function(e) {
                        var t = e.toast,
                            n = t.message,
                            a = t.show;
                        return n ? a ? {
                            show: a
                        } : null : {
                            show: !1
                        }
                    }
                }]), n
            }(v.a.PureComponent);
        A.propTypes = {
            toast: y.a.object,
            isScChat: y.a.bool,
            setToastInformation: y.a.func
        }, t.a = A
    },
    OW4m: function(e, t, n) {
        "use strict";
        n("RW0V"), n("ioFf"), n("0l/t"), n("mYba"), n("8+KV"), n("jm62"), n("WLL4"), n("HAE/");
        var a = n("lSNA"),
            r = n.n(a),
            o = n("XnKn");

        function c(e, t) {
            var n = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var a = Object.getOwnPropertySymbols(e);
                t && (a = a.filter((function(t) {
                    return Object.getOwnPropertyDescriptor(e, t).enumerable
                }))), n.push.apply(n, a)
            }
            return n
        }

        function s(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n = null != arguments[t] ? arguments[t] : {};
                t % 2 ? c(Object(n), !0).forEach((function(t) {
                    r()(e, t, n[t])
                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : c(Object(n)).forEach((function(t) {
                    Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                }))
            }
            return e
        }
        var i = null,
            l = null,
            u = "";
        window.addEventListener("message", (function(e) {
            e.data.received && window.clearInterval(l)
        }), !1), t.a = function(e) {
            var t = e.currentConversation,
                n = void 0 === t ? {} : t,
                a = e.webChatUrl;
            return Object(o.getItem)("mini-sc_redirect").then((function(e) {
                e && e.conversationId === n.id || (e = {
                    shopId: n.shop_id,
                    userId: n.to_id
                });
                var t = s(s({}, e), {}, {
                    type: "MiniChatRedirect"
                });
                i && !i.closed ? (u !== a && (i.location.href = a), i.focus()) : i = window.open("".concat(a), "_blank"), u = a, l && window.clearInterval(l), l = window.setInterval((function() {
                    try {
                        i.postMessage(t, a)
                    } catch (e) {
                        i = null, window.clearInterval(l)
                    }
                }), 1e3)
            }))
        }
    },
    QiV6: function(e, t) {
        performance && performance.mark && performance.mark("STATIC_LOADED")
    },
    S4Or: function(e, t, n) {
        e.exports = n.p + "91095bcead05511cb1282ef16d60c2bf.png"
    },
    "S7/o": function(e, t, n) {
        "use strict";
        n("I5cv"), n("ioFf"), n("0l/t"), n("mYba"), n("jm62"), n("WLL4"), n("HAE/");
        var a = n("pVnL"),
            r = n.n(a),
            o = n("lSNA"),
            c = n.n(o),
            s = n("QILm"),
            i = n.n(s),
            l = n("lwsE"),
            u = n.n(l),
            d = n("W8MJ"),
            p = n.n(d),
            f = n("PJYZ"),
            h = n.n(f),
            m = n("7W2i"),
            v = n.n(m),
            b = n("a1gu"),
            y = n.n(b),
            g = n("Nsbk"),
            w = n.n(g),
            C = (n("2Spj"), n("L9s1"), n("Z2Ku"), n("8+KV"), n("RW0V"), n("bWfx"), n("fN96"), n("xfY5"), n("q1tI")),
            O = n.n(C),
            R = n("17x9"),
            S = n.n(R),
            k = n("dGdO"),
            E = n.n(k),
            j = n("MQp2"),
            N = n("KmjB"),
            I = n("C5SH"),
            x = n("s3ZY"),
            M = n("GqUL"),
            P = n("Iatj"),
            _ = n("4LQ7"),
            T = ["stopIndex"];

        function L(e, t) {
            var n = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var a = Object.getOwnPropertySymbols(e);
                t && (a = a.filter((function(t) {
                    return Object.getOwnPropertyDescriptor(e, t).enumerable
                }))), n.push.apply(n, a)
            }
            return n
        }

        function W(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n = null != arguments[t] ? arguments[t] : {};
                t % 2 ? L(Object(n), !0).forEach((function(t) {
                    c()(e, t, n[t])
                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : L(Object(n)).forEach((function(t) {
                    Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                }))
            }
            return e
        }

        function D(e) {
            var t = function() {
                if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                if (Reflect.construct.sham) return !1;
                if ("function" == typeof Proxy) return !0;
                try {
                    return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                } catch (e) {
                    return !1
                }
            }();
            return function() {
                var n, a = w()(e);
                if (t) {
                    var r = w()(this).constructor;
                    n = Reflect.construct(a, arguments, r)
                } else n = a.apply(this, arguments);
                return y()(this, n)
            }
        }
        var A = function(e) {
            v()(n, e);
            var t = D(n);

            function n(e) {
                var a;
                return u()(this, n), (a = t.call(this, e)).listRef = null, a.cellMeasureRefs = {}, a.scrollTop = 0, a.onRowsRendered = null, a.state = {
                    loadedRowsMap: {}
                }, a.cache = new P.a({
                    fixedWidth: !0
                }), a.isRowLoaded = a.isRowLoaded.bind(h()(a)), a.rowRenderer = a.rowRenderer.bind(h()(a)), a.cellRenderer = a.cellRenderer.bind(h()(a)), a.loadMoreRows = a.loadMoreRows.bind(h()(a)), a.handleScroll = a.handleScroll.bind(h()(a)), a.remeasure = Object(N.c)(a.remeasure.bind(h()(a)), 500), a.setCellMeasureRef = a.setCellMeasureRef.bind(h()(a)), a.onSectionRendered = a.onSectionRendered.bind(h()(a)), a.handleRowRendered = a.handleRowRendered.bind(h()(a)), a.renderAutoSizerList = a.renderAutoSizerList.bind(h()(a)), a
            }
            return p()(n, [{
                key: "componentDidUpdate",
                value: function(e) {
                    var t = e.extraProps,
                        n = e.listItems,
                        a = this.props,
                        r = a.listItems,
                        o = a.needRemeasure,
                        c = a.extraProps;
                    o && ([r.length + 1, r.length - 1].includes(n.length) || t.measureFlag !== c.measureFlag) && this.remeasure()
                }
            }, {
                key: "remeasure",
                value: function() {
                    var e = this;
                    this.cache.clearAll(), this.listRef && this.listRef.recomputeRowHeights(), this.cellMeasureRefs && Object.keys(this.cellMeasureRefs).forEach((function(t) {
                        e.cellMeasureRefs[t] && e.cellMeasureRefs[t]._maybeMeasureCell()
                    }))
                }
            }, {
                key: "setCellMeasureRef",
                value: function(e, t) {
                    this.cellMeasureRefs[e] = t
                }
            }, {
                key: "handleRowRendered",
                value: function(e) {
                    var t = e.stopIndex,
                        n = i()(e, T),
                        a = this.props.handleRowRendered;
                    a && a(t), this.onRowsRendered && this.onRowsRendered(W({
                        stopIndex: t
                    }, n))
                }
            }, {
                key: "onSectionRendered",
                value: function(e) {
                    var t = e.columnStartIndex,
                        n = e.columnStopIndex,
                        a = e.rowStartIndex,
                        r = e.rowStopIndex,
                        o = this.props.columnCount,
                        c = a * o + t,
                        s = r * o + n;
                    this.onRowsRendered({
                        startIndex: c,
                        stopIndex: s
                    })
                }
            }, {
                key: "handleScroll",
                value: function(e) {
                    var t = e.scrollTop,
                        n = this.props,
                        a = n.handleComponentScroll,
                        r = n.handleListScroll;
                    r && r(t), this.scrollTop > t ? a("up") : a("down"), this.scrollTop = t
                }
            }, {
                key: "rowRenderer",
                value: function(e) {
                    var t = e.key,
                        n = e.index,
                        a = (e.isScrolling, e.isVisible, e.parent),
                        r = e.style,
                        o = this.props,
                        c = o.listItems,
                        s = o.makeRenderedCell,
                        i = c[n];
                    if (!i) return null;
                    var l = "".concat(t, "_").concat(i.id);
                    return (O.a.createElement(M.a, {
                        key: l,
                        parent: a,
                        columnIndex: 0,
                        rowIndex: n,
                        cache: this.cache
                    }, (function(e) {
                        var t = e.measure;
                        return s(i, r, t)
                    })))
                }
            }, {
                key: "cellRenderer",
                value: function(e) {
                    var t = this,
                        n = e.columnIndex,
                        a = (e.isScrolling, e.isVisible, e.key, e.parent),
                        r = e.rowIndex,
                        o = e.style,
                        c = this.props,
                        s = c.listItems,
                        i = c.columnCount,
                        l = c.makeRenderedCell,
                        u = s[r * i + n];
                    if (u) {
                        var d = "".concat(u.id, "_card");
                        return (O.a.createElement(M.a, {
                            key: d,
                            parent: a,
                            cache: this.cache,
                            rowIndex: r,
                            columnIndex: n,
                            ref: function(e) {
                                return t.setCellMeasureRef(d, e)
                            }
                        }, (function(e) {
                            var t = e.measure;
                            return l(u, o, t)
                        })))
                    }
                }
            }, {
                key: "loadMoreRows",
                value: function(e) {
                    var t = e.startIndex,
                        n = e.failedStatus,
                        a = void 0 === n ? "" : n,
                        r = this.state.loadedRowsMap;
                    if (!r[t]) {
                        var o = this.props,
                            s = o.status;
                        (0, o.loadMoreRowsRequested)({
                            needReset: "failedInit" === a
                        }), s.includes("failed") || this.setState({
                            loadedRowsMap: W(W({}, r), {}, c()({}, t, !0))
                        })
                    }
                }
            }, {
                key: "isRowLoaded",
                value: function(e) {
                    var t = e.index;
                    return !!this.props.listItems[t]
                }
            }, {
                key: "renderAutoSizerList",
                value: function(e, t) {
                    var n = this,
                        a = this.props,
                        o = a.listItems,
                        c = a.extraProps,
                        s = a.getListRef,
                        i = a.needScrollSpace;
                    this.onRowsRendered = e;
                    var l = o.length || 0;
                    return (O.a.createElement(x.a, null, (function(e) {
                        var a = e.width,
                            o = e.height;
                        return (O.a.createElement(I.a, r()({
                            ref: function(e) {
                                n.listRef = e, s && s(e), t && t(e)
                            },
                            width: a,
                            height: o,
                            overscanRowCount: 20,
                            rowCount: l,
                            onScroll: n.handleScroll,
                            rowRenderer: n.rowRenderer,
                            rowHeight: n.cache.rowHeight,
                            onRowsRendered: n.handleRowRendered,
                            deferredMeasurementCache: n.cache,
                            onRecomputeGrid: function() {},
                            containerStyle: {},
                            className: "".concat(E.a.list, " ").concat(i ? E.a.space : "")
                        }, c)))
                    })))
                }
            }, {
                key: "render",
                value: function() {
                    var e = this;
                    return (O.a.createElement("div", {
                        className: E.a.root
                    }, this.props.isInfinite ? O.a.createElement(_.a, {
                        rowCount: 9999,
                        isRowLoaded: this.isRowLoaded,
                        loadMoreRows: this.loadMoreRows
                    }, (function(t) {
                        var n = t.onRowsRendered,
                            a = t.registerChild;
                        return e.renderAutoSizerList(n, a)
                    })) : this.renderAutoSizerList()))
                }
            }], [{
                key: "getDerivedStateFromProps",
                value: function(e, t) {
                    var n = t.loadedRowsMap,
                        a = e.status,
                        r = e.resetRowsMap,
                        o = e.onResetCacheMap;
                    if (r) return o && o(), {
                        loadedRowsMap: {}
                    };
                    if (a.includes("failed")) {
                        var s = Object.keys(n).map((function(e) {
                                return parseInt(e)
                            })),
                            i = Math.max.apply(null, s);
                        return i = Number.isInteger(i) ? i : 0, {
                            loadedRowsMap: W(W({}, n), {}, c()({}, i, !1))
                        }
                    }
                    return null
                }
            }]), n
        }(O.a.PureComponent);
        A.propTypes = {
            status: S.a.string,
            isInfinite: S.a.bool,
            listItems: S.a.array,
            rowHeight: S.a.number,
            getListRef: S.a.func,
            resetRowsMap: S.a.bool,
            extraProps: S.a.object,
            columnCount: S.a.number,
            columnWidth: S.a.number,
            needRemeasure: S.a.bool,
            needScrollSpace: S.a.bool,
            makeRenderedCell: S.a.func,
            handleListScroll: S.a.func,
            handleRowRendered: S.a.func,
            loadMoreRowsRequested: S.a.func,
            handleComponentScroll: S.a.func,
            onResetCacheMap: S.a.func
        }, A.defaultProps = {
            status: "",
            listItems: [],
            extraProps: {},
            isInfinite: !0,
            resetRowsMap: !1,
            needRemeasure: !1,
            needScrollSpace: !1
        }, t.a = Object(j.CatchStatus)(A)
    },
    SUBy: function(e, t, n) {
        "use strict";
        n("I5cv");
        var a = n("lwsE"),
            r = n.n(a),
            o = n("W8MJ"),
            c = n.n(o),
            s = n("7W2i"),
            i = n.n(s),
            l = n("a1gu"),
            u = n.n(l),
            d = n("Nsbk"),
            p = n.n(d),
            f = (n("pIFo"), n("Tze0"), n("q1tI")),
            h = n.n(f),
            m = n("17x9"),
            v = n.n(m),
            b = n("MQp2"),
            y = n("KjsW"),
            g = n.n(y),
            w = n("CYsx"),
            C = n.n(w),
            O = n("kuoV"),
            R = n.n(O),
            S = ["blue", "green", "orange", "purple", "red", "yellow"],
            k = ["blue-gray", "green-gray", "orange-gray", "purple-gray", "red-gray", "yellow-gray"],
            E = function(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "",
                    n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "member",
                    a = e % S.length;
                return "member" === n ? "inactive" === t ? k[a] : S[a] : "inactive" === t ? "group-gray" : "group"
            };

        function j(e) {
            var t = function() {
                if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                if (Reflect.construct.sham) return !1;
                if ("function" == typeof Proxy) return !0;
                try {
                    return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                } catch (e) {
                    return !1
                }
            }();
            return function() {
                var n, a = p()(e);
                if (t) {
                    var r = p()(this).constructor;
                    n = Reflect.construct(a, arguments, r)
                } else n = a.apply(this, arguments);
                return u()(this, n)
            }
        }
        var N = /[\uD800-\uDBFF][\uDC00-\uDFFF]/g,
            I = {
                shop: g.a,
                user: C.a
            },
            x = function(e) {
                i()(n, e);
                var t = j(n);

                function n() {
                    return r()(this, n), t.apply(this, arguments)
                }
                return c()(n, [{
                    key: "render",
                    value: function() {
                        var e = this.props,
                            t = e.icon,
                            n = e.shape,
                            a = e.status,
                            r = e.avatar,
                            o = e.avatarHash,
                            c = e.userId,
                            s = e.origin,
                            i = e.username,
                            l = e.avatarRef,
                            u = e.fontSize,
                            d = void 0 === u ? 24 : u,
                            p = e.type,
                            f = void 0 === p ? "member" : p,
                            m = null,
                            v = null;
                        return r || (m = "cb" === s ? "member" === f ? "".concat(R.a[E(c, a, f)], " ").concat(R.a["font".concat(d)]) : "".concat(R.a[E(c, a, f)]) : "", "member" !== f || t || (v = (i || "S").trim().replace(N, "#")[0])), h.a.createElement("div", {
                            ref: function(e) {
                                l && l(e)
                            },
                            className: "".concat(R.a.root, " ").concat(R.a[n])
                        }, r ? h.a.createElement("div", {
                            className: R.a.avatarWrapper
                        }, h.a.createElement(b.Image, {
                            src: r,
                            hash: o
                        }), h.a.createElement("div", {
                            className: R.a.avatarBorder
                        })) : t ? h.a.createElement("div", {
                            className: m,
                            style: {
                                width: "100%",
                                height: "100%"
                            }
                        }, h.a.createElement("div", {
                            className: R.a["".concat(t, "Icon")]
                        })) : "cb" === s ? "member" !== f ? h.a.createElement("div", {
                            className: m
                        }) : h.a.createElement("div", {
                            className: m
                        }, v.toUpperCase()) : h.a.createElement(b.Icon, {
                            svg: I[s],
                            className: R.a[s]
                        }))
                    }
                }]), n
            }(h.a.PureComponent);
        x.propTypes = {
            avatar: v.a.string,
            username: v.a.string,
            userId: v.a.number,
            avatarRef: v.a.func,
            status: v.a.string,
            type: v.a.string,
            icon: v.a.string,
            origin: v.a.string,
            avatarHash: v.a.string,
            shape: v.a.string,
            fontSize: v.a.number
        }, x.defaultProps = {
            origin: "user",
            shape: "square"
        };
        t.a = x
    },
    SdKD: function(e, t, n) {
        "use strict";
        var a = n("lSNA"),
            r = n.n(a),
            o = n("J4zp"),
            c = n.n(o),
            s = (n("f3/d"), n("bWfx"), n("q1tI")),
            i = n.n(s),
            l = n("RBR7"),
            u = n.n(l),
            d = n("17x9"),
            p = n.n(d),
            f = (n("I5cv"), n("lwsE")),
            h = n.n(f),
            m = n("W8MJ"),
            v = n.n(m),
            b = n("7W2i"),
            y = n.n(b),
            g = n("a1gu"),
            w = n.n(g),
            C = n("Nsbk"),
            O = n.n(C),
            R = n("sF2i"),
            S = n.n(R);

        function k(e) {
            var t = function() {
                if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                if (Reflect.construct.sham) return !1;
                if ("function" == typeof Proxy) return !0;
                try {
                    return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                } catch (e) {
                    return !1
                }
            }();
            return function() {
                var n, a = O()(e);
                if (t) {
                    var r = O()(this).constructor;
                    n = Reflect.construct(a, arguments, r)
                } else n = a.apply(this, arguments);
                return w()(this, n)
            }
        }
        var E = function(e) {
            y()(n, e);
            var t = k(n);

            function n() {
                return h()(this, n), t.apply(this, arguments)
            }
            return v()(n, [{
                key: "render",
                value: function() {
                    var e = this.props,
                        t = e.icon,
                        n = e.label,
                        a = e.iconComp;
                    return (i.a.createElement("div", {
                        key: t,
                        className: "".concat(S.a.base, " ").concat(a ? "" : S.a[t])
                    }, a, n))
                }
            }]), n
        }(i.a.PureComponent);
        E.propTypes = {
            iconComp: p.a.node,
            icon: p.a.string,
            label: p.a.string
        };
        var j = E,
            N = n("MQp2"),
            I = n("4ToT"),
            x = n.n(I),
            M = function(e) {
                var t = e.content,
                    n = e.label,
                    a = e.labelStyle,
                    o = e.options,
                    l = e.onOpen,
                    d = e.onClose,
                    p = e.placement,
                    f = e.distance,
                    h = e.settingNodeRef,
                    m = Object(s.useState)({}),
                    v = c()(m, 2),
                    b = v[0],
                    y = v[1],
                    g = Object(s.useRef)({}),
                    w = Object(s.useState)(!1),
                    C = c()(w, 2),
                    O = C[0],
                    R = C[1],
                    S = function() {
                        R(!1), d && d()
                    },
                    k = function(e, t) {
                        if (e && t.isOutLink) {
                            var n = r()({}, t.id, !0);
                            y(n)
                        } else y({})
                    };
                return i.a.createElement("div", {
                    className: u.a.root,
                    onClick: function(e) {
                        e.stopPropagation()
                    }
                }, i.a.createElement(N.Popover, {
                    className: u.a.popover,
                    trigger: "click",
                    placement: p,
                    distance: f,
                    withState: !1,
                    isOpen: O,
                    setIsOpen: function(e) {
                        e ? (R(!0), l && l()) : (R(!1), d && d())
                    },
                    content: i.a.createElement("div", {
                        style: g.current.portal,
                        className: u.a.portal
                    }, i.a.createElement("div", {
                        style: g.current.list,
                        className: u.a.list
                    }, t ? t(S) : o.map((function(e, t) {
                        return function(e, t) {
                            var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
                                a = e.id,
                                r = e.icon,
                                o = e.iconComp,
                                c = e.name,
                                s = e.node,
                                l = e.handleSelect,
                                d = e.meta,
                                p = void 0 === d ? {} : d,
                                f = p.hasRedPoint,
                                m = "".concat(c ? u.a.option : u.a.node),
                                v = r || o ? i.a.createElement(j, {
                                    icon: r,
                                    iconComp: o,
                                    label: c
                                }) : c;
                            return i.a.createElement("div", {
                                key: "item".concat(n),
                                className: m,
                                onClick: function(e) {
                                    l && l(), t(e), e.stopPropagation()
                                },
                                onMouseEnter: function() {
                                    return k(!0, e)
                                },
                                onMouseLeave: function() {
                                    return k(!1, e)
                                },
                                ref: p.isSettingMenu && h
                            }, b[a] && i.a.createElement("div", {
                                className: u.a.outerLink
                            }, i.a.createElement(N.Icon, {
                                svg: x.a,
                                className: u.a.outerLinkIcon
                            })), c ? f ? i.a.createElement("div", {
                                className: u.a.reddot
                            }, v) : v : s)
                        }(e, S, t)
                    }))))
                }, i.a.createElement("div", {
                    style: a,
                    className: u.a.button
                }, n)))
            };
        M.propTypes = {
            label: p.a.node,
            placement: p.a.string,
            distance: p.a.number,
            options: p.a.array,
            settingNodeRef: p.a.func,
            onOpen: p.a.func,
            onClose: p.a.func,
            labelStyle: p.a.object,
            content: p.a.oneOfType([p.a.func, p.a.node])
        };
        t.a = M
    },
    VLYj: function(e, t, n) {
        "use strict";
        (function(e) {
            n("I5cv");
            var a = n("lwsE"),
                r = n.n(a),
                o = n("W8MJ"),
                c = n.n(o),
                s = n("PJYZ"),
                i = n.n(s),
                l = n("7W2i"),
                u = n.n(l),
                d = n("a1gu"),
                p = n.n(d),
                f = n("Nsbk"),
                h = n.n(f),
                m = (n("2Spj"), n("Z2Ku"), n("91GP"), n("q1tI")),
                v = n.n(m),
                b = n("17x9"),
                y = n.n(b),
                g = n("SdKD"),
                w = n("SUBy"),
                C = n("MQp2"),
                O = n("tvxL"),
                R = n("XnKn"),
                S = n("4iwc"),
                k = n.n(S),
                E = n("0zYX"),
                j = n.n(E),
                N = n("xNaz"),
                I = n.n(N),
                x = n("0D0a"),
                M = n.n(x),
                P = n("3rmy"),
                _ = n.n(P),
                T = n("4+Ig"),
                L = n.n(T),
                W = n("UZrK"),
                D = n.n(W),
                A = n("zMki"),
                q = n.n(A),
                F = n("AlKw"),
                B = n.n(F);

            function U(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, a = h()(e);
                    if (t) {
                        var r = h()(this).constructor;
                        n = Reflect.construct(a, arguments, r)
                    } else n = a.apply(this, arguments);
                    return p()(this, n)
                }
            }
            var H = {
                    pin: j.a,
                    unpin: j.a,
                    mark_as_read: M.a,
                    mark_as_unread: M.a,
                    delete: L.a,
                    close: _.a,
                    restart: D.a
                },
                K = function(t) {
                    u()(a, t);
                    var n = U(a);

                    function a(e) {
                        var t;
                        return r()(this, a), (t = n.call(this, e)).state = {
                            hover: !1,
                            opened: !1
                        }, t.rootNode = null, t.sendTracker = t.sendTracker.bind(i()(t)), t.handleMouseEvent = t.handleMouseEvent.bind(i()(t)), t.getConversationMenuOptions = t.getConversationMenuOptions.bind(i()(t)), t.handleConversationMenuOpen = t.handleConversationMenuOpen.bind(i()(t)), t.handleConversationMenuClose = t.handleConversationMenuClose.bind(i()(t)), t.getConversationStatus = t.getConversationStatus.bind(i()(t)), t.getOperationItem = t.getOperationItem.bind(i()(t)), t.getCommonOptions = t.getCommonOptions.bind(i()(t)), t.getSubAccountMenuOptions = t.getSubAccountMenuOptions.bind(i()(t)), t
                    }
                    return c()(a, [{
                        key: "sendTracker",
                        value: function(e, t) {
                            Object(O.tracker)({
                                section: e,
                                type: t
                            })
                        }
                    }, {
                        key: "handleConversationMenuOpen",
                        value: function() {
                            this.sendTracker("chat_list", "chat_more");
                            var e = this.props;
                            (0, e.updateOpenedMenu)(e.conversation.id), this.setState({
                                opened: !0
                            })
                        }
                    }, {
                        key: "handleConversationMenuClose",
                        value: function() {
                            var e = this.props,
                                t = e.conversation,
                                n = e.openedMenu,
                                a = this.state.hover;
                            t.id !== n && a && (a = !1), this.setState({
                                hover: a,
                                opened: !1
                            })
                        }
                    }, {
                        key: "getOperationItem",
                        value: function(t, n) {
                            var a = this,
                                r = this.props,
                                o = r.operationRequest,
                                c = r.showModal,
                                s = r.closeModal;
                            return {
                                iconComp: v.a.createElement(C.Icon, {
                                    svg: H[t],
                                    className: B.a.optionsIcon
                                }),
                                icon: t,
                                name: e("common.".concat("delete" === t ? "delete_chat" : t)),
                                handleSelect: function() {
                                    var r;
                                    "delete" === t ? c({
                                        type: "CONFIRM_MODAL",
                                        title: {
                                            key: "conversation_list.conversation_cell.menu.delete_chat_title"
                                        },
                                        actions: {
                                            cancel: {
                                                label: {
                                                    key: "common.cancel"
                                                },
                                                handler: function() {
                                                    s()
                                                }
                                            },
                                            confirm: {
                                                label: {
                                                    key: "common.ok"
                                                },
                                                handler: function() {
                                                    o({
                                                        type: t,
                                                        extra: n
                                                    }), s()
                                                }
                                            }
                                        },
                                        additions: {
                                            content: e("conversation_list.conversation_cell.menu.delete_chat_content")
                                        }
                                    }) : o({
                                        type: t,
                                        extra: n
                                    }), a.sendTracker("chat_more_dropdown", "chat_more_".concat("pin" === (r = t) ? "pinned_message" : "unpin" === r ? "unpinned_message" : r))
                                }
                            }
                        }
                    }, {
                        key: "getCommonOptions",
                        value: function(e, t, n, a, r) {
                            return [this.getOperationItem(n ? "unpin" : "pin", {
                                conversationId: t,
                                shopId: e,
                                isPinned: n
                            }), this.getOperationItem(a ? "mark_as_read" : "mark_as_unread", {
                                conversationId: t,
                                shopId: e,
                                isRead: a,
                                latestMessageId: r
                            }), this.getOperationItem("delete", {
                                conversationId: t,
                                shopId: e
                            })]
                        }
                    }, {
                        key: "getSubAccountMenuOptions",
                        value: function(e, t, n) {
                            return e ? [this.getOperationItem("close", {
                                conversationId: n,
                                shopId: t,
                                status: "closed"
                            })] : [this.getOperationItem("restart", {
                                conversationId: n,
                                shopId: t,
                                status: "activated"
                            })]
                        }
                    }, {
                        key: "getConversationMenuOptions",
                        value: function() {
                            var e = this.props,
                                t = e.conversation,
                                n = e.isSubAccount,
                                a = t.status,
                                r = t.pinned,
                                o = t.id,
                                c = t.shop_id,
                                s = t.unread_count,
                                i = void 0 === s ? 0 : s,
                                l = t.latest_message_id,
                                u = !!i,
                                d = this.getCommonOptions(c, o, r, u, l);
                            if (n) {
                                var p = "activated" === a,
                                    f = this.getSubAccountMenuOptions(p, c, o).concat(d);
                                return p || f.splice(2, 1), f
                            }
                            return d
                        }
                    }, {
                        key: "getConversationStatus",
                        value: function(t, n, a) {
                            return "closed" === t ? v.a.createElement("div", {
                                className: B.a.closed
                            }, e("common.closed")) : ["banned"].includes(n) ? v.a.createElement("div", {
                                className: B.a.banned
                            }, e("common.".concat(n))) : a ? v.a.createElement("div", {
                                className: B.a.banned
                            }, e("common.blocked")) : null
                        }
                    }, {
                        key: "handleMouseEvent",
                        value: function(e) {
                            this.setState({
                                hover: e
                            })
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var t = this,
                                n = this.props,
                                a = n.style,
                                r = n.onClick,
                                o = n.isScChat,
                                c = n.draftHash,
                                s = n.openedMenu,
                                i = n.conversation,
                                l = n.currentConversationId,
                                u = n.lastMessage,
                                d = i.status,
                                p = i.pinned,
                                f = i.id,
                                h = i.to_name,
                                m = i.to_avatar,
                                b = i.to_avatar_hash,
                                y = i.unread_count,
                                O = i.flag,
                                S = i.to_status,
                                E = i.is_blocked,
                                j = i.crm_message_preview,
                                N = void 0 === j ? {} : j,
                                x = i.entry_point,
                                M = u.send_status,
                                P = 1 === M ? "sending" : 2 === M ? "failed" : "",
                                _ = this.state,
                                T = _.hover,
                                L = _.opened,
                                W = this.getConversationStatus(d, S, E),
                                D = f === l,
                                A = y >= 1e3 ? "999+" : y,
                                F = this.getConversationMenuOptions(),
                                U = c[f],
                                H = !D && U,
                                K = "failed" === P,
                                V = "sending" === P,
                                z = u,
                                J = Object.assign({}, z, {
                                    crm_message_preview: N
                                }),
                                X = Object(R.previewMessage)(J),
                                Y = z.created_at || 1e3 * z.created_timestamp,
                                G = Object(R.customizeTime)(Y, {
                                    noTodayFlag: !0,
                                    noTimeFlag: !0
                                }),
                                Q = v.a.createElement("div", {
                                    className: B.a.username,
                                    title: h
                                }, h),
                                Z = "closed" !== d && "feed_story" === x;
                            return v.a.createElement("div", {
                                style: a,
                                ref: function(e) {
                                    return t.rootNode = e
                                },
                                onClick: function() {
                                    return r(i)
                                },
                                className: "".concat(B.a.root, " ").concat(D ? B.a.highlighted : ""),
                                onMouseEnter: function() {
                                    return t.handleMouseEvent(!0)
                                },
                                onMouseLeave: function() {
                                    return t.handleMouseEvent(!1)
                                }
                            }, p && v.a.createElement(C.Icon, {
                                svg: k.a,
                                className: B.a.pinned
                            }), v.a.createElement("div", {
                                className: B.a.avatar
                            }, v.a.createElement(w.a, {
                                avatar: m,
                                avatarHash: b
                            })), v.a.createElement("div", {
                                className: B.a.container
                            }, v.a.createElement("div", {
                                className: B.a.upper
                            }, Z ? v.a.createElement("div", {
                                className: B.a.usernameFeedContainer
                            }, Q, v.a.createElement("div", {
                                className: B.a.feed
                            }, e("conversation_detail.feed_badge"))) : Q, W || y > 0 && v.a.createElement("div", {
                                className: B.a[o ? "unread" : "mallUnread"]
                            }, A)), v.a.createElement("div", {
                                className: B.a.lower
                            }, v.a.createElement("div", {
                                className: B.a.message
                            }, H ? v.a.createElement(v.a.Fragment, null, v.a.createElement("span", {
                                className: B.a.draft
                            }, "[", e("label.draft"), "]"), v.a.createElement("span", {
                                title: H
                            }, H)) : v.a.createElement(v.a.Fragment, null, K ? v.a.createElement(C.Icon, {
                                svg: q.a,
                                className: B.a[P]
                            }) : V && !D ? v.a.createElement("span", {
                                className: B.a[P]
                            }) : "move" === O && v.a.createElement("span", {
                                className: B.a.forward
                            }, "[", e("label.forward"), "]"), v.a.createElement("span", {
                                title: X
                            }, X))), T || L ? v.a.createElement(g.a, {
                                placement: "bottom-end",
                                menuKey: f,
                                openedMenu: s,
                                options: F,
                                onOpen: this.handleConversationMenuOpen,
                                onClose: this.handleConversationMenuClose,
                                label: v.a.createElement("div", {
                                    id: f,
                                    className: B.a.threeDots
                                }, v.a.createElement(C.Icon, {
                                    svg: I.a,
                                    className: "".concat(B.a.threeDotsIcon, " ").concat(L ? B.a.active : "")
                                }))
                            }) : v.a.createElement("div", {
                                className: B.a.timestamp
                            }, G))))
                        }
                    }]), a
                }(v.a.Component);
            K.propTypes = {
                style: y.a.object,
                onClick: y.a.func,
                isScChat: y.a.bool,
                draftHash: y.a.object,
                openedMenu: y.a.string,
                isSubAccount: y.a.bool,
                conversation: y.a.object,
                operationRequest: y.a.func,
                updateOpenedMenu: y.a.func,
                currentConversationId: y.a.string,
                lastMessage: y.a.object,
                showModal: y.a.func,
                closeModal: y.a.func
            }, t.a = K
        }).call(this, n("kiXb").t)
    },
    VTii: function(e, t, n) {
        e.exports = n.p + "b43d095455136d3f4080437deba43624.png"
    },
    VYkd: function(e, t, n) {
        "use strict";
        n("I5cv");
        var a = n("lwsE"),
            r = n.n(a),
            o = n("W8MJ"),
            c = n.n(o),
            s = n("7W2i"),
            i = n.n(s),
            l = n("a1gu"),
            u = n.n(l),
            d = n("Nsbk"),
            p = n.n(d),
            f = n("q1tI"),
            h = n.n(f),
            m = n("17x9"),
            v = n.n(m),
            b = n("MQp2"),
            y = n("p6iB"),
            g = n.n(y),
            w = n("IsXm"),
            C = n.n(w);

        function O(e) {
            var t = function() {
                if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                if (Reflect.construct.sham) return !1;
                if ("function" == typeof Proxy) return !0;
                try {
                    return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                } catch (e) {
                    return !1
                }
            }();
            return function() {
                var n, a = p()(e);
                if (t) {
                    var r = p()(this).constructor;
                    n = Reflect.construct(a, arguments, r)
                } else n = a.apply(this, arguments);
                return u()(this, n)
            }
        }
        var R = function(e) {
            i()(n, e);
            var t = O(n);

            function n() {
                return r()(this, n), t.apply(this, arguments)
            }
            return c()(n, [{
                key: "render",
                value: function() {
                    var e = this.props,
                        t = e.title,
                        n = e.closeModal,
                        a = e.noCancel,
                        r = "".concat(C.a.root, " ").concat(a ? "" : C.a.hasCancel);
                    return h.a.createElement("div", {
                        className: r
                    }, h.a.createElement("div", {
                        className: C.a.title
                    }, t), !a && h.a.createElement(b.Icon, {
                        svg: g.a,
                        className: C.a.cancel,
                        onClick: n
                    }))
                }
            }]), n
        }(h.a.PureComponent);
        R.propTypes = {
            title: v.a.string,
            closeModal: v.a.func,
            noCancel: v.a.bool
        }, t.a = R
    },
    W2jc: function(e, t, n) {
        "use strict";
        (function(e) {
            var a = n("lSNA"),
                r = n.n(a),
                o = n("J4zp"),
                c = n.n(o),
                s = (n("eM6i"), n("Z2Ku"), n("RW0V"), n("ioFf"), n("0l/t"), n("mYba"), n("8+KV"), n("jm62"), n("WLL4"), n("HAE/"), n("q1tI")),
                i = n.n(s),
                l = n("17x9"),
                u = n.n(l),
                d = n("pQ8y"),
                p = n("MQp2"),
                f = n("XnKn"),
                h = n("tvxL"),
                m = n("XmQJ"),
                v = n.n(m),
                b = n("Ji9V"),
                y = n.n(b),
                g = n("yTWb"),
                w = n.n(g),
                C = n("TelQ"),
                O = n.n(C),
                R = n("Hdln"),
                S = n("OW4m"),
                k = n("f48l"),
                E = n.n(k);

            function j(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var a = Object.getOwnPropertySymbols(e);
                    t && (a = a.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, a)
                }
                return n
            }

            function N(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? j(Object(n), !0).forEach((function(t) {
                        r()(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : j(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }
            var I = function(t) {
                var n = t.newbie,
                    a = t.isScChat,
                    r = t.showEntry,
                    o = t.currentUser,
                    l = t.isSubAccount,
                    u = t.loginSuccess,
                    m = t.socketSuccess,
                    b = t.showChatWindow,
                    g = t.totalUnreadCount,
                    C = t.updateGuideRequested,
                    k = t.showConversationDetail,
                    j = t.updateChatWindowStatus,
                    I = Object(s.useState)(!0),
                    x = c()(I, 2),
                    M = x[0],
                    P = x[1];
                Object(s.useEffect)((function() {
                    a && Object(h.tracker)({
                        type: "chat_icon",
                        data: {
                            ctx_url: window.location.href
                        },
                        operation: "impression"
                    })
                }), []), Object(s.useEffect)((function() {
                    b && P(!1)
                }), [b]), Object(s.useEffect)((function() {
                    if (r) {
                        var e = Date.now() - window.__START_MINICHAT__;
                        Object(h.collectComponentTask)(h.ReportComponent.APP, {
                            duration: e,
                            id: h.ReportPoint.SHOW_WEBCHAT
                        })
                    }
                }), [r]);
                var _ = o.distribution_status,
                    T = o.locale,
                    L = ["tw", "cn"].includes(Object(f.handleLocale)(T, !1)),
                    W = Object(f.checkEntryGuide)(n),
                    D = g > 0,
                    A = g > 99 ? "99+" : g,
                    q = "\n    ".concat(E.a.root, "\n    ").concat(a ? E.a.scEntry : "", "\n    ").concat(D ? E.a.hasUnread : "", "\n  "),
                    F = Object(s.useMemo)((function() {
                        var e = {
                            enter: E.a.windowEnter,
                            enterActive: E.a.windowEnterActive,
                            exit: E.a.windowExit,
                            exitActive: E.a.windowExitActive
                        };
                        return a || (e.exitActive = E.a.mallWindowExitActive), k || (e = N(N({}, e), {}, {
                            enter: E.a.halfWindowEnter,
                            enterActive: E.a.halfWindowEnterActive,
                            exitActive: a ? E.a.halfWindowExitActive : E.a.halfMallWindowExitActive
                        })), e
                    }), [a, k]);
                return r ? i.a.createElement(i.a.Fragment, null, M && i.a.createElement("div", {
                    className: q
                }, i.a.createElement("div", {
                    className: E.a.logoWrapper,
                    onClick: function() {
                        u && m && Object(h.tracker)({
                            type: "chat_icon",
                            data: {
                                redbot: g,
                                ctx_url: window.location.href
                            }
                        }), j({
                            shouldShowWindow: !0
                        })
                    }
                }, g > 0 && i.a.createElement("div", {
                    className: E.a.counts
                }, A), l && _ && a && i.a.createElement("div", {
                    className: "".concat(E.a.statusDot, " ").concat(E.a[_])
                }), i.a.createElement(p.Icon, {
                    svg: w.a,
                    className: E.a.chat
                }), i.a.createElement(p.Icon, {
                    svg: L ? O.a : v.a,
                    className: E.a.logo
                })), a && i.a.createElement("div", {
                    className: E.a.jumpbar,
                    onClick: function() {
                        Object(h.tracker)({
                            type: "to_webchat_button"
                        }), Object(S.a)({
                            currentConversation: {},
                            webChatUrl: Object(f.getWebChatUrl)()
                        })
                    }
                }, i.a.createElement(p.Tooltip, {
                    placement: "right",
                    content: e("header.tooltip.see_all")
                }, i.a.createElement(p.Icon, {
                    svg: y.a,
                    className: E.a.jump
                }))), a && W && i.a.createElement("div", {
                    className: E.a.portal
                }, i.a.createElement("div", {
                    className: E.a.guideContent
                }, i.a.createElement("div", {
                    className: E.a.guideItem
                }, i.a.createElement(p.Icon, {
                    svg: w.a,
                    className: "".concat(E.a.guideIcon, " ").concat(E.a.chatLogo)
                }), i.a.createElement("span", {
                    className: E.a.guideTip
                }, e("newbie.tips.chat_icon"))), i.a.createElement("div", {
                    className: E.a.guideItem
                }, i.a.createElement(p.Icon, {
                    svg: y.a,
                    className: "".concat(E.a.guideIcon, " ").concat(E.a.jump)
                }), i.a.createElement("span", {
                    className: E.a.guideTip
                }, e("newbie.tips.open_webchat_icon")))), i.a.createElement("div", {
                    className: E.a.guideBtn,
                    onClick: function() {
                        var e = Object(f.checkEntryGuide)(n);
                        C({
                            newbieId: e.id
                        })
                    }
                }, e("settings.message_shortcuts.import.confirm")))), i.a.createElement(d.a, {
                    unmountOnExit: !0,
                    in: b,
                    timeout: k ? 300 : 225,
                    classNames: F,
                    onEnter: null,
                    onExited: function() {
                        return P(!0)
                    }
                }, i.a.createElement(R.a, t))) : null
            };
            I.propTypes = {
                newbie: u.a.array,
                isScChat: u.a.bool,
                showEntry: u.a.bool,
                currentUser: u.a.object,
                isSubAccount: u.a.bool,
                loginSuccess: u.a.bool,
                socketSuccess: u.a.bool,
                showChatWindow: u.a.bool,
                totalUnreadCount: u.a.number,
                updateGuideRequested: u.a.func,
                showConversationDetail: u.a.bool,
                updateChatWindowStatus: u.a.func
            }, t.a = I
        }).call(this, n("kiXb").t)
    },
    WBRc: function(e, t, n) {
        "use strict";
        n("I5cv");
        var a = n("lwsE"),
            r = n.n(a),
            o = n("W8MJ"),
            c = n.n(o),
            s = n("PJYZ"),
            i = n.n(s),
            l = n("7W2i"),
            u = n.n(l),
            d = n("a1gu"),
            p = n.n(d),
            f = n("Nsbk"),
            h = n.n(f),
            m = (n("2Spj"), n("91GP"), n("Tze0"), n("pIFo"), n("Oyvg"), n("KKXr"), n("I78e"), n("q1tI")),
            v = n.n(m),
            b = n("17x9"),
            y = n.n(b),
            g = n("Xjjk"),
            w = n.n(g),
            C = n("m2L4"),
            O = n.n(C);

        function R(e) {
            var t = function() {
                if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                if (Reflect.construct.sham) return !1;
                if ("function" == typeof Proxy) return !0;
                try {
                    return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                } catch (e) {
                    return !1
                }
            }();
            return function() {
                var n, a = h()(e);
                if (t) {
                    var r = h()(this).constructor;
                    n = Reflect.construct(a, arguments, r)
                } else n = a.apply(this, arguments);
                return p()(this, n)
            }
        }
        var S = function(e) {
            u()(n, e);
            var t = R(n);

            function n(e) {
                var a;
                return r()(this, n), (a = t.call(this, e)).state = {
                    anchorParentRef: null,
                    anchorRef: null,
                    shadowRef: null,
                    prevSearchword: ""
                }, a.getAnchorRef = a.getAnchorRef.bind(i()(a)), a.getAnchorParentRef = a.getAnchorParentRef.bind(i()(a)), a.getShadowRef = a.getShadowRef.bind(i()(a)), a
            }
            return c()(n, [{
                key: "getAnchorRef",
                value: function(e) {
                    e && this.setState({
                        anchorRef: e
                    })
                }
            }, {
                key: "getAnchorParentRef",
                value: function(e) {
                    e && this.setState({
                        anchorParentRef: e
                    })
                }
            }, {
                key: "getShadowRef",
                value: function(e) {
                    e && this.setState({
                        shadowRef: e
                    })
                }
            }, {
                key: "getWrapperStyle",
                value: function() {
                    var e = this.props.rows,
                        t = this.state.anchorParentRef,
                        n = {
                            width: "100%",
                            overflow: "hidden",
                            textOverflow: "ellipsis",
                            wordBreak: "break-all"
                        };
                    if (t) {
                        var a = t.getBoundingClientRect().height;
                        n.maxHeight = "".concat(a * e, "px"), n.lineHeight = "".concat(a, "px")
                    }
                    return e > 1 ? Object.assign(n, {
                        display: "-webkit-box",
                        WebkitBoxOrient: "vertical",
                        WebkitLineClamp: String(e)
                    }) : Object.assign(n, {
                        whiteSpace: "nowrap"
                    })
                }
            }, {
                key: "render",
                value: function() {
                    var e = this.props,
                        t = e.searchWords,
                        n = e.highlightTag,
                        a = e.textToHighlight,
                        r = e.highlightClassName,
                        o = e.rows,
                        c = e.prefix;
                    if (!a || "string" != typeof a) return "";
                    a = w()(a, {
                        whiteList: {}
                    });
                    var s = t.trim().toLowerCase(),
                        i = a.toLowerCase(),
                        l = this.state,
                        u = l.anchorRef,
                        d = l.anchorParentRef,
                        p = l.shadowRef,
                        f = s.replace(/[.[\]{}()+?*^\\$?]/g, "\\$&"),
                        h = new RegExp(f, "gi"),
                        m = s && i.split(s) || [],
                        b = m.length > 1,
                        y = m.pop(),
                        g = b ? m.join(t) : a,
                        C = a,
                        R = !b;
                    if (u && d && p && !R) {
                        var S = u.getBoundingClientRect(),
                            k = S.left,
                            E = S.width,
                            j = d.getBoundingClientRect(),
                            N = j.left,
                            I = j.width,
                            x = p.getBoundingClientRect().width * o;
                        if (k - N + E - x > 0) {
                            var M = c ? c.length : 0,
                                P = g.length / a.length,
                                _ = Math.ceil(x / I * a.length),
                                T = g.slice(g.length - Math.ceil(_ * P) + M + 5);
                            C = (g.length ? "..." : "") + T + t + y
                        }
                        R = !0, C = b && C.replace(h, "<".concat(n, " class='").concat(r, "'>$&</").concat(n, ">")) || a
                    }
                    return R ? v.a.createElement(O.a, {
                        clamp: o
                    }, v.a.createElement("div", {
                        style: this.getWrapperStyle(),
                        title: a,
                        dangerouslySetInnerHTML: {
                            __html: "".concat(c, " ").concat(C)
                        }
                    })) : v.a.createElement(v.a.Fragment, null, v.a.createElement("span", {
                        style: {
                            position: "absolute",
                            opacity: 0,
                            zIndex: -1,
                            wordBreak: "keep-all",
                            whiteSpace: "nowrap"
                        },
                        ref: this.getAnchorParentRef
                    }, g, v.a.createElement("span", {
                        ref: this.getAnchorRef
                    }, t), y), v.a.createElement("div", {
                        style: {
                            width: "100%",
                            overflow: "hidden",
                            opacity: 0
                        },
                        ref: this.getShadowRef
                    }, " ", a))
                }
            }], [{
                key: "getDerivedStateFromProps",
                value: function(e, t) {
                    var n = e.searchWords;
                    return n !== t.prevSearchword ? {
                        prevSearchword: n,
                        anchorParentRef: null
                    } : null
                }
            }]), n
        }(v.a.PureComponent);
        S.propTypes = {
            searchWords: y.a.string,
            highlightTag: y.a.string,
            textToHighlight: y.a.string,
            highlightClassName: y.a.string,
            rows: y.a.number,
            prefix: y.a.string
        }, S.defaultProps = {
            highlightTag: "span",
            rows: 1,
            searchWords: "",
            prefix: ""
        }, t.a = S
    },
    WbBG: function(e, t, n) {
        "use strict";
        e.exports = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED"
    },
    b7p5: function(e, t, n) {
        "use strict";
        (function(e) {
            n("I5cv");
            var a = n("pVnL"),
                r = n.n(a),
                o = n("lwsE"),
                c = n.n(o),
                s = n("W8MJ"),
                i = n.n(s),
                l = n("PJYZ"),
                u = n.n(l),
                d = n("7W2i"),
                p = n.n(d),
                f = n("a1gu"),
                h = n.n(f),
                m = n("Nsbk"),
                v = n.n(m),
                b = (n("2Spj"), n("0l/t"), n("Z2Ku"), n("q1tI")),
                y = n.n(b),
                g = n("17x9"),
                w = n.n(g),
                C = n("Hxv6"),
                O = n.n(C),
                R = n("2r9f"),
                S = n.n(R),
                k = n("O8oF"),
                E = n("FL2V"),
                j = n("MQp2"),
                N = n("S7/o"),
                I = n("tvxL"),
                x = n("AlKw"),
                M = n.n(x);

            function P(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, a = v()(e);
                    if (t) {
                        var r = v()(this).constructor;
                        n = Reflect.construct(a, arguments, r)
                    } else n = a.apply(this, arguments);
                    return h()(this, n)
                }
            }
            var _ = ["Unread", "All", "Pinned", "Unreplied"],
                T = ["Unread", "Unreplied"],
                L = function(t) {
                    p()(a, t);
                    var n = P(a);

                    function a(e) {
                        var t;
                        return c()(this, a), (t = n.call(this, e)).state = {
                            resetRowsMap: !1
                        }, t.listNode = null, t.scrollTop = 0, t.needScrollToRow = !1, t.getListRef = t.getListRef.bind(u()(t)), t.onListScroll = t.onListScroll.bind(u()(t)), t.makeRenderedCell = t.makeRenderedCell.bind(u()(t)), t.onRowRendered = t.onRowRendered.bind(u()(t)), t.loadMoreRowsRequested = t.loadMoreRowsRequested.bind(u()(t)), t.handleClickConversation = t.handleClickConversation.bind(u()(t)), t.handleResetCacheMap = t.handleResetCacheMap.bind(u()(t)), t
                    }
                    return i()(a, [{
                        key: "componentDidUpdate",
                        value: function(e) {
                            var t = this.props.sortedConversations,
                                n = e.sortedConversations.length,
                                a = t.length;
                            n < a && (this.stopIndex = this.stopIndex + a - n, this.needScrollToRow = !0);
                            var r = this.props,
                                o = r.filter,
                                c = r.conversationDirection;
                            if (this.needScrollToRow && T.includes(o) && "latest" === c) {
                                var s = this.stopIndex < 0 || this.scrollTop < 60 ? 0 : this.stopIndex;
                                this.listNode && this.listNode.scrollToRow(s)
                            }
                            this.needScrollToRow = !1
                        }
                    }, {
                        key: "getListRef",
                        value: function(e) {
                            this.listNode = e
                        }
                    }, {
                        key: "onListScroll",
                        value: function(e) {
                            this.scrollTop = e
                        }
                    }, {
                        key: "onRowRendered",
                        value: function(e) {
                            this.needScrollToRow || (this.stopIndex = e)
                        }
                    }, {
                        key: "loadMoreRowsRequested",
                        value: function() {
                            (0, this.props.fetchConversationsRequested)({
                                direction: "older"
                            })
                        }
                    }, {
                        key: "makeRenderedCell",
                        value: function(e, t) {
                            var n = this.props,
                                a = n.keyword,
                                r = n.currentUser,
                                o = n.isSubAccount,
                                c = n.updateOpenedMenu,
                                s = n.currentConversation,
                                i = n.openedMenu,
                                l = n.draftHash,
                                u = n.isInSearch,
                                d = n.isScChat;
                            return u ? y.a.createElement(k.a, {
                                currentUser: r,
                                style: t,
                                keyword: a,
                                conversation: e,
                                isSubAccount: o,
                                onClick: this.handleClickConversation
                            }) : y.a.createElement(E.a, {
                                style: t,
                                isScChat: d,
                                draftHash: l,
                                openedMenu: i,
                                currentUser: r,
                                conversation: e,
                                isSubAccount: o,
                                updateOpenedMenu: c,
                                onClick: this.handleClickConversation,
                                currentConversationId: s.id
                            })
                        }
                    }, {
                        key: "handleClickConversation",
                        value: function(e) {
                            var t = this.props,
                                n = t.isInSearch,
                                a = t.currentConversation,
                                r = t.showConversationRequested,
                                o = t.searchConversationsRequested,
                                c = t.updateConversationDetailStatus,
                                s = e.id,
                                i = e.unread_count;
                            if (n) return o({}), void r({
                                conversation: e
                            });
                            a ? s !== a.id && (Object(I.tracker)({
                                section: "chat_list",
                                type: "chat_user",
                                data: {
                                    rebbot: i
                                }
                            }), r({
                                conversation: e
                            })) : (Object(I.tracker)({
                                section: "chat_list",
                                type: "chat_user",
                                data: {
                                    rebbot: i
                                }
                            }), r({
                                conversation: e
                            }));
                            c({
                                shouldShowConversationDetail: !0
                            })
                        }
                    }, {
                        key: "handleResetCacheMap",
                        value: function() {
                            this.setState({
                                resetRowsMap: !1
                            })
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var t = this.props,
                                n = t.results,
                                a = t.keyword,
                                o = t.listsHash,
                                c = t.isInSearch,
                                s = t.sortedConversations,
                                i = t.currentConversation,
                                l = t.openedMenu,
                                u = t.conversationHttpStatus,
                                d = t.searchConversationHttpStatus,
                                p = {};
                            if (c) p = {
                                status: d,
                                isInfinite: !1,
                                listItems: n,
                                extraProps: {
                                    keyword: a
                                }
                            };
                            else {
                                var f = {
                                    openedMenu: l,
                                    listsHash: o,
                                    currentConversation: i
                                };
                                p = {
                                    status: u,
                                    listItems: s,
                                    resetRowsMap: this.state.resetRowsMap,
                                    loadMoreRowsRequested: this.loadMoreRowsRequested,
                                    extraProps: f
                                }
                            }
                            return 0 === p.listItems.length && "succeed" === p.status ? y.a.createElement(j.Empty, {
                                classname: M.a.empty,
                                image: c ? O.a : S.a,
                                text: e("conversation_list.no_search_result")
                            }) : y.a.createElement(N.a, r()({}, p, {
                                needPaddingBottom: !0,
                                getListRef: this.getListRef,
                                handleListScroll: this.onListScroll,
                                makeRenderedCell: this.makeRenderedCell,
                                handleRowRendered: this.onRowRendered,
                                onResetCacheMap: this.handleResetCacheMap
                            }))
                        }
                    }], [{
                        key: "getDerivedStateFromProps",
                        value: function(e, t) {
                            var n = t.resetRowsMap,
                                a = t.filter,
                                r = e.filter,
                                o = null;
                            if (r !== a) {
                                o = {
                                    filter: r
                                };
                                var c = _.includes(a) && _.includes(r) && a !== r;
                                n !== c && (o.resetRowsMap = c)
                            }
                            return o
                        }
                    }]), a
                }(y.a.PureComponent);
            L.propTypes = {
                filter: w.a.string,
                results: w.a.array,
                keyword: w.a.string,
                isScChat: w.a.bool,
                listsHash: w.a.string,
                draftHash: w.a.object,
                isInSearch: w.a.bool,
                openedMenu: w.a.string,
                currentUser: w.a.object,
                isSubAccount: w.a.bool,
                currentUserId: w.a.number,
                updateOpenedMenu: w.a.func,
                sortedConversations: w.a.array,
                currentConversation: w.a.object,
                conversationDirection: w.a.string,
                conversationHttpStatus: w.a.string,
                showConversationRequested: w.a.func,
                fetchConversationsRequested: w.a.func,
                searchConversationsRequested: w.a.func,
                searchConversationHttpStatus: w.a.string,
                updateConversationDetailStatus: w.a.func
            }, t.a = L
        }).call(this, n("kiXb").t)
    },
    fe4J: function(e, t, n) {
        "use strict";
        (function(e) {
            var a = n("q1tI"),
                r = n.n(a),
                o = n("MQp2"),
                c = n("2e4M");
            t.a = function(t) {
                var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                    s = r.a.createElement("div", {
                        style: {
                            width: "100%",
                            height: "100%",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center"
                        }
                    }, r.a.createElement(o.Loading, {
                        isInit: !0,
                        text: e(n.loadingKey || "")
                    }));
                return function(e) {
                    return r.a.createElement(c.a, null, r.a.createElement(a.Suspense, {
                        fallback: s
                    }, r.a.createElement(t, e)))
                }
            }
        }).call(this, n("kiXb").t)
    },
    gSTE: function(e, t, n) {
        "use strict";
        (function(e) {
            n("I5cv"), n("RW0V"), n("ioFf"), n("mYba"), n("8+KV"), n("jm62"), n("WLL4"), n("HAE/");
            var a = n("lSNA"),
                r = n.n(a),
                o = n("lwsE"),
                c = n.n(o),
                s = n("W8MJ"),
                i = n.n(s),
                l = n("PJYZ"),
                u = n.n(l),
                d = n("7W2i"),
                p = n.n(d),
                f = n("a1gu"),
                h = n.n(f),
                m = n("Nsbk"),
                v = n.n(m),
                b = (n("2Spj"), n("0l/t"), n("L9s1"), n("Z2Ku"), n("bWfx"), n("OG14"), n("q1tI")),
                y = n.n(b),
                g = n("17x9"),
                w = n.n(g),
                C = n("SdKD"),
                O = n("tvxL"),
                R = n("XnKn"),
                S = n("MQp2"),
                k = n("4i+F"),
                E = n.n(k),
                j = n("+DaP"),
                N = n.n(j),
                I = n("bByp"),
                x = n.n(I);

            function M(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var a = Object.getOwnPropertySymbols(e);
                    t && (a = a.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, a)
                }
                return n
            }

            function P(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var n, a = v()(e);
                    if (t) {
                        var r = v()(this).constructor;
                        n = Reflect.construct(a, arguments, r)
                    } else n = a.apply(this, arguments);
                    return h()(this, n)
                }
            }
            var _ = function(t) {
                p()(a, t);
                var n = P(a);

                function a(e) {
                    var t;
                    return c()(this, a), (t = n.call(this, e)).state = {
                        focus: !1
                    }, t.handleFocus = t.handleFocus.bind(u()(t)), t.handleCancelSearch = t.handleCancelSearch.bind(u()(t)), t.handleKeyDown = t.handleKeyDown.bind(u()(t)), t.handleSearch = Object(R.debounce)(t.handleChange.bind(u()(t))), t.handleFilterMenuOpen = t.handleFilterMenuOpen.bind(u()(t)), t
                }
                return i()(a, [{
                    key: "componentDidUpdate",
                    value: function(e) {
                        var t = this.props.keyword;
                        t === e.keyword || t || (this.input.value = "")
                    }
                }, {
                    key: "handleFocus",
                    value: function(e) {
                        this.setState({
                            focus: e
                        }), e && Object(O.tracker)({
                            type: "search_name"
                        })
                    }
                }, {
                    key: "handleCancelSearch",
                    value: function() {
                        this.input.value = "", this.handleChange()
                    }
                }, {
                    key: "handleChange",
                    value: function(e) {
                        this.input && this.props.searchConversationsRequested({
                            keyword: this.input.value
                        })
                    }
                }, {
                    key: "handleKeyDown",
                    value: function(e) {
                        switch (e.keyCode) {
                            case 27:
                                this.handleCancelSearch(), e.preventDefault()
                        }
                    }
                }, {
                    key: "filter",
                    value: function(e) {
                        var t = this.props,
                            n = t.filter,
                            a = t.updateConversationFilter,
                            r = t.resetConversationRequested,
                            o = t.fetchConversationsRequested;
                        if (e !== n) {
                            a({
                                filter: e
                            });
                            var c = [e, n];
                            r(), Object(O.tracker)({
                                section: "chat_list_dropdown",
                                type: "filter_".concat(e.toLowerCase())
                            });
                            var s = c.includes("Unread"),
                                i = c.includes("Pinned"),
                                l = c.includes("Unreplied");
                            (s || i || l) && o({
                                direction: "reset"
                            })
                        }
                    }
                }, {
                    key: "getFilterOptions",
                    value: function(t) {
                        var n = this,
                            a = t.isSubAccount,
                            o = t.totalUnreadConversationsCount,
                            c = t.isScChat,
                            s = ["All", "Unread", "Pinned"];
                        !a && c && s.splice(s.length - 1, 0, "Unreplied");
                        var i = s.map((function(t) {
                            var a = {};
                            return o > 0 && "Unread" === t && (a.icon = "reddotIcon"),
                                function(e) {
                                    for (var t = 1; t < arguments.length; t++) {
                                        var n = null != arguments[t] ? arguments[t] : {};
                                        t % 2 ? M(Object(n), !0).forEach((function(t) {
                                            r()(e, t, n[t])
                                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : M(Object(n)).forEach((function(t) {
                                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                                        }))
                                    }
                                    return e
                                }({
                                    name: e("conversation_list.filter.".concat(t.toLowerCase())),
                                    handleSelect: function() {
                                        n.filter(t)
                                    }
                                }, a)
                        }));
                        return a && i.push({
                            name: e("common.closed"),
                            handleSelect: function() {
                                n.filter("Closed")
                            }
                        }), i
                    }
                }, {
                    key: "handleFilterMenuOpen",
                    value: function() {
                        var e = this.props.updateOpenedMenu;
                        Object(O.tracker)({
                            section: "chat_list_dropdown",
                            type: "filter"
                        }), e("conversions_filter")
                    }
                }, {
                    key: "render",
                    value: function() {
                        var t = this,
                            n = this.state.focus,
                            a = this.props,
                            r = a.keyword,
                            o = void 0 === r ? "" : r,
                            c = a.filter,
                            s = a.openedMenu,
                            i = a.isSubAccount,
                            l = a.totalUnreadConversationsCount,
                            u = a.isScChat,
                            d = function() {
                                var t, n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
                                return t = "Closed" === n ? "common.closed" : "conversation_list.filter.".concat(n.toLowerCase()), e(t)
                            }(c),
                            p = this.getFilterOptions({
                                isSubAccount: i,
                                totalUnreadConversationsCount: l,
                                isScChat: u
                            }),
                            f = e("conversation_list.search.placehoder");
                        return y.a.createElement("div", {
                            className: x.a.root
                        }, y.a.createElement("div", {
                            className: x.a.search
                        }, y.a.createElement("input", {
                            defaultValue: o,
                            className: x.a.input,
                            onChange: this.handleSearch,
                            onKeyDown: this.handleKeyDown,
                            placeholder: f,
                            ref: function(e) {
                                return t.input = e
                            },
                            onBlur: function() {
                                return t.handleFocus(!1)
                            },
                            onFocus: function() {
                                return t.handleFocus(!0)
                            }
                        }), y.a.createElement("div", {
                            className: "".concat(x.a.wrapper, " ").concat(n || o ? x.a.focus : "")
                        }, y.a.createElement(S.Icon, {
                            svg: N.a,
                            className: x.a.icon
                        })), o && y.a.createElement("div", {
                            className: x.a.cancel,
                            onClick: this.handleCancelSearch
                        })), !o && !n && y.a.createElement("div", {
                            className: "".concat(x.a.filter, " ").concat(x.a.reddotFilter)
                        }, l > 0 && y.a.createElement("div", {
                            className: x.a.reddot
                        }), y.a.createElement(C.a, {
                            menuKey: "conversions_filter",
                            options: p,
                            openedMenu: s,
                            onOpen: this.handleFilterMenuOpen,
                            placement: "bottom-end",
                            label: y.a.createElement("div", {
                                className: x.a.selected
                            }, d, y.a.createElement(S.Icon, {
                                svg: E.a,
                                className: x.a.arrowDown
                            }))
                        })))
                    }
                }]), a
            }(y.a.PureComponent);
            _.propTypes = {
                filter: w.a.string,
                keyword: w.a.string,
                openedMenu: w.a.string,
                isSubAccount: w.a.bool,
                updateOpenedMenu: w.a.func,
                updateConversationFilter: w.a.func,
                resetConversationRequested: w.a.func,
                fetchConversationsRequested: w.a.func,
                searchConversationsRequested: w.a.func,
                isScChat: w.a.bool,
                totalUnreadConversationsCount: w.a.number
            }, t.a = _
        }).call(this, n("kiXb").t)
    },
    gXTF: function(e, t, n) {
        "use strict";
        n("I5cv"), n("RW0V"), n("ioFf"), n("0l/t"), n("mYba"), n("8+KV"), n("jm62"), n("WLL4"), n("HAE/");
        var a = n("lSNA"),
            r = n.n(a),
            o = n("lwsE"),
            c = n.n(o),
            s = n("W8MJ"),
            i = n.n(s),
            l = n("7W2i"),
            u = n.n(l),
            d = n("a1gu"),
            p = n.n(d),
            f = n("Nsbk"),
            h = n.n(f),
            m = n("q1tI"),
            v = n.n(m),
            b = n("/MKj"),
            y = n("tvxL"),
            g = n("QILm"),
            w = n.n(g),
            C = n("17x9"),
            O = n.n(C),
            R = n("V5eP"),
            S = n.n(R),
            k = n("9rZX"),
            E = n.n(k),
            j = n("KmjB"),
            N = n("X+/D"),
            I = n.n(N);

        function x(e) {
            var t = function() {
                if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                if (Reflect.construct.sham) return !1;
                if ("function" == typeof Proxy) return !0;
                try {
                    return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                } catch (e) {
                    return !1
                }
            }();
            return function() {
                var n, a = h()(e);
                if (t) {
                    var r = h()(this).constructor;
                    n = Reflect.construct(a, arguments, r)
                } else n = a.apply(this, arguments);
                return p()(this, n)
            }
        }
        var M = function(e) {
            u()(n, e);
            var t = x(n);

            function n() {
                return c()(this, n), t.apply(this, arguments)
            }
            return i()(n, [{
                key: "render",
                value: function() {
                    var e = this.props,
                        t = e.title,
                        n = e.additions,
                        a = n.content,
                        r = n.contentStyle,
                        o = n.modalStyle,
                        c = e.closeModal,
                        s = e.actions,
                        i = s.confirm,
                        l = s.cancel,
                        u = t && Object(j.g)(t),
                        d = a && Object(j.g)(a),
                        p = l && Object(j.g)(l.label),
                        f = i && Object(j.g)(i.label),
                        h = "".concat(I.a.content, " ").concat(u ? "" : I.a.noTitle);
                    return v.a.createElement("div", {
                        className: I.a.root,
                        style: o,
                        onClick: function(e) {
                            return e.stopPropagation()
                        }
                    }, u && v.a.createElement("div", {
                        className: I.a.title
                    }, u), d && v.a.createElement("div", {
                        className: h,
                        style: r
                    }, d), v.a.createElement("div", {
                        className: I.a.actions
                    }, Object(j.b)(l) && v.a.createElement("div", {
                        className: I.a.cancel,
                        onClick: l.handler
                    }, p), Object(j.b)(i) && v.a.createElement("div", {
                        className: I.a.confirm,
                        onClick: i.handler || c
                    }, f)))
                }
            }]), n
        }(v.a.PureComponent);
        M.propTypes = {
            title: O.a.oneOfType([O.a.string, O.a.object]),
            additions: O.a.object,
            closeModal: O.a.func,
            actions: O.a.shape({
                confirm: O.a.oneOfType([O.a.string, O.a.object]),
                cancel: O.a.oneOfType([O.a.string, O.a.object])
            })
        };
        var P = M,
            _ = n("PJYZ"),
            T = n.n(_),
            L = (n("2Spj"), n("t+QN")),
            W = n.n(L),
            D = n("VYkd"),
            A = n("/o74"),
            q = n.n(A),
            F = (n("I78e"), n("2WOU")),
            B = n.n(F),
            U = ["onClick", "text", "style"];

        function H(e) {
            var t = function() {
                if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                if (Reflect.construct.sham) return !1;
                if ("function" == typeof Proxy) return !0;
                try {
                    return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                } catch (e) {
                    return !1
                }
            }();
            return function() {
                var n, a = h()(e);
                if (t) {
                    var r = h()(this).constructor;
                    n = Reflect.construct(a, arguments, r)
                } else n = a.apply(this, arguments);
                return p()(this, n)
            }
        }
        var K = function(e) {
            u()(n, e);
            var t = H(n);

            function n(e) {
                var a;
                return c()(this, n), (a = t.call(this, e)).getRenderClass = a.getRenderClass.bind(T()(a)), a.uppercaseFirstLetter = a.uppercaseFirstLetter.bind(T()(a)), a
            }
            return i()(n, [{
                key: "uppercaseFirstLetter",
                value: function(e) {
                    return "".concat(e[0].toUpperCase()).concat(e.slice(1))
                }
            }, {
                key: "getRenderClass",
                value: function(e) {
                    var t = e.size,
                        n = e.shape,
                        a = e.theme,
                        r = e.disabled,
                        o = e.rounded,
                        c = e.noHoverChange,
                        s = "default" !== t ? B.a["size".concat(this.uppercaseFirstLetter(t))] : "",
                        i = "default" !== a ? B.a["theme".concat(this.uppercaseFirstLetter(a))] : "",
                        l = "default" !== n ? B.a["shape".concat(this.uppercaseFirstLetter(n))] : "",
                        u = o ? B.a.buttonRounded : "",
                        d = r ? B.a.disabled : "",
                        p = c ? B.a.btn : B.a.shopeeBtn;
                    return "".concat(p, " ").concat(s, " ").concat(i, " ").concat(l, " ").concat(u, " ").concat(d)
                }
            }, {
                key: "render",
                value: function() {
                    var e = this.props,
                        t = e.onClick,
                        n = e.text,
                        a = e.style,
                        r = w()(e, U),
                        o = this.getRenderClass(r),
                        c = r.disabled;
                    return v.a.createElement("button", {
                        style: a,
                        disabled: c,
                        className: o,
                        onClick: t
                    }, n)
                }
            }]), n
        }(v.a.PureComponent);
        K.propTypes = {
            text: O.a.string,
            style: O.a.object,
            size: O.a.string.isRequired,
            theme: O.a.string.isRequired,
            disabled: O.a.bool.isRequired,
            rounded: O.a.bool.isRequired,
            onClick: O.a.func.isRequired,
            shape: O.a.string.isRequired,
            noHoverChange: O.a.bool.isRequired
        }, K.defaultProps = {
            size: "default",
            shape: "default",
            theme: "default",
            disabled: !1,
            rounded: !1,
            noHoverChange: !1,
            style: {}
        };
        var V = K;

        function z(e) {
            var t = function() {
                if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                if (Reflect.construct.sham) return !1;
                if ("function" == typeof Proxy) return !0;
                try {
                    return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                } catch (e) {
                    return !1
                }
            }();
            return function() {
                var n, a = h()(e);
                if (t) {
                    var r = h()(this).constructor;
                    n = Reflect.construct(a, arguments, r)
                } else n = a.apply(this, arguments);
                return p()(this, n)
            }
        }
        var J = function(e) {
            u()(n, e);
            var t = z(n);

            function n() {
                return c()(this, n), t.apply(this, arguments)
            }
            return i()(n, [{
                key: "render",
                value: function() {
                    var e = this.props,
                        t = e.size,
                        n = e.cancelOption,
                        a = e.confirmOption,
                        r = e.handleClick,
                        o = e.disabled,
                        c = n.label,
                        s = n.theme,
                        i = void 0 === s ? "default" : s,
                        l = n.shape,
                        u = void 0 === l ? "frameless" : l,
                        d = a.label,
                        p = a.theme,
                        f = void 0 === p ? "primary" : p,
                        h = a.shape,
                        m = void 0 === h ? "default" : h,
                        b = Object(j.g)(c),
                        y = Object(j.g)(d);
                    return v.a.createElement("div", {
                        className: q.a.root
                    }, v.a.createElement(V, {
                        size: t,
                        theme: i,
                        onClick: function() {
                            return r("cancel")
                        },
                        shape: u,
                        text: b
                    }), v.a.createElement(V, {
                        size: t,
                        theme: f,
                        onClick: function() {
                            return r("confirm")
                        },
                        shape: m,
                        text: y,
                        disabled: o
                    }))
                }
            }]), n
        }(v.a.PureComponent);
        J.propTypes = {
            size: O.a.string,
            cancelOption: O.a.object,
            confirmOption: O.a.object,
            handleClick: O.a.func,
            disabled: O.a.bool
        }, J.defaultProps = {
            size: "large"
        };
        var X = J,
            Y = n("XnKn");

        function G(e) {
            var t = function() {
                if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                if (Reflect.construct.sham) return !1;
                if ("function" == typeof Proxy) return !0;
                try {
                    return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                } catch (e) {
                    return !1
                }
            }();
            return function() {
                var n, a = h()(e);
                if (t) {
                    var r = h()(this).constructor;
                    n = Reflect.construct(a, arguments, r)
                } else n = a.apply(this, arguments);
                return p()(this, n)
            }
        }
        var Q = function(e) {
            u()(n, e);
            var t = G(n);

            function n(e) {
                var a;
                return c()(this, n), (a = t.call(this, e)).onClick = a.onClick.bind(T()(a)), a.getContentRef = a.getContentRef.bind(T()(a)), a.handleClickNotices = a.handleClickNotices.bind(T()(a)), a
            }
            return i()(n, [{
                key: "onClick",
                value: function(e) {
                    var t = this.props.actions,
                        n = t.cancel,
                        a = t.confirm;
                    if ("cancel" === e) {
                        var r = n.handler;
                        r && r()
                    } else {
                        var o = a.handler;
                        o && o()
                    }
                }
            }, {
                key: "getContentRef",
                value: function(e) {
                    e && (this.contentRef = e)
                }
            }, {
                key: "componentDidMount",
                value: function() {
                    if (this.contentRef) {
                        var e = this.contentRef.firstElementChild;
                        e && (e.className = W.a.policy, e.addEventListener("click", this.handleClickNotices))
                    }
                }
            }, {
                key: "componentWillUnmount",
                value: function() {
                    if (this.contentRef) {
                        var e = this.contentRef.firstElementChild;
                        e && (e.className = W.a.policy, e.removeEventListener("click", this.handleClickNotices))
                    }
                }
            }, {
                key: "handleClickNotices",
                value: function() {
                    var e = this.props.additions.region;
                    window.open("".concat(Y.cancelOrderPolicy[e]))
                }
            }, {
                key: "render",
                value: function() {
                    var e = this.props,
                        t = e.title,
                        n = e.additions.content,
                        a = e.closeModal,
                        r = e.actions,
                        o = r.cancel,
                        c = r.confirm,
                        s = Object(j.g)(t),
                        i = Object(j.g)(n);
                    return v.a.createElement("div", {
                        className: W.a.root
                    }, v.a.createElement(D.a, {
                        title: s,
                        closeModal: a,
                        noCancel: !0
                    }), v.a.createElement("div", {
                        className: W.a.content,
                        ref: this.getContentRef,
                        dangerouslySetInnerHTML: {
                            __html: i
                        }
                    }), v.a.createElement(X, {
                        size: "custome",
                        cancelOption: o,
                        confirmOption: c,
                        handleClick: this.onClick
                    }))
                }
            }]), n
        }(v.a.PureComponent);
        Q.propTypes = {
            title: O.a.oneOfType([O.a.string, O.a.object]),
            additions: O.a.object,
            closeModal: O.a.func,
            actions: O.a.object
        };
        var Z = Q,
            $ = ["type"],
            ee = ["show", "closeable"];

        function te(e) {
            var t = function() {
                if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                if (Reflect.construct.sham) return !1;
                if ("function" == typeof Proxy) return !0;
                try {
                    return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                } catch (e) {
                    return !1
                }
            }();
            return function() {
                var n, a = h()(e);
                if (t) {
                    var r = h()(this).constructor;
                    n = Reflect.construct(a, arguments, r)
                } else n = a.apply(this, arguments);
                return p()(this, n)
            }
        }
        var ne = function(e) {
            u()(n, e);
            var t = te(n);

            function n() {
                return c()(this, n), t.apply(this, arguments)
            }
            return i()(n, [{
                key: "render",
                value: function() {
                    var e = this.props,
                        t = e.type,
                        n = w()(e, $);
                    switch (t) {
                        case "CONFIRM_MODAL":
                            return v.a.createElement(P, n);
                        case "Cancel_ORDER_WARNING_MODAL":
                            return v.a.createElement(Z, n);
                        default:
                            return null
                    }
                }
            }]), n
        }(v.a.PureComponent);
        ne.propTypes = {
            type: O.a.string.isRequired
        };
        var ae = function(e) {
            u()(n, e);
            var t = te(n);

            function n() {
                return c()(this, n), t.apply(this, arguments)
            }
            return i()(n, [{
                key: "componentDidMount",
                value: function() {
                    var e = window.miniChatContainerId;
                    E.a.setAppElement("#".concat(e))
                }
            }, {
                key: "render",
                value: function() {
                    var e = this.props,
                        t = e.show,
                        n = e.closeable,
                        a = w()(e, ee),
                        r = window.miniChatContainerId;
                    return v.a.createElement(E.a, {
                        isOpen: t,
                        onRequestClose: n ? a.closeModal : void 0,
                        parentSelector: function() {
                            return document.querySelector("#".concat(r))
                        },
                        overlayClassName: S.a.overlay,
                        className: S.a.content,
                        shouldReturnFocusAfterClose: !1
                    }, v.a.createElement(ne, a))
                }
            }]), n
        }(v.a.PureComponent);
        ae.propTypes = {
            show: O.a.bool,
            closeable: O.a.bool
        };
        var re = ae;

        function oe(e, t) {
            var n = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var a = Object.getOwnPropertySymbols(e);
                t && (a = a.filter((function(t) {
                    return Object.getOwnPropertyDescriptor(e, t).enumerable
                }))), n.push.apply(n, a)
            }
            return n
        }

        function ce(e) {
            var t = function() {
                if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                if (Reflect.construct.sham) return !1;
                if ("function" == typeof Proxy) return !0;
                try {
                    return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                } catch (e) {
                    return !1
                }
            }();
            return function() {
                var n, a = h()(e);
                if (t) {
                    var r = h()(this).constructor;
                    n = Reflect.construct(a, arguments, r)
                } else n = a.apply(this, arguments);
                return p()(this, n)
            }
        }
        var se = function(e) {
                u()(n, e);
                var t = ce(n);

                function n() {
                    return c()(this, n), t.apply(this, arguments)
                }
                return i()(n, [{
                    key: "render",
                    value: function() {
                        return v.a.createElement(re, this.props)
                    }
                }]), n
            }(v.a.PureComponent),
            ie = {
                closeModal: y.closeModal
            };
        t.a = Object(b.connect)((function(e) {
            return function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? oe(Object(n), !0).forEach((function(t) {
                        r()(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : oe(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }({}, e.modalReducer)
        }), ie)(se)
    },
    imT4: function(e, t, n) {
        "use strict";
        (function(e) {
            var a = n("J4zp"),
                r = n.n(a),
                o = (n("bWfx"), n("Z2Ku"), n("q1tI")),
                c = n.n(o),
                s = n("17x9"),
                i = n.n(s),
                l = n("tvxL"),
                u = n("MQp2"),
                d = n("XnKn"),
                p = n("OW4m"),
                f = n("gXTF"),
                h = n("SdKD"),
                m = n("OTLN"),
                v = n("l4Er"),
                b = n("fe4J"),
                y = n("PWQ0"),
                g = n.n(y),
                w = n("XmQJ"),
                C = n.n(w),
                O = n("4Ntn"),
                R = n.n(O),
                S = n("YnXV"),
                k = n.n(S),
                E = n("vd8H"),
                j = n.n(E),
                N = n("aCn2"),
                I = n.n(N),
                x = n("TelQ"),
                M = n.n(x),
                P = n("5deg"),
                _ = n.n(P),
                T = n("DIuY"),
                L = n.n(T),
                W = n("RK9Y"),
                D = n.n(W),
                A = n("oWPI"),
                q = n.n(A),
                F = n("S4Or"),
                B = n.n(F),
                U = n("VTii"),
                H = n.n(U),
                K = n("FK2i"),
                V = n.n(K),
                z = Object(o.lazy)((function() {
                    return Promise.all([n.e(5), n.e(4), n.e(1), n.e(2), n.e(3), n.e(0), n.e(6), n.e(7), n.e(8)]).then(n.bind(null, "Lzd8"))
                })),
                J = Object(b.a)(z),
                X = {
                    seeAll: D.a,
                    minimize: g.a,
                    hideDialog: L.a,
                    showDialog: _.a
                },
                Y = function(t) {
                    var n, a, s = t.newbie,
                        i = t.isScChat,
                        b = t.openedMenu,
                        y = t.currentUser,
                        g = t.isSubAccount,
                        w = t.currentBuyer,
                        O = t.loginSuccess,
                        S = t.socketSuccess,
                        E = t.totalUnreadCount,
                        N = t.showConversationDetail,
                        x = t.currentConversation,
                        P = t.updateGuideRequested,
                        _ = t.updateUserRequested,
                        T = t.updateOpenedMenu,
                        W = t.setToastInformation,
                        D = t.toast,
                        A = t.connectSocket,
                        F = t.updateChatWindowStatus,
                        U = t.changeConversationStatusRequested,
                        K = t.updateConversationDetailStatus,
                        z = Object(o.useState)(!1),
                        Y = r()(z, 2),
                        G = Y[0],
                        Q = Y[1],
                        Z = Object(o.useState)(!1),
                        $ = r()(Z, 2),
                        ee = $[0],
                        te = $[1],
                        ne = {
                            key: "seeAll",
                            tip: "header.tooltip.see_all",
                            customProps: {
                                position: "right",
                                edgeDistance: 12
                            },
                            icon: "seeAll",
                            handler: function(e) {
                                Object(l.tracker)({
                                    type: "to_webchat_button"
                                }), Object(p.a)({
                                    currentConversation: x,
                                    webChatUrl: Object(d.getWebChatUrl)()
                                })
                            }
                        },
                        ae = {
                            key: "minimize",
                            tip: "header.tooltip.minimize",
                            icon: "minimize",
                            handler: function(e) {
                                F({
                                    shouldShowWindow: !1
                                }), Object(l.tracker)({
                                    type: "close_button"
                                })
                            }
                        },
                        re = y.distribution_status,
                        oe = y.locale,
                        ce = ["tw", "cn"].includes(Object(d.handleLocale)(oe, !1)),
                        se = "working" === re,
                        ie = function(t) {
                            return [{
                                name: c.a.createElement("div", {
                                    className: V.a.statusOption
                                }, c.a.createElement("div", {
                                    className: V.a.selected
                                }, t && c.a.createElement(u.Icon, {
                                    svg: R.a,
                                    className: V.a.currentStatus
                                })), c.a.createElement("div", {
                                    className: "".concat(V.a.status, " ").concat(V.a.working)
                                }), c.a.createElement("div", {
                                    className: t ? V.a.active : ""
                                }, e("common.online"))),
                                handleSelect: function() {
                                    !t && _({
                                        status: "working"
                                    }), !t && Object(l.tracker)({
                                        section: "shop_head_status_dropdown",
                                        type: "status_online_button"
                                    })
                                },
                                meta: {
                                    noBorder: !0
                                }
                            }, {
                                name: c.a.createElement("div", {
                                    className: V.a.statusOption
                                }, c.a.createElement("div", {
                                    className: V.a.selected
                                }, !t && c.a.createElement(u.Icon, {
                                    svg: R.a,
                                    className: V.a.currentStatus
                                })), c.a.createElement("div", {
                                    className: "".concat(V.a.status, " ").concat(V.a.hangup)
                                }), c.a.createElement("div", {
                                    className: t ? "" : V.a.active
                                }, e("common.offline"))),
                                handleSelect: function() {
                                    t && _({
                                        status: "hang_up"
                                    }), t && Object(l.tracker)({
                                        section: "shop_head_status_dropdown",
                                        type: "status_hangup"
                                    })
                                }
                            }]
                        }(se),
                        le = Object(d.checkHeaderGuide)(s),
                        ue = "".concat(V.a.userStatus, " ").concat(V.a.hoverStyle, " ").concat(se ? V.a.working : V.a.hangup);
                    return c.a.createElement("div", {
                        style: i ? {
                            borderRadius: "4px"
                        } : {},
                        className: N ? V.a.container : V.a.halfContainer
                    }, c.a.createElement("div", {
                        className: V.a.header
                    }, c.a.createElement("div", {
                        className: V.a.logoWrapper
                    }, g && i && c.a.createElement("div", {
                        className: V.a.customMenu
                    }, c.a.createElement(h.a, {
                        options: ie,
                        menuKey: "user_status",
                        openedMenu: b,
                        placement: "bottom-start",
                        onOpen: function() {
                            Object(l.tracker)({
                                type: "shop_head_status"
                            }), T("user_status"), te(!0)
                        },
                        onClose: function() {
                            return te(!1)
                        },
                        label: c.a.createElement(u.Tooltip, {
                            content: e("common.".concat(se ? "online" : "offline"))
                        }, c.a.createElement("div", {
                            className: ue,
                            onMouseEnter: function() {
                                return Q(!0)
                            },
                            onMouseLeave: function() {
                                return Q(!1)
                            }
                        }, (ee || G) && c.a.createElement(u.Icon, {
                            svg: k.a,
                            className: V.a.arrow
                        })))
                    })), c.a.createElement(u.Icon, {
                        svg: ce ? M.a : C.a,
                        className: V.a.logo
                    }), !!E && c.a.createElement("div", {
                        className: V.a.unread
                    }, c.a.createElement(u.Icon, {
                        svg: j.a,
                        className: V.a.unreadOpen
                    }), E, c.a.createElement(u.Icon, {
                        svg: I.a,
                        className: V.a.unreadClose
                    }))), (a = [], N ? a.push({
                        key: "hideDialog",
                        tip: "header.tooltip.close_dialog",
                        icon: "hideDialog",
                        handler: function(e) {
                            K({
                                shouldShowConversationDetail: !1
                            }), Object(l.tracker)({
                                type: "fold_button"
                            })
                        }
                    }) : a.push({
                        key: "showDialog",
                        tip: "header.tooltip.open_dialog",
                        icon: "showDialog",
                        handler: function(e) {
                            K({
                                shouldShowConversationDetail: !0,
                                needMark: !0
                            }), Object(l.tracker)({
                                type: "unfold_button"
                            })
                        }
                    }), a.push(ae), i && a.push(ne), c.a.createElement("div", {
                        className: V.a.operatorWrapper
                    }, a.map((function(t) {
                        return c.a.createElement("div", {
                            key: t.key,
                            className: V.a.operatorItemWrapper
                        }, c.a.createElement(u.Tooltip, {
                            content: e(t.tip)
                        }, c.a.createElement(u.Icon, {
                            svg: X[t.icon],
                            className: V.a[t.icon],
                            onClick: t.handler
                        })))
                    }))))), c.a.createElement("div", {
                        className: V.a.windows
                    }, (n = {
                        isScChat: i,
                        openedMenu: b,
                        currentUser: y,
                        isSubAccount: g,
                        currentBuyer: w,
                        loginSuccess: O,
                        socketSuccess: S,
                        updateOpenedMenu: T,
                        setToastInformation: W,
                        currentConversation: x,
                        showConversationDetail: N,
                        changeConversationStatusRequested: U,
                        currentUserId: (y || {}).id
                    }, O ? S ? c.a.createElement(c.a.Fragment, null, c.a.createElement(m.a, {
                        toast: D,
                        isScChat: i,
                        setToastInformation: W
                    }), c.a.createElement("div", {
                        className: V.a.details
                    }, x.id ? c.a.createElement(J, n) : c.a.createElement("div", {
                        className: V.a.blank
                    }, c.a.createElement("img", {
                        src: q.a,
                        className: V.a.image
                    }), c.a.createElement("div", {
                        className: V.a.title
                    }, e("blank_page.".concat(i ? "" : "mall_", "title"))), i && c.a.createElement("div", {
                        className: V.a.subtitle
                    }, e("blank_page.tip")))), c.a.createElement(v.a, n), c.a.createElement(f.a, null)) : c.a.createElement("div", {
                        className: V.a.maxBlank
                    }, c.a.createElement("img", {
                        src: B.a,
                        className: V.a.errorImage
                    }), c.a.createElement("div", {
                        className: V.a.title
                    }, e("socket_error.title")), c.a.createElement("div", {
                        className: V.a.reload,
                        onClick: A
                    }, e("common.error.reload"))) : c.a.createElement("div", {
                        className: V.a.maxBlank
                    }, c.a.createElement("img", {
                        src: H.a,
                        className: V.a.errorImage
                    }), c.a.createElement("div", {
                        className: V.a.title
                    }, e("common.error.hint_text")), c.a.createElement("div", {
                        className: V.a.subtitle
                    }, e("login_error.tips"))))), i && le && c.a.createElement("div", {
                        className: V.a.portal
                    }, c.a.createElement("div", {
                        className: V.a.guideContent
                    }, c.a.createElement("div", {
                        className: V.a.guideItem
                    }, c.a.createElement(u.Icon, {
                        svg: L.a,
                        className: "".concat(V.a.guideIcon, " ").concat(V.a.hideDialog)
                    }), c.a.createElement("span", {
                        className: V.a.guideTip
                    }, e("newbie.tips.hide_conversation")))), c.a.createElement("div", {
                        className: V.a.guideBtn,
                        onClick: function() {
                            var e = Object(d.checkHeaderGuide)(s);
                            P({
                                newbieId: e.id
                            })
                        }
                    }, e("settings.message_shortcuts.import.confirm"))))
                };
            Y.propTypes = {
                newbie: i.a.array,
                toast: i.a.object,
                isScChat: i.a.bool,
                openedMenu: i.a.string,
                currentUser: i.a.object,
                isSubAccount: i.a.bool,
                loginSuccess: i.a.bool,
                currentBuyer: i.a.object,
                socketSuccess: i.a.bool,
                connectSocket: i.a.func,
                updateChatParams: i.a.func,
                updateOpenedMenu: i.a.func,
                totalUnreadCount: i.a.number,
                updateUserRequested: i.a.func,
                setToastInformation: i.a.func,
                currentConversation: i.a.object,
                updateGuideRequested: i.a.func,
                updateChatWindowStatus: i.a.func,
                showConversationDetail: i.a.bool,
                resetConversationRequested: i.a.func,
                updateConversationDetailStatus: i.a.func,
                changeConversationStatusRequested: i.a.func
            }, t.a = Y
        }).call(this, n("kiXb").t)
    },
    kiXb: function(e, t, n) {
        "use strict";
        n.r(t), n.d(t, "t", (function() {
            return r
        }));
        n("2Spj");
        var a = n("XzT5"),
            r = a.default.t.bind(a.default)
    },
    l4Er: function(e, t, n) {
        "use strict";
        n("I5cv");
        var a = n("lwsE"),
            r = n.n(a),
            o = n("W8MJ"),
            c = n.n(o),
            s = n("7W2i"),
            i = n.n(s),
            l = n("a1gu"),
            u = n.n(l),
            d = n("Nsbk"),
            p = n.n(d),
            f = n("q1tI"),
            h = n.n(f),
            m = n("/MKj"),
            v = n("tvxL"),
            b = n("FZfk");

        function y(e) {
            var t = function() {
                if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                if (Reflect.construct.sham) return !1;
                if ("function" == typeof Proxy) return !0;
                try {
                    return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                } catch (e) {
                    return !1
                }
            }();
            return function() {
                var n, a = p()(e);
                if (t) {
                    var r = p()(this).constructor;
                    n = Reflect.construct(a, arguments, r)
                } else n = a.apply(this, arguments);
                return u()(this, n)
            }
        }
        var g = function(e) {
                i()(n, e);
                var t = y(n);

                function n() {
                    return r()(this, n), t.apply(this, arguments)
                }
                return c()(n, [{
                    key: "render",
                    value: function() {
                        return h.a.createElement(b.a, this.props)
                    }
                }]), n
            }(h.a.PureComponent),
            w = {
                markMessagesRequested: v.markMessagesRequested,
                updateConversationFilter: v.updateConversationFilter,
                showConversationRequested: v.showConversationRequested,
                resetConversationRequested: v.resetConversationRequested,
                deleteConversationRequested: v.deleteConversationRequested,
                fetchConversationsRequested: v.fetchConversationsRequested,
                searchConversationsRequested: v.searchConversationsRequested,
                redirectConversationRequested: v.redirectConversationRequested,
                updateConversationDetailStatus: v.updateConversationDetailStatus,
                fetchDegradeConversationsDetail: v.fetchDegradeConversationsDetail
            };
        t.a = Object(m.connect)((function(e) {
            return {
                filter: Object(v.filterSelector)(e),
                keyword: Object(v.keywordSelector)(e),
                results: Object(v.resultsSelector)(e),
                listsHash: Object(v.listsHashSelector)(e),
                draftHash: Object(v.draftHashSelector)(e),
                socketFeedback: Object(v.feedbackSelector)(e),
                networkStatus: Object(v.networkStatusSelector)(e),
                totalUnreadConversationsCount: Object(v.totalUnreadConversationsCountSelector)(e),
                sortedConversations: Object(v.sortedConversationsSelector)(e),
                conversationDirection: Object(v.conversationDirectionSelector)(e),
                conversationHttpStatus: Object(v.conversationHttpStatusSelector)(e),
                searchConversationHttpStatus: Object(v.searchConversationHttpStatusSelector)(e)
            }
        }), w)(g)
    },
    oWPI: function(e, t, n) {
        e.exports = n.p + "6abdc0872a25853b36d17e7498335326.png"
    },
    tjUo: function(e, t, n) {
        "use strict";
        n.r(t);
        n("8+KV"), n("RW0V"), n("QiV6");
        var a = n("XnKn");
        Object(a.init)("VN", "live", "6.1.1", "vi-VN", {
            resources: {
                en: {
                    common: {
                        "common.error.hint_text": "Oops, the page crashed",
                        "header.tooltip.close_dialog": "Show message list only",
                        "header.tooltip.minimize": "Minimize",
                        "header.tooltip.see_all": "Go to the full version of Chat",
                        "login_error.tips": "Please try to reload or login the page again."
                    }
                },
                "vi-VN": {
                    common: {
                        "common.error.hint_text": "Oops, có lỗi xảy ra",
                        "header.tooltip.close_dialog": "Ẩn cửa sổ Chat",
                        "header.tooltip.minimize": "Thu gọn",
                        "header.tooltip.see_all": "Xem toàn bộ Webchat",
                        "login_error.tips": "Uiii, có lỗi rồi. Bạn vui lòng thử đăng nhập lại nhé!"
                    }
                }
            }
        });
        var r = n("q1tI"),
            o = n.n(r),
            c = n("i8i4"),
            s = n.n(c),
            i = n("/MKj"),
            l = n("0cfB"),
            u = n("wNa6"),
            d = n("W2jc"),
            p = n("tvxL"),
            f = {
                updateGuideRequested: p.updateGuideRequested,
                updateChatWindowStatus: p.updateChatWindowStatus
            },
            h = Object(i.connect)((function(e) {
                return {
                    newbie: Object(p.newbieSelector)(e),
                    isScChat: Object(p.isScChatSelector)(e),
                    showEntry: Object(p.showEntrySelector)(e),
                    currentUser: Object(p.currentUserSelector)(e) || {},
                    isSubAccount: Object(p.isSubAccountSelector)(e),
                    loginSuccess: Object(p.loginSuccessSelector)(e),
                    socketSuccess: Object(p.socketSuccessSelector)(e),
                    showChatWindow: Object(p.showChatWindowSelector)(e),
                    totalUnreadCount: Object(p.totalUnreadConversationsCountSelector)(e),
                    showConversationDetail: Object(p.showConversationDetailSelector)(e)
                }
            }), f)((function(e) {
                return o.a.createElement(d.a, e)
            }));
        n("p2bk");
        Object(p.initPapSdk)(), Object(p.initSentry)();
        var m = Object(a.getChatSource)(),
            v = function(e) {
                return {
                    position: "fixed",
                    right: m ? "16px" : "8px",
                    bottom: m ? "".concat((e ? 64 : 0) + 16, "px") : 0,
                    zIndex: 99999
                }
            },
            b = {
                create: function(e) {
                    var t, n, a = document.getElementById(e);
                    if (m && (t = (((n = (window.SellerFramework ? window.SellerFramework.app : window.dev) || {}).componentData || {}).FixBottomCard || {}).isFixed, n.on && n.on("FixBottomCardChange", (function(e) {
                            var t = v(e);
                            Object.keys(t).forEach((function(e) {
                                a.style[e] = t[e]
                            }))
                        }))), !a) {
                        (a = document.createElement("div")).setAttribute("id", e);
                        var r = v(t);
                        Object.keys(r).forEach((function(e) {
                            a.style[e] = r[e]
                        })), document.body.appendChild(a)
                    }
                    window.miniChatContainerId = e,
                        function(e, t) {
                            s.a.render(o.a.createElement(l.AppContainer, null, o.a.createElement(i.Provider, {
                                store: u.store
                            }, o.a.createElement(e, null))), document.getElementById(t))
                        }(h, e)
                },
                startOrderChat: function(e, t, n) {
                    var a = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {};
                    m && !a.entryPoint && (a.entryPoint = 7), u.store.dispatch(Object(p.redirectConversationRequested)({
                        userId: t,
                        shopId: e,
                        orderId: n,
                        entryPointType: a.entryPoint
                    }))
                },
                startChatWithText: function(e, t) {
                    var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
                    u.store.dispatch(Object(p.redirectConversationRequested)({
                        userId: e,
                        message: t,
                        entryPointType: n.entryPoint
                    }))
                },
                startChat: function(e, t, n) {
                    var a = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {};
                    u.store.dispatch(Object(p.redirectConversationRequested)({
                        userId: t,
                        shopId: e,
                        productId: n,
                        entryPointType: a.entryPoint
                    }))
                },
                minimizeChatWindow: function() {
                    u.store.dispatch(Object(p.updateChatWindowStatus)({
                        shouldShowWindow: !1
                    }))
                },
                inNewBie: function() {
                    var e = (u.store.getState().userReducer || {}).newbie,
                        t = void 0 === e ? [] : e;
                    return Object(a.checkEntryGuide)(t)
                },
                updateLoginStatus: function() {
                    u.store.dispatch(Object(p.loginRequested)())
                },
                logout: function() {
                    u.store.dispatch(Object(p.forceLogoutRequested)())
                }
            };
        window.ChatEasy = b, "function" == typeof window.chatReady && window.chatReady(), b.create("shopee-mini-chat-embedded")
    },
    wNa6: function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("ANjH"),
            r = n("Nz8i"),
            o = n("5fBF"),
            c = n("rRWa"),
            s = n("RIqP"),
            i = n.n(s),
            l = (n("bWfx"), n("o0o1")),
            u = n.n(l),
            d = n("5rFJ"),
            p = n("tvxL"),
            f = (n("RW0V"), n("ioFf"), n("0l/t"), n("mYba"), n("8+KV"), n("jm62"), n("WLL4"), n("HAE/"), n("lSNA")),
            h = n.n(f),
            m = n("J4zp"),
            v = n.n(m),
            b = (n("DNiP"), n("/8Fb"), n("L9s1"), n("Z2Ku"), n("FH7K"));

        function y(e, t) {
            var n = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var a = Object.getOwnPropertySymbols(e);
                t && (a = a.filter((function(t) {
                    return Object.getOwnPropertyDescriptor(e, t).enumerable
                }))), n.push.apply(n, a)
            }
            return n
        }

        function g(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n = null != arguments[t] ? arguments[t] : {};
                t % 2 ? y(Object(n), !0).forEach((function(t) {
                    h()(e, t, n[t])
                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : y(Object(n)).forEach((function(t) {
                    Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                }))
            }
            return e
        }
        var w = Object(b.a)({
                REDUX_RESET: function() {
                    return {}
                }
            }).reduxReset,
            C = u.a.mark(R),
            O = u.a.mark(S);

        function R(e) {
            var t;
            return u.a.wrap((function(n) {
                for (;;) switch (n.prev = n.next) {
                    case 0:
                        if (t = e.payload.resource, n.t0 = "login" === t, !n.t0) {
                            n.next = 5;
                            break
                        }
                        return n.next = 5, Object(d.put)(Object(p.updateChatEntryStatus)({
                            showEntry: !0
                        }));
                    case 5:
                        return n.next = 7, Object(d.put)(Object(p.updateLoginSuccessStatus)({
                            loginSuccess: !1
                        }));
                    case 7:
                        return n.next = 9, Object(d.put)(Object(p.forceLogoutRequested)());
                    case 9:
                    case "end":
                        return n.stop()
                }
            }), C)
        }

        function S() {
            return u.a.wrap((function(e) {
                for (;;) switch (e.prev = e.next) {
                    case 0:
                        return e.next = 2, Object(d.takeEvery)(p.handle401ErrorRequested, R);
                    case 2:
                    case "end":
                        return e.stop()
                }
            }), O)
        }
        var k = n("7i0w"),
            E = u.a.mark(I),
            j = {
                blacklist: ["modalReducer", "userReducer"]
            },
            N = {
                modalReducer: p.modalReducer,
                userReducer: p.userReducer,
                shopReducer: p.shopReducer,
                toastReducer: p.toastReducer,
                draftReducer: p.draftReducer,
                entityReducer: p.entityReducer,
                socketReducer: p.socketReducer,
                settingsReducer: p.settingsReducer,
                unreadCountReducer: p.unreadCountReducer,
                conversationReducer: p.conversationReducer,
                translatePreferenceReducer: p.translatePreferenceReducer
            };

        function I() {
            return u.a.wrap((function(e) {
                for (;;) switch (e.prev = e.next) {
                    case 0:
                        return e.next = 2, Object(d.takeEvery)("@@Internal/ModuleManager/ModuleAdded", u.a.mark((function e(t) {
                            var n;
                            return u.a.wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        n = t.payload, Object(k.register)(n);
                                    case 2:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        })));
                    case 2:
                    case "end":
                        return e.stop()
                }
            }), E)
        }
        var x = u.a.mark((function e() {
                return u.a.wrap((function(e) {
                    for (;;) switch (e.prev = e.next) {
                        case 0:
                            return e.next = 2, Object(d.all)([I, S].concat(i()(p.watchUserSagas), i()(p.watchShopSagas), i()(p.watchToastSagas), i()(p.watchSocketSagas), i()(p.watchUnreadSagas), i()(p.watchTranslationSagas), i()(p.watchConversationSagas), [k.watchModuleCenterChannel]).map(d.call));
                        case 2:
                        case "end":
                            return e.stop()
                    }
                }), e)
            })),
            M = n("XnKn"),
            P = u.a.mark(_);

        function _() {
            var e;
            return u.a.wrap((function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return t.prev = 0, t.next = 3, Object(d.put)(Object(p.setChatSource)({
                            isScChat: Object(M.getChatSource)()
                        }));
                    case 3:
                        return t.next = 5, Object(d.call)(p.login);
                    case 5:
                        if (e = t.sent, e.user) {
                            t.next = 11;
                            break
                        }
                        return t.next = 10, Object(d.put)(Object(p.updateLoginSuccessStatus)({
                            loginSuccess: !1
                        }));
                    case 10:
                        return t.abrupt("return");
                    case 11:
                        return t.next = 13, Object(d.put)(Object(p.updateLoginSuccessStatus)({
                            loginSuccess: !0
                        }));
                    case 13:
                        return t.next = 15, Object(d.call)(p.handleLoginSucceeded, e);
                    case 15:
                        return t.next = 17, Object(d.put)(Object(p.updateUnreadCount)({
                            type: p.unreadCountActions.REFRESH_TOTAL_UNREAD_CONVERSATION_COUNT
                        }));
                    case 17:
                        return t.next = 19, Object(d.spawn)(p.fetchConversationsRequestedSaga, {
                            payload: {
                                direction: "reset"
                            }
                        });
                    case 19:
                        t.next = 26;
                        break;
                    case 21:
                        return t.prev = 21, t.t0 = t.catch(0), console.error("[Load Chat Failed]\n", t.t0), t.next = 26, Object(d.put)(Object(p.updateLoginSuccessStatus)({
                            loginSuccess: !1
                        }));
                    case 26:
                    case "end":
                        return t.stop()
                }
            }), P, null, [
                [0, 21]
            ])
        }
        n.d(t, "store", (function() {
            return W
        }));
        var T = Object(c.default)(),
            L = Object(a.applyMiddleware)(T),
            W = Object(r.createStore)({
                advancedCombineReducers: function(e) {
                    return Object(a.combineReducers)(function(e, t) {
                        return Object.entries(t).reduce((function(t, n) {
                            var a = v()(n, 2),
                                r = a[0],
                                o = a[1];
                            return g(g({}, t), {}, h()({}, r, (function(t, n) {
                                return n.type !== "".concat(w) || e.blacklist.includes(r) || (t = void 0), o(t, n)
                            })))
                        }), {})
                    }(j, e))
                },
                enhancers: [L],
                extensions: [Object(o.getSagaExtension)()]
            }, {
                id: "root",
                reducerMap: N
            }),
            D = T.run(x);
        T.run(_);
        ! function e() {
            D.toPromise().catch((function(t) {
                D.cancel(), D = T.run(x), e()
            }))
        }()
    }
});
//# sourceMappingURL=app.748942c6.3c3a757cbde2692f55e8.js.map