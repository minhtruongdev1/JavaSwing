(("undefined" != typeof self ? self : this).webpackChunkshopee_pc = ("undefined" != typeof self ? self : this).webpackChunkshopee_pc || []).push([
    [5760], {
        2552: function(e, t, n) {
            "use strict";
            n.d(t, {
                k: function() {
                    return s
                }
            });
            var r = n(27378),
                o = n(79308),
                i = n(84106);
            n(18363);
            var a = {};

            function s(e) {
                var t = e.limit,
                    n = e.offset,
                    s = e.isItemOnly,
                    c = e.itemCardStyle,
                    u = e.forceRefetch,
                    l = e.skipFirstPage,
                    m = e.getDailyDiscoverMainStore,
                    f = (0, o.useDispatch)(),
                    d = r.useState(n || 0),
                    p = d[0],
                    y = d[1],
                    v = r.useMemo((function() {
                        return p + "-" + (p + t)
                    }), [p, t]),
                    E = r.useCallback((function() {
                        return !u && !!a[v]
                    }), [u, v]),
                    _ = r.useCallback((function() {
                        a[v] || (a[v] = !0)
                    }), [v]);
                r.useEffect((function() {
                    l && 0 === p ? _() : f((0, i.aN)({
                        offset: p,
                        limit: t,
                        itemCardStyle: c,
                        shouldSkipCall: E,
                        onFinish: _
                    }))
                }), [p, f, c, t, _, E, l]);
                var I = r.useCallback((function(e) {
                        y(e)
                    }), []),
                    C = (0, o.useSelector)((function(e) {
                        return m(e)
                    }));
                return {
                    items: r.useMemo((function() {
                        return s ? (0, i.l_)(C, {
                            limit: t,
                            offset: n
                        }) : (0, i.KM)(C, {
                            limit: t,
                            offset: n
                        })
                    }), [s, t, n, C]),
                    total: (0, i.NU)(C),
                    limit: t,
                    offset: p,
                    store: C,
                    loadPage: I
                }
            }
        },
        46316: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return b
                }
            });
            var r, o = n(27378),
                i = n(94184),
                a = n.n(i),
                s = n(40830),
                c = n(49370),
                u = n(98466),
                l = n(26235),
                m = "_3BrES5",
                f = "_3PNTgJ",
                d = (0, u.Z)((function(e) {
                    var t = e.url,
                        n = e.recommendType,
                        r = e.trackingRef;
                    return o.createElement("div", {
                        className: m,
                        ref: r
                    }, o.createElement(c.Sy, {
                        size: "m",
                        link: t,
                        className: f,
                        recommendType: n
                    }, (0, l.t)("rcmd_label_see_more")))
                }), "HomeRecommendSeeMoreButton"),
                p = n(45141),
                y = n(34995),
                v = n(22333),
                E = n(3811),
                _ = n(76282),
                I = n(41525),
                C = n(6508),
                S = n(91208),
                h = "_1syN0y",
                D = "_1YAByT",
                g = "_3OV6O1",
                O = "_1DCRPM",
                T = "SvLatV",
                k = ((r = {})[S.V2.Tiny] = O, r[S.V2.Portrait] = g, r),
                N = function(e) {
                    return k.hasOwnProperty(e) ? {
                        responsiveClassName: k[e]
                    } : {
                        responsiveClassName: ""
                    }
                },
                b = function(e) {
                    var t = e.items,
                        n = e.total,
                        r = e.loading,
                        i = e.isUserAdult,
                        c = e.tabId,
                        u = e.recommendType,
                        m = (0, S.uW)({
                            mapLayoutTypeToUsedLayoutValue: N
                        }).responsiveClassName;
                    if (r) return o.createElement("div", {
                        className: h
                    }, o.createElement(p.Z, {
                        show: !0,
                        hideOverlay: !0
                    }));
                    if (!t || !t.length) return o.createElement("div", {
                        className: T
                    }, (0, l.t)("label_no_products_found"));
                    var f = u === _.P.DAILY_DISCOVER ? E.jT.getUrl({
                            pageNumber: 2
                        }) : E.SP.getUrl({
                            pageNumber: 2
                        }),
                        g = !!n && n > I.ID.DAILY_DISCOVER_BATCH_SIZE && f;
                    return o.createElement("div", {
                        className: h
                    }, t.map((function(e, t) {
                        var n = {
                                item: e,
                                recommendType: u,
                                listPosition: t,
                                from: e.from,
                                showItemFindSimilarButton: !0,
                                adsTrackingData: {
                                    placement: C.E_.DAILY_DISCOVER,
                                    item: {
                                        adsid: e.adsid,
                                        abtest_sign: e.info
                                    }
                                },
                                isUserAdult: i,
                                tabId: c
                            },
                            r = t < 18 ? o.createElement(s.Z, n) : o.createElement(y.Z, {
                                placeholder: o.createElement(s.C, null)
                            }, o.createElement(s.Z, n));
                        return o.createElement(v.ZP, {
                            key: e.itemid,
                            targetData: {
                                index: t
                            }
                        }, o.createElement("div", {
                            className: a()(D, m)
                        }, r))
                    })), g && o.createElement(d, {
                        url: f,
                        recommendType: u
                    }))
                }
        },
        51611: function(e, t, n) {
            "use strict";
            n.r(t);
            var r = n(27378),
                o = n(79308),
                i = n(84691),
                a = n(46316),
                s = n(69627),
                c = n(84106),
                u = n(2552),
                l = n(93387),
                m = n(21875),
                f = n(41525),
                d = n(18363),
                p = n(77576);
            var y = [d.Z.INIT, d.Z.REQ];
            t.default = (0, i.compose)(s.fg, (0, o.connect)())((function(e) {
                var t = e.recommendType,
                    n = e.tabId,
                    o = e.isUserAdult,
                    i = e.isConfigFromBff,
                    s = e.injectAsyncReducer;
                r.useEffect((function() {
                    var e;
                    s(((e = {})[f.tW] = c.fp, e))
                }), [s]);
                var d = (0, u.k)({
                        limit: f.ID.DAILY_DISCOVER_BATCH_SIZE,
                        getDailyDiscoverMainStore: m.S,
                        isItemOnly: !0,
                        itemCardStyle: p.$o.SIMPLIFIED_COUNT,
                        skipFirstPage: i
                    }),
                    v = d.items,
                    E = d.total,
                    _ = d.store,
                    I = r.useMemo((function() {
                        return (0, l.O)(v).slice(0, f.ID.DAILY_DISCOVER_DISPLAY_SIZE)
                    }), [v]),
                    C = !_ || y.includes(_.progress);
                return r.createElement(a.Z, {
                    items: I,
                    total: E,
                    loading: C,
                    isUserAdult: o,
                    tabId: n,
                    recommendType: t
                })
            }))
        },
        21875: function(e, t, n) {
            "use strict";
            n.d(t, {
                S: function() {
                    return o
                },
                E: function() {
                    return i
                }
            });
            var r = n(41525);

            function o(e) {
                return e[r.tW]
            }

            function i(e) {
                return e[r.of]
            }
        },
        34995: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return s
                }
            });
            var r = n(27378),
                o = n.n(r),
                i = n(61439);

            function a(e, t) {
                return (a = Object.setPrototypeOf || function(e, t) {
                    return e.__proto__ = t, e
                })(e, t)
            }
            var s = function(e) {
                var t, n;

                function r(t) {
                    var n;
                    return (n = e.call(this, t) || this).state = {
                        showContent: !1
                    }, n
                }
                return n = e, (t = r).prototype = Object.create(n.prototype), t.prototype.constructor = t, a(t, n), r.prototype.render = function() {
                    var e = this,
                        t = this.props,
                        n = t.wrapperStyle,
                        r = t.extraRenderCondition,
                        a = void 0 === r || r,
                        s = t.onEnterViewPort,
                        c = t.children,
                        u = t.placeholder;
                    return this.state.showContent && a ? c : o().createElement(i.U, {
                        onEnterViewPort: function() {
                            "function" == typeof s && s(), e.setState({
                                showContent: !0
                            })
                        }
                    }, o().createElement("div", {
                        style: n
                    }, !!u && u))
                }, r
            }(r.Component)
        },
        93387: function(e, t, n) {
            "use strict";
            n.d(t, {
                O: function() {
                    return r.Ok
                }
            });
            var r = n(72364)
        }
    }
]);
//# sourceMappingURL=https://shopee.sg/assets/HomeDailyDiscoverMainContent.4b2066bda7ac64b00f03.js.map