! function() {
    var t = {
            2829: function(t, n, e) {
                var r = e(8e3),
                    o = e(9711),
                    i = r("keys");
                t.exports = function(t) {
                    return i[t] || (i[t] = o(t))
                }
            },
            2484: function(t, n, e) {
                var r = e(7854),
                    o = e(3505),
                    i = "__core-js_shared__",
                    c = r[i] || o(i, {});
                t.exports = c
            },
            8e3: function(t, n, e) {
                var r = e(1913),
                    o = e(2484);
                (t.exports = function(t, n) {
                    return o[t] || (o[t] = void 0 !== n ? n : {})
                })("versions", []).push({
                    version: "3.17.2",
                    mode: r ? "pure" : "global",
                    copyright: "© 2021 Denis Pushkarev (zloirock.ru)"
                })
            },
            8865: function(t, n, e) {
                "use strict";
                e.d(n, {
                    getRuleSet: function() {
                        return f
                    },
                    injectRules: function() {
                        return a
                    },
                    v2ToV3: function() {
                        return s
                    }
                });
                e(6992), e(8674);
                var r = null,
                    o = {};
                var i = null;

                function c() {
                    return i || (i = function t(n) {
                        return e.e(631).then(e.bind(e, 6631)).catch((function(e) {
                            return n >= 5 ? null : function(t) {
                                return new Promise((function(n) {
                                    return setTimeout(n, t)
                                }))
                            }(1e3 * Math.pow(2, n++)).then((function() {
                                return t(n)
                            }))
                        }))
                    }(0))
                }

                function u() {
                    return r ? Promise.resolve(r) : c().then((function(t) {
                        if (!t || !t.conversion) return null;
                        r = t;
                        var n = t.conversion;
                        return self.match = n.match, self.ruleSet = n.ruleSet, self.schema = n.schema, t
                    }))
                }

                function f() {
                    return u().then((function(t) {
                        return t && t.conversion ? p(t.conversion.getRuleSet()) : []
                    }))
                }

                function a(t) {
                    return u().then((function(n) {
                        if (n && !o[t]) try {
                            self.importScripts(t), o[t] = !0
                        } catch (t) {}
                    }))
                }

                function s(t) {
                    if (t && "v3" === t.type) return Promise.resolve([t]);
                    var n = e.p;
                    return e.p = "https://deo.shopeemobile.com/shopee/shopee-pcmall-live-sg//assets/", u().then((function(r) {
                        if (e.p = n, !r || !r.conversion) return [t];
                        var o = r.conversion.v2ToV3(t).map((function(t) {
                            if (t && t.errorObj) try {
                                t.errorObj = Object.assign({}, t.errorObj)
                            } catch (n) {
                                t.errorObj = {}
                            }
                            return t
                        }));
                        return o && o.length > 0 ? o : [t]
                    }))
                }

                function p(t) {
                    if (Array.isArray(t)) return t.map(p);
                    if ("object" == typeof t) {
                        var n = {};
                        for (var e in t) n[e] = p(t[e]);
                        return n
                    }
                    return "function" == typeof t ? t.name : t
                }
                addEventListener("message", (function(t) {
                    var e, r = t.data,
                        o = r.type,
                        i = r.method,
                        c = r.id,
                        u = r.params;
                    "RPC" === o && i && ((e = n[i]) ? Promise.resolve().then((function() {
                        return e.apply(n, u)
                    })) : Promise.reject("No such method")).then((function(t) {
                        postMessage({
                            type: "RPC",
                            id: c,
                            result: t
                        })
                    })).catch((function(t) {
                        var n = {
                            message: t
                        };
                        t.stack && (n.message = t.message, n.stack = t.stack, n.name = t.name), postMessage({
                            type: "RPC",
                            id: c,
                            error: n
                        })
                    }))
                })), postMessage({
                    type: "RPC",
                    method: "ready"
                })
            },
            3099: function(t) {
                t.exports = function(t) {
                    if ("function" != typeof t) throw TypeError(String(t) + " is not a function");
                    return t
                }
            },
            6077: function(t, n, e) {
                var r = e(111);
                t.exports = function(t) {
                    if (!r(t) && null !== t) throw TypeError("Can't set " + String(t) + " as a prototype");
                    return t
                }
            },
            1223: function(t, n, e) {
                var r = e(5112),
                    o = e(30),
                    i = e(3070),
                    c = r("unscopables"),
                    u = Array.prototype;
                null == u[c] && i.f(u, c, {
                    configurable: !0,
                    value: o(null)
                }), t.exports = function(t) {
                    u[c][t] = !0
                }
            },
            5787: function(t) {
                t.exports = function(t, n, e) {
                    if (!(t instanceof n)) throw TypeError("Incorrect " + (e ? e + " " : "") + "invocation");
                    return t
                }
            },
            9670: function(t, n, e) {
                var r = e(111);
                t.exports = function(t) {
                    if (!r(t)) throw TypeError(String(t) + " is not an object");
                    return t
                }
            },
            1318: function(t, n, e) {
                var r = e(5656),
                    o = e(7466),
                    i = e(1400),
                    c = function(t) {
                        return function(n, e, c) {
                            var u, f = r(n),
                                a = o(f.length),
                                s = i(c, a);
                            if (t && e != e) {
                                for (; a > s;)
                                    if ((u = f[s++]) != u) return !0
                            } else
                                for (; a > s; s++)
                                    if ((t || s in f) && f[s] === e) return t || s || 0;
                            return !t && -1
                        }
                    };
                t.exports = {
                    includes: c(!0),
                    indexOf: c(!1)
                }
            },
            7072: function(t, n, e) {
                var r = e(5112)("iterator"),
                    o = !1;
                try {
                    var i = 0,
                        c = {
                            next: function() {
                                return {
                                    done: !!i++
                                }
                            },
                            return: function() {
                                o = !0
                            }
                        };
                    c[r] = function() {
                        return this
                    }, Array.from(c, (function() {
                        throw 2
                    }))
                } catch (t) {}
                t.exports = function(t, n) {
                    if (!n && !o) return !1;
                    var e = !1;
                    try {
                        var i = {};
                        i[r] = function() {
                            return {
                                next: function() {
                                    return {
                                        done: e = !0
                                    }
                                }
                            }
                        }, t(i)
                    } catch (t) {}
                    return e
                }
            },
            4326: function(t) {
                var n = {}.toString;
                t.exports = function(t) {
                    return n.call(t).slice(8, -1)
                }
            },
            648: function(t, n, e) {
                var r = e(1694),
                    o = e(4326),
                    i = e(5112)("toStringTag"),
                    c = "Arguments" == o(function() {
                        return arguments
                    }());
                t.exports = r ? o : function(t) {
                    var n, e, r;
                    return void 0 === t ? "Undefined" : null === t ? "Null" : "string" == typeof(e = function(t, n) {
                        try {
                            return t[n]
                        } catch (t) {}
                    }(n = Object(t), i)) ? e : c ? o(n) : "Object" == (r = o(n)) && "function" == typeof n.callee ? "Arguments" : r
                }
            },
            9920: function(t, n, e) {
                var r = e(6656),
                    o = e(3887),
                    i = e(1236),
                    c = e(3070);
                t.exports = function(t, n) {
                    for (var e = o(n), u = c.f, f = i.f, a = 0; a < e.length; a++) {
                        var s = e[a];
                        r(t, s) || u(t, s, f(n, s))
                    }
                }
            },
            8544: function(t, n, e) {
                var r = e(7293);
                t.exports = !r((function() {
                    function t() {}
                    return t.prototype.constructor = null, Object.getPrototypeOf(new t) !== t.prototype
                }))
            },
            4994: function(t, n, e) {
                "use strict";
                var r = e(3383).IteratorPrototype,
                    o = e(30),
                    i = e(9114),
                    c = e(8003),
                    u = e(7497),
                    f = function() {
                        return this
                    };
                t.exports = function(t, n, e) {
                    var a = n + " Iterator";
                    return t.prototype = o(r, {
                        next: i(1, e)
                    }), c(t, a, !1, !0), u[a] = f, t
                }
            },
            8880: function(t, n, e) {
                var r = e(9781),
                    o = e(3070),
                    i = e(9114);
                t.exports = r ? function(t, n, e) {
                    return o.f(t, n, i(1, e))
                } : function(t, n, e) {
                    return t[n] = e, t
                }
            },
            9114: function(t) {
                t.exports = function(t, n) {
                    return {
                        enumerable: !(1 & t),
                        configurable: !(2 & t),
                        writable: !(4 & t),
                        value: n
                    }
                }
            },
            654: function(t, n, e) {
                "use strict";
                var r = e(2109),
                    o = e(4994),
                    i = e(9518),
                    c = e(7674),
                    u = e(8003),
                    f = e(8880),
                    a = e(1320),
                    s = e(5112),
                    p = e(1913),
                    l = e(7497),
                    v = e(3383),
                    h = v.IteratorPrototype,
                    y = v.BUGGY_SAFARI_ITERATORS,
                    d = s("iterator"),
                    m = "keys",
                    g = "values",
                    b = "entries",
                    x = function() {
                        return this
                    };
                t.exports = function(t, n, e, s, v, w, j) {
                    o(e, n, s);
                    var O, S, P, T = function(t) {
                            if (t === v && I) return I;
                            if (!y && t in k) return k[t];
                            switch (t) {
                                case m:
                                case g:
                                case b:
                                    return function() {
                                        return new e(this, t)
                                    }
                            }
                            return function() {
                                return new e(this)
                            }
                        },
                        E = n + " Iterator",
                        _ = !1,
                        k = t.prototype,
                        A = k[d] || k["@@iterator"] || v && k[v],
                        I = !y && A || T(v),
                        M = "Array" == n && k.entries || A;
                    if (M && (O = i(M.call(new t)), h !== Object.prototype && O.next && (p || i(O) === h || (c ? c(O, h) : "function" != typeof O[d] && f(O, d, x)), u(O, E, !0, !0), p && (l[E] = x))), v == g && A && A.name !== g && (_ = !0, I = function() {
                            return A.call(this)
                        }), p && !j || k[d] === I || f(k, d, I), l[n] = I, v)
                        if (S = {
                                values: T(g),
                                keys: w ? I : T(m),
                                entries: T(b)
                            }, j)
                            for (P in S)(y || _ || !(P in k)) && a(k, P, S[P]);
                        else r({
                            target: n,
                            proto: !0,
                            forced: y || _
                        }, S);
                    return S
                }
            },
            9781: function(t, n, e) {
                var r = e(7293);
                t.exports = !r((function() {
                    return 7 != Object.defineProperty({}, 1, {
                        get: function() {
                            return 7
                        }
                    })[1]
                }))
            },
            317: function(t, n, e) {
                var r = e(7854),
                    o = e(111),
                    i = r.document,
                    c = o(i) && o(i.createElement);
                t.exports = function(t) {
                    return c ? i.createElement(t) : {}
                }
            },
            7871: function(t) {
                t.exports = "object" == typeof window
            },
            1528: function(t, n, e) {
                var r = e(8113),
                    o = e(7854);
                t.exports = /ipad|iphone|ipod/i.test(r) && void 0 !== o.Pebble
            },
            6833: function(t, n, e) {
                var r = e(8113);
                t.exports = /(?:ipad|iphone|ipod).*applewebkit/i.test(r)
            },
            5268: function(t, n, e) {
                var r = e(4326),
                    o = e(7854);
                t.exports = "process" == r(o.process)
            },
            1036: function(t, n, e) {
                var r = e(8113);
                t.exports = /web0s(?!.*chrome)/i.test(r)
            },
            8113: function(t, n, e) {
                var r = e(5005);
                t.exports = r("navigator", "userAgent") || ""
            },
            7392: function(t, n, e) {
                var r, o, i = e(7854),
                    c = e(8113),
                    u = i.process,
                    f = i.Deno,
                    a = u && u.versions || f && f.version,
                    s = a && a.v8;
                s ? o = (r = s.split("."))[0] < 4 ? 1 : r[0] + r[1] : c && (!(r = c.match(/Edge\/(\d+)/)) || r[1] >= 74) && (r = c.match(/Chrome\/(\d+)/)) && (o = r[1]), t.exports = o && +o
            },
            748: function(t) {
                t.exports = ["constructor", "hasOwnProperty", "isPrototypeOf", "propertyIsEnumerable", "toLocaleString", "toString", "valueOf"]
            },
            2109: function(t, n, e) {
                var r = e(7854),
                    o = e(1236).f,
                    i = e(8880),
                    c = e(1320),
                    u = e(3505),
                    f = e(9920),
                    a = e(4705);
                t.exports = function(t, n) {
                    var e, s, p, l, v, h = t.target,
                        y = t.global,
                        d = t.stat;
                    if (e = y ? r : d ? r[h] || u(h, {}) : (r[h] || {}).prototype)
                        for (s in n) {
                            if (l = n[s], p = t.noTargetGet ? (v = o(e, s)) && v.value : e[s], !a(y ? s : h + (d ? "." : "#") + s, t.forced) && void 0 !== p) {
                                if (typeof l == typeof p) continue;
                                f(l, p)
                            }(t.sham || p && p.sham) && i(l, "sham", !0), c(e, s, l, t)
                        }
                }
            },
            7293: function(t) {
                t.exports = function(t) {
                    try {
                        return !!t()
                    } catch (t) {
                        return !0
                    }
                }
            },
            9974: function(t, n, e) {
                var r = e(3099);
                t.exports = function(t, n, e) {
                    if (r(t), void 0 === n) return t;
                    switch (e) {
                        case 0:
                            return function() {
                                return t.call(n)
                            };
                        case 1:
                            return function(e) {
                                return t.call(n, e)
                            };
                        case 2:
                            return function(e, r) {
                                return t.call(n, e, r)
                            };
                        case 3:
                            return function(e, r, o) {
                                return t.call(n, e, r, o)
                            }
                    }
                    return function() {
                        return t.apply(n, arguments)
                    }
                }
            },
            5005: function(t, n, e) {
                var r = e(7854),
                    o = function(t) {
                        return "function" == typeof t ? t : void 0
                    };
                t.exports = function(t, n) {
                    return arguments.length < 2 ? o(r[t]) : r[t] && r[t][n]
                }
            },
            1246: function(t, n, e) {
                var r = e(648),
                    o = e(7497),
                    i = e(5112)("iterator");
                t.exports = function(t) {
                    if (null != t) return t[i] || t["@@iterator"] || o[r(t)]
                }
            },
            8554: function(t, n, e) {
                var r = e(9670),
                    o = e(1246);
                t.exports = function(t, n) {
                    var e = arguments.length < 2 ? o(t) : n;
                    if ("function" != typeof e) throw TypeError(String(t) + " is not iterable");
                    return r(e.call(t))
                }
            },
            7854: function(t, n, e) {
                var r = function(t) {
                    return t && t.Math == Math && t
                };
                t.exports = r("object" == typeof globalThis && globalThis) || r("object" == typeof window && window) || r("object" == typeof self && self) || r("object" == typeof e.g && e.g) || function() {
                    return this
                }() || Function("return this")()
            },
            6656: function(t, n, e) {
                var r = e(7908),
                    o = {}.hasOwnProperty;
                t.exports = Object.hasOwn || function(t, n) {
                    return o.call(r(t), n)
                }
            },
            3501: function(t) {
                t.exports = {}
            },
            842: function(t, n, e) {
                var r = e(7854);
                t.exports = function(t, n) {
                    var e = r.console;
                    e && e.error && (1 === arguments.length ? e.error(t) : e.error(t, n))
                }
            },
            490: function(t, n, e) {
                var r = e(5005);
                t.exports = r("document", "documentElement")
            },
            4664: function(t, n, e) {
                var r = e(9781),
                    o = e(7293),
                    i = e(317);
                t.exports = !r && !o((function() {
                    return 7 != Object.defineProperty(i("div"), "a", {
                        get: function() {
                            return 7
                        }
                    }).a
                }))
            },
            8361: function(t, n, e) {
                var r = e(7293),
                    o = e(4326),
                    i = "".split;
                t.exports = r((function() {
                    return !Object("z").propertyIsEnumerable(0)
                })) ? function(t) {
                    return "String" == o(t) ? i.call(t, "") : Object(t)
                } : Object
            },
            2788: function(t, n, e) {
                var r = e(2484),
                    o = Function.toString;
                "function" != typeof r.inspectSource && (r.inspectSource = function(t) {
                    return o.call(t)
                }), t.exports = r.inspectSource
            },
            9909: function(t, n, e) {
                var r, o, i, c = e(8536),
                    u = e(7854),
                    f = e(111),
                    a = e(8880),
                    s = e(6656),
                    p = e(2484),
                    l = e(2829),
                    v = e(3501),
                    h = "Object already initialized",
                    y = u.WeakMap;
                if (c || p.state) {
                    var d = p.state || (p.state = new y),
                        m = d.get,
                        g = d.has,
                        b = d.set;
                    r = function(t, n) {
                        if (g.call(d, t)) throw new TypeError(h);
                        return n.facade = t, b.call(d, t, n), n
                    }, o = function(t) {
                        return m.call(d, t) || {}
                    }, i = function(t) {
                        return g.call(d, t)
                    }
                } else {
                    var x = l("state");
                    v[x] = !0, r = function(t, n) {
                        if (s(t, x)) throw new TypeError(h);
                        return n.facade = t, a(t, x, n), n
                    }, o = function(t) {
                        return s(t, x) ? t[x] : {}
                    }, i = function(t) {
                        return s(t, x)
                    }
                }
                t.exports = {
                    set: r,
                    get: o,
                    has: i,
                    enforce: function(t) {
                        return i(t) ? o(t) : r(t, {})
                    },
                    getterFor: function(t) {
                        return function(n) {
                            var e;
                            if (!f(n) || (e = o(n)).type !== t) throw TypeError("Incompatible receiver, " + t + " required");
                            return e
                        }
                    }
                }
            },
            7659: function(t, n, e) {
                var r = e(5112),
                    o = e(7497),
                    i = r("iterator"),
                    c = Array.prototype;
                t.exports = function(t) {
                    return void 0 !== t && (o.Array === t || c[i] === t)
                }
            },
            4705: function(t, n, e) {
                var r = e(7293),
                    o = /#|\.prototype\./,
                    i = function(t, n) {
                        var e = u[c(t)];
                        return e == a || e != f && ("function" == typeof n ? r(n) : !!n)
                    },
                    c = i.normalize = function(t) {
                        return String(t).replace(o, ".").toLowerCase()
                    },
                    u = i.data = {},
                    f = i.NATIVE = "N",
                    a = i.POLYFILL = "P";
                t.exports = i
            },
            111: function(t) {
                t.exports = function(t) {
                    return "object" == typeof t ? null !== t : "function" == typeof t
                }
            },
            1913: function(t) {
                t.exports = !1
            },
            2190: function(t, n, e) {
                var r = e(5005),
                    o = e(3307);
                t.exports = o ? function(t) {
                    return "symbol" == typeof t
                } : function(t) {
                    var n = r("Symbol");
                    return "function" == typeof n && Object(t) instanceof n
                }
            },
            408: function(t, n, e) {
                var r = e(9670),
                    o = e(7659),
                    i = e(7466),
                    c = e(9974),
                    u = e(8554),
                    f = e(1246),
                    a = e(9212),
                    s = function(t, n) {
                        this.stopped = t, this.result = n
                    };
                t.exports = function(t, n, e) {
                    var p, l, v, h, y, d, m, g = e && e.that,
                        b = !(!e || !e.AS_ENTRIES),
                        x = !(!e || !e.IS_ITERATOR),
                        w = !(!e || !e.INTERRUPTED),
                        j = c(n, g, 1 + b + w),
                        O = function(t) {
                            return p && a(p, "normal", t), new s(!0, t)
                        },
                        S = function(t) {
                            return b ? (r(t), w ? j(t[0], t[1], O) : j(t[0], t[1])) : w ? j(t, O) : j(t)
                        };
                    if (x) p = t;
                    else {
                        if ("function" != typeof(l = f(t))) throw TypeError("Target is not iterable");
                        if (o(l)) {
                            for (v = 0, h = i(t.length); h > v; v++)
                                if ((y = S(t[v])) && y instanceof s) return y;
                            return new s(!1)
                        }
                        p = u(t, l)
                    }
                    for (d = p.next; !(m = d.call(p)).done;) {
                        try {
                            y = S(m.value)
                        } catch (t) {
                            a(p, "throw", t)
                        }
                        if ("object" == typeof y && y && y instanceof s) return y
                    }
                    return new s(!1)
                }
            },
            9212: function(t, n, e) {
                var r = e(9670);
                t.exports = function(t, n, e) {
                    var o, i;
                    r(t);
                    try {
                        if (void 0 === (o = t.return)) {
                            if ("throw" === n) throw e;
                            return e
                        }
                        o = o.call(t)
                    } catch (t) {
                        i = !0, o = t
                    }
                    if ("throw" === n) throw e;
                    if (i) throw o;
                    return r(o), e
                }
            },
            3383: function(t, n, e) {
                "use strict";
                var r, o, i, c = e(7293),
                    u = e(9518),
                    f = e(8880),
                    a = e(6656),
                    s = e(5112),
                    p = e(1913),
                    l = s("iterator"),
                    v = !1;
                [].keys && ("next" in (i = [].keys()) ? (o = u(u(i))) !== Object.prototype && (r = o) : v = !0);
                var h = null == r || c((function() {
                    var t = {};
                    return r[l].call(t) !== t
                }));
                h && (r = {}), p && !h || a(r, l) || f(r, l, (function() {
                    return this
                })), t.exports = {
                    IteratorPrototype: r,
                    BUGGY_SAFARI_ITERATORS: v
                }
            },
            7497: function(t) {
                t.exports = {}
            },
            5948: function(t, n, e) {
                var r, o, i, c, u, f, a, s, p = e(7854),
                    l = e(1236).f,
                    v = e(261).set,
                    h = e(6833),
                    y = e(1528),
                    d = e(1036),
                    m = e(5268),
                    g = p.MutationObserver || p.WebKitMutationObserver,
                    b = p.document,
                    x = p.process,
                    w = p.Promise,
                    j = l(p, "queueMicrotask"),
                    O = j && j.value;
                O || (r = function() {
                    var t, n;
                    for (m && (t = x.domain) && t.exit(); o;) {
                        n = o.fn, o = o.next;
                        try {
                            n()
                        } catch (t) {
                            throw o ? c() : i = void 0, t
                        }
                    }
                    i = void 0, t && t.enter()
                }, h || m || d || !g || !b ? !y && w && w.resolve ? ((a = w.resolve(void 0)).constructor = w, s = a.then, c = function() {
                    s.call(a, r)
                }) : c = m ? function() {
                    x.nextTick(r)
                } : function() {
                    v.call(p, r)
                } : (u = !0, f = b.createTextNode(""), new g(r).observe(f, {
                    characterData: !0
                }), c = function() {
                    f.data = u = !u
                })), t.exports = O || function(t) {
                    var n = {
                        fn: t,
                        next: void 0
                    };
                    i && (i.next = n), o || (o = n, c()), i = n
                }
            },
            3366: function(t, n, e) {
                var r = e(7854);
                t.exports = r.Promise
            },
            133: function(t, n, e) {
                var r = e(7392),
                    o = e(7293);
                t.exports = !!Object.getOwnPropertySymbols && !o((function() {
                    var t = Symbol();
                    return !String(t) || !(Object(t) instanceof Symbol) || !Symbol.sham && r && r < 41
                }))
            },
            8536: function(t, n, e) {
                var r = e(7854),
                    o = e(2788),
                    i = r.WeakMap;
                t.exports = "function" == typeof i && /native code/.test(o(i))
            },
            8523: function(t, n, e) {
                "use strict";
                var r = e(3099),
                    o = function(t) {
                        var n, e;
                        this.promise = new t((function(t, r) {
                            if (void 0 !== n || void 0 !== e) throw TypeError("Bad Promise constructor");
                            n = t, e = r
                        })), this.resolve = r(n), this.reject = r(e)
                    };
                t.exports.f = function(t) {
                    return new o(t)
                }
            },
            30: function(t, n, e) {
                var r, o = e(9670),
                    i = e(6048),
                    c = e(748),
                    u = e(3501),
                    f = e(490),
                    a = e(317),
                    s = e(2829),
                    p = s("IE_PROTO"),
                    l = function() {},
                    v = function(t) {
                        return "<script>" + t + "</" + "script>"
                    },
                    h = function(t) {
                        t.write(v("")), t.close();
                        var n = t.parentWindow.Object;
                        return t = null, n
                    },
                    y = function() {
                        try {
                            r = new ActiveXObject("htmlfile")
                        } catch (t) {}
                        var t, n;
                        y = "undefined" != typeof document ? document.domain && r ? h(r) : ((n = a("iframe")).style.display = "none", f.appendChild(n), n.src = String("javascript:"), (t = n.contentWindow.document).open(), t.write(v("document.F=Object")), t.close(), t.F) : h(r);
                        for (var e = c.length; e--;) delete y.prototype[c[e]];
                        return y()
                    };
                u[p] = !0, t.exports = Object.create || function(t, n) {
                    var e;
                    return null !== t ? (l.prototype = o(t), e = new l, l.prototype = null, e[p] = t) : e = y(), void 0 === n ? e : i(e, n)
                }
            },
            6048: function(t, n, e) {
                var r = e(9781),
                    o = e(3070),
                    i = e(9670),
                    c = e(1956);
                t.exports = r ? Object.defineProperties : function(t, n) {
                    i(t);
                    for (var e, r = c(n), u = r.length, f = 0; u > f;) o.f(t, e = r[f++], n[e]);
                    return t
                }
            },
            3070: function(t, n, e) {
                var r = e(9781),
                    o = e(4664),
                    i = e(9670),
                    c = e(4948),
                    u = Object.defineProperty;
                n.f = r ? u : function(t, n, e) {
                    if (i(t), n = c(n), i(e), o) try {
                        return u(t, n, e)
                    } catch (t) {}
                    if ("get" in e || "set" in e) throw TypeError("Accessors not supported");
                    return "value" in e && (t[n] = e.value), t
                }
            },
            1236: function(t, n, e) {
                var r = e(9781),
                    o = e(5296),
                    i = e(9114),
                    c = e(5656),
                    u = e(4948),
                    f = e(6656),
                    a = e(4664),
                    s = Object.getOwnPropertyDescriptor;
                n.f = r ? s : function(t, n) {
                    if (t = c(t), n = u(n), a) try {
                        return s(t, n)
                    } catch (t) {}
                    if (f(t, n)) return i(!o.f.call(t, n), t[n])
                }
            },
            8006: function(t, n, e) {
                var r = e(6324),
                    o = e(748).concat("length", "prototype");
                n.f = Object.getOwnPropertyNames || function(t) {
                    return r(t, o)
                }
            },
            5181: function(t, n) {
                n.f = Object.getOwnPropertySymbols
            },
            9518: function(t, n, e) {
                var r = e(6656),
                    o = e(7908),
                    i = e(2829),
                    c = e(8544),
                    u = i("IE_PROTO"),
                    f = Object.prototype;
                t.exports = c ? Object.getPrototypeOf : function(t) {
                    return t = o(t), r(t, u) ? t[u] : "function" == typeof t.constructor && t instanceof t.constructor ? t.constructor.prototype : t instanceof Object ? f : null
                }
            },
            6324: function(t, n, e) {
                var r = e(6656),
                    o = e(5656),
                    i = e(1318).indexOf,
                    c = e(3501);
                t.exports = function(t, n) {
                    var e, u = o(t),
                        f = 0,
                        a = [];
                    for (e in u) !r(c, e) && r(u, e) && a.push(e);
                    for (; n.length > f;) r(u, e = n[f++]) && (~i(a, e) || a.push(e));
                    return a
                }
            },
            1956: function(t, n, e) {
                var r = e(6324),
                    o = e(748);
                t.exports = Object.keys || function(t) {
                    return r(t, o)
                }
            },
            5296: function(t, n) {
                "use strict";
                var e = {}.propertyIsEnumerable,
                    r = Object.getOwnPropertyDescriptor,
                    o = r && !e.call({
                        1: 2
                    }, 1);
                n.f = o ? function(t) {
                    var n = r(this, t);
                    return !!n && n.enumerable
                } : e
            },
            7674: function(t, n, e) {
                var r = e(9670),
                    o = e(6077);
                t.exports = Object.setPrototypeOf || ("__proto__" in {} ? function() {
                    var t, n = !1,
                        e = {};
                    try {
                        (t = Object.getOwnPropertyDescriptor(Object.prototype, "__proto__").set).call(e, []), n = e instanceof Array
                    } catch (t) {}
                    return function(e, i) {
                        return r(e), o(i), n ? t.call(e, i) : e.__proto__ = i, e
                    }
                }() : void 0)
            },
            2140: function(t, n, e) {
                var r = e(111);
                t.exports = function(t, n) {
                    var e, o;
                    if ("string" === n && "function" == typeof(e = t.toString) && !r(o = e.call(t))) return o;
                    if ("function" == typeof(e = t.valueOf) && !r(o = e.call(t))) return o;
                    if ("string" !== n && "function" == typeof(e = t.toString) && !r(o = e.call(t))) return o;
                    throw TypeError("Can't convert object to primitive value")
                }
            },
            3887: function(t, n, e) {
                var r = e(5005),
                    o = e(8006),
                    i = e(5181),
                    c = e(9670);
                t.exports = r("Reflect", "ownKeys") || function(t) {
                    var n = o.f(c(t)),
                        e = i.f;
                    return e ? n.concat(e(t)) : n
                }
            },
            2534: function(t) {
                t.exports = function(t) {
                    try {
                        return {
                            error: !1,
                            value: t()
                        }
                    } catch (t) {
                        return {
                            error: !0,
                            value: t
                        }
                    }
                }
            },
            9478: function(t, n, e) {
                var r = e(9670),
                    o = e(111),
                    i = e(8523);
                t.exports = function(t, n) {
                    if (r(t), o(n) && n.constructor === t) return n;
                    var e = i.f(t);
                    return (0, e.resolve)(n), e.promise
                }
            },
            2248: function(t, n, e) {
                var r = e(1320);
                t.exports = function(t, n, e) {
                    for (var o in n) r(t, o, n[o], e);
                    return t
                }
            },
            1320: function(t, n, e) {
                var r = e(7854),
                    o = e(8880),
                    i = e(6656),
                    c = e(3505),
                    u = e(2788),
                    f = e(9909),
                    a = f.get,
                    s = f.enforce,
                    p = String(String).split("String");
                (t.exports = function(t, n, e, u) {
                    var f, a = !!u && !!u.unsafe,
                        l = !!u && !!u.enumerable,
                        v = !!u && !!u.noTargetGet;
                    "function" == typeof e && ("string" != typeof n || i(e, "name") || o(e, "name", n), (f = s(e)).source || (f.source = p.join("string" == typeof n ? n : ""))), t !== r ? (a ? !v && t[n] && (l = !0) : delete t[n], l ? t[n] = e : o(t, n, e)) : l ? t[n] = e : c(n, e)
                })(Function.prototype, "toString", (function() {
                    return "function" == typeof this && a(this).source || u(this)
                }))
            },
            4488: function(t) {
                t.exports = function(t) {
                    if (null == t) throw TypeError("Can't call method on " + t);
                    return t
                }
            },
            3505: function(t, n, e) {
                var r = e(7854);
                t.exports = function(t, n) {
                    try {
                        Object.defineProperty(r, t, {
                            value: n,
                            configurable: !0,
                            writable: !0
                        })
                    } catch (e) {
                        r[t] = n
                    }
                    return n
                }
            },
            6340: function(t, n, e) {
                "use strict";
                var r = e(5005),
                    o = e(3070),
                    i = e(5112),
                    c = e(9781),
                    u = i("species");
                t.exports = function(t) {
                    var n = r(t),
                        e = o.f;
                    c && n && !n[u] && e(n, u, {
                        configurable: !0,
                        get: function() {
                            return this
                        }
                    })
                }
            },
            8003: function(t, n, e) {
                var r = e(3070).f,
                    o = e(6656),
                    i = e(5112)("toStringTag");
                t.exports = function(t, n, e) {
                    t && !o(t = e ? t : t.prototype, i) && r(t, i, {
                        configurable: !0,
                        value: n
                    })
                }
            },
            6707: function(t, n, e) {
                var r = e(9670),
                    o = e(3099),
                    i = e(5112)("species");
                t.exports = function(t, n) {
                    var e, c = r(t).constructor;
                    return void 0 === c || null == (e = r(c)[i]) ? n : o(e)
                }
            },
            261: function(t, n, e) {
                var r, o, i, c, u = e(7854),
                    f = e(7293),
                    a = e(9974),
                    s = e(490),
                    p = e(317),
                    l = e(6833),
                    v = e(5268),
                    h = u.setImmediate,
                    y = u.clearImmediate,
                    d = u.process,
                    m = u.MessageChannel,
                    g = u.Dispatch,
                    b = 0,
                    x = {},
                    w = "onreadystatechange";
                try {
                    r = u.location
                } catch (t) {}
                var j = function(t) {
                        if (x.hasOwnProperty(t)) {
                            var n = x[t];
                            delete x[t], n()
                        }
                    },
                    O = function(t) {
                        return function() {
                            j(t)
                        }
                    },
                    S = function(t) {
                        j(t.data)
                    },
                    P = function(t) {
                        u.postMessage(String(t), r.protocol + "//" + r.host)
                    };
                h && y || (h = function(t) {
                    for (var n = [], e = arguments.length, r = 1; e > r;) n.push(arguments[r++]);
                    return x[++b] = function() {
                        ("function" == typeof t ? t : Function(t)).apply(void 0, n)
                    }, o(b), b
                }, y = function(t) {
                    delete x[t]
                }, v ? o = function(t) {
                    d.nextTick(O(t))
                } : g && g.now ? o = function(t) {
                    g.now(O(t))
                } : m && !l ? (c = (i = new m).port2, i.port1.onmessage = S, o = a(c.postMessage, c, 1)) : u.addEventListener && "function" == typeof postMessage && !u.importScripts && r && "file:" !== r.protocol && !f(P) ? (o = P, u.addEventListener("message", S, !1)) : o = w in p("script") ? function(t) {
                    s.appendChild(p("script")).onreadystatechange = function() {
                        s.removeChild(this), j(t)
                    }
                } : function(t) {
                    setTimeout(O(t), 0)
                }), t.exports = {
                    set: h,
                    clear: y
                }
            },
            1400: function(t, n, e) {
                var r = e(9958),
                    o = Math.max,
                    i = Math.min;
                t.exports = function(t, n) {
                    var e = r(t);
                    return e < 0 ? o(e + n, 0) : i(e, n)
                }
            },
            5656: function(t, n, e) {
                var r = e(8361),
                    o = e(4488);
                t.exports = function(t) {
                    return r(o(t))
                }
            },
            9958: function(t) {
                var n = Math.ceil,
                    e = Math.floor;
                t.exports = function(t) {
                    return isNaN(t = +t) ? 0 : (t > 0 ? e : n)(t)
                }
            },
            7466: function(t, n, e) {
                var r = e(9958),
                    o = Math.min;
                t.exports = function(t) {
                    return t > 0 ? o(r(t), 9007199254740991) : 0
                }
            },
            7908: function(t, n, e) {
                var r = e(4488);
                t.exports = function(t) {
                    return Object(r(t))
                }
            },
            7593: function(t, n, e) {
                var r = e(111),
                    o = e(2190),
                    i = e(2140),
                    c = e(5112)("toPrimitive");
                t.exports = function(t, n) {
                    if (!r(t) || o(t)) return t;
                    var e, u = t[c];
                    if (void 0 !== u) {
                        if (void 0 === n && (n = "default"), e = u.call(t, n), !r(e) || o(e)) return e;
                        throw TypeError("Can't convert object to primitive value")
                    }
                    return void 0 === n && (n = "number"), i(t, n)
                }
            },
            4948: function(t, n, e) {
                var r = e(7593),
                    o = e(2190);
                t.exports = function(t) {
                    var n = r(t, "string");
                    return o(n) ? n : String(n)
                }
            },
            1694: function(t, n, e) {
                var r = {};
                r[e(5112)("toStringTag")] = "z", t.exports = "[object z]" === String(r)
            },
            9711: function(t) {
                var n = 0,
                    e = Math.random();
                t.exports = function(t) {
                    return "Symbol(" + String(void 0 === t ? "" : t) + ")_" + (++n + e).toString(36)
                }
            },
            3307: function(t, n, e) {
                var r = e(133);
                t.exports = r && !Symbol.sham && "symbol" == typeof Symbol.iterator
            },
            5112: function(t, n, e) {
                var r = e(7854),
                    o = e(8e3),
                    i = e(6656),
                    c = e(9711),
                    u = e(133),
                    f = e(3307),
                    a = o("wks"),
                    s = r.Symbol,
                    p = f ? s : s && s.withoutSetter || c;
                t.exports = function(t) {
                    return i(a, t) && (u || "string" == typeof a[t]) || (u && i(s, t) ? a[t] = s[t] : a[t] = p("Symbol." + t)), a[t]
                }
            },
            6992: function(t, n, e) {
                "use strict";
                var r = e(5656),
                    o = e(1223),
                    i = e(7497),
                    c = e(9909),
                    u = e(654),
                    f = "Array Iterator",
                    a = c.set,
                    s = c.getterFor(f);
                t.exports = u(Array, "Array", (function(t, n) {
                    a(this, {
                        type: f,
                        target: r(t),
                        index: 0,
                        kind: n
                    })
                }), (function() {
                    var t = s(this),
                        n = t.target,
                        e = t.kind,
                        r = t.index++;
                    return !n || r >= n.length ? (t.target = void 0, {
                        value: void 0,
                        done: !0
                    }) : "keys" == e ? {
                        value: r,
                        done: !1
                    } : "values" == e ? {
                        value: n[r],
                        done: !1
                    } : {
                        value: [r, n[r]],
                        done: !1
                    }
                }), "values"), i.Arguments = i.Array, o("keys"), o("values"), o("entries")
            },
            8674: function(t, n, e) {
                "use strict";
                var r, o, i, c, u = e(2109),
                    f = e(1913),
                    a = e(7854),
                    s = e(5005),
                    p = e(3366),
                    l = e(1320),
                    v = e(2248),
                    h = e(7674),
                    y = e(8003),
                    d = e(6340),
                    m = e(111),
                    g = e(3099),
                    b = e(5787),
                    x = e(2788),
                    w = e(408),
                    j = e(7072),
                    O = e(6707),
                    S = e(261).set,
                    P = e(5948),
                    T = e(9478),
                    E = e(842),
                    _ = e(8523),
                    k = e(2534),
                    A = e(9909),
                    I = e(4705),
                    M = e(5112),
                    R = e(7871),
                    C = e(5268),
                    F = e(7392),
                    N = M("species"),
                    D = "Promise",
                    L = A.get,
                    z = A.set,
                    G = A.getterFor(D),
                    U = p && p.prototype,
                    W = p,
                    B = U,
                    V = a.TypeError,
                    Y = a.document,
                    q = a.process,
                    K = _.f,
                    H = K,
                    X = !!(Y && Y.createEvent && a.dispatchEvent),
                    J = "function" == typeof PromiseRejectionEvent,
                    Q = "unhandledrejection",
                    Z = !1,
                    $ = I(D, (function() {
                        var t = x(W),
                            n = t !== String(W);
                        if (!n && 66 === F) return !0;
                        if (f && !B.finally) return !0;
                        if (F >= 51 && /native code/.test(t)) return !1;
                        var e = new W((function(t) {
                                t(1)
                            })),
                            r = function(t) {
                                t((function() {}), (function() {}))
                            };
                        return (e.constructor = {})[N] = r, !(Z = e.then((function() {})) instanceof r) || !n && R && !J
                    })),
                    tt = $ || !j((function(t) {
                        W.all(t).catch((function() {}))
                    })),
                    nt = function(t) {
                        var n;
                        return !(!m(t) || "function" != typeof(n = t.then)) && n
                    },
                    et = function(t, n) {
                        if (!t.notified) {
                            t.notified = !0;
                            var e = t.reactions;
                            P((function() {
                                for (var r = t.value, o = 1 == t.state, i = 0; e.length > i;) {
                                    var c, u, f, a = e[i++],
                                        s = o ? a.ok : a.fail,
                                        p = a.resolve,
                                        l = a.reject,
                                        v = a.domain;
                                    try {
                                        s ? (o || (2 === t.rejection && ct(t), t.rejection = 1), !0 === s ? c = r : (v && v.enter(), c = s(r), v && (v.exit(), f = !0)), c === a.promise ? l(V("Promise-chain cycle")) : (u = nt(c)) ? u.call(c, p, l) : p(c)) : l(r)
                                    } catch (t) {
                                        v && !f && v.exit(), l(t)
                                    }
                                }
                                t.reactions = [], t.notified = !1, n && !t.rejection && ot(t)
                            }))
                        }
                    },
                    rt = function(t, n, e) {
                        var r, o;
                        X ? ((r = Y.createEvent("Event")).promise = n, r.reason = e, r.initEvent(t, !1, !0), a.dispatchEvent(r)) : r = {
                            promise: n,
                            reason: e
                        }, !J && (o = a["on" + t]) ? o(r) : t === Q && E("Unhandled promise rejection", e)
                    },
                    ot = function(t) {
                        S.call(a, (function() {
                            var n, e = t.facade,
                                r = t.value;
                            if (it(t) && (n = k((function() {
                                    C ? q.emit("unhandledRejection", r, e) : rt(Q, e, r)
                                })), t.rejection = C || it(t) ? 2 : 1, n.error)) throw n.value
                        }))
                    },
                    it = function(t) {
                        return 1 !== t.rejection && !t.parent
                    },
                    ct = function(t) {
                        S.call(a, (function() {
                            var n = t.facade;
                            C ? q.emit("rejectionHandled", n) : rt("rejectionhandled", n, t.value)
                        }))
                    },
                    ut = function(t, n, e) {
                        return function(r) {
                            t(n, r, e)
                        }
                    },
                    ft = function(t, n, e) {
                        t.done || (t.done = !0, e && (t = e), t.value = n, t.state = 2, et(t, !0))
                    },
                    at = function(t, n, e) {
                        if (!t.done) {
                            t.done = !0, e && (t = e);
                            try {
                                if (t.facade === n) throw V("Promise can't be resolved itself");
                                var r = nt(n);
                                r ? P((function() {
                                    var e = {
                                        done: !1
                                    };
                                    try {
                                        r.call(n, ut(at, e, t), ut(ft, e, t))
                                    } catch (n) {
                                        ft(e, n, t)
                                    }
                                })) : (t.value = n, t.state = 1, et(t, !1))
                            } catch (n) {
                                ft({
                                    done: !1
                                }, n, t)
                            }
                        }
                    };
                if ($ && (B = (W = function(t) {
                        b(this, W, D), g(t), r.call(this);
                        var n = L(this);
                        try {
                            t(ut(at, n), ut(ft, n))
                        } catch (t) {
                            ft(n, t)
                        }
                    }).prototype, (r = function(t) {
                        z(this, {
                            type: D,
                            done: !1,
                            notified: !1,
                            parent: !1,
                            reactions: [],
                            rejection: !1,
                            state: 0,
                            value: void 0
                        })
                    }).prototype = v(B, {
                        then: function(t, n) {
                            var e = G(this),
                                r = K(O(this, W));
                            return r.ok = "function" != typeof t || t, r.fail = "function" == typeof n && n, r.domain = C ? q.domain : void 0, e.parent = !0, e.reactions.push(r), 0 != e.state && et(e, !1), r.promise
                        },
                        catch: function(t) {
                            return this.then(void 0, t)
                        }
                    }), o = function() {
                        var t = new r,
                            n = L(t);
                        this.promise = t, this.resolve = ut(at, n), this.reject = ut(ft, n)
                    }, _.f = K = function(t) {
                        return t === W || t === i ? new o(t) : H(t)
                    }, !f && "function" == typeof p && U !== Object.prototype)) {
                    c = U.then, Z || (l(U, "then", (function(t, n) {
                        var e = this;
                        return new W((function(t, n) {
                            c.call(e, t, n)
                        })).then(t, n)
                    }), {
                        unsafe: !0
                    }), l(U, "catch", B.catch, {
                        unsafe: !0
                    }));
                    try {
                        delete U.constructor
                    } catch (t) {}
                    h && h(U, B)
                }
                u({
                    global: !0,
                    wrap: !0,
                    forced: $
                }, {
                    Promise: W
                }), y(W, D, !1, !0), d(D), i = s(D), u({
                    target: D,
                    stat: !0,
                    forced: $
                }, {
                    reject: function(t) {
                        var n = K(this);
                        return n.reject.call(void 0, t), n.promise
                    }
                }), u({
                    target: D,
                    stat: !0,
                    forced: f || $
                }, {
                    resolve: function(t) {
                        return T(f && this === i ? W : this, t)
                    }
                }), u({
                    target: D,
                    stat: !0,
                    forced: tt
                }, {
                    all: function(t) {
                        var n = this,
                            e = K(n),
                            r = e.resolve,
                            o = e.reject,
                            i = k((function() {
                                var e = g(n.resolve),
                                    i = [],
                                    c = 0,
                                    u = 1;
                                w(t, (function(t) {
                                    var f = c++,
                                        a = !1;
                                    i.push(void 0), u++, e.call(n, t).then((function(t) {
                                        a || (a = !0, i[f] = t, --u || r(i))
                                    }), o)
                                })), --u || r(i)
                            }));
                        return i.error && o(i.value), e.promise
                    },
                    race: function(t) {
                        var n = this,
                            e = K(n),
                            r = e.reject,
                            o = k((function() {
                                var o = g(n.resolve);
                                w(t, (function(t) {
                                    o.call(n, t).then(e.resolve, r)
                                }))
                            }));
                        return o.error && r(o.value), e.promise
                    }
                })
            }
        },
        n = {};

    function e(r) {
        if (n[r]) return n[r].exports;
        var o = n[r] = {
            exports: {}
        };
        return t[r].call(o.exports, o, o.exports, e), o.exports
    }
    e.m = t, e.n = function(t) {
            var n = t && t.__esModule ? function() {
                return t.default
            } : function() {
                return t
            };
            return e.d(n, {
                a: n
            }), n
        }, e.d = function(t, n) {
            for (var r in n) e.o(n, r) && !e.o(t, r) && Object.defineProperty(t, r, {
                enumerable: !0,
                get: n[r]
            })
        }, e.f = {}, e.e = function(t) {
            return Promise.all(Object.keys(e.f).reduce((function(n, r) {
                return e.f[r](t, n), n
            }), []))
        }, e.u = function(t) {
            return t + "." + e.h() + ".worker.js"
        }, e.h = function() {
            return "2f2a4e4266f7f381286f"
        }, e.g = function() {
            if ("object" == typeof globalThis) return globalThis;
            try {
                return this || new Function("return this")()
            } catch (t) {
                if ("object" == typeof window) return window
            }
        }(), e.o = function(t, n) {
            return Object.prototype.hasOwnProperty.call(t, n)
        }, e.r = function(t) {
            "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
                value: "Module"
            }), Object.defineProperty(t, "__esModule", {
                value: !0
            })
        }, e.p = "https://deo.shopeemobile.com/shopee/shopee-pcmall-live-sg//assets/",
        function() {
            var t = {
                179: 1
            };
            e.f.i = function(n, r) {
                t[n] || importScripts("" + e.u(n))
            };
            var n = ("undefined" != typeof self ? self : this).webpackChunkshopee_pc = ("undefined" != typeof self ? self : this).webpackChunkshopee_pc || [],
                r = n.push.bind(n);
            n.push = function(n) {
                var o = n[0],
                    i = n[1],
                    c = n[2];
                for (var u in i) e.o(i, u) && (e.m[u] = i[u]);
                for (c && c(e); o.length;) t[o.pop()] = 1;
                r(n)
            }
        }(), e(8865)
}();
//# sourceMappingURL=https://shopee.sg/assets/2f2a4e4266f7f381286f.worker.js.map